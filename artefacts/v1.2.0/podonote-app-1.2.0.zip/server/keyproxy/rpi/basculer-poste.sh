#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — brancher un poste sur le keyproxy (au lieu de sa clé Anthropic).
#
#      bash server/keyproxy/rpi/basculer-poste.sh --url https://api.studio-margerit.fr
#      bash server/keyproxy/rpi/basculer-poste.sh --url … --env /chemin/vers/.env
#      bash server/keyproxy/rpi/basculer-poste.sh --url … --purger-cle
#
#  Effet : LLM_BACKEND=sonnet et LLM_PROXY_URL=… dans le .env du poste. À partir
#  de là, c'est la CLÉ DE LICENCE du poste qui sert de clé d'accès ; la vraie clé
#  Anthropic ne vit plus que sur le serveur.
#
#  --purger-cle vide en plus ANTHROPIC_API_KEY du .env (le coffre système, lui,
#  se vide depuis l'app — voir le rappel en fin d'exécution).
# ============================================================================ #
set -euo pipefail

ICI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENVF="$(cd "$ICI/../../.." && pwd)/.env"          # racine du dépôt podonote
URL=""
PURGER=0

while [ $# -gt 0 ]; do
  case "$1" in
    --url) URL="${2%/}"; shift 2 ;;
    --env) ENVF="$2"; shift 2 ;;
    --purger-cle) PURGER=1; shift ;;
    -h|--help) sed -n '2,17p' "$0"; exit 0 ;;
    *) printf 'Option inconnue : %s\n' "$1" >&2; exit 2 ;;
  esac
done

say()  { printf '\033[1;33m▶ %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

[ -n "$URL" ] || fail "Indiquez l'URL du proxy :  --url https://api.studio-margerit.fr"
[ -f "$ENVF" ] || fail "Fichier .env introuvable : $ENVF (précisez-le avec --env)"

# Le proxy répond-il, avant de rediriger un poste vers lui ?
say "Contrôle du proxy…"
if curl -fsS --max-time 15 "$URL/healthz" >/dev/null 2>&1; then
  ok "$URL répond"
else
  fail "$URL ne répond pas — ne branchez pas un poste sur un proxy injoignable.
   Vérifiez d'abord :  bash $ICI/verifier.sh --url $URL"
fi

# Réglage idempotent : on remplace la ligne si elle existe, sinon on l'ajoute.
regler() {                                   # $1 = clé, $2 = valeur
  local cle="$1" valeur="$2"
  if grep -Eq "^[[:space:]]*#?[[:space:]]*${cle}=" "$ENVF"; then
    # Le .env peut contenir des caractères spéciaux : on passe par awk, pas sed.
    awk -v c="$cle" -v v="$valeur" '
      $0 ~ "^[[:space:]]*#?[[:space:]]*" c "=" && !fait { print c "=" v; fait=1; next }
      { print }
    ' "$ENVF" > "$ENVF.tmp" && mv "$ENVF.tmp" "$ENVF"
  else
    printf '%s=%s\n' "$cle" "$valeur" >> "$ENVF"
  fi
}

cp "$ENVF" "$ENVF.avant-bascule"
say "Modification de $ENVF (copie de sûreté : $ENVF.avant-bascule)…"
regler LLM_BACKEND sonnet
regler LLM_PROXY_URL "$URL"
ok "LLM_BACKEND=sonnet · LLM_PROXY_URL=$URL"

if [ "$PURGER" -eq 1 ]; then
  regler ANTHROPIC_API_KEY ""
  ok "ANTHROPIC_API_KEY vidée du .env"
elif grep -Eq '^ANTHROPIC_API_KEY=..+' "$ENVF"; then
  printf '\033[1;33m   ⚠️ Une clé Anthropic reste dans ce .env. Elle ne sert plus (le proxy\n'
  printf '      prend le relais) : relancez avec --purger-cle pour la retirer.\033[0m\n'
fi

cat <<FIN

$(printf '\033[1;32m═══ Poste basculé ═══\033[0m')

Deux points à vérifier avant de crier victoire :
  1. Une LICENCE doit être activée sur ce poste — c'est elle qui sert désormais
     de clé d'accès. Sans licence, l'analyse refusera de partir.
  2. Redémarrer Diktae, puis « État du système » :
     la ligne LLM doit afficher « Sonnet OK via proxy ».

Si le poste avait sa clé Anthropic dans le coffre du système (DPAPI sous
Windows, Trousseau sous macOS), ce script ne l'y touche pas : elle devient
simplement inutile, le proxy étant prioritaire dès que LLM_PROXY_URL est posée.

FIN
