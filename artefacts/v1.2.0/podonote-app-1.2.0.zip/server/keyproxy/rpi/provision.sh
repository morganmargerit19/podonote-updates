#!/usr/bin/env bash
# ============================================================================ #
# Provisionnement AUTONOME du keyproxy Diktae sur Raspberry Pi (une commande).
#
#   sudo bash /boot/firmware/keyproxy/rpi/provision.sh
#
# Prérequis (cf. README-RPI.md) : le dossier `server/keyproxy/` du repo copié
# sur la partition boot de la carte SD (visible depuis Windows après flash),
# avec un fichier `.env` rempli à sa racine (ANTHROPIC_API_KEY,
# PROXY_ADMIN_TOKEN, TUNNEL_TOKEN).
#
# Idempotent : relançable sans casse (réinstalle/redémarre proprement).
# ============================================================================ #
set -euo pipefail

DEST=/opt/diktae-keyproxy
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # …/keyproxy

say()  { echo -e "\033[1;33m▶ $*\033[0m"; }
fail() { echo -e "\033[1;31m✖ $*\033[0m" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Lancez avec sudo : sudo bash $0"
[ -f "$SRC/app.py" ] || fail "app.py introuvable à côté de rpi/ — copiez le dossier keyproxy COMPLET."
[ -f "$SRC/.env" ] || fail "Fichier .env manquant dans $SRC — copiez .env.example en .env et remplissez ANTHROPIC_API_KEY, PROXY_ADMIN_TOKEN et TUNNEL_TOKEN."

# Les 3 secrets doivent être présents et non vides.
for var in ANTHROPIC_API_KEY PROXY_ADMIN_TOKEN TUNNEL_TOKEN; do
  grep -Eq "^${var}=..+" "$SRC/.env" || fail "$var absent ou vide dans $SRC/.env"
done

say "Mise à jour du système (peut prendre quelques minutes)…"
apt-get update -qq
apt-get install -y -qq curl ca-certificates >/dev/null

if ! command -v docker >/dev/null 2>&1; then
  say "Installation de Docker…"
  curl -fsSL https://get.docker.com | sh >/dev/null
else
  say "Docker déjà installé."
fi

say "Copie du keyproxy vers ${DEST}…"
mkdir -p "$DEST"
cp -r "$SRC/app.py" "$SRC/requirements.txt" "$SRC/Dockerfile" "$SRC/rpi" "$DEST/"
# .env : copie en 600 (racine seulement), puis retiré de la partition boot si
# c'est de là qu'on provisionne — un secret n'a rien à faire sur une FAT lisible.
install -m 600 "$SRC/.env" "$DEST/.env"
case "$SRC" in /boot/*) say "Secrets déplacés hors de la partition boot."; rm -f "$SRC/.env" ;; esac

say "Construction et démarrage (keyproxy + tunnel Cloudflare)…"
cd "$DEST"
docker compose -f rpi/docker-compose.yml --project-directory . up -d --build

say "Vérification locale…"
for _ in $(seq 1 20); do
  sleep 2
  if curl -fsS http://127.0.0.1:8787/healthz >/dev/null 2>&1; then break; fi
done
curl -fsS http://127.0.0.1:8787/healthz || fail "Le proxy ne répond pas — voir : docker compose -f $DEST/rpi/docker-compose.yml logs"
echo

say "✅ Keyproxy en service sur ce Pi (redémarre tout seul avec la machine)."
cat <<'EOF'

Dernière étape (une fois, dans le tableau de bord Cloudflare) :
  Zero Trust → Networks → Tunnels → votre tunnel → Public hostname
  → api.studio-margerit.fr  →  Service : HTTP  →  URL : keyproxy:8787

Puis testez depuis n'importe où :
  curl https://api.studio-margerit.fr/healthz
  → {"ok": true, ..., "key_configured": true}

Côté postes Diktae (.env) :
  LLM_BACKEND=sonnet
  LLM_PROXY_URL=https://api.studio-margerit.fr

Suivi de conso :
  curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
       "https://api.studio-margerit.fr/admin/usage?month=2026-08"
EOF
