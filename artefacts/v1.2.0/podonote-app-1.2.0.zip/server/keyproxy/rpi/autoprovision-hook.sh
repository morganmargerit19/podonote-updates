#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — accroche d'auto-provisionnement, exécutée par firstrun.sh au tout
#  premier démarrage du Pi (déposée par rpi/preparer-carte-sd.sh).
#
#  Elle ne provisionne PAS elle-même : firstrun tourne très tôt, souvent avant
#  que le réseau soit utilisable, et provision.sh a besoin d'Internet (apt,
#  Docker, images). Elle installe donc un service systemd qui, lui, attendra le
#  réseau, réessaiera en cas d'échec, et se désactivera une fois le travail fait.
#
#  Journal sur le Pi :  /var/log/diktae-provision.log
# ============================================================================ #
set -euo pipefail

# Bookworm monte la partition de démarrage sur /boot/firmware ; Bullseye sur /boot.
for candidat in /boot/firmware /boot; do
  if [ -f "$candidat/keyproxy/rpi/provision.sh" ]; then
    BOOT="$candidat"
    break
  fi
done
[ -n "${BOOT:-}" ] || { echo "keyproxy introuvable sur la partition de démarrage." >&2; exit 1; }

RUNNER=/usr/local/sbin/diktae-provision-runner.sh

cat > "$RUNNER" <<RUNNERSH
#!/usr/bin/env bash
# Enveloppe de provisionnement : réessaie, car un premier démarrage peut trouver
# le DNS ou les dépôts APT encore indisponibles pendant une poignée de secondes.
set -uo pipefail
BOOT="$BOOT"

for tentative in 1 2 3; do
  echo "=== Tentative \$tentative — \$(date -Is) ==="
  if bash "\$BOOT/keyproxy/rpi/provision.sh"; then
    echo "=== Provisionnement réussi — \$(date -Is) ==="
    systemctl disable diktae-keyproxy-provision.service || true
    exit 0
  fi
  echo "--- Échec de la tentative \$tentative, nouvelle tentative dans 60 s ---"
  sleep 60
done

echo "=== ÉCHEC après 3 tentatives — \$(date -Is) ==="
echo "Diagnostic :  sudo bash \$BOOT/keyproxy/rpi/provision.sh"
exit 1
RUNNERSH
chmod 700 "$RUNNER"

cat > /etc/systemd/system/diktae-keyproxy-provision.service <<'UNIT'
[Unit]
Description=Provisionnement du keyproxy Diktae (premier démarrage)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
TimeoutStartSec=3600
ExecStart=/usr/local/sbin/diktae-provision-runner.sh
StandardOutput=append:/var/log/diktae-provision.log
StandardError=append:/var/log/diktae-provision.log

[Install]
WantedBy=multi-user.target
UNIT

systemctl enable diktae-keyproxy-provision.service
echo "Auto-provisionnement armé (service diktae-keyproxy-provision)."
