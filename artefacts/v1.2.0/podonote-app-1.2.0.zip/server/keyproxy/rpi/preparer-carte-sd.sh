#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — préparation de la carte SD du keyproxy, depuis le Mac (ou Linux).
#
#  À lancer APRÈS avoir flashé la carte avec Raspberry Pi Imager, carte toujours
#  branchée :
#
#      bash server/keyproxy/rpi/preparer-carte-sd.sh
#
#  Le script :
#    1. trouve la partition de démarrage de la carte (bootfs) ;
#    2. demande les secrets (saisie masquée) et écrit le .env ;
#    3. copie le keyproxy sur la carte ;
#    4. installe l'AUTO-PROVISIONNEMENT : au premier démarrage, le Pi installe
#       Docker, construit l'image, lance le proxy et le tunnel — TOUT SEUL.
#       Aucune connexion SSH n'est nécessaire.
#
#  Ensuite : éjecter, mettre la carte dans le Pi, brancher Ethernet + alim,
#  attendre ~10 min, puis `bash rpi/verifier.sh`.
# ============================================================================ #
set -euo pipefail

ICI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"     # …/keyproxy/rpi
SRC="$(cd "$ICI/.." && pwd)"                            # …/keyproxy

say()  { printf '\033[1;33m▶ %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

SD=""
while [ $# -gt 0 ]; do
  case "$1" in
    --sd) SD="$2"; shift 2 ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    *) fail "Option inconnue : $1" ;;
  esac
done

# --------------------------------------------------------------------------- #
# 1. Trouver la partition de démarrage
# --------------------------------------------------------------------------- #
if [ -z "$SD" ]; then
  for candidat in /Volumes/bootfs /Volumes/boot /media/*/bootfs /media/*/boot; do
    [ -d "$candidat" ] || continue
    SD="$candidat"
    break
  done
fi
[ -n "$SD" ] || fail "Carte SD introuvable. Flashez-la d'abord avec Raspberry Pi Imager
   et laissez-la branchée, ou indiquez le chemin :  --sd /Volumes/bootfs"
[ -d "$SD" ] || fail "$SD n'existe pas."
# Une partition de démarrage Raspberry Pi contient toujours ces deux fichiers.
[ -f "$SD/config.txt" ] || fail "$SD ne ressemble pas à une carte Raspberry Pi (config.txt absent).
   Flashez la carte AVANT de lancer ce script."
ok "Carte trouvée : $SD"

# --------------------------------------------------------------------------- #
# 2. Les secrets (jamais affichés, jamais dans l'historique du shell)
# --------------------------------------------------------------------------- #
demander_secret() {                       # $1 = libellé, $2 = nom de variable
  local valeur=""
  printf '   %s : ' "$1" >&2
  read -rs valeur
  printf '\n' >&2
  printf '%s' "$valeur"
}

say "Secrets (la saisie ne s'affiche pas)"

CLE_ANTHROPIC="$(demander_secret 'Clé Anthropic (sk-ant-…)')"
[ -n "$CLE_ANTHROPIC" ] || fail "La clé Anthropic est obligatoire : c'est elle que le proxy protège."
case "$CLE_ANTHROPIC" in
  sk-ant-*) : ;;
  *) fail "Cette clé ne commence pas par « sk-ant- » — vérifiez le copier-coller." ;;
esac

TUNNEL_TOKEN="$(demander_secret 'Token du tunnel Cloudflare (eyJ…)')"
[ -n "$TUNNEL_TOKEN" ] || fail "Le token du tunnel est obligatoire : sans lui, pas d'accès HTTPS public.
   Cf. rpi/README-RPI.md § « Le tunnel Cloudflare »."
case "$TUNNEL_TOKEN" in
  eyJ*) : ;;
  *) printf '\033[1;33m   (⚠️ ce token ne commence pas par « eyJ » — inhabituel, je continue quand même)\033[0m\n' ;;
esac

# Le jeton admin n'a pas à être mémorisé par un humain : on le tire au sort.
if command -v openssl >/dev/null 2>&1; then
  JETON_ADMIN="$(openssl rand -hex 24)"
else
  JETON_ADMIN="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
fi
ok "Jeton admin engendré (il sera rappelé à la fin — notez-le)"

# --------------------------------------------------------------------------- #
# 3. Copier le keyproxy sur la carte
# --------------------------------------------------------------------------- #
DEST="$SD/keyproxy"
say "Copie du keyproxy vers ${DEST}…"
rm -rf "$DEST"
mkdir -p "$DEST"
for f in app.py requirements.txt Dockerfile README.md .env.example; do
  [ -f "$SRC/$f" ] || fail "$f manquant dans $SRC — dépôt incomplet ?"
  cp "$SRC/$f" "$DEST/"
done
mkdir -p "$DEST/rpi"
cp "$ICI/docker-compose.yml" "$ICI/provision.sh" "$ICI/autoprovision-hook.sh" \
   "$ICI/README-RPI.md" "$DEST/rpi/"

# Le .env : sur une FAT, les permissions n'existent pas — c'est pourquoi
# provision.sh l'efface de la carte dès qu'il l'a recopié en 600 sur le Pi.
umask 077
cat > "$DEST/.env" <<ENVFILE
# Écrit par rpi/preparer-carte-sd.sh — ce fichier sera DÉPLACÉ hors de la carte
# par le provisionnement (un secret n'a rien à faire sur une partition FAT).
ANTHROPIC_API_KEY=$CLE_ANTHROPIC
PROXY_ADMIN_TOKEN=$JETON_ADMIN
TUNNEL_TOKEN=$TUNNEL_TOKEN
ENVFILE
umask 022
ok "Keyproxy et secrets déposés sur la carte"

# --------------------------------------------------------------------------- #
# 4. Auto-provisionnement au premier démarrage (plus de SSH à faire)
# --------------------------------------------------------------------------- #
# Raspberry Pi OS exécute /boot/firmware/firstrun.sh au tout premier démarrage,
# via `systemd.run=` ajouté à cmdline.txt. Imager s'en sert déjà pour créer
# l'utilisateur et le Wi-Fi : on s'y greffe au lieu de l'écraser.
HOOK='bash /boot/firmware/keyproxy/rpi/autoprovision-hook.sh || bash /boot/keyproxy/rpi/autoprovision-hook.sh || true'
FIRSTRUN="$SD/firstrun.sh"

if [ -f "$FIRSTRUN" ]; then
  if grep -q "autoprovision-hook" "$FIRSTRUN"; then
    ok "Auto-provisionnement déjà greffé sur firstrun.sh"
  else
    # Insérer AVANT le ménage de fin d'Imager (rm firstrun / exit 0), sinon
    # notre ligne ne serait jamais atteinte.
    tmp="$(mktemp)"
    if grep -q '^rm -f /boot/firstrun.sh' "$FIRSTRUN"; then
      awk -v hook="$HOOK" '/^rm -f \/boot\/firstrun.sh/ && !done {print hook; done=1} {print}' \
        "$FIRSTRUN" > "$tmp"
    elif grep -q '^exit 0' "$FIRSTRUN"; then
      awk -v hook="$HOOK" '/^exit 0/ && !done {print hook; done=1} {print}' "$FIRSTRUN" > "$tmp"
    else
      cat "$FIRSTRUN" > "$tmp"; printf '%s\n' "$HOOK" >> "$tmp"
    fi
    cat "$tmp" > "$FIRSTRUN"; rm -f "$tmp"
    ok "Auto-provisionnement greffé sur le firstrun.sh d'Imager"
  fi
else
  # Pas de personnalisation Imager : on crée le firstrun et on l'accroche.
  cat > "$FIRSTRUN" <<'FIRST'
#!/bin/bash
# Créé par Diktae (rpi/preparer-carte-sd.sh) : lance l'auto-provisionnement.
bash /boot/firmware/keyproxy/rpi/autoprovision-hook.sh || bash /boot/keyproxy/rpi/autoprovision-hook.sh || true
rm -f /boot/firmware/firstrun.sh /boot/firstrun.sh
exit 0
FIRST
  CMDLINE="$SD/cmdline.txt"
  [ -f "$CMDLINE" ] || fail "cmdline.txt introuvable sur $SD — carte inattendue."
  if ! grep -q "systemd.run=" "$CMDLINE"; then
    # cmdline.txt DOIT rester sur une seule ligne, sinon le Pi ne démarre pas.
    printf '%s systemd.run=/boot/firmware/firstrun.sh systemd.run_success_action=reboot systemd.unit=kernel-command-line.target\n' \
      "$(tr -d '\n' < "$CMDLINE")" > "$CMDLINE"
  fi
  ok "firstrun.sh créé et accroché à cmdline.txt"
  printf '\033[1;33m   ⚠️ Aucune personnalisation Imager détectée : pensez au Wi-Fi/SSH si\n'
  printf '      vous n%s branchez pas le Pi en Ethernet.\033[0m\n' "'"
fi

# --------------------------------------------------------------------------- #
# 5. Récapitulatif
# --------------------------------------------------------------------------- #
cat <<RECAP

$(printf '\033[1;32m═══ Carte prête ═══\033[0m')

NOTEZ CE JETON ADMIN (il ne sera plus affiché) :

    $JETON_ADMIN

Il sert à lire la consommation :
    curl -H "Authorization: Bearer $JETON_ADMIN" \\
         "https://api.studio-margerit.fr/admin/usage?month=\$(date +%Y-%m)"

Suite des opérations :
  1. Éjecter la carte proprement, la mettre dans le Pi.
  2. Brancher Ethernet PUIS l'alimentation.
  3. Attendre ~10 min (Docker s'installe, l'image se construit).
  4. Sur ce Mac :  bash server/keyproxy/rpi/verifier.sh

Si le tunnel n'est pas encore configuré côté Cloudflare :
  Zero Trust → Networks → Tunnels → votre tunnel → Public hostname
  → api.studio-margerit.fr · Service HTTP · URL keyproxy:8787

RECAP
