# Keyproxy sur Raspberry Pi 4 — flash & go (~20 min, zéro commande sur le Pi)

Coût de fonctionnement : **~0 €** (2-3 €/an d'électricité). Le Pi relaie du
JSON, rien d'autre — il tiendra des dizaines de praticiens. Migration VPS
documentée en bas de page pour plus tard.

## Le jour J en 4 gestes

Une seule chose est à préparer à l'avance : le **tunnel Cloudflare** (section
plus bas). Le reste s'enchaîne carte en main.

| # | Où | Durée |
|---|---|---|
| 1 | Flasher la carte avec **Raspberry Pi Imager** | 5 min |
| 2 | `bash server/keyproxy/rpi/preparer-carte-sd.sh` sur le Mac | 1 min |
| 3 | Carte dans le Pi, **Ethernet puis alim** — il se provisionne SEUL | ~10 min sans vous |
| 4 | `bash server/keyproxy/rpi/verifier.sh` sur le Mac | 30 s |

### 1. Flasher (Raspberry Pi Imager)

Modèle **Raspberry Pi 4** · OS **Raspberry Pi OS Lite (64-bit)** · votre carte.
Dans ⚙️ « Modifier réglages » : nom d'hôte `diktae-proxy`, **SSH activé** (utile
en cas de pépin), utilisateur + mot de passe, Wi-Fi si pas d'Ethernet —
**l'Ethernet reste recommandé** pour un serveur. Écrire, puis **laisser la carte
branchée**.

### 2. Préparer la carte, depuis le Mac

```bash
bash server/keyproxy/rpi/preparer-carte-sd.sh
```

Il trouve la carte tout seul, demande les deux secrets (saisie masquée : clé
Anthropic et token du tunnel), **engendre le jeton admin**, copie le keyproxy et
installe l'auto-provisionnement. **Notez le jeton admin affiché à la fin** : il
ne sera plus jamais montré.

### 3. Brancher le Pi

Carte dans le Pi, **Ethernet d'abord, alimentation ensuite**. Au premier
démarrage il installe Docker, construit l'image arm64, lance le proxy et le
tunnel, puis déplace les secrets hors de la carte. **Aucun SSH, aucune commande.**
Comptez ~10 min. Si le réseau n'est pas prêt, il réessaie trois fois.

Journal sur le Pi, en cas de doute : `sudo cat /var/log/diktae-provision.log`.

### 4. Vérifier, depuis le Mac

```bash
bash server/keyproxy/rpi/verifier.sh
bash server/keyproxy/rpi/verifier.sh --licence "AgIA…" --admin "<jeton>"
```

Sans option : le proxy répond-il, et détient-il bien la clé. Avec `--licence` :
**aller-retour réel** jusqu'à Anthropic. Avec `--admin` : la consommation du mois.

## Le tunnel Cloudflare (une fois, avant le jour J)

HTTPS public **sans ouvrir un seul port** sur la box, et sans IP fixe.

1. `studio-margerit.fr` doit être géré par Cloudflare (offre Free — on ne change
   que les serveurs DNS chez le registrar ; le site Vercel n'est pas impacté, ses
   enregistrements sont repris tels quels).
2. [one.dash.cloudflare.com](https://one.dash.cloudflare.com) → **Zero Trust →
   Networks → Tunnels → Create a tunnel** → type *Cloudflared* → nom `diktae-api`
   → **copier le TOKEN** (longue chaîne `eyJ…`).
3. Onglet **Public hostname** du tunnel : `api.studio-margerit.fr` → Service
   **HTTP** → URL **`keyproxy:8787`**.

Prévoyez aussi la **vraie clé Anthropic** (console.anthropic.com) : elle ne
vivra que sur le Pi.

## Si l'auto-provisionnement échoue (repli manuel)

Rien n'est perdu, tout est déjà sur la carte :

```bash
ssh morgan@diktae-proxy.local
sudo cat /var/log/diktae-provision.log                # ce qui s'est passé
sudo bash /boot/firmware/keyproxy/rpi/provision.sh    # relancer à la main
```

`provision.sh` est idempotent : le relancer ne casse rien.

## Brancher les postes Diktae

```bash
curl https://api.studio-margerit.fr/healthz
# {"ok": true, "upstream": "https://api.anthropic.com", "key_configured": true}
```

Un script s'en charge, en refusant de basculer un poste vers un proxy injoignable :

```bash
bash server/keyproxy/rpi/basculer-poste.sh --url https://api.studio-margerit.fr
bash server/keyproxy/rpi/basculer-poste.sh --url … --purger-cle   # retire aussi la clé locale
```

À la main, c'est deux lignes dans le `.env` du poste :

```
LLM_BACKEND=sonnet
LLM_PROXY_URL=https://api.studio-margerit.fr
```

⚠️ Une **licence doit être activée** sur le poste : c'est elle qui sert
désormais de clé d'accès. `ANTHROPIC_API_KEY` peut alors être retirée.

Conso par licencié :
```bash
curl -H "Authorization: Bearer <PROXY_ADMIN_TOKEN>" \
  "https://api.studio-margerit.fr/admin/usage?month=2026-08"
```

## Bon à savoir

- **Si le Pi ou la box tombe** : la génération de fiche échoue le temps de la
  panne ; la transcription locale continue, le transcript est conservé, le
  bouton « Réessayer » relance la fiche sans refaire l'ASR. Rien n'est perdu.
- **Mise à jour du proxy** : recopier `app.py` dans `/opt/diktae-keyproxy` puis
  `cd /opt/diktae-keyproxy && docker compose -f rpi/docker-compose.yml --project-directory . up -d --build`.
- **Logs** : `docker compose -f /opt/diktae-keyproxy/rpi/docker-compose.yml logs -f`.

## Migration vers un VPS (plus tard, ~20 min)

Mêmes fichiers, même compose — seule la base de conso est à emporter :

```bash
# Sur le Pi : exporter la base du volume
docker run --rm -v diktae-keyproxy_keyproxy-data:/data -v /tmp:/out alpine \
  cp /data/keyproxy.db /out/keyproxy.db
scp /tmp/keyproxy.db morgan@VPS:/tmp/

# Sur le VPS : copier /opt/diktae-keyproxy (avec son .env), réimporter la base,
# lancer le même compose, puis déplacer le TUNNEL (ou pointer le DNS) — les
# postes clients ne changent RIEN (même URL).
```
