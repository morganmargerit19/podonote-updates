"""Diktae — assistant local de transcription & bilan de consultation (podologie)."""

# Source de vérité de la version applicative. Le mécanisme de mise à jour
# (app/updater.py) compare CETTE valeur à la version publiée dans le manifest
# signé. À incrémenter à chaque déploiement (scripts/deploy_update.ps1 la lit).
__version__ = "1.1.7"
