# Keyproxy sur Raspberry Pi 4 — flash & go (~20 min, zéro commande sur le Pi)

Coût de fonctionnement : **~0 €** (2-3 €/an d'électricité). Le Pi relaie du
JSON, rien d'autre — il tiendra des dizaines de praticiens. Migration VPS
documentée en bas de page pour plus tard.

## Le jour J en 4 gestes

Rien n'est à préparer à l'avance : le **tunnel Cloudflare** (accès public HTTPS)
peut venir après — le Pi tourne sans lui, et `ajouter-tunnel.sh` le branche plus
tard sans rien réinstaller.

| # | Où | Durée |
|---|---|---|
| 1 | Flasher la carte avec **Raspberry Pi Imager 2** | 5-10 min |
| 2 | `bash server/keyproxy/rpi/preparer-carte-sd.sh` sur le Mac | 1 min |
| 3 | Carte dans le Pi, **Ethernet puis alim** — il se provisionne SEUL | ~15 min sans vous |
| 4 | `bash server/keyproxy/rpi/verifier.sh --ssh …` sur le Mac | attend tout seul |

### 1. Flasher (Raspberry Pi Imager 2)

- **Appareil** : Raspberry Pi 4
- **Système** : *Raspberry Pi OS (other)* → **Raspberry Pi OS Lite (64-bit)**
  (pas de bureau : c'est un serveur)
- **Stockage** : la carte SD (vérifier la taille : 32 Go — ne pas se tromper de disque)
- **Personnalisation — obligatoire**, le Pi n'aura ni écran ni clavier :
  - nom d'hôte **`diktae-proxy`**
  - fuseau *Europe/Paris*, clavier *fr*
  - **utilisateur + mot de passe** (à retenir : c'est l'accès SSH)
  - Wi-Fi : **laisser vide** si le Pi est en Ethernet (recommandé pour un serveur)
  - **SSH activé**, authentification par mot de passe
  - Raspberry Pi Connect : non
- Écrire. Imager **éjecte la carte à la fin** : la **retirer puis la
  réinsérer**, pour que le Mac monte la partition `bootfs`.

Imager 2 personnalise Raspberry Pi OS Trixie par **cloud-init** (fichier
`user-data` sur la carte) ; l'ancien Bookworm par `firstrun.sh`. Le script de
l'étape 2 reconnaît les deux et refuse une carte flashée sans personnalisation.

### 2. Préparer la carte, depuis le Mac

```bash
bash server/keyproxy/rpi/preparer-carte-sd.sh
```

Il trouve la carte, vérifie la personnalisation d'Imager, puis demande (saisie
masquée) :
- la **clé Anthropic** — *Entrée* reprend celle du `.env` de ce Mac ;
- le **token du tunnel** Cloudflare — *Entrée* = plus tard.

Il **engendre le jeton admin** (affiché ET rangé dans le `.env` du Mac,
`KEYPROXY_ADMIN_TOKEN`), copie le keyproxy, ajoute l'auto-provisionnement au
`user-data`, et propose d'éjecter la carte.

### 3. Brancher le Pi

Carte dans le Pi, **Ethernet d'abord, alimentation ensuite**. Au premier
démarrage, cloud-init crée le compte et active SSH, puis le Pi installe Docker,
construit l'image arm64 et lance le proxy (et le tunnel s'il a un token), puis
déplace les secrets hors de la carte. **Aucun SSH, aucune commande.** Comptez
~15 min. En cas d'échec réseau, il réessaie trois fois.

Journal sur le Pi, en cas de doute : `sudo cat /var/log/diktae-provision.log`.

### 4. Vérifier, depuis le Mac

Sans tunnel (le proxy n'écoute que sur le Pi — on l'interroge en SSH ; le mot
de passe n'est demandé qu'une fois) :

```bash
bash server/keyproxy/rpi/verifier.sh --ssh morgan@diktae-proxy.local
```

Avec le tunnel :

```bash
bash server/keyproxy/rpi/verifier.sh
bash server/keyproxy/rpi/verifier.sh --licence "AgIA…" --admin "<jeton>"
```

Sans option : le proxy répond-il, et détient-il bien la clé. Avec `--licence` :
**aller-retour réel** jusqu'à Anthropic. Avec `--admin` : la consommation du mois.

## Le tunnel Cloudflare (quand vous voulez, avant ou après le Pi)

HTTPS public **sans ouvrir un seul port** sur la box, et sans IP fixe.

1. `studio-margerit.fr` doit être géré par Cloudflare (offre Free). **Au
   2026-09-18 il est encore chez OVH** (`ns109.ovh.net`) : ajouter le domaine
   dans Cloudflare, vérifier que les enregistrements repris (site Vercel, mails)
   sont complets, puis remplacer les serveurs DNS dans l'espace client OVH par
   les deux que donne Cloudflare. Propagation : de quelques minutes à 24 h.
2. [one.dash.cloudflare.com](https://one.dash.cloudflare.com) → **Zero Trust →
   Networks → Tunnels → Create a tunnel** → type *Cloudflared* → nom `diktae-api`
   → **copier le TOKEN** (longue chaîne `eyJ…`).
3. Onglet **Public hostname** du tunnel : `api.studio-margerit.fr` → Service
   **HTTP** → URL **`keyproxy:8787`**.
4. Si le Pi tourne déjà :

   ```bash
   bash server/keyproxy/rpi/ajouter-tunnel.sh --ssh morgan@diktae-proxy.local
   bash server/keyproxy/rpi/verifier.sh
   ```

## Si l'auto-provisionnement échoue (repli manuel)

Rien n'est perdu, tout est déjà sur la carte :

```bash
ssh morgan@diktae-proxy.local
sudo cat /var/log/diktae-provision.log                # ce qui s'est passé
sudo cat /var/log/cloud-init-output.log               # le premier démarrage
sudo bash /boot/firmware/keyproxy/rpi/provision.sh    # relancer à la main
```

`provision.sh` est idempotent : le relancer ne casse rien.

## Brancher les postes Diktae

```bash
curl https://api.studio-margerit.fr/healthz
# {"ok": true, "upstream": "https://api.anthropic.com", "key_configured": true}
```

**Depuis la 1.3.1, rien à faire** : le proxy est la route par défaut du code,
les postes installés basculent par l'OTA et les nouveaux installeurs
n'intègrent plus de clé. Il faut seulement une **licence activée** sur le poste
(c'est elle qui sert d'accès). `LLM_PROXY_URL=direct` dans le `.env` rétablit
l'appel direct avec la clé locale (développement).

`basculer-poste.sh` reste utile pour un poste Mac/Linux resté en 1.3.0 (il
refuse de basculer vers un proxy injoignable, `--purger-cle` retire la clé du
`.env`).

Conso par licencié :
```bash
curl -H "Authorization: Bearer <PROXY_ADMIN_TOKEN>" \
  "https://api.studio-margerit.fr/admin/usage?month=2026-08"
```

## Bon à savoir

- **Si le Pi ou la box tombe** : la génération de fiche échoue le temps de la
  panne ; la transcription locale continue, le transcript est conservé, le
  bouton « Réessayer » relance la fiche sans refaire l'ASR. Rien n'est perdu.
- **Mise à jour du proxy** : recopier `app.py` dans `/opt/diktae-keyproxy` puis
  `cd /opt/diktae-keyproxy && docker compose -f rpi/docker-compose.yml --project-directory . up -d --build`.
- **Logs** : `docker compose -f /opt/diktae-keyproxy/rpi/docker-compose.yml logs -f`.

## Migration vers un VPS (plus tard, ~20 min)

Mêmes fichiers, même compose — seule la base de conso est à emporter :

```bash
# Sur le Pi : exporter la base du volume
docker run --rm -v diktae-keyproxy_keyproxy-data:/data -v /tmp:/out alpine \
  cp /data/keyproxy.db /out/keyproxy.db
scp /tmp/keyproxy.db morgan@VPS:/tmp/

# Sur le VPS : copier /opt/diktae-keyproxy (avec son .env), réimporter la base,
# lancer le même compose, puis déplacer le TUNNEL (ou pointer le DNS) — les
# postes clients ne changent RIEN (même URL).
```
