"""Retours praticiens — « signaler un bug » et « suggérer une amélioration ».

Chemin : le praticien écrit depuis l'app -> le texte est PSEUDONYMISÉ sur le
poste -> envoi au proxy Studio Margerit (`server/keyproxy/`, route `/feedback`)
authentifié par la CLÉ DE LICENCE, exactement comme les appels Claude. Aucun
secret supplémentaire n'est distribué avec l'app, et le retour est déjà rattaché
au licencié par sa signature.

Deux garde-fous portés par ce module :

1. **Rien d'identifiant ne sort.** Un praticien écrit naturellement « la fiche de
   Mme Dupont n'a pas généré » : ce serait une donnée de santé identifiante chez
   l'éditeur. Le message passe donc par `Pseudonymizer.for_patients()` chargé de
   TOUTES les ancres du dossier local (noms, prénoms, dates de naissance) plus le
   filet générique (e-mail, téléphone, dates, suites de chiffres). Le mapping est
   jeté : le masquage est IRRÉVERSIBLE, personne ne peut ré-identifier côté
   serveur. Le journal technique joint (facultatif) subit le même traitement.

2. **Une capture d'écran ne fuite pas.** Une image ne se pseudonymise pas
   automatiquement, et une capture de Diktae montre presque toujours un nom de
   patient. Le praticien masque donc lui-même les zones sensibles dans la page
   (rectangles noirs **brûlés dans l'image** avant l'envoi : le fichier
   d'origine ne quitte jamais le poste), et doit confirmer l'avoir vérifiée —
   `submit()` refuse la capture sans cette confirmation, côté serveur, pas
   seulement dans le navigateur. L'image est ensuite ré-encodée par
   `app/photos.py` (bornée à 1600 px, EXIF/GPS supprimés).

3. **Un retour ne se perd pas.** Le praticien signale souvent un problème au
   moment où le réseau est en cause. Chaque retour est donc d'abord écrit dans
   une file locale (`data/feedback_outbox.json`), puis envoyé ; ce qui n'est pas
   parti est réessayé au démarrage suivant et au retour suivant. Le champ `ref`
   (tiré au sort ici) rend ces réémissions sans danger : le proxy dédoublonne.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import platform
import secrets
import threading
from typing import Any, Optional

from .config import DATA_DIR, ensure_dirs, settings

log = logging.getLogger(__name__)

# La file est lue-modifiée-réécrite depuis deux fils : l'envoi différé du
# démarrage et le clic du praticien. Un verrou évite qu'un retour disparaisse
# dans l'entre-deux.
_lock = threading.Lock()

# Types de retour (valeurs stockées côté proxy — ne pas renommer sans migration).
KINDS = {"bug": "Problème rencontré", "idee": "Amélioration suggérée"}

OUTBOX_FILE = DATA_DIR / "feedback_outbox.json"
MAX_MESSAGE_CHARS = 4000
# Plafond de la file locale : au-delà, le proxy est durablement injoignable et
# empiler davantage n'aide personne (on garde les plus RÉCENTS).
MAX_OUTBOX = 50
# Journal technique joint sur demande : les dernières lignes suffisent au
# diagnostic, et moins on en envoie moins il y a à pseudonymiser.
LOG_TAIL_LINES = 60
# Capture d'écran jointe, APRÈS masquage et ré-encodage (le navigateur a déjà
# rogné à 1600 px et ré-encodé en JPEG : 2 Mo est très large).
MAX_IMAGE_BYTES = 2 * 1024 * 1024
# Le praticien ATTEND devant sa fenêtre pendant cet appel : on plafonne court.
# Dépasser le délai n'est pas une perte — le retour reste en file locale.
SEND_TIMEOUT_SECONDS = 10.0


# --------------------------------------------------------------------------- #
# Contexte technique (aucune donnée patient — que de la machine)
# --------------------------------------------------------------------------- #
def diagnostics() -> dict[str, Any]:
    """Contexte joint à chaque retour : ce qu'il faut pour reproduire un bug.

    Strictement technique. Aucun nom de patient, aucun contenu de fiche."""
    from . import license as license_mod, updater

    ctx: dict[str, Any] = {}
    try:
        ctx["version"] = updater.current_version()
    except Exception:
        ctx["version"] = "?"
    try:
        ctx["os"] = f"{platform.system()} {platform.release()}"
        ctx["python"] = platform.python_version()
        ctx["machine"] = platform.machine()
    except Exception:
        pass
    try:
        ctx["llm_backend"] = settings.llm_backend
        ctx["whisper_model"] = settings.whisper_model
        ctx["proxy"] = "oui" if settings.llm_proxy_url.strip() else "direct"
    except Exception:
        pass
    try:
        status = license_mod.get_status()
        ctx["licence"] = status.get("state", "?")
        ctx["formule"] = status.get("plan", "?")
    except Exception:
        pass
    return ctx


def _log_tail() -> str:
    """Dernières lignes de `data/podonote.log`, pseudonymisées par l'appelant."""
    path = DATA_DIR / "podonote.log"
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-LOG_TAIL_LINES:])


# --------------------------------------------------------------------------- #
# Pseudonymisation du texte libre
# --------------------------------------------------------------------------- #
def _known_patients() -> list[dict[str, Any]]:
    """Tous les dossiers locaux, réduits aux seules ancres d'identité."""
    from .db import get_connection

    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT nom, prenom, date_naissance FROM patients").fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def scrub(text: str) -> str:
    """Masque tout identifiant connu ou détectable. IRRÉVERSIBLE (mapping jeté).

    Ne JAMAIS envoyer de texte libre au serveur sans passer par ici."""
    if not text:
        return ""
    from .pseudonymize import Pseudonymizer

    try:
        patients = _known_patients()
    except Exception:
        # Base illisible : on pseudonymise quand même (filet générique seul)
        # plutôt que de laisser passer le texte brut.
        log.exception("Ancres patients illisibles — filet générique seul.")
        patients = []
    return Pseudonymizer.for_patients(patients).scrub(text)


# --------------------------------------------------------------------------- #
# Capture d'écran jointe
# --------------------------------------------------------------------------- #
def prepare_image(raw: bytes) -> tuple[bytes | None, str]:
    """Valide et ré-encode une capture déjà masquée. (image | None, erreur).

    Le masquage a eu lieu dans la page (rectangles brûlés dans l'image) ; il
    n'est pas rejouable ici et n'a pas à l'être. Ce qui se joue ici est
    l'hygiène : vraie image PNG/JPEG (octets magiques, pas l'extension),
    taille bornée, et ré-encodage qui supprime tout EXIF/GPS résiduel."""
    from . import photos

    if not raw:
        return None, "Capture vide."
    if len(raw) > photos.MAX_INPUT_BYTES:
        return None, "Capture trop volumineuse."
    if not photos.is_supported_image(raw):
        return None, "Seules les captures PNG ou JPEG sont acceptées."
    try:
        image = photos.reencode(raw)       # JPEG borné à 1600 px, sans EXIF
    except ValueError:
        return None, "Capture illisible ou corrompue."
    if len(image) > MAX_IMAGE_BYTES:
        return None, "Capture trop volumineuse après ré-encodage."
    return image, ""


# --------------------------------------------------------------------------- #
# File d'attente locale
# --------------------------------------------------------------------------- #
def _read_outbox() -> list[dict[str, Any]]:
    try:
        data = json.loads(OUTBOX_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [r for r in data if isinstance(r, dict)] if isinstance(data, list) else []


def _write_outbox(records: list[dict[str, Any]]) -> None:
    ensure_dirs()
    tmp = OUTBOX_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(records[-MAX_OUTBOX:], ensure_ascii=False, indent=1),
                   encoding="utf-8")
    os.replace(tmp, OUTBOX_FILE)


def pending_count() -> int:
    """Nombre de retours écrits localement mais pas encore remis au proxy."""
    return len(_read_outbox())


# --------------------------------------------------------------------------- #
# Envoi
# --------------------------------------------------------------------------- #
def _proxy_url() -> Optional[str]:
    base = settings.llm_proxy_url.strip().rstrip("/")
    return f"{base}/feedback" if base else None


def _post(record: dict[str, Any]) -> tuple[bool, str]:
    """Remet UN retour au proxy. (ok, message lisible par le praticien)."""
    import httpx

    from . import license as license_mod

    url = _proxy_url()
    if not url:
        return False, ("Aucun serveur Studio Margerit configuré sur ce poste "
                       "(LLM_PROXY_URL=direct) : le retour reste en attente ici.")
    token = license_mod.current_token()
    if not token:
        return False, ("Aucune licence activée : activez votre clé de licence "
                       "dans Réglages pour que vos retours nous parviennent.")
    try:
        resp = httpx.post(url, json=record, timeout=SEND_TIMEOUT_SECONDS,
                          headers={"x-api-key": token})
    except httpx.HTTPError as exc:
        return False, f"Serveur injoignable ({exc.__class__.__name__})."
    if resp.status_code < 400:
        return True, "OK"
    try:
        detail = resp.json().get("error", {}).get("message", "")
    except ValueError:
        detail = ""
    return False, detail or f"Refusé par le serveur (HTTP {resp.status_code})."


def flush() -> tuple[int, int]:
    """Réessaie la file locale. Renvoie (envoyés, restants).

    Un échec arrête la tournée : si le serveur est injoignable pour l'un, il
    l'est pour les suivants — inutile d'enchaîner les temporisations."""
    with _lock:
        pending = _read_outbox()
        if not pending:
            return 0, 0
        sent = 0
        for record in list(pending):
            ok, why = _post(record)
            if not ok:
                log.info("Retour en attente (%d) : %s", len(pending), why)
                break
            pending.pop(0)
            sent += 1
        _write_outbox(pending)
        return sent, len(pending)


def start_background_flush() -> None:
    """Tente la file en tâche de fond (démarrage) — jamais bloquant."""
    def _run() -> None:
        try:
            sent, left = flush()
            if sent:
                log.info("Retours praticien remis au serveur : %d (reste %d).", sent, left)
        except Exception:
            log.exception("Envoi différé des retours en échec (non bloquant).")

    threading.Timer(8.0, _run).start()


# --------------------------------------------------------------------------- #
# Point d'entrée de l'UI
# --------------------------------------------------------------------------- #
def submit(kind: str, message: str, include_log: bool = False,
           image: bytes | None = None, image_checked: bool = False) -> tuple[bool, str]:
    """Enregistre un retour et tente de l'envoyer.

    Renvoie (envoyé_tout_de_suite, message pour le praticien). Un `False` n'est
    PAS une perte : le retour est dans la file locale et repartira tout seul.

    `image` est une capture DÉJÀ masquée par le praticien ; `image_checked` est
    sa confirmation de l'avoir relue. Sans cette confirmation la capture est
    refusée ici — le garde-fou vit dans le code, pas seulement dans la page."""
    kind = (kind or "").strip().lower()
    if kind not in KINDS:
        return False, "Type de retour inconnu."
    message = (message or "").strip()
    if not message:
        return False, "Le message est vide."
    if image and not image_checked:
        return False, ("Confirmez avoir vérifié la capture (aucun nom de patient "
                       "lisible) avant de l'envoyer.")

    contexte = diagnostics()
    record: dict[str, Any] = {
        "ref": secrets.token_hex(8),
        "kind": kind,
        "message": scrub(message)[:MAX_MESSAGE_CHARS],
        "app_version": contexte.get("version", "?"),
        "platform": f"{platform.system()} {platform.release()}",
        "context": contexte,
    }
    if image:
        record["image"] = base64.b64encode(image).decode("ascii")
    if include_log:
        tail = _log_tail()
        if tail:
            contexte["journal"] = scrub(tail)[:MAX_MESSAGE_CHARS]

    # Écrit AVANT d'envoyer : une coupure pendant l'envoi ne perd pas le retour.
    with _lock:
        _write_outbox(_read_outbox() + [record])
    sent, left = flush()
    if sent:
        return True, ("Merci — votre retour est bien arrivé chez Studio Margerit."
                      if not left else
                      f"Retour envoyé ({left} encore en attente).")
    return False, ("Votre retour est enregistré sur ce poste : il partira tout "
                   "seul dès que la connexion au serveur sera rétablie.")
