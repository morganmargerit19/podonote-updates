"""Tests du proxy de clés API (server/keyproxy) — AUTONOMES.

Clés Ed25519 éphémères + API Anthropic simulée (monkeypatch de l'appel amont) :
aucun réseau, aucune vraie clé, base SQLite dans un dossier temporaire.
"""
from __future__ import annotations

import base64
import importlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "server" / "keyproxy"))

from cryptography.hazmat.primitives import serialization as ser  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: E402
    Ed25519PrivateKey,
)

# --- Environnement du proxy AVANT import du module (il lit l'env au chargement).
_priv = Ed25519PrivateKey.generate()
_pub_b64 = base64.b64encode(
    _priv.public_key().public_bytes(ser.Encoding.Raw, ser.PublicFormat.Raw)).decode()
_tmp = Path(tempfile.mkdtemp())
os.environ.update({
    "PROXY_LICENSE_PUBLIC_KEY": _pub_b64,
    "ANTHROPIC_API_KEY": "sk-test-fake",
    "PROXY_ADMIN_TOKEN": "admin-secret",
    "PROXY_DB": str(_tmp / "keyproxy.db"),
    "PROXY_DAILY_REQ_LIMIT": "5",
})

import app as keyproxy  # noqa: E402  (server/keyproxy/app.py)

importlib.reload(keyproxy)  # relit l'env si le module était déjà chargé

from starlette.testclient import TestClient  # noqa: E402

_DAY = 86400


def mktok(licensee: str, plan_code: int, exp_in_days: float) -> str:
    """Jeton compact signé avec la clé éphémère (même format que l'app)."""
    exp = int(time.time() + exp_in_days * _DAY)
    raw = bytes([2, plan_code]) + (exp // _DAY).to_bytes(4, "big") + licensee.encode()
    payload = base64.urlsafe_b64encode(raw).decode().rstrip("=")
    sig = base64.urlsafe_b64encode(_priv.sign(payload.encode("ascii"))).decode().rstrip("=")
    return f"{payload}.{sig}"


# --- API Anthropic SIMULÉE : capture la requête, renvoie une réponse Messages.
_captured: dict = {}


class _FakeUpstreamResponse:
    status_code = 200
    content = json.dumps({
        "id": "msg_test", "type": "message", "role": "assistant",
        "content": [{"type": "text", "text": "{}"}],
        "usage": {"input_tokens": 1200, "output_tokens": 800,
                  "cache_read_input_tokens": 100},
    }).encode()


async def _fake_upstream(url, headers, payload):
    _captured.update(url=url, headers=headers, payload=payload)
    return _FakeUpstreamResponse()

keyproxy._upstream_post = _fake_upstream
c = TestClient(keyproxy.app)

# 1. Santé
r = c.get("/healthz")
assert r.status_code == 200 and r.json()["key_configured"]
print("HEALTHZ ok")

# 2. Sans licence / licence falsifiée -> 401 au format d'erreur Anthropic
r = c.post("/v1/messages", json={"model": "claude-sonnet-5"}, headers={"x-api-key": ""})
assert r.status_code == 401 and r.json()["error"]["type"] == "authentication_error"
tok = mktok("Cabinet Nico", 0, 35)
bad = tok[:-4] + ("AAAA" if not tok.endswith("AAAA") else "BBBB")
r = c.post("/v1/messages", json={"model": "claude-sonnet-5"}, headers={"x-api-key": bad})
assert r.status_code == 401
print("AUTH licence (absente/falsifiée refusée) ok")

# 3. Licence expirée : mensuel -1 j = accepté (grâce 7 j) ; démo -1 j = refusé (sans grâce)
_body = {"model": "claude-sonnet-5", "max_tokens": 1000,
         "messages": [{"role": "user", "content": "bonjour"}]}
r = c.post("/v1/messages", json=_body, headers={"x-api-key": mktok("Grace SARL", 0, -1)})
assert r.status_code == 200, r.text
r = c.post("/v1/messages", json=_body, headers={"x-api-key": mktok("Demo X", 5, -1)})
assert r.status_code == 401 and "expirée" in r.json()["error"]["message"]
print("GRÂCE mensuel oui / démo non ok")

# 4. Relais nominal : la VRAIE clé part vers l'amont, la réponse revient telle
# quelle, la conso est journalisée SANS le contenu.
r = c.post("/v1/messages", json=_body, headers={"x-api-key": tok,
                                                "anthropic-version": "2023-06-01",
                                                "anthropic-beta": "beta-x"})
assert r.status_code == 200 and r.json()["usage"]["output_tokens"] == 800
assert _captured["headers"]["x-api-key"] == "sk-test-fake"       # vraie clé côté serveur
assert _captured["headers"]["anthropic-beta"] == "beta-x"        # en-tête beta relayé
assert _captured["payload"]["messages"][0]["content"] == "bonjour"
import sqlite3  # noqa: E402
_conn = sqlite3.connect(os.environ["PROXY_DB"]); _conn.row_factory = sqlite3.Row
_rows = _conn.execute("SELECT * FROM usage WHERE licensee = 'Cabinet Nico'").fetchall()
assert _rows and _rows[-1]["input_tokens"] == 1200 and _rows[-1]["output_tokens"] == 800
assert "content" not in _rows[-1].keys() and "prompt" not in _rows[-1].keys()
print("RELAIS + JOURNAL de conso (métadonnées seules) ok")

# 5. Garde-fous : modèle interdit, streaming refusé, max_tokens plafonné
r = c.post("/v1/messages", json={**_body, "model": "claude-opus-5"},
           headers={"x-api-key": tok})
assert r.status_code == 403 and "non autorisé" in r.json()["error"]["message"]
r = c.post("/v1/messages", json={**_body, "stream": True}, headers={"x-api-key": tok})
assert r.status_code == 400
c.post("/v1/messages", json={**_body, "max_tokens": 999999}, headers={"x-api-key": tok})
assert _captured["payload"]["max_tokens"] == keyproxy.MAX_TOKENS_LIMIT
print("GARDE-FOUS modèle/stream/max_tokens ok")

# 6. Quota journalier (limite de test = 5) : la 6e requête du licencié est 429.
for _ in range(6):
    last = c.post("/v1/messages", json=_body, headers={"x-api-key": tok})
assert last.status_code == 429 and "Quota" in last.json()["error"]["message"]
print("QUOTA journalier ok")

# 7. Rapport admin : agrégats par licencié + coût estimé ; jeton admin exigé.
r = c.get("/admin/usage")
assert r.status_code == 401
r = c.get("/admin/usage", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200
_usage = r.json()["usage"]
_nico = [u for u in _usage if u["licensee"] == "Cabinet Nico"]
assert _nico and _nico[0]["requests"] >= 5 and _nico[0]["tok_out"] >= 800
assert _nico[0]["cost_estimate_eur"] > 0
_month = time.strftime("%Y-%m")
r = c.get(f"/admin/usage?month={_month}", headers={"Authorization": "Bearer admin-secret"})
assert r.json()["month"] == _month and r.json()["usage"]
print("ADMIN /usage (agrégats + coût estimé + auth) ok")

# 8. Tarifs : Sonnet 5 (2 $ / 10 $) est plus spécifique que Sonnet 4.x (3 $ / 15 $),
# et le cache compte (lecture 0,1 ×, écriture 1,25 × le prix d'entrée).
_e = keyproxy.USD_EUR
assert abs(keyproxy._cost_eur("claude-sonnet-5", 1_000_000, 0) - 2.0 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-4-6", 1_000_000, 0) - 3.0 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-5", 0, 1_000_000) - 10.0 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-5", 0, 0, 1_000_000, 0) - 0.2 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-5", 0, 0, 0, 1_000_000) - 2.5 * _e) < 1e-9
print("TARIFS Sonnet 5 + cache ok")

# 9. Tableau de bord : /admin/stats exige le jeton, agrège par jour et par
# licencié, liste les dernières requêtes ; /admin sert la page sans données.
r = c.get("/admin/stats")
assert r.status_code == 401
r = c.get("/admin/stats", headers={"Authorization": "Bearer mauvais"})
assert r.status_code == 401
r = c.get("/admin/stats", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
_st = r.json()
_names = [l["licensee"] for l in _st["licensees"]]
assert "Cabinet Nico" in _names and "Grace SARL" in _names
_d = [d for d in _st["daily"] if d["licensee"] == "Cabinet Nico"]
assert _d and sum(x["requests"] for x in _d) >= 5
_attendu = keyproxy._cost_eur("claude-sonnet-5", 1200, 800, 100, 0)
assert abs(_d[0]["cost_eur"] - _d[0]["requests"] * _attendu) < 1e-4, (_d[0], _attendu)
assert _st["recent"] and set(_st["recent"][0]) >= {"ts", "licensee", "status", "cost_eur"}
assert all("content" not in q and "messages" not in q for q in _st["recent"])
assert _st["tz"] == "Europe/Paris" and len(_st["daily"][0]["day"]) == 10
r = c.get("/admin")
assert r.status_code == 200 and "Dépenses Diktae" in r.text and "Cabinet Nico" not in r.text
assert r.headers["cache-control"] == "no-store"
print("ADMIN /stats + page tableau de bord ok")

# 10. Retours praticiens : même authentification par licence que /v1/messages,
# dédoublonnage des réémissions de la file locale, quota, et lecture admin.
r = c.post("/feedback", json={"kind": "bug", "message": "test"})
assert r.status_code == 401                                   # sans licence
r = c.post("/feedback", json={"kind": "bug", "message": "test"},
           headers={"x-api-key": "pas.unelicence"})
assert r.status_code == 401
_tok = mktok("Cabinet Nico", 0, 30)
r = c.post("/feedback", json={"kind": "sondage", "message": "x"},
           headers={"x-api-key": _tok})
assert r.status_code == 400 and "Type de retour" in r.text    # type inconnu
r = c.post("/feedback", json={"kind": "bug", "message": "   "},
           headers={"x-api-key": _tok})
assert r.status_code == 400 and "vide" in r.text
# Dépôt nominal, avec contexte technique.
r = c.post("/feedback", headers={"x-api-key": _tok}, json={
    "ref": "ref-aaa", "kind": "bug", "app_version": "1.3.4",
    "message": "La fiche de ‹NOM_1› est restée bloquée sur « transcription ».",
    "platform": "Windows 11", "context": {"llm_backend": "sonnet", "os": "Windows 11"}})
assert r.status_code == 200, r.text
_id = r.json()["id"]
# Réémission après coupure réseau : le même `ref` ne crée PAS un doublon.
r = c.post("/feedback", headers={"x-api-key": _tok}, json={
    "ref": "ref-aaa", "kind": "bug", "message": "La fiche de ‹NOM_1› est restée bloquée."})
assert r.status_code == 200 and r.json() == {"ok": True, "id": _id, "duplicate": True}
# Suggestion d'un autre licencié.
r = c.post("/feedback", headers={"x-api-key": mktok("Grace SARL", 0, 30)},
           json={"kind": "idee", "message": "Pouvoir dupliquer une ordonnance."})
assert r.status_code == 200
# Message surdimensionné : tronqué, jamais refusé (le praticien a écrit, ça part).
r = c.post("/feedback", headers={"x-api-key": _tok},
           json={"kind": "bug", "message": "z" * (keyproxy.FEEDBACK_MAX_CHARS + 500)})
assert r.status_code == 200

# Lecture admin : jeton exigé, tri du plus récent au plus ancien, contexte relu.
r = c.get("/admin/feedback")
assert r.status_code == 401
r = c.get("/admin/feedback", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
_fb = r.json()["feedback"]
assert len(_fb) == 3 and _fb[-1]["id"] == _id          # 3 entrées, pas 4 (dédoublonné)
_first = [f for f in _fb if f["id"] == _id][0]
assert _first["licensee"] == "Cabinet Nico" and _first["plan"] == "mensuel"
assert _first["kind"] == "bug" and _first["status"] == "nouveau"
assert _first["context"]["llm_backend"] == "sonnet" and _first["app_version"] == "1.3.4"
assert len(_fb[0]["message"]) == keyproxy.FEEDBACK_MAX_CHARS   # tronqué côté serveur
assert {f["kind"] for f in _fb} == {"bug", "idee"}
# Suivi : marquer traité, filtrer dessus, refuser un statut inventé.
r = c.post(f"/admin/feedback/{_id}/status", json={"status": "traite"},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
r = c.post(f"/admin/feedback/{_id}/status", json={"status": "archive"},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 400
r = c.post("/admin/feedback/99999/status", json={"status": "vu"},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 404
r = c.get("/admin/feedback?status=traite", headers={"Authorization": "Bearer admin-secret"})
assert [f["id"] for f in r.json()["feedback"]] == [_id]
assert r.json()["counts"]["traite"] == 1
# Quota journalier : au-delà, on refuse proprement (429) sans perdre l'existant.
for _i in range(keyproxy.FEEDBACK_DAILY_LIMIT):
    _r = c.post("/feedback", headers={"x-api-key": _tok},
                json={"kind": "idee", "message": f"idée {_i}"})
    if _r.status_code == 429:
        break
else:
    raise SystemExit("ERREUR : quota de retours jamais atteint")
# Suppression définitive : jeton exigé, ligne réellement partie, 404 ensuite.
# Licence à part : le test de quota ci-dessus a épuisé celle de `_tok`.
_tok_del = mktok("Cabinet Suppr", 0, 30)
_del = c.post("/feedback", headers={"x-api-key": _tok_del},
              json={"ref": "a-supprimer", "kind": "bug", "message": "À supprimer.",
                    "image": base64.b64encode(b"\xff\xd8\xff" + b"\x00" * 64).decode()})
assert _del.status_code == 200, _del.text
_del_id = _del.json()["id"]
assert c.delete(f"/admin/feedback/{_del_id}").status_code == 401       # sans jeton
r = c.delete(f"/admin/feedback/{_del_id}", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200 and r.json()["deleted"] is True, r.text
r = c.get("/admin/feedback", headers={"Authorization": "Bearer admin-secret"})
assert _del_id not in [f["id"] for f in r.json()["feedback"]]
# La capture part avec la ligne : plus rien à servir.
assert c.get(f"/admin/feedback/{_del_id}/image",
             headers={"Authorization": "Bearer admin-secret"}).status_code == 404
assert c.delete(f"/admin/feedback/{_del_id}",
                headers={"Authorization": "Bearer admin-secret"}).status_code == 404
print("RETOURS praticiens (dépôt licencié + dédoublonnage + quota + admin + suppression) ok")

# 11. Capture d'écran jointe : stockée à part de la liste, servie sur jeton
# admin, et seules de vraies images sont acceptées.
import io as _io_kp  # noqa: E402

_jpeg = (b"\xff\xd8\xff" + b"\x00" * 512)          # en-tête JPEG + remplissage
_tok2 = mktok("Cabinet Shot", 0, 30)
r = c.post("/feedback", headers={"x-api-key": _tok2}, json={
    "ref": "shot-1", "kind": "bug", "message": "Voir la capture.",
    "image": base64.b64encode(_jpeg).decode()})
assert r.status_code == 200, r.text
_shot_id = r.json()["id"]
# Un PDF déguisé en capture est refusé (octets magiques, pas l'extension).
r = c.post("/feedback", headers={"x-api-key": _tok2}, json={
    "kind": "bug", "message": "x", "image": base64.b64encode(b"%PDF-1.7 pas une image").decode()})
assert r.status_code == 400 and "PNG/JPEG" in r.text, r.text
# Base64 invalide -> refus lisible, pas une 500.
r = c.post("/feedback", headers={"x-api-key": _tok2},
           json={"kind": "bug", "message": "x", "image": "pas~du~base64!"})
assert r.status_code == 400 and "base64" in r.text
# Au-delà du plafond -> 413.
r = c.post("/feedback", headers={"x-api-key": _tok2}, json={
    "kind": "bug", "message": "x",
    "image": base64.b64encode(b"\xff\xd8\xff" + b"\x00" * keyproxy.FEEDBACK_MAX_IMAGE_BYTES).decode()})
assert r.status_code == 413, r.status_code

# La liste admin annonce la capture sans transporter les octets.
r = c.get("/admin/feedback", headers={"Authorization": "Bearer admin-secret"})
_avec = [f for f in r.json()["feedback"] if f["id"] == _shot_id][0]
assert _avec["has_image"] is True and "image" not in _avec
assert all(f["has_image"] is False for f in r.json()["feedback"] if f["id"] != _shot_id)
# L'image elle-même : jeton exigé, en en-tête OU en ?token= (une balise <img>
# ne peut pas porter d'en-tête).
assert c.get(f"/admin/feedback/{_shot_id}/image").status_code == 401
r = c.get(f"/admin/feedback/{_shot_id}/image",
          headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200 and r.content == _jpeg
assert r.headers["content-type"].startswith("image/jpeg")
assert c.get(f"/admin/feedback/{_shot_id}/image?token=admin-secret").status_code == 200
assert c.get(f"/admin/feedback/{_shot_id}/image?token=faux").status_code == 401
# Un retour sans capture : 404 explicite, pas une image vide.
assert c.get(f"/admin/feedback/{_id}/image",
             headers={"Authorization": "Bearer admin-secret"}).status_code == 404
print("CAPTURE d'écran jointe (validée, stockée à part, servie sur jeton) ok")

# 12. Notification par mail : facultative, jamais bloquante, sans la capture.
_mails = []


class _FakeSMTP:
    def __init__(self, host, port, timeout=None):
        _mails.append({"host": host, "port": port})

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self, context=None):
        _mails[-1]["tls"] = True

    def login(self, user, password):
        _mails[-1]["login"] = user

    def send_message(self, mail):
        _mails[-1]["mail"] = mail


import smtplib as _smtplib  # noqa: E402

_saved_smtp = _smtplib.SMTP
_saved_conf = (keyproxy.SMTP_HOST, keyproxy.NOTIFY_FROM, keyproxy.NOTIFY_TO)
try:
    # SMTP non configuré (cas par défaut) : aucun envoi, aucune erreur.
    keyproxy.SMTP_HOST = ""
    keyproxy._notify_feedback(1, "X", "bug", "m", "1.3.4", False)
    assert _mails == []

    _smtplib.SMTP = _FakeSMTP
    keyproxy.SMTP_HOST = "smtp.exemple.fr"
    keyproxy.NOTIFY_FROM = "diktae@studio-margerit.fr"
    keyproxy.NOTIFY_TO = ["morgan@studio-margerit.fr"]
    keyproxy._notify_feedback(7, "Cabinet Nico", "bug",
                              "La fiche de ‹NOM_1› est bloquée.", "1.3.4", True)
    assert len(_mails) == 1 and _mails[0]["tls"] is True
    _mail = _mails[0]["mail"]
    assert "Bug signalé" in _mail["Subject"] and "Cabinet Nico" in _mail["Subject"]
    _corps = _mail.get_content()
    assert "‹NOM_1›" in _corps and "pseudonymisé" in _corps
    assert "capture d'écran est jointe" in _corps          # annoncée…
    assert not _mail.is_multipart()                        # …mais PAS attachée
    assert keyproxy.DASHBOARD_URL in _corps
    # Une suggestion porte l'autre libellé.
    keyproxy._notify_feedback(8, "X", "idee", "m", "", False)
    assert "Amélioration suggérée" in _mails[-1]["mail"]["Subject"]

    # SMTP en panne : le retour est déjà en base, l'exception ne remonte pas.
    class _BrokenSMTP:
        def __init__(self, *a, **k):
            raise OSError("smtp injoignable")

    _smtplib.SMTP = _BrokenSMTP
    # L'échec est journalisé (avec sa trace) : on le fait taire ici, sinon la
    # sortie des tests ressemble à une panne alors que c'est le cas nominal.
    import logging as _logging_kp
    _logging_kp.getLogger("keyproxy").setLevel(_logging_kp.CRITICAL)
    keyproxy._notify_feedback(9, "X", "bug", "m", "", False)   # ne doit pas lever
    _logging_kp.getLogger("keyproxy").setLevel(_logging_kp.NOTSET)
finally:
    _smtplib.SMTP = _saved_smtp
    keyproxy.SMTP_HOST, keyproxy.NOTIFY_FROM, keyproxy.NOTIFY_TO = _saved_conf
print("NOTIFICATION mail (facultative, sans la capture, jamais bloquante) ok")

# 13. Test de configuration SMTP : dire ce qui cloche AVANT qu'un praticien
# compte dessus (un échec d'envoi est silencieux par conception).
_saved_conf = (keyproxy.SMTP_HOST, keyproxy.SMTP_PORT, keyproxy.NOTIFY_FROM,
               keyproxy.NOTIFY_TO, keyproxy.SMTP_USER)
_saved_smtp = (_smtplib.SMTP, _smtplib.SMTP_SSL)
try:
    assert c.post("/admin/test-mail").status_code == 401        # jeton exigé
    _admin = {"Authorization": "Bearer admin-secret"}
    # Rien de configuré -> on NOMME les variables manquantes, sans tenter d'envoi.
    keyproxy.SMTP_HOST, keyproxy.NOTIFY_FROM, keyproxy.NOTIFY_TO = "", "", []
    _r = c.post("/admin/test-mail", headers=_admin).json()
    assert _r["ok"] is False and _r["configured"] is False
    assert "PROXY_SMTP_HOST" in _r["detail"] and "PROXY_NOTIFY_TO" in _r["detail"]

    # Configuré et joignable -> mail de test parti.
    _mails.clear()
    _smtplib.SMTP = _FakeSMTP
    keyproxy.SMTP_HOST, keyproxy.SMTP_PORT = "smtp.exemple.fr", 587
    keyproxy.NOTIFY_FROM = "diktae@studio-margerit.fr"
    keyproxy.NOTIFY_TO = ["morgan@studio-margerit.fr"]
    _r = c.post("/admin/test-mail", headers=_admin)
    assert _r.status_code == 200 and _r.json()["ok"] is True, _r.text
    assert "Test de la notification" in _mails[-1]["mail"]["Subject"]
    assert _r.json()["to"] == ["morgan@studio-margerit.fr"]

    # Port 465 -> TLS implicite (SMTP_SSL), PAS de starttls : se tromper de
    # couple port/mode est l'erreur de configuration la plus banale.
    _ssl_appels = []

    class _FakeSMTPS(_FakeSMTP):
        def __init__(self, host, port, timeout=None, context=None):
            _ssl_appels.append(port)
            super().__init__(host, port, timeout)

    _smtplib.SMTP_SSL = _FakeSMTPS
    keyproxy.SMTP_PORT = 465
    assert c.post("/admin/test-mail", headers=_admin).json()["ok"] is True
    assert _ssl_appels == [465] and "tls" not in _mails[-1]    # pas de STARTTLS

    # Mot de passe refusé -> message qui DIT quoi corriger (piège Gmail).
    class _RefusSMTP:
        def __init__(self, *a, **k):
            raise _smtplib.SMTPAuthenticationError(535, b"Username and Password not accepted")

    _smtplib.SMTP = _RefusSMTP
    keyproxy.SMTP_PORT = 587
    _r = c.post("/admin/test-mail", headers=_admin)
    assert _r.status_code == 502 and _r.json()["ok"] is False
    assert "MOT DE PASSE D'APPLICATION" in _r.json()["detail"], _r.text
finally:
    (keyproxy.SMTP_HOST, keyproxy.SMTP_PORT, keyproxy.NOTIFY_FROM,
     keyproxy.NOTIFY_TO, keyproxy.SMTP_USER) = _saved_conf
    _smtplib.SMTP, _smtplib.SMTP_SSL = _saved_smtp
print("TEST de configuration SMTP (variables manquantes, 465, mot de passe refusé) ok")

print("=== TESTS KEYPROXY OK ===")
