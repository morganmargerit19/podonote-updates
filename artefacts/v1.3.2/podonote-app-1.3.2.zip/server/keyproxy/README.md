# Proxy de clés API — Studio Margerit

**But** : les postes Diktae des clients n'ont **aucune clé Anthropic**. Ils
appellent ce proxy avec leur **clé de licence** (jeton signé Ed25519 déjà en
place) ; le proxy vérifie la licence, relaie vers l'API Anthropic avec la vraie
clé (qui ne vit que sur ce serveur), et **compte la consommation par licencié**
(tokens, coût estimé) — jamais le contenu des messages.

```
Poste Diktae ──(clé de LICENCE en x-api-key)──▶  keyproxy  ──(vraie clé)──▶ api.anthropic.com
                                                   │
                                                   └─ keyproxy.db (conso par licencié)
```

## Déploiement rapide (VPS avec Docker — ~15 min)

Sur n'importe quel petit VPS (Scaleway/OVH/Hetzner, 1 vCPU suffit — le proxy ne
fait que relayer du JSON) :

```bash
git clone <repo> && cd podonote/server/keyproxy
cp .env.example .env          # puis renseigner ANTHROPIC_API_KEY + PROXY_ADMIN_TOKEN
docker build -t diktae-keyproxy .
docker run -d --name keyproxy --restart unless-stopped \
  --env-file .env -p 127.0.0.1:8787:8787 -v keyproxy-data:/data diktae-keyproxy
```

Mettre un **reverse-proxy TLS** devant (Caddy, le plus simple — certificat
automatique) :

```
# /etc/caddy/Caddyfile
api.studio-margerit.fr {
    reverse_proxy 127.0.0.1:8787
}
```

> ⚠️ **HTTPS obligatoire** en production : le texte (pseudonymisé) des
> consultations transite par ce proxy.

Sans Docker : `pip install -r requirements.txt` puis
`uvicorn app:app --host 127.0.0.1 --port 8787` derrière Caddy, avec les
variables du `.env` exportées (systemd `EnvironmentFile=` par exemple).

## Variante à ~0 € : Raspberry Pi 4 + Cloudflare Tunnel — kit « flash & go »

Le proxy ne fait que relayer du JSON (aucun ML) : un **RPi4 est largement
suffisant** pour des dizaines de praticiens. Coût : l'électricité (~2-3 €/an),
HTTPS via **Cloudflare Tunnel** gratuit (aucun port à ouvrir sur la box, pas
d'IP fixe). Tout est prêt dans **`rpi/`** : flash avec Raspberry Pi Imager,
copie du dossier sur la carte, puis **UNE commande** sur le Pi
(`sudo bash /boot/firmware/keyproxy/rpi/provision.sh`).
→ Pas-à-pas complet : **`rpi/README-RPI.md`** (migration VPS incluse — mêmes
fichiers, on copie `keyproxy.db`, les postes clients ne changent rien).

Limite à connaître (acceptable pour démarrer) : si le Pi ou la box tombe, la
**génération de fiche** échoue chez les clients le temps de la panne — la
transcription locale continue, le transcript est conservé et « Réessayer »
relance la fiche sans refaire l'ASR. Rien n'est perdu.

## Vérifier

```bash
curl https://api.studio-margerit.fr/healthz
# {"ok": true, "upstream": "https://api.anthropic.com", "key_configured": true}
```

## Côté poste client (Diktae)

**Rien à régler depuis la 1.3.1** : le proxy est la route par défaut du code
(`app/config.py`, `DEFAULT_LLM_PROXY_URL`). Un `.env` où `LLM_PROXY_URL` est
absente ou vide — c'est le cas de tous les postes installés — passe par
`https://api.studio-margerit.fr` ; il suffit d'une **licence activée** (c'est
elle qui sert d'accès). Les postes existants basculent donc **par l'OTA 1.3.1**,
Nico compris ; les installeurs n'intègrent plus de clé.

`LLM_PROXY_URL=direct` rétablit l'appel direct avec la clé locale (poste de
développement). Une fois tous les postes basculés (visibles dans `/admin/usage`),
**révoquer l'ancienne clé** Anthropic qui était intégrée aux paquets.

## Suivre la consommation

**Tableau de bord** : <https://api.studio-margerit.fr/admin> — coût du mois et
projection, coût par praticien et par génération, courbe jour par jour, erreurs,
dernières requêtes. La page ne contient aucune donnée : elle demande le jeton
admin (gardé dans le navigateur) puis interroge `/admin/stats`. Coûts estimés
d'après les tarifs publics, cache compris (la facture Anthropic fait foi).

En ligne de commande :

```bash
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  "https://api.studio-margerit.fr/admin/usage?month=2026-08"
```

Réponse : par licencié et par modèle — nombre de requêtes (`requests`, `ok`),
tokens entrée/sortie, tokens servis du cache, `cost_estimate_eur` (indicatif —
la facture Anthropic fait foi), dernière activité. C'est la base du comptage
des paliers d'abonnement (cf. `docs/TARIFS.md`).

## Retours des praticiens (bugs et suggestions)

Le même tableau de bord affiche la section **« Retours des praticiens »** :
chaque bug signalé et chaque suggestion envoyés depuis un poste, avec le
praticien, la version de l'app, le système, le moteur utilisé, et un bouton
« Marquer traité ».

Le poste dépose son retour sur `POST /feedback`, **authentifié par la clé de
licence** comme les appels Claude — aucun secret supplémentaire n'est distribué
avec l'app. Le texte arrive **déjà pseudonymisé** par le poste
(`app/feedback.py` : noms, prénoms, dates de naissance des patients remplacés
par des jetons, filet générique e-mail/téléphone/dates/longs nombres). Le
mapping reste sur le poste : **ce serveur ne peut pas ré-identifier**.

Un poste hors-ligne garde son retour dans une file locale et le réémet plus
tard ; le champ `ref` rend ces réémissions inoffensives (dédoublonnage).

**Captures d'écran.** Un retour peut porter une capture. Une image ne se
pseudonymise pas toute seule, et une capture de Diktae montre presque toujours
un nom de patient : le praticien masque donc lui-même les zones sensibles dans
l'app, et les rectangles sont **brûlés dans l'image avant l'envoi** (le fichier
d'origine ne quitte jamais son poste). Ici, on revérifie les octets magiques et
la taille. La capture n'est pas servie dans la liste — elle a sa propre route,
`GET /admin/feedback/{id}/image`, elle aussi sur jeton admin.

### Notification par mail (facultative)

Le Pi **n'est pas un serveur de mail** : il se contente de remettre le message
à un SMTP existant (Gmail, OVH, Infomaniak…) comme le ferait un client de
messagerie. Pas besoin de Resend, Mailgun ou d'un domaine dédié : le compte
mail que vous avez déjà suffit. (Faire tourner un vrai MTA sur une IP
résidentielle serait au contraire le mauvais choix — sans reverse DNS ni SPF,
les messages finiraient en indésirables.)

Dans le `.env` du Pi :

```bash
PROXY_SMTP_HOST=smtp.gmail.com
PROXY_SMTP_PORT=587
PROXY_SMTP_USER=votre.adresse@gmail.com
PROXY_SMTP_PASSWORD=<mot de passe d'application, 16 lettres>
PROXY_NOTIFY_TO=votre.adresse@gmail.com
```

- `PROXY_SMTP_PASSWORD` est un **mot de passe d'application** Google
  (myaccount.google.com → Sécurité → Validation en 2 étapes → Mots de passe des
  applications), pas le mot de passe du compte. La validation en 2 étapes doit
  être active pour pouvoir en créer un.
- `PROXY_NOTIFY_FROM` vaut par défaut `PROXY_SMTP_USER` : **laissez-le vide**.
  Mettre une autre adresse (`diktae@studio-margerit.fr`) suppose de l'avoir
  d'abord déclarée en « Envoyer des e-mails en tant que » dans Gmail, sinon
  l'adresse est réécrite ou le message refusé.
- `PROXY_NOTIFY_TO` accepte plusieurs adresses séparées par des virgules.
- Port 465 (TLS implicite) et 587 (STARTTLS) sont tous deux gérés — le port
  choisit le mode.

Puis relancer le conteneur et **vérifier tout de suite** :

```bash
curl -X POST -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  https://api.studio-margerit.fr/admin/test-mail
```

La réponse dit `ok: true` (un mail de test part) ou nomme précisément ce qui
cloche — variable absente, mot de passe refusé, serveur injoignable. Faites-le :
en fonctionnement normal, un échec d'envoi est **silencieux par conception**
(il ne doit pas faire échouer le dépôt d'un retour), donc sans ce test une
configuration fausse ne se verrait jamais.

L'envoi part dans un fil séparé et **ne peut pas faire échouer un dépôt** : un
SMTP en panne ne doit jamais faire croire à un praticien que son signalement
est perdu. La capture n'est **pas** jointe au mail — elle resterait chez
l'hébergeur de votre messagerie ; le mail renvoie au tableau de bord.

```bash
# Lire les retours en ligne de commande
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  "https://api.studio-margerit.fr/admin/feedback?status=nouveau"
```

Réglages : `PROXY_FEEDBACK_MAX_CHARS` (défaut 4000),
`PROXY_FEEDBACK_DAILY_LIMIT` (défaut 20 par licencié et par jour).

## Garde-fous intégrés

- **Licence obligatoire** : signature Ed25519 vérifiée contre la clé publique
  Diktae ; expiration avec grâce de 7 j (aucune grâce pour les plans `demo`).
- **Modèles bornés** (`PROXY_ALLOWED_MODELS`, défaut sonnet/haiku) et
  `max_tokens` plafonné (`PROXY_MAX_TOKENS`) : un jeton volé ne peut pas brûler
  du budget sur Opus.
- **Quota journalier** par licencié (`PROXY_DAILY_REQ_LIMIT`, défaut 250).
- **Aucun contenu stocké** : seuls des métadonnées (tokens, modèle, statut,
  durée) sont journalisées.
- **Retours bornés** : type et taille validés, quota journalier
  (`PROXY_FEEDBACK_DAILY_LIMIT`), dédoublonnage par `ref`. Le serveur ne fait
  jamais confiance au client : il retronque même un message déjà borné côté app.

## Tests

`python scripts/test_keyproxy.py` (à la racine du repo) : suite autonome —
clés Ed25519 éphémères + API Anthropic simulée, aucun réseau ni vraie clé.
