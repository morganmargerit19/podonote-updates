#!/usr/bin/env python3
"""Migre la clé Anthropic du .env (texte brut) vers un blob DPAPI.

À lancer UNE FOIS sur un poste installé (ou depuis install.ps1) :
  python scripts/protect_api_key.py

Effet :
  1. lit ANTHROPIC_API_KEY dans le .env ;
  2. l'écrit chiffrée (DPAPI, portée utilisateur) dans data/anthropic.key.dpapi ;
  3. efface la valeur du .env (la ligne reste, vide, pour mémoire).

L'app lit d'abord le blob DPAPI puis, à défaut, le .env (app/winsecret.py) :
le script est donc sans risque — en cas d'échec, rien n'est effacé.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    from app.config import settings
    from app.winsecret import BLOB_PATH, protect_api_key

    key = settings.anthropic_api_key.strip()
    if not key:
        print("Aucune clé ANTHROPIC_API_KEY dans le .env : rien à migrer.")
        return 0
    if not protect_api_key(key):
        print("ÉCHEC du chiffrement DPAPI (hors Windows ?). Le .env est inchangé.")
        return 1
    print(f"Clé chiffrée -> {BLOB_PATH}")

    env_path = ROOT / ".env"
    try:
        text = env_path.read_text(encoding="utf-8")
        new = re.sub(r"(?m)^(ANTHROPIC_API_KEY=).*$",
                     r"\1   # migrée vers data/anthropic.key.dpapi", text)
        if new != text:
            env_path.write_text(new, encoding="utf-8")
            print("Clé effacée du .env.")
    except OSError as exc:
        print(f"AVERTISSEMENT : .env non modifiable ({exc}) — la clé y reste en clair.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
