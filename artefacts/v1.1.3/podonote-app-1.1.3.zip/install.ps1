﻿# =============================================================================
#  PodoNote — Installation automatique (Windows 11)
#  Lance : clic droit -> "Exécuter avec PowerShell"  (ou depuis un terminal)
#  Installe : Python 3.12, ffmpeg, environnement Python, libs ML.
#
#  Deux modes (paramètre -Mode) :
#    hybride (DÉFAUT) : fiche-bilan via Claude Sonnet (cloud). N'installe PAS
#                       Ollama. Demande la clé Anthropic et configure le .env.
#    local            : fiche-bilan 100 % locale via Ollama (nécessite un GPU
#                       pour être utilisable). Installe Ollama + le modèle.
#
#  Exemples :
#    .\install.ps1                                  # hybride (recommandé)
#    .\install.ps1 -AnthropicKey "sk-ant-..."       # hybride, clé fournie
#    .\install.ps1 -Mode local                      # 100 % local (repli)
# =============================================================================
param(
    [ValidateSet("hybride", "local")]
    [string]$Mode = "hybride",
    [string]$AnthropicKey = "",
    # -NoShortcut : ne crée pas le raccourci Bureau (l'installeur Setup.exe s'en
    # charge lui-même, pour que la désinstallation les retire proprement).
    [switch]$NoShortcut
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

# Bundle HORS-LIGNE embarqué par l'installeur : wheels pip + modèles ML. S'il est
# présent, l'installation n'effectue AUCUN gros téléchargement (corrige les connexions
# lentes / HuggingFace bridé). Absent (install depuis les sources) -> mode en ligne.
$Wheelhouse = "$Root\wheels"
$Offline = Test-Path $Wheelhouse
$BundledModels = Test-Path "$Root\model_cache"

# NB : on n'utilise PAS Start-Transcript ici. Il intercepte les flux de sortie
# et fait DEADLOCKER les sous-processus natifs (ex. `py -m venv` -> ensurepip).
# Le journal d'installation est produit par redirection au niveau de l'appelant
# (l'installeur redirige la sortie vers install.log).

function Step($n, $msg) { Write-Host "`n[$n] $msg" -ForegroundColor Cyan }
function Ok($msg)       { Write-Host "    OK  $msg" -ForegroundColor Green }
function Warn($msg)     { Write-Host "    !!  $msg" -ForegroundColor Yellow }
function Has($cmd)      { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }

# Écrit (ou remplace) une ligne "Clé=Valeur" dans le fichier .env, en préservant le reste.
function Set-EnvVar($path, $key, $value) {
    $lines = Get-Content $path
    $pattern = "^\s*$([regex]::Escape($key))\s*="
    $found = $false
    $out = foreach ($line in $lines) {
        if ($line -match $pattern) { $found = $true; "$key=$value" } else { $line }
    }
    if (-not $found) { $out += "$key=$value" }
    # UTF-8 SANS BOM : un BOM en tête casserait la 1re clé lue par python-dotenv.
    [System.IO.File]::WriteAllLines($path, $out, (New-Object System.Text.UTF8Encoding($false)))
}

# Lit la valeur d'une clé dans un .env (chaîne vide si absente).
function Get-EnvVar($path, $key) {
    if (-not (Test-Path $path)) { return "" }
    $m = Get-Content $path | Select-String "^\s*$([regex]::Escape($key))\s*=\s*(.*)$"
    if (-not $m) { return "" }
    return $m.Matches[0].Groups[1].Value.Trim().Trim('"').Trim("'")
}

Write-Host "============================================" -ForegroundColor Magenta
Write-Host "        Installation de PodoNote" -ForegroundColor Magenta
Write-Host "============================================" -ForegroundColor Magenta
if ($Mode -eq "hybride") {
    Write-Host "  Mode : HYBRIDE (fiche-bilan via Claude Sonnet)" -ForegroundColor Magenta
    Write-Host "  -> L'audio reste local ; seul du texte PSEUDONYMISÉ part vers le cloud." -ForegroundColor DarkGray
} else {
    Write-Host "  Mode : LOCAL (fiche-bilan via Ollama, GPU recommandé)" -ForegroundColor Magenta
}

# --- 0. winget disponible ? ---------------------------------------------------
$haveWinget = Has "winget"
if (-not $haveWinget) { Warn "winget introuvable : certaines installations devront être faites à la main." }

# --- 1. Python 3.12 -----------------------------------------------------------
Step 1 "Vérification de Python 3.12"

# Renvoie le CHEMIN ABSOLU d'un python.exe 3.12, ou $null. On évite le lanceur
# "py -3.12" comme commande de création de venv : selon le contexte (sortie
# redirigée, autres versions installées), il pouvait perdre ses arguments et
# lancer un REPL d'une autre version. Un chemin absolu est sans ambiguïté.
function Find-Python312 {
    # 1) Chemins d'installation standard (les plus fiables).
    foreach ($p in @(
        "$env:LocalAppData\Programs\Python\Python312\python.exe",
        "$env:ProgramFiles\Python312\python.exe",
        "${env:ProgramFiles(x86)}\Python312\python.exe")) {
        if (Test-Path $p) { return $p }
    }
    # 2) Sinon, demander au lanceur py le chemin réel de l'interpréteur 3.12.
    if (Has "py") {
        $exe = (& py -3.12 -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1)
        if ($exe) { $exe = "$exe".Trim() }
        if ($exe -and (Test-Path $exe)) { return $exe }
    }
    return $null
}

$python = Find-Python312
if (-not $python -and $haveWinget) {
    Warn "Python 3.12 absent : installation via winget…"
    # --scope user : évite d'exiger l'admin (cohérent avec une install per-user).
    winget install -e --id Python.Python.3.12 --scope user --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) {
        Warn "winget (scope user) a échoué (code $LASTEXITCODE) — nouvelle tentative scope machine…"
        winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
    }
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    $python = Find-Python312
}
if (-not $python) { throw "Python 3.12 introuvable. Installez-le depuis https://www.python.org/downloads/ puis relancez (rouvrez la session)." }
Ok "Python 3.12 disponible ($python)"

# --- 2. ffmpeg (requis pour l'audio) -----------------------------------------
Step 2 "Vérification de ffmpeg"
if (Has "ffmpeg") { Ok "ffmpeg déjà présent" }
elseif ($haveWinget) {
    Warn "Installation de ffmpeg via winget…"
    winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
    Ok "ffmpeg installé (un redémarrage du terminal peut être nécessaire)"
} else { Warn "Installez ffmpeg manuellement : https://www.gyan.dev/ffmpeg/builds/" }

# --- 3. Ollama + modèle (mode local uniquement) ------------------------------
if ($Mode -eq "local") {
    Step 3 "Vérification d'Ollama (LLM local)"
    if (Has "ollama") { Ok "Ollama déjà présent" }
    elseif ($haveWinget) {
        Warn "Installation d'Ollama via winget…"
        winget install -e --id Ollama.Ollama --accept-source-agreements --accept-package-agreements
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        Ok "Ollama installé"
    } else { Warn "Installez Ollama manuellement : https://ollama.com/download" }

    $model = "qwen2.5:7b"
    if (Has "ollama") {
        Step "3b" "Téléchargement du modèle $model (peut être long la 1re fois)"
        try { ollama pull $model; Ok "Modèle $model prêt" }
        catch { Warn "Impossible de télécharger $model maintenant. Lancez plus tard : ollama pull $model" }
    }
} else {
    Step 3 "LLM cloud (Claude Sonnet) — Ollama non requis, étape ignorée"
    Ok "Mode hybride : la fiche-bilan est générée par Claude Sonnet (pas d'Ollama à installer)"
}

# --- 4. Environnement Python --------------------------------------------------
Step 4 "Création de l'environnement Python (.venv)"
# Immunise contre un environnement Python actif hérité (VIRTUAL_ENV/PYTHONHOME…)
# qui ferait échouer ou BLOQUER la création du venv (ex. installation lancée
# depuis un terminal où un venv est activé).
$env:VIRTUAL_ENV = $null
$env:PYTHONHOME = $null
$env:PYTHONPATH = $null
$pyexe = "$Root\.venv\Scripts\python.exe"
# Recrée le venv s'il est absent OU incomplet (création précédente interrompue).
if (-not (Test-Path $pyexe)) {
    if (Test-Path "$Root\.venv") { Remove-Item "$Root\.venv" -Recurse -Force }
    & $python -m venv "$Root\.venv"
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $pyexe)) { throw "Échec de création de l'environnement Python (.venv)." }
    Ok "Environnement créé"
} else { Ok "Environnement déjà présent" }

Step "4b" "Mise à jour de pip"
& $pyexe -m pip install --upgrade pip --quiet --timeout 120 --retries 5
if ($LASTEXITCODE -ne 0) { throw "Échec de la mise à jour de pip (connexion ?)." }
Ok "pip à jour"

Step "4c" "Installation des dépendances de base"
if ($Offline) {
    & $pyexe -m pip install --no-index --find-links $Wheelhouse -r "$Root\requirements.txt"
} else {
    # --timeout/--retries : robustesse sur réseau lent/instable (vieux PC).
    & $pyexe -m pip install -r "$Root\requirements.txt" --timeout 120 --retries 5
}
if ($LASTEXITCODE -ne 0) { throw "Échec de l'installation des dépendances (requirements.txt)." }
Ok $(if ($Offline) { "Dépendances web installées (hors-ligne)" } else { "Dépendances web installées" })

# --- 5. Libs ML (lourdes) -----------------------------------------------------
Step 5 "Installation des briques ML (torch CPU, faster-whisper, whisperx)"
if ($Offline) { & "$Root\scripts\install_ml.ps1" -PyExe $pyexe -Wheelhouse $Wheelhouse }
else          { & "$Root\scripts\install_ml.ps1" -PyExe $pyexe }
if ($LASTEXITCODE -ne 0) {
    throw "L'installation ML a échoué. Vérifiez la connexion puis relancez l'installation."
} else {
    # Vérifie que les libs s'importent réellement
    & $pyexe -c "import torch, whisperx, faster_whisper" 2>$null
    if ($LASTEXITCODE -eq 0) { Ok "Briques ML installées et vérifiées" }
    else { Warn "Briques ML installées mais non importables. Relancez .\scripts\install_ml.ps1" }
}

# --- 5b. ffmpeg réellement dans le PATH ? ------------------------------------
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
if (Has "ffmpeg") { Ok "ffmpeg accessible" }
else { Warn "ffmpeg pas encore dans le PATH : fermez/rouvrez la session, ou redémarrez le PC." }

# --- 5c. Runtime Microsoft Edge WebView2 (fenêtre native de l'app) ------------
# Sans ce runtime (fréquent sur un vieux PC), la fenêtre native ne s'affiche pas
# (l'app a un repli navigateur, mais la fenêtre dédiée est préférable). On le
# détecte via la clé de version EdgeUpdate, et on l'installe en silence sinon.
Step "5c" "Runtime WebView2 (fenêtre de l'application)"
function Has-WebView2 {
    $guid = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
    foreach ($p in @(
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\$guid",
        "HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\$guid",
        "HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\$guid")) {
        try {
            $pv = (Get-ItemProperty -Path $p -Name pv -ErrorAction Stop).pv
            if ($pv -and $pv -ne "0.0.0.0") { return $true }
        } catch {}
    }
    return $false
}
if (Has-WebView2) {
    Ok "WebView2 déjà présent"
} else {
    Warn "WebView2 absent : installation du runtime (silencieuse)…"
    try {
        $wv = Join-Path $env:TEMP "MicrosoftEdgeWebview2Setup.exe"
        Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?LinkId=2124703" -OutFile $wv -UseBasicParsing
        Start-Process -FilePath $wv -ArgumentList "/silent","/install" -Wait
        if (Has-WebView2) { Ok "WebView2 installé" }
        else { Warn "WebView2 non confirmé — l'app s'ouvrira dans le navigateur (repli automatique)." }
    } catch {
        Warn "Echec installation WebView2 ($_). L'app utilisera le navigateur (repli automatique)."
    }
}

# --- 6. Fichier .env ----------------------------------------------------------
Step 6 "Configuration (.env)"
$envPath = "$Root\.env"
if (-not (Test-Path $envPath)) {
    Copy-Item "$Root\.env.example" $envPath
    Ok ".env créé"
} else { Ok ".env déjà présent" }

if ($Mode -eq "hybride") {
    Step "6a" "Backend de génération : Claude Sonnet (cloud)"
    Set-EnvVar $envPath "LLM_BACKEND" "sonnet"
    Ok "LLM_BACKEND=sonnet"

    # Clé API. Priorité : paramètre > clé DÉJÀ présente dans .env (distribution
    # préparée par make_dist.ps1 = rien à saisir) > demande interactive (usage
    # manuel uniquement). Pour Nico, la clé est déjà là -> aucune question.
    $existing = Get-EnvVar $envPath "ANTHROPIC_API_KEY"
    $key = $AnthropicKey.Trim()
    if ((-not $key) -and $existing) {
        Ok "Clé Anthropic déjà présente (rien à saisir)."
    } elseif (-not $key) {
        $key = (Read-Host "Clé API Anthropic (sk-ant-..., vide = à remplir plus tard)").Trim()
    }
    if ($key) {
        Set-EnvVar $envPath "ANTHROPIC_API_KEY" $key
        Ok "Clé Anthropic enregistrée dans .env"
    } elseif (-not $existing) {
        Warn "Aucune clé. Renseignez ANTHROPIC_API_KEY dans .env avant le 1er usage."
    }

    # Chiffrement de la clé (DPAPI, lié au compte Windows du poste) : la clé ne
    # reste pas en texte brut dans le .env. Best effort : en cas d'échec, l'app
    # continue de lire le .env.
    & $pyexe "$Root\scripts\protect_api_key.py"
    if ($LASTEXITCODE -eq 0) { Ok "Clé API chiffrée (DPAPI) — retirée du .env" }
    else { Warn "Chiffrement DPAPI impossible : la clé reste dans .env (texte brut)." }
} else {
    Set-EnvVar $envPath "LLM_BACKEND" "ollama"
    Ok "LLM_BACKEND=ollama (100 % local)"
}

# --- 6b. Pré-téléchargement des modèles (pour l'usage hors-ligne) ------------
Step "6b" "Pré-téléchargement des modèles ML (transcription, alignement) — peut être long"
if ($BundledModels) {
    # Modèles déjà EMBARQUÉS (model_cache\) : config.py y redirige les caches HF/torch.
    # On force le mode hors-ligne HF pour ne tenter AUCUN accès réseau (HF bridé).
    $env:HF_HUB_OFFLINE = "1"; $env:TRANSFORMERS_OFFLINE = "1"
    & $pyexe "$Root\scripts\warmup_models.py"
    Remove-Item Env:\HF_HUB_OFFLINE, Env:\TRANSFORMERS_OFFLINE -ErrorAction SilentlyContinue
    if ($LASTEXITCODE -eq 0) { Ok "Modèles embarqués vérifiés (aucun téléchargement)" }
    else { Warn "Modèles embarqués non chargés — vérifiez le dossier model_cache." }
} else {
    & $pyexe "$Root\scripts\warmup_models.py"
    if ($LASTEXITCODE -eq 0) { Ok "Modèles pré-téléchargés" }
    else { Warn "Pré-téléchargement incomplet (réseau ?). Les modèles seront récupérés au 1er usage en ligne." }
}

# --- 6c. Auto-test : l'application peut-elle démarrer ? ----------------------
# Importe réellement le serveur web. Si une brique manque (pip interrompu sur un
# PC lent/réseau coupé), on le détecte ICI et on pose un rapport TRÈS VISIBLE sur
# le Bureau plutôt que de laisser le praticien face à un échec opaque au lancement.
Step "6c" "Vérification finale : l'application peut-elle démarrer ?"
$selfTest = & $pyexe -c "import app.main; print('PODONOTE_IMPORT_OK')" 2>&1
if ($LASTEXITCODE -eq 0 -and ("$selfTest" -match 'PODONOTE_IMPORT_OK')) {
    Ok "L'application est prête à démarrer."
    Write-Host "PODONOTE_READY"   # marqueur lu par l'installeur Inno (succès)
} else {
    Write-Host "PODONOTE_NOT_READY"  # marqueur lu par l'installeur Inno (échec)
    Warn "L'application ne peut PAS démarrer (dépendance manquante ?)."
    try {
        $desk = [Environment]::GetFolderPath("Desktop")
        $report = Join-Path $desk "PodoNote-PROBLEME-installation.txt"
        $body = @(
            "PodoNote : l'installation s'est terminee, mais l'application ne demarre pas.",
            "=> Merci d'envoyer CE fichier a Studio Margerit (Morgan). Aucune donnee patient.",
            "",
            "Date    : $(Get-Date)",
            "Python  : $pyexe",
            "Dossier : $Root",
            "",
            "----- Erreur technique (cause exacte) -----",
            ("$selfTest")
        )
        [System.IO.File]::WriteAllLines($report, $body, (New-Object System.Text.UTF8Encoding($false)))
        Warn "Rapport depose sur le Bureau : PodoNote-PROBLEME-installation.txt"
    } catch { Warn "Impossible d'ecrire le rapport sur le Bureau : $_" }
}

# --- 6d. Nettoyage du cache d'installation -----------------------------------
# Les wheels (~1,5 Go) ne servent qu'à l'installation hors-ligne : on les retire
# une fois l'app prête, pour ne pas gaspiller l'espace disque du praticien.
# (En cas d'échec plus haut, le script s'est déjà arrêté → wheels conservés pour
#  permettre une relance hors-ligne.) Les modèles (model_cache\) sont CONSERVÉS.
if ($Offline -and (Test-Path $Wheelhouse)) {
    try { Remove-Item $Wheelhouse -Recurse -Force; Ok "Cache d'installation (wheels) retiré — espace disque libéré" }
    catch { Warn "Wheels non supprimés (non bloquant) : $_" }
}

# --- 7. Raccourci bureau ------------------------------------------------------
if ($NoShortcut) {
    Step 7 "Raccourci géré par l'installeur — étape ignorée"
} else {
Step 7 "Création du raccourci sur le Bureau"
try {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $sc = (New-Object -ComObject WScript.Shell).CreateShortcut("$desktop\PodoNote.lnk")
    # Le raccourci pointe sur le LANCEUR AUTO-RÉPARANT (PodoNote.vbs), jamais
    # directement sur pythonw.exe : si le .venv est absent (install interrompue,
    # nouveau PC), le lanceur termine l'installation au lieu de laisser un
    # raccourci mort (dialogue Windows « Problème de raccourci »). wscript.exe
    # lance le .vbs sans aucune fenêtre console sur le cas normal.
    $sc.TargetPath = "$env:WINDIR\System32\wscript.exe"
    $sc.Arguments = "`"$Root\PodoNote.vbs`""
    $sc.WorkingDirectory = $Root
    $ico = "$Root\static\podonote.ico"
    $sc.IconLocation = $(if (Test-Path $ico) { $ico } else { "shell32.dll,13" })
    $sc.Description = "Lancer PodoNote"
    $sc.Save()
    Ok "Raccourci 'PodoNote' créé sur le Bureau"
} catch { Warn "Raccourci non créé : $_" }
}

Write-Host "`n============================================" -ForegroundColor Green
Write-Host "  Installation terminée !" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host "  1. Double-cliquez sur 'PodoNote' (Bureau) pour démarrer."
Write-Host "  2. Au premier lancement, l'application vous guide pour créer"
Write-Host "     votre mot de passe et votre code PIN (rien à éditer à la main)."
Write-Host "  3. Pour activer l'identification des locuteurs (qui parle), ajoutez"
Write-Host "     plus tard votre HUGGINGFACE_TOKEN dans le fichier .env (voir GUIDE.md)."
Write-Host ""
