"""Catalogue de prescription (topiques + pansements) et suggestions par diagnostic.

Cadre réglementaire : les pédicures-podologues peuvent prescrire/appliquer une
liste de TOPIQUES À USAGE EXTERNE non vénéneux (antiseptiques, antifongiques,
kératolytiques et verrucides, adoucissants/asséchants/calmants/cicatrisants/
révulsifs, anti-inflammatoires locaux pour l'hallux valgus et les ongles
incarnés, hémostatiques, anesthésiques locaux) ainsi qu'une liste de PANSEMENTS
(dont des pansements spécifiques pour le patient diabétique).
Réf. : Arrêté du 30 juillet 2008 + Décret n° 2009-956 du 29 juillet 2009.
Les spécialités renfermant des substances vénéneuses en sont EXCLUES.

⚠️ Catalogue de DÉPART, volontairement GÉNÉRIQUE (par catégorie, sans marque) —
à affiner/compléter avec le praticien. Le logiciel ne fait que PROPOSER des
lignes : le praticien reste seul responsable, il édite/valide avant de générer.
Le diagnostic est TOUJOURS choisi explicitement par le praticien (jamais inféré
par l'IA), cohérent avec la posture « pas de diagnostic automatique » de l'app.
"""
from __future__ import annotations

# Topiques prescriptibles (par catégorie). `ligne` = texte inséré dans l'ordonnance.
TOPIQUES = [
    {"key": "antifongique_vernis", "categorie": "Antifongique",
     "label": "Antifongique local — vernis (onychomycose)",
     "ligne": "Vernis antifongique à usage externe — 1 application/jour sur le(s) ongle(s) atteint(s) jusqu'à repousse saine"},
    {"key": "antifongique_creme", "categorie": "Antifongique",
     "label": "Antifongique local — crème/poudre (mycose cutanée)",
     "ligne": "Antifongique local (crème ou poudre) — 2 applications/jour sur la zone atteinte pendant 3 semaines"},
    {"key": "antiseptique", "categorie": "Antiseptique",
     "label": "Antiseptique à usage externe",
     "ligne": "Antiseptique à usage externe — 1 à 2 applications/jour sur la zone concernée"},
    {"key": "keratolytique", "categorie": "Kératolytique",
     "label": "Kératolytique (hyperkératose, cor, durillon)",
     "ligne": "Préparation kératolytique adoucissante — application locale quotidienne sur l'hyperkératose"},
    {"key": "verrucide", "categorie": "Kératolytique / verrucide",
     "label": "Verrucide (verrue plantaire)",
     "ligne": "Préparation verrucide à l'acide salicylique — application locale sur la verrue, protéger la peau saine"},
    {"key": "ains_local", "categorie": "Anti-inflammatoire local",
     "label": "AINS local (hallux valgus, ongle incarné)",
     "ligne": "Anti-inflammatoire non stéroïdien à usage local — 1 à 2 applications/jour sur la zone douloureuse"},
    {"key": "cicatrisant", "categorie": "Cicatrisant / adoucissant",
     "label": "Cicatrisant / adoucissant",
     "ligne": "Topique cicatrisant et adoucissant à usage externe — 1 application/jour"},
    {"key": "hemostatique", "categorie": "Hémostatique",
     "label": "Hémostatique local",
     "ligne": "Hémostatique local à usage externe — application ponctuelle en cas de saignement"},
]

# Pansements prescriptibles (les 3 derniers : renouvellement pour le pied diabétique).
PANSEMENTS = [
    {"key": "compresses", "label": "Compresses stériles",
     "ligne": "Compresses stériles de gaze hydrophile — à renouveler selon besoin"},
    {"key": "sparadrap", "label": "Sparadrap / maintien",
     "ligne": "Sparadrap (élastique ou non) pour le maintien du pansement"},
    {"key": "hydrocolloide", "label": "Pansement hydrocolloïde (diabétique)",
     "ligne": "Pansement hydrocolloïde — à renouveler selon l'état de la plaie"},
    {"key": "alginate", "label": "Pansement à l'alginate de calcium (diabétique)",
     "ligne": "Pansement à l'alginate de calcium — plaie exsudative, à renouveler selon besoin"},
    {"key": "hydrogel", "label": "Pansement hydrogel (diabétique)",
     "ligne": "Pansement hydrogel — plaie sèche/nécrotique, à renouveler selon besoin"},
]

# Semelles / orthèses plantaires (retour Nico : ne plus les prescrire d'office,
# mais les CHOISIR comme le reste). Catalogue de départ, à affiner avec Nico.
SEMELLES = [
    {"key": "orthopediques_mesure", "label": "Semelles orthopédiques sur mesure",
     "ligne": "1 PAIRE DE SEMELLES ORTHOPÉDIQUES SUR MESURE"},
    {"key": "ortheses_thermoformees", "label": "Orthèses plantaires thermoformées",
     "ligne": "1 PAIRE D'ORTHÈSES PLANTAIRES THERMOFORMÉES SUR MESURE"},
    {"key": "semelles_amortissantes", "label": "Semelles de décharge / amortissantes",
     "ligne": "1 PAIRE DE SEMELLES DE DÉCHARGE AMORTISSANTES"},
    {"key": "renouvellement_semelles", "label": "Renouvellement de semelles",
     "ligne": "RENOUVELLEMENT — 1 PAIRE DE SEMELLES ORTHOPÉDIQUES SUR MESURE"},
]

# Suggestions : un DIAGNOSTIC choisi par le praticien -> lignes proposées.
DIAGNOSTICS = [
    {"key": "onychomycose", "label": "Onychomycose (mycose de l'ongle)",
     "topiques": ["antifongique_vernis"], "pansements": []},
    {"key": "mycose_cutanee", "label": "Mycose cutanée / intertrigo",
     "topiques": ["antifongique_creme", "antiseptique"], "pansements": []},
    {"key": "verrue", "label": "Verrue plantaire",
     "topiques": ["verrucide"], "pansements": []},
    {"key": "hyperkeratose", "label": "Hyperkératose / cor / durillon",
     "topiques": ["keratolytique"], "pansements": []},
    {"key": "ongle_incarne", "label": "Ongle incarné (onychocryptose)",
     "topiques": ["antiseptique", "ains_local"], "pansements": ["compresses", "sparadrap"]},
    {"key": "plaie_diabetique", "label": "Plaie du pied diabétique",
     "topiques": ["antiseptique"], "pansements": ["hydrocolloide", "alginate"]},
]

_TOPIQUE_BY_KEY = {t["key"]: t for t in TOPIQUES}
_PANSEMENT_BY_KEY = {p["key"]: p for p in PANSEMENTS}


def lines_for_diagnostic(key: str) -> list[str]:
    """Lignes d'ordonnance proposées pour un diagnostic (topiques puis pansements)."""
    d = next((x for x in DIAGNOSTICS if x["key"] == key), None)
    if not d:
        return []
    out = [_TOPIQUE_BY_KEY[k]["ligne"] for k in d["topiques"] if k in _TOPIQUE_BY_KEY]
    out += [_PANSEMENT_BY_KEY[k]["ligne"] for k in d["pansements"] if k in _PANSEMENT_BY_KEY]
    return out


def diagnostic_lines_map() -> dict[str, list[str]]:
    """{diagnostic_key: [lignes]} — pour l'insertion côté formulaire (JS)."""
    return {d["key"]: lines_for_diagnostic(d["key"]) for d in DIAGNOSTICS}


def line_map() -> dict[str, str]:
    """{'t:<key>'|'p:<key>'|'s:<key>': ligne} — ajout individuel d'un topique,
    pansement ou semelle/orthèse (JS)."""
    m = {f"t:{t['key']}": t["ligne"] for t in TOPIQUES}
    m.update({f"p:{p['key']}": p["ligne"] for p in PANSEMENTS})
    m.update({f"s:{s['key']}": s["ligne"] for s in SEMELLES})
    return m
