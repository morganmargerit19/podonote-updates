"""Génération de la fiche-bilan via Ollama (LLM local). Sortie JSON stricte."""
from __future__ import annotations

import json
import re
from typing import Any, Optional

import httpx

from .. import bilan, fiches
from ..config import settings

# --------------------------------------------------------------------------- #
# Prompt système + schéma du bilan : définis par TYPE de fiche (registre
# app/fiches.py). `SYSTEM_PROMPT` reste le prompt podologie historique (défaut
# des backends si aucun prompt n'est passé) ; generate_recap sélectionne le bon
# prompt/normaliseur selon `bilan_type`.
# --------------------------------------------------------------------------- #
SYSTEM_PROMPT = bilan.SYSTEM_PROMPT


class LLMError(RuntimeError):
    """Erreur de communication ou de parsing avec Ollama."""


# En dessous de ce nombre de mots, l'audio est considéré comme un test / sans
# contenu exploitable. On NE génère PAS de fiche via le LLM : sinon, avec un
# transcript quasi vide, il a tendance à recopier l'historique du patient.
MIN_TRANSCRIPT_WORDS = 12


def _empty_recap(reason: str) -> dict[str, Any]:
    """Fiche minimale honnête quand la transcription n'a aucun contenu clinique."""
    return bilan.empty(reason)


# --------------------------------------------------------------------------- #
# Disponibilité Ollama
# --------------------------------------------------------------------------- #
def check_ollama() -> tuple[bool, str]:
    try:
        r = httpx.get(f"{settings.ollama_host}/api/tags", timeout=5.0)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]
        if not any(settings.ollama_model.split(":")[0] in m for m in models):
            return False, (
                f"Ollama répond mais le modèle '{settings.ollama_model}' n'est pas "
                f"installé. Modèles présents : {', '.join(models) or 'aucun'}."
            )
        return True, f"Ollama OK ({settings.ollama_model})"
    except Exception as exc:
        return False, f"Ollama injoignable sur {settings.ollama_host} : {exc}"


def list_models() -> list[str]:
    try:
        r = httpx.get(f"{settings.ollama_host}/api/tags", timeout=5.0)
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]
    except Exception:
        return []


# --------------------------------------------------------------------------- #
# Construction du prompt
# --------------------------------------------------------------------------- #
def _build_history_block(history: Optional[list[dict[str, Any]]]) -> str:
    """Résumé compact des consultations précédentes pour le contexte d'évolution."""
    if not history:
        return "Aucune visite précédente connue pour ce patient."
    lignes = ["HISTORIQUE DES VISITES PRÉCÉDENTES (de la plus récente à la plus ancienne) :"]
    for c in history:
        recap = c.get("recap") or {}
        date = c.get("date", "?")
        souci = (recap.get("anamnese") or {}).get("souci_actuel", "")
        tl = recap.get("tl_dr") or souci or "(pas de synthèse)"
        conclusion = recap.get("conclusion") or {}
        synthese = conclusion.get("synthese", "")
        suivi = conclusion.get("suivi", "")
        lignes.append(f"- {date} — {tl}")
        if synthese:
            lignes.append(f"  conclusion : {synthese}")
        if suivi:
            lignes.append(f"  suivi/recommandations : {suivi}")
    return "\n".join(lignes)


def build_user_prompt(
    transcript: str,
    history: Optional[list[dict[str, Any]]],
    patient_context: str = "",
) -> str:
    history_block = _build_history_block(history)
    ctx = f"{patient_context}\n\n" if patient_context else ""
    return (
        f"{ctx}"
        f"{history_block}\n\n"
        f"TRANSCRIPTION DE LA CONSULTATION DU JOUR :\n"
        f"\"\"\"\n{transcript}\n\"\"\"\n\n"
        f"Produis maintenant la fiche-bilan JSON, en respectant toutes les règles."
    )


# --------------------------------------------------------------------------- #
# Parsing robuste
# --------------------------------------------------------------------------- #
def _strip_trailing_commas(text: str) -> str:
    """Supprime les virgules traînantes avant } ou ] (erreur fréquente des LLM)."""
    return re.sub(r",(\s*[}\]])", r"\1", text)


def _extract_json(raw: str) -> dict[str, Any]:
    """Extrait un objet JSON même entouré de texte ou de balises Markdown."""
    text = raw.strip()
    # Retire les balises ```json ... ``` où qu'elles soient.
    text = re.sub(r"```(?:json)?", "", text).strip()

    candidates = [text]
    # Capture du premier { au dernier } (objet le plus englobant).
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        candidates.append(text[start : end + 1])

    for cand in candidates:
        for variant in (cand, _strip_trailing_commas(cand)):
            try:
                data = json.loads(variant)
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                continue
    raise LLMError("Aucun objet JSON valide trouvé dans la réponse du LLM.")


# Normalisation déléguée au schéma unique du bilan (app/bilan.py).
_normalize = bilan.normalize


# --------------------------------------------------------------------------- #
# Génération
# --------------------------------------------------------------------------- #
def _require_loopback_ollama() -> None:
    """Refuse tout hôte Ollama non local : le prompt envoyé à Ollama n'est PAS
    pseudonymisé (backend « 100 % local » par contrat). Un OLLAMA_HOST pointant
    ailleurs exfiltrerait les transcriptions brutes en HTTP clair."""
    from urllib.parse import urlparse

    host = (urlparse(settings.ollama_host).hostname or "").lower()
    if host not in ("127.0.0.1", "localhost", "::1"):
        raise LLMError(
            f"OLLAMA_HOST pointe vers '{host}' : seul un hôte local "
            "(127.0.0.1/localhost) est autorisé — le texte envoyé à Ollama "
            "n'est pas pseudonymisé et ne doit jamais quitter la machine."
        )


def _call_ollama(
    prompt: str, model: Optional[str] = None, system_prompt: Optional[str] = None
) -> str:
    """Backend local : Ollama. Renvoie le texte brut de la réponse."""
    _require_loopback_ollama()
    model = model or settings.ollama_model
    payload = {
        "model": model,
        "system": system_prompt or SYSTEM_PROMPT,
        "prompt": prompt,
        "stream": False,
        "format": "json",            # force une sortie JSON
        "options": {"temperature": 0.2},
    }
    try:
        r = httpx.post(
            f"{settings.ollama_host}/api/generate",
            json=payload,
            timeout=600.0,           # CPU : peut être long
        )
        r.raise_for_status()
        return r.json().get("response", "")
    except httpx.HTTPError as exc:
        raise LLMError(f"Appel Ollama échoué : {exc}") from exc


def _call_sonnet(
    prompt: str, model: Optional[str] = None, system_prompt: Optional[str] = None
) -> str:
    """Backend cloud : Claude (Anthropic). Renvoie le texte brut de la réponse.

    ⚠️ N'est appelé QU'AVEC du texte déjà pseudonymisé (cf. generate_recap).
    L'audio ne passe jamais ici (texte uniquement).
    """
    from ..winsecret import get_anthropic_api_key

    key = get_anthropic_api_key()
    if not key:
        raise LLMError(
            "ANTHROPIC_API_KEY absente : backend Sonnet indisponible. "
            "Renseignez la clé dans .env ou repassez LLM_BACKEND=ollama."
        )
    try:
        import anthropic  # import paresseux : non requis en mode local
    except Exception as exc:  # pragma: no cover
        raise LLMError(
            "Paquet 'anthropic' non installé (pip install anthropic)."
        ) from exc

    model = model or settings.anthropic_model
    try:
        # timeout : sans lui, un réseau dégradé laisse le pipeline pendu
        # indéfiniment (l'appel Ollama local a déjà son timeout de 600 s).
        client = anthropic.Anthropic(
            api_key=key, timeout=settings.anthropic_timeout_seconds,
        )

        def _create(limit: int, timeout: Optional[float] = None):
            c = client.with_options(timeout=timeout) if timeout else client
            # Sonnet 5 : les paramètres d'échantillonnage (temperature…) sont
            # REJETÉS (400), et omettre `thinking` activerait la réflexion
            # adaptative — utile en chat, mais ici la tâche est une extraction
            # structurée : on la désactive pour garder un coût et une latence
            # prévisibles (accepté aussi par Sonnet 4.6 si un .env l'épingle).
            # `extra_body` car le SDK épinglé (0.42.0) ne type pas encore
            # `thinking` — le champ part tel quel dans le corps JSON.
            return c.messages.create(
                model=model,
                max_tokens=limit,
                system=system_prompt or SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
                extra_body={"thinking": {"type": "disabled"}},
            )

        msg = _create(settings.anthropic_max_tokens)
        if getattr(msg, "stop_reason", None) == "max_tokens":
            # Fiche tronquée (JSON coupé en plein vol). Les .env déjà installés
            # plafonnent parfois bas (4096) et l'OTA ne réécrit JAMAIS le .env :
            # la correction doit donc vivre ici. On retente une fois avec un
            # plafond large ; timeout relevé car la sortie peut être longue.
            retry_limit = max(16000, settings.anthropic_max_tokens)
            msg = _create(retry_limit, timeout=600.0)
    except Exception as exc:
        raise LLMError(f"Appel Sonnet échoué : {exc}") from exc
    if getattr(msg, "stop_reason", None) == "max_tokens":
        # Même la 2e tentative (>= 16000 tokens) est tronquée : cas anormal
        # (transcript hors norme). Sans ce test, l'erreur remontée serait un
        # cryptique « Aucun objet JSON valide » après la transcription complète.
        raise LLMError(
            "Réponse du LLM tronquée malgré une nouvelle tentative à "
            "16000 tokens. Contactez le support (transcript anormalement long)."
        )
    parts = [b.text for b in msg.content if getattr(b, "type", "") == "text"]
    return "".join(parts)


def generate_recap(
    transcript: str,
    history: Optional[list[dict[str, Any]]] = None,
    model: Optional[str] = None,
    patient_context: str = "",
    patient: Optional[dict[str, Any]] = None,
    bilan_type: str = "podologie",
) -> dict[str, Any]:
    """Génère la fiche-bilan normalisée (dict) via le backend configuré.

    Backend local (ollama) : tout reste sur la machine.
    Backend cloud (sonnet) : le texte est PSEUDONYMISÉ avant l'appel et les
    identifiants sont réinjectés dans la réponse. L'audio ne sort jamais.

    `bilan_type` sélectionne le schéma/prompt/normaliseur dans le registre
    app/fiches.py (défaut 'podologie').
    """
    fiche = fiches.get(bilan_type)

    # Garde-fou : transcript trop court (audio de test, inaudible) -> pas de LLM,
    # pour ne pas que le modèle invente à partir de l'historique du patient.
    if len((transcript or "").split()) < MIN_TRANSCRIPT_WORDS:
        return fiche.empty(
            "Enregistrement trop court : aucun contenu de consultation exploitable."
        )

    prompt = build_user_prompt(transcript, history, patient_context)
    backend = settings.llm_backend.strip().lower()

    if backend == "sonnet":
        # Pseudonymisation : on n'envoie QUE du texte sans identifiants directs.
        # Sans dossier patient, AUCUNE ancre (nom/prénom/naissance) n'existe :
        # le texte partirait au cloud avec les identifiants dits à l'oral.
        # Concerne les chemins outils (cli.py, bancs) — jamais l'app web.
        if patient is None:
            raise LLMError(
                "Backend cloud (sonnet) refusé sans dossier patient : la "
                "pseudonymisation n'aurait aucune ancre (nom/prénom/naissance). "
                "Utilisez LLM_BACKEND=ollama pour les outils en ligne de commande."
            )
        from ..pseudonymize import Pseudonymizer

        pseudo = Pseudonymizer.for_patient(patient)
        safe_prompt = pseudo.scrub(prompt)
        # Garde-fou egress (RGPD) : ultime vérification qu'aucun identifiant
        # certain du patient ne subsiste AVANT l'envoi au cloud (fail-safe).
        safe_prompt, leaked = pseudo.guard_certain(safe_prompt)
        if leaked:
            import logging
            logging.getLogger("podonote.pipeline").warning(
                "Garde-fou egress : %d identifiant(s) patient re-masqué(s) avant "
                "l'appel cloud (la pseudonymisation initiale en avait laissé passer).",
                len(leaked),
            )
        # Fail-safe générique : re-passe les filets regex (e-mail, tél., n° longs,
        # dates) sur le texte sortant. Nominalement sans effet (scrub les a déjà
        # appliqués) ; couvre tout résidu avant l'envoi au cloud.
        safe_prompt, masked_generic = pseudo.guard_generic(safe_prompt)
        if masked_generic:
            import logging
            logging.getLogger("podonote.pipeline").warning(
                "Garde-fou egress générique : résidu(s) de type e-mail/tél./n°/date "
                "re-masqué(s) avant l'appel cloud."
            )
        raw = _call_sonnet(safe_prompt, model, system_prompt=fiche.system_prompt)
        if not raw.strip():
            raise LLMError("Réponse vide du LLM (Sonnet).")
        recap = fiche.normalize(_extract_json(raw))
        # Réinjection des valeurs réelles dans la fiche produite.
        restored = pseudo.restore_obj(recap)
        # Qualité : un jeton altéré par le LLM (ex. « PRENOM_1 » sans guillemets)
        # ne peut plus être réinjecté — on le signale au lieu de le laisser
        # apparaître silencieusement dans la fiche.
        leftover = pseudo.residual_tokens(json.dumps(restored, ensure_ascii=False))
        if leftover:
            import logging
            logging.getLogger("podonote.pipeline").warning(
                "Réinjection incomplète : %d jeton(s) de pseudonymisation "
                "résiduel(s) dans la fiche (altérés par le LLM).", len(leftover),
            )
        return restored

    # Défaut : backend local Ollama.
    raw = _call_ollama(prompt, model, system_prompt=fiche.system_prompt)
    if not raw.strip():
        raise LLMError("Réponse vide du LLM.")
    return fiche.normalize(_extract_json(raw))


def check_llm() -> tuple[bool, str]:
    """Vérifie la disponibilité du backend LLM configuré."""
    backend = settings.llm_backend.strip().lower()
    if backend == "sonnet":
        from ..winsecret import get_anthropic_api_key

        if not get_anthropic_api_key():
            return False, "Backend Sonnet : ANTHROPIC_API_KEY absente."
        try:
            import anthropic  # noqa: F401
        except Exception:
            return False, "Backend Sonnet : paquet 'anthropic' non installé."
        return True, f"Sonnet OK ({settings.anthropic_model})"
    return check_ollama()
