"""Banque d'exercices à remettre au patient (étirements, mobilité, renforcement…).

Le praticien coche les exercices utiles → un seul PDF est généré (à imprimer ou à
enregistrer pour l'envoyer). Contenu 100 % TEXTE et générique (pas d'images ni de
protocole sous copyright — cf. la remarque de Nico sur Volodalen) : descriptions
rédigées, réutilisables librement. Catalogue de départ, à enrichir avec Nico.
"""
from __future__ import annotations

# Chaque exercice : clé stable, catégorie (regroupement UI/PDF), titre, description.
EXERCICES = [
    {"key": "etir_gastro", "categorie": "Étirements",
     "titre": "Étirement du mollet (gastrocnémiens)",
     "description": "Face à un mur, mains appuyées. La jambe à étirer est tendue en "
                    "arrière, talon au sol, pointe de pied vers le mur. Avancez le "
                    "bassin jusqu'à sentir l'étirement à l'arrière du mollet. "
                    "Tenez 30 secondes, 3 fois de chaque côté."},
    {"key": "etir_soleaire", "categorie": "Étirements",
     "titre": "Étirement du soléaire",
     "description": "Même position que pour le mollet, mais genou arrière LÉGÈREMENT "
                    "FLÉCHI, talon au sol. L'étirement se ressent plus bas, vers le "
                    "tendon d'Achille. Tenez 30 secondes, 3 fois de chaque côté."},
    {"key": "etir_aponevrose", "categorie": "Étirements",
     "titre": "Étirement de l'aponévrose plantaire",
     "description": "Assis, croisez la cheville sur le genou opposé. Saisissez les "
                    "orteils et tirez-les doucement vers vous jusqu'à sentir la tension "
                    "sous le pied. Tenez 30 secondes, 3 fois — surtout le matin avant "
                    "le premier pas."},
    {"key": "mob_cheville", "categorie": "Mobilité",
     "titre": "Mobilité de la cheville (alphabet)",
     "description": "Assis, jambe tendue. Dessinez lentement l'alphabet dans l'air avec "
                    "le gros orteil, en ne bougeant que la cheville. 1 à 2 passages "
                    "par pied."},
    {"key": "short_foot", "categorie": "Renforcement",
     "titre": "Renforcement de la voûte (« short foot »)",
     "description": "Pied à plat au sol. Sans crisper ni recroqueviller les orteils, "
                    "rapprochez la base du gros orteil vers le talon pour creuser "
                    "légèrement la voûte. Tenez 5 secondes, relâchez. 10 répétitions, "
                    "2 à 3 séries."},
    {"key": "serviette", "categorie": "Renforcement",
     "titre": "Ramassage de serviette",
     "description": "Assis, une serviette au sol sous le pied. Agrippez-la avec les "
                    "orteils pour la ramener vers vous, puis relâchez. 10 à 15 "
                    "répétitions par pied."},
    {"key": "orteils_ecart", "categorie": "Renforcement",
     "titre": "Écartement des orteils",
     "description": "Pied à plat, écartez les orteils les uns des autres sans décoller "
                    "le pied du sol, puis relâchez lentement. 10 répétitions."},
    {"key": "flechisseurs", "categorie": "Renforcement",
     "titre": "Attrape-objets avec les orteils",
     "description": "Posez de petits objets au sol (billes, stylo) et attrapez-les avec "
                    "les orteils pour les déposer dans une coupelle. 1 à 2 minutes "
                    "par pied."},
    {"key": "proprio_unipodal", "categorie": "Proprioception",
     "titre": "Équilibre sur une jambe",
     "description": "Debout, tenez-vous sur une seule jambe, regard devant, près d'un "
                    "appui en cas de besoin. Maintenez 30 secondes. Progression : yeux "
                    "fermés, ou sur un coussin. 3 fois de chaque côté."},
    {"key": "automassage", "categorie": "Auto-massage",
     "titre": "Auto-massage plantaire à la balle",
     "description": "Assis, faites rouler une balle (tennis ou spécifique) sous la "
                    "voûte plantaire, du talon vers les orteils, pendant 1 à 2 minutes "
                    "par pied. Idéal le matin ou après une station debout prolongée."},
    {"key": "etir_chaine_post", "categorie": "Étirements",
     "titre": "Étirement de la chaîne postérieure",
     "description": "Debout, jambes tendues, penchez-vous lentement vers l'avant en "
                    "gardant le dos long, mains vers les pieds, sans forcer. Vous "
                    "étirez l'arrière des jambes. Tenez 30 secondes, 3 fois, sans "
                    "à-coups."},
    {"key": "mob_orteils", "categorie": "Mobilité",
     "titre": "Mobilité du gros orteil",
     "description": "Assis, pied à plat. Décollez UNIQUEMENT le gros orteil en gardant "
                    "les autres au sol, puis inversez (gros orteil au sol, les autres "
                    "levés). Contrôlez le mouvement. 10 répétitions par pied."},
    {"key": "releve_talons", "categorie": "Renforcement",
     "titre": "Relevés de talons (mollets)",
     "description": "Debout, appui léger sur un plan de travail. Montez lentement sur "
                    "la pointe des pieds, tenez 2 secondes en haut, redescendez en "
                    "contrôlant. 12 à 15 répétitions, 2 à 3 séries. Progression : sur "
                    "une seule jambe."},
    {"key": "proprio_fentes", "categorie": "Proprioception",
     "titre": "Transferts d'appui contrôlés",
     "description": "Debout, pieds écartés largeur de bassin. Transférez lentement le "
                    "poids d'un pied sur l'autre, puis d'avant en arrière, en gardant "
                    "l'équilibre. 1 à 2 minutes, regard devant."},
]

_BY_KEY = {e["key"]: e for e in EXERCICES}


def exists(key: str) -> bool:
    return key in _BY_KEY


def selected(keys: list[str]) -> list[dict]:
    """Exercices correspondant aux clés (dans l'ordre du catalogue, sans doublon)."""
    wanted = set(keys or [])
    return [e for e in EXERCICES if e["key"] in wanted]


def by_category() -> list[tuple[str, list[dict]]]:
    """[(catégorie, [exercices])] dans l'ordre d'apparition — pour l'affichage."""
    order: list[str] = []
    groups: dict[str, list[dict]] = {}
    for e in EXERCICES:
        cat = e["categorie"]
        if cat not in groups:
            groups[cat] = []
            order.append(cat)
        groups[cat].append(e)
    return [(cat, groups[cat]) for cat in order]
