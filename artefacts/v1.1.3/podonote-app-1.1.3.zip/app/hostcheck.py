"""Vérifications de l'environnement hôte (chiffrement disque).

La base SQLite et les exports PDF sont en clair sur le disque : la protection
au repos repose entièrement sur BitLocker (choix d'archi documenté). Ce module
vérifie — en best effort, sans bloquer le démarrage — que le volume système est
bien protégé, pour afficher un avertissement persistant dans l'UI sinon
(poste Windows Home, BitLocker désactivé, etc.).
"""
from __future__ import annotations

import logging
import os
import subprocess
import threading

logger = logging.getLogger("podonote.hostcheck")

# None = indéterminé (vérification impossible : pas d'admin, hors Windows…) ;
# True = volume protégé ; False = volume NON protégé (avertir).
_bitlocker_protected: bool | None = None
_checked = False


def bitlocker_protected() -> bool | None:
    """Dernier état connu (rempli en arrière-plan par start_background_check)."""
    return _bitlocker_protected


def _query_bitlocker() -> bool | None:
    """Interroge l'état BitLocker du volume système. None si indéterminable.

    Get-BitLockerVolume exige souvent l'élévation : un échec n'est PAS traité
    comme « non protégé » (on ne crie pas au loup sans certitude)."""
    if os.name != "nt":
        return None
    cmd = [
        "powershell", "-NoProfile", "-NonInteractive", "-Command",
        "(Get-BitLockerVolume -MountPoint $env:SystemDrive).ProtectionStatus",
    ]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    out = (proc.stdout or "").strip().lower()
    # ProtectionStatus : 1/'on' = protégé ; 0/'off' = non protégé.
    if out in ("1", "on"):
        return True
    if out in ("0", "off"):
        return False
    return None


def start_background_check() -> None:
    """Lance la vérification dans un thread (PowerShell peut prendre des secondes)."""
    global _checked
    if _checked:
        return
    _checked = True

    def _run() -> None:
        global _bitlocker_protected
        _bitlocker_protected = _query_bitlocker()
        if _bitlocker_protected is False:
            logger.warning(
                "BitLocker INACTIF sur le volume système : la base patients et "
                "les exports PDF ne sont pas chiffrés au repos."
            )
        elif _bitlocker_protected is None:
            logger.info("État BitLocker indéterminable (droits insuffisants ?).")

    threading.Thread(target=_run, daemon=True, name="podonote-hostcheck").start()
