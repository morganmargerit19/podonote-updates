"""Lanceur « application de bureau » de PodoNote.

Démarre le serveur web local (FastAPI/uvicorn) en arrière-plan puis ouvre
l'interface dans **sa propre fenêtre** (WebView2, intégré à Windows 11), sans
onglet de navigateur visible. Le serveur écoute aussi sur le réseau local
(0.0.0.0) afin que l'upload depuis l'iPhone continue de fonctionner.

Robustesse (lancé via pythonw, sans console) : tout est journalisé dans
data/desktop.log, ET en cas d'échec un **rapport de diagnostic lisible est
déposé sur le Bureau** (PodoNote-diagnostic.txt) — donc plus besoin d'aller
fouiller un dossier caché. La cause exacte d'un plantage du serveur (traceback,
dépendance manquante…) y figure. Si WebView2 est absent, repli automatique sur
le navigateur par défaut.

Réglages par variable d'environnement :
  PODONOTE_START_TIMEOUT : délai max d'attente du serveur en secondes (défaut 300).
  PODONOTE_NO_WINDOW=1   : mode serveur seul (debug), sans fenêtre.

Lancement : python -m app.desktop  (ou pythonw -m app.desktop, sans console)
"""
from __future__ import annotations

import datetime
import logging
import os
import platform
import socket
import sys
import threading
import time
import traceback
import webbrowser

from .config import BASE_DIR, DATA_DIR, STATIC_DIR, ensure_dirs, settings

LOG_PATH = DATA_DIR / "desktop.log"
log = logging.getLogger("podonote.desktop")

_server = None            # référence au serveur uvicorn (pour l'arrêt propre)
_server_error: str | None = None  # traceback du serveur s'il a planté au démarrage

# Délai d'attente du serveur. Allongé (vieux PC à disque mécanique : démarrage à
# froid lent) et surchargeable par env. On détecte de toute façon un VRAI
# plantage en quelques secondes (cf. _wait_until_up), donc ce délai ne pénalise
# que les démarrages réellement lents.
START_TIMEOUT = float(os.environ.get("PODONOTE_START_TIMEOUT", "300"))


def _ensure_std_streams() -> None:
    """Garantit que sys.stdout / sys.stderr existent (lancement via pythonw).

    Sans console, pythonw.exe laisse sys.stdout et sys.stderr à None. Or uvicorn
    (formateur de logs par défaut) appelle sys.stdout.isatty() → AttributeError
    « 'NoneType' object has no attribute 'isatty' », ce qui empêche TOUT démarrage
    du serveur. On branche donc les flux manquants sur le « trou noir » système
    (isatty() y renvoie False, comportement attendu hors terminal).
    """
    try:
        devnull = open(os.devnull, "w", encoding="utf-8")
    except Exception:
        return
    if sys.stdout is None:
        sys.stdout = devnull
    if sys.stderr is None:
        sys.stderr = devnull


# Identité d'application Windows (AppUserModelID). À DÉFAUT, le bouton de la barre
# des tâches hérite de l'identité du processus hôte (pythonw.exe) et affiche SON
# icône (le logo Python), alors même que la fenêtre porte bien l'icône PodoNote.
# La poser AVANT toute création de fenêtre fait afficher l'icône de la fenêtre
# (static/podonote.ico) dans la barre des tâches. Doit rester STABLE entre versions
# et identique à l'AppUserModelID des raccourcis (installer/PodoNote.iss) pour que
# la fenêtre et un raccourci épinglé ne forment qu'un seul bouton.
# Identifiant technique de barre des tâches : DOIT rester aligné avec le
# raccourci créé par l'installeur Windows existant — le renommage visuel
# Diktae ne change pas cet ID (chantier packaging séparé).
APP_USER_MODEL_ID = "StudioMargerit.PodoNote"


def _set_app_user_model_id() -> None:
    """Donne au process sa propre identité de barre des tâches (Windows uniquement)."""
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
    except Exception:
        log.exception("AppUserModelID non posé (non bloquant).")


def _setup_logging() -> None:
    ensure_dirs()
    handler = logging.FileHandler(str(LOG_PATH), encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)


def _message_box(text: str, title: str = "Diktae") -> None:
    """Boîte de dialogue Windows (utile sans console). Silencieuse si indisponible."""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)  # MB_ICONERROR
    except Exception:
        log.exception("Impossible d'afficher la boîte de dialogue.")


# --------------------------------------------------------------------------- #
# Rapport de diagnostic sur le Bureau (pour ne PAS dépendre d'un fichier caché)
# --------------------------------------------------------------------------- #
def _desktop_dir():
    """Meilleur emplacement « visible » : Bureau (gère la redirection OneDrive)."""
    candidates = []
    up = os.environ.get("USERPROFILE")
    one = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
    if one:
        candidates.append(os.path.join(one, "Desktop"))
    if up:
        candidates.append(os.path.join(up, "Desktop"))
    for c in candidates:
        if os.path.isdir(c):
            return c
    # Replis : racine du profil, sinon dossier data.
    if up and os.path.isdir(up):
        return up
    return str(DATA_DIR)


def _tail(path, n: int = 150) -> str:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-n:]) if lines else "(vide)"
    except Exception:
        return "(absent ou illisible)"


def _redact(text: str) -> str:
    """Caviarde les noms de fichiers audio dans un extrait de log : ce rapport
    promet « aucune donnée patient », or les logs des versions précédentes
    citaient des chemins incoming/ dont le nom contenait l'identité du patient."""
    import re
    return re.sub(
        r"(incoming[\\/])[^\s'\"]+",
        r"\1[audio caviardé]",
        text or "",
        flags=re.IGNORECASE,
    )


def _write_report(reason: str) -> str | None:
    """Écrit PodoNote-diagnostic.txt sur le Bureau (+ copie dans data/). Renvoie le chemin."""
    try:
        from . import __version__ as ver
    except Exception:
        ver = "?"
    parts = [
        "================================================================",
        "  Diktae — rapport de diagnostic",
        "  => Merci d'envoyer CE fichier a Studio Margerit (Morgan).",
        "     Il ne contient AUCUNE donnee patient, juste l'erreur technique.",
        "================================================================",
        f"Date    : {datetime.datetime.now():%Y-%m-%d %H:%M:%S}",
        f"Version : {ver}",
        f"Python  : {sys.version.split()[0]} — {sys.executable}",
        f"Systeme : {platform.platform()}",
        f"Dossier : {BASE_DIR}",
        f"Cause   : {reason}",
    ]
    if _server_error:
        parts += ["", "---- Erreur du serveur (CAUSE PROBABLE) ----", _redact(_server_error)]
    parts += ["", "---- desktop.log (fin) ----", _redact(_tail(LOG_PATH))]
    parts += ["", "---- podonote.log (fin) ----", _redact(_tail(DATA_DIR / "podonote.log"))]
    parts += ["", "---- install.log (fin) ----", _redact(_tail(BASE_DIR / "install.log"))]
    content = "\n".join(parts)

    written = None
    for folder in (_desktop_dir(), str(DATA_DIR)):
        try:
            p = os.path.join(folder, "Diktae-diagnostic.txt")
            with open(p, "w", encoding="utf-8") as f:
                f.write(content)
            if written is None:
                written = p
        except Exception:
            log.exception("Écriture du rapport impossible dans %s", folder)
    return written


def _port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def _wait_until_up(port: int, timeout: float, thread: threading.Thread | None = None) -> bool:
    """Attend que le serveur réponde sur 127.0.0.1:port.

    Sort TÔT si le serveur a planté (inutile d'attendre tout le délai pour un
    échec certain) : soit `_server_error` est renseigné, soit le thread serveur
    s'est terminé sans que le port n'écoute.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _port_in_use("127.0.0.1", port):
            return True
        if _server_error:
            return False
        if thread is not None and not thread.is_alive():
            # Le thread s'est arrêté ; un dernier coup d'œil au port par sécurité.
            return _port_in_use("127.0.0.1", port)
        time.sleep(0.3)
    return False


def _run_server() -> None:
    global _server, _server_error
    try:
        import uvicorn
        # log_config=None : on n'utilise pas le formateur de logs d'uvicorn (qui
        # sonde sys.stdout.isatty() et plante sous pythonw) ; notre logging fichier
        # est déjà en place. Double sécurité avec _ensure_std_streams().
        config = uvicorn.Config(
            "app.main:app", host=settings.host, port=settings.port,
            log_level="warning", log_config=None,
        )
        _server = uvicorn.Server(config)
        _server.run()
    except Exception:
        # Capture la cause EXACTE (import d'une dépendance manquante, etc.) pour
        # la faire remonter dans le rapport, sans dépendre du journal caché.
        _server_error = traceback.format_exc()
        log.exception("Le serveur n'a pas pu démarrer / s'est arrêté sur une erreur.")


def _idle_until_stop(server_thread: threading.Thread | None = None) -> None:
    """Garde le process vivant (repli navigateur) tant que le serveur tourne.

    Sort aussi si le THREAD serveur est mort ou si une erreur a été capturée :
    sinon, un uvicorn tombé sur exception laisse un process pythonw fantôme
    (port fermé, et un relancement croit l'app « déjà ouverte »)."""
    try:
        while _server is None or not getattr(_server, "should_exit", False):
            if _server_error:
                return
            if server_thread is not None and not server_thread.is_alive():
                return
            time.sleep(1)
    except KeyboardInterrupt:
        pass


def _webview2_available() -> bool:
    """True si le runtime Microsoft Edge WebView2 est installé.

    CRUCIAL : sans ce runtime (vieux PC), pywebview NE LÈVE PAS d'erreur — il
    bascule en silence sur le moteur déprécié MSHTML/IE11 qui n'affiche pas l'UI
    moderne (fenêtre blanche, aucun diagnostic). On détecte donc le runtime AVANT
    de tenter la fenêtre, et à défaut on ouvre directement le navigateur.
    Détection par la clé de version (pv) d'EdgeUpdate. Réf. Microsoft.
    """
    if os.name != "nt":
        return True
    try:
        import winreg
    except Exception:
        return True  # hors Windows / indéterminé : on laisse la suite décider
    guid = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
    subkey = rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{guid}"
    candidates = [
        (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY),  # Evergreen 64 bits -> WOW6432Node
        (winreg.HKEY_LOCAL_MACHINE, 0),
        (winreg.HKEY_CURRENT_USER, 0),
    ]
    for root, extra in candidates:
        try:
            with winreg.OpenKey(root, subkey, 0, winreg.KEY_READ | extra) as k:
                pv, _ = winreg.QueryValueEx(k, "pv")
                if pv and str(pv) not in ("", "0.0.0.0"):
                    return True
        except OSError:
            continue
    return False


def _window_icon() -> str | None:
    """Chemin de l'icône PodoNote pour la fenêtre native (sinon None)."""
    ico = STATIC_DIR / "podonote.ico"
    return str(ico) if ico.exists() else None


def _start_webview() -> None:
    """Lance la boucle pywebview en posant l'icône PodoNote sur la fenêtre.

    Sans icône explicite, la fenêtre WebView2 hérite de celle du processus
    (pythonw.exe) → un logo Python s'affiche en haut à gauche. On passe donc
    notre .ico à webview.start(icon=...). Repli silencieux si l'argument n'est
    pas supporté par la version de pywebview installée (TypeError)."""
    import webview
    icon = _window_icon()
    if icon:
        try:
            webview.start(icon=icon)
            return
        except TypeError:
            log.warning("pywebview ne supporte pas l'argument icon — fenêtre sans icône dédiée.")
    webview.start()


def _open_in_browser(url: str, server_thread: threading.Thread | None = None) -> None:
    log.info("Ouverture dans le navigateur par défaut : %s", url)
    opened = False
    try:
        opened = webbrowser.open(url)
    except Exception:
        log.exception("webbrowser.open a échoué.")
    if not opened:
        # Aucun navigateur n'a pu être lancé : on donne l'URL à coller.
        _message_box(
            "Diktae a démarré, mais aucun navigateur n'a pu être ouvert "
            f"automatiquement.\n\nOuvrez votre navigateur et allez à :\n{url}",
            "Diktae",
        )
    _idle_until_stop(server_thread)


def main() -> int:
    _ensure_std_streams()
    _setup_logging()
    _set_app_user_model_id()  # avant toute fenêtre : icône PodoNote dans la barre des tâches
    log.info("Démarrage de Diktae (bureau). Version=%s Python=%s", _safe_ver(), sys.executable)
    try:
        return _run()
    except Exception as exc:  # filet de dernier recours : jamais de mort muette
        log.exception("Échec inattendu au démarrage.")
        report = _write_report(f"Erreur inattendue au démarrage : {exc}")
        _message_box(
            "Diktae n'a pas pu démarrer.\n\n"
            + (f"Un rapport a été déposé sur votre Bureau :\n{os.path.basename(report)}\n"
               "Merci de l'envoyer à Studio Margerit.\n\n" if report else "")
            + f"Détail : {exc}"
        )
        return 1


def _safe_ver() -> str:
    try:
        from . import __version__
        return __version__
    except Exception:
        return "?"


def _run() -> int:
    url = f"http://localhost:{settings.port}"

    # Déjà lancé ? (port occupé avant qu'on démarre notre propre serveur) :
    # plutôt que d'échouer, on ouvre une fenêtre/onglet sur l'instance existante.
    if _port_in_use("127.0.0.1", settings.port):
        log.warning("Port %s déjà occupé — Diktae semble déjà ouvert ; on l'ouvre.", settings.port)
        if not os.environ.get("PODONOTE_NO_WINDOW") and _webview2_available():
            try:
                import webview
                webview.create_window("Diktae", url=url, width=1180, height=820,
                                      min_size=(900, 640))
                _start_webview()
                return 0
            except Exception:
                log.exception("Ouverture de l'instance existante en fenêtre impossible — navigateur.")
        # Instance déjà en service : on ouvre un onglet et ce process peut sortir.
        try:
            webbrowser.open(url)
        except Exception:
            log.exception("webbrowser.open a échoué (instance existante).")
        return 0

    server_thread = threading.Thread(target=_run_server, daemon=True, name="podonote-server")
    server_thread.start()

    if not _wait_until_up(settings.port, START_TIMEOUT, server_thread):
        # Distingue un PLANTAGE (cause connue → on la donne) d'une LENTEUR.
        if _server_error or not server_thread.is_alive():
            reason = "Le serveur web a planté au démarrage (dépendance manquante ?)."
        else:
            reason = f"Le serveur n'a pas répondu dans le délai imparti ({int(START_TIMEOUT)} s)."
        log.error(reason)
        report = _write_report(reason)
        _message_box(
            "Diktae n'a pas réussi à démarrer.\n\n"
            + (f"Un rapport vient d'être déposé sur votre Bureau :\n"
               f"« {os.path.basename(report)} »\n"
               "Merci de l'envoyer à Studio Margerit (Morgan) : il contient la\n"
               "cause exacte, sans aucune donnée patient.\n\n" if report else "")
            + "Vous pouvez aussi réessayer en double-cliquant à nouveau sur l'icône.",
        )
        return 1
    log.info("Serveur prêt sur %s", url)

    # Mode serveur seul (tests / dépannage) : pas de fenêtre.
    if os.environ.get("PODONOTE_NO_WINDOW"):
        print(f"Diktae (serveur seul) sur {url}")
        _idle_until_stop(server_thread)
        return 0

    # Fenêtre native (WebView2). Si le runtime WebView2 est ABSENT, on ne tente
    # même pas la fenêtre (sinon écran blanc silencieux) : repli navigateur direct.
    if not _webview2_available():
        log.warning("Runtime WebView2 absent — repli direct sur le navigateur "
                    "(l'app fonctionne, mais dans un onglet plutôt qu'en fenêtre dédiée).")
        _open_in_browser(url)
        return 0

    try:
        import webview
    except Exception:
        log.exception("pywebview indisponible — repli navigateur.")
        _open_in_browser(url)
        return 0
    log.info("Runtime WebView2 détecté — ouverture de la fenêtre native.")

    def _on_closed():
        log.info("Fenêtre fermée — arrêt du serveur.")
        if _server is not None:
            _server.should_exit = True

    try:
        window = webview.create_window(
            "Diktae", url=url, width=1180, height=820, min_size=(900, 640),
        )
        try:
            window.events.closed += _on_closed
        except Exception:
            log.exception("Abonnement à l'événement de fermeture impossible (non bloquant).")
        _start_webview()
    except Exception:
        log.exception("Échec de la fenêtre WebView2 — repli navigateur.")
        _message_box(
            "Impossible d'ouvrir la fenêtre Diktae (composant Microsoft Edge WebView2 manquant ?).\n"
            "Diktae va s'ouvrir dans votre navigateur.\n\n"
            "Pour la fenêtre dédiée, installez WebView2 :\n"
            "https://go.microsoft.com/fwlink/p/?LinkId=2124703",
            "Diktae",
        )
        _open_in_browser(url)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
