"""Système de licence (abonnement mensuel) — vérification côté app.

Modèle hybride : un serveur Studio Margerit (hors app) émet un JETON SIGNÉ
(Ed25519) valable ~35 jours, mis en cache localement. L'app vérifie la signature
avec la CLÉ PUBLIQUE embarquée ci-dessous, contrôle l'expiration, et tolère une
courte période de grâce. Aucune donnée de santé n'intervient ici.

Format du jeton : "<base64url(payload_json)>.<base64url(signature)>"
payload = {"licensee","plan","iat","exp"(unix s),"machine"(optionnel)}
"""
from __future__ import annotations

import base64
import json
import time
from typing import Any, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .config import DATA_DIR, ensure_dirs

# Clé publique de Studio Margerit (la clé privée signe les licences, hors app).
PUBLIC_KEY_B64 = "4BtFnPdW+EjMlukFYI+xUa4oPKBurvDV566V0sWsB7g="

LICENSE_FILE = DATA_DIR / "license.json"
GRACE_DAYS = 7
_DAY = 86400

# Formules connues, encodées sur 1 octet dans le jeton compact (gain de place).
PLAN_CODES = {0: "mensuel", 1: "annuel", 2: "dev", 3: "essai", 4: "trimestriel"}
PLAN_IDS = {v: k for k, v in PLAN_CODES.items()}
_FMT_COMPACT = 2  # 1er octet de la charge utile binaire (distingue du JSON hérité)


# --------------------------------------------------------------------------- #
# base64url
# --------------------------------------------------------------------------- #
def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def b64u_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _public_key() -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))


# --------------------------------------------------------------------------- #
# Charge utile COMPACTE (binaire) — jeton bien plus court que l'ancien JSON.
# Format : [0]=2  [1]=code formule  [2:6]=exp en JOURS unix (uint32 BE)  [6:]=titulaire UTF-8
# La signature Ed25519 (64 o) reste le gros du jeton : incompressible hors-ligne.
# --------------------------------------------------------------------------- #
def encode_payload(licensee: str, plan: str, exp_unix: int) -> str:
    code = PLAN_IDS.get(plan, 0)
    exp_days = int(exp_unix) // _DAY
    raw = bytes([_FMT_COMPACT, code]) + exp_days.to_bytes(4, "big") + (licensee or "").encode("utf-8")
    return b64u_encode(raw)


def _decode_payload(raw: bytes) -> dict[str, Any]:
    """Décode une charge utile compacte (v2) OU l'ancien JSON (rétrocompat)."""
    if len(raw) >= 6 and raw[0] == _FMT_COMPACT:
        return {
            "plan": PLAN_CODES.get(raw[1], str(raw[1])),
            "exp": int.from_bytes(raw[2:6], "big") * _DAY,
            "licensee": raw[6:].decode("utf-8", "replace") or "—",
        }
    return json.loads(raw)  # jeton hérité (JSON)


# --------------------------------------------------------------------------- #
# Exigence de licence (au niveau du CODE, pas du .env) : se propage par OTA,
# contrairement au .env qui n'est jamais redistribué. Échappatoire pour le
# développement et les tests via la variable d'environnement PODONOTE_NO_LICENSE.
# --------------------------------------------------------------------------- #
def is_enforced() -> bool:
    import os
    return not os.environ.get("PODONOTE_NO_LICENSE")


# --------------------------------------------------------------------------- #
# Identifiant machine (binding optionnel, anonyme)
# --------------------------------------------------------------------------- #
def _machine_guid() -> Optional[str]:
    """MachineGuid Windows (stable, survit aux changements de carte réseau)."""
    import os
    if os.name != "nt":
        return None
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
            0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
        ) as k:
            val, _ = winreg.QueryValueEx(k, "MachineGuid")
            return str(val)
    except Exception:
        return None


def machine_id() -> str:
    import hashlib
    import platform
    import uuid
    # MachineGuid en priorité (stable) ; repli node()+MAC si indisponible.
    raw = _machine_guid() or f"{platform.node()}|{uuid.getnode()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


# --------------------------------------------------------------------------- #
# Vérification d'un jeton
# --------------------------------------------------------------------------- #
def machine_display(mid: str | None = None) -> str:
    """Présentation Diktae de l'identifiant machine : « DKT-XXXX-XXXX-XXXX-XXXX ».

    Pur AFFICHAGE : le calcul (machine_id) et le flux d'émission de licence sont
    inchangés — les clés déjà émises restent valables. Les tirets/le préfixe
    sont ignorés à la saisie côté support (l'hex sous-jacent suffit).
    """
    raw = (mid or machine_id()).upper()
    groups = [raw[i:i + 4] for i in range(0, len(raw), 4)]
    return "DKT-" + "-".join(groups)


def verify_token(token: str) -> tuple[bool, str, Optional[dict[str, Any]]]:
    """Vérifie la signature et le format. Renvoie (signature_ok, raison, payload).

    Ne juge PAS l'expiration ici (gérée par get_status) — seulement l'authenticité.
    """
    try:
        payload_b64, sig_b64 = token.strip().split(".")
    except ValueError:
        return False, "Format de clé invalide.", None
    try:
        sig = _b64u_decode(sig_b64)
        _public_key().verify(sig, payload_b64.encode("ascii"))
    except InvalidSignature:
        return False, "Signature invalide (clé non émise par Studio Margerit).", None
    except Exception:
        return False, "Clé illisible.", None
    try:
        payload = _decode_payload(_b64u_decode(payload_b64))
    except Exception:
        return False, "Contenu de clé illisible.", None
    if not isinstance(payload, dict):
        return False, "Contenu de clé invalide.", None
    # Binding machine optionnel
    if payload.get("machine") and payload["machine"] != machine_id():
        return False, "Cette clé est liée à un autre ordinateur.", None
    return True, "OK", payload


# --------------------------------------------------------------------------- #
# Stockage / statut
# --------------------------------------------------------------------------- #
def _load() -> Optional[str]:
    if not LICENSE_FILE.exists():
        return None
    try:
        return json.loads(LICENSE_FILE.read_text(encoding="utf-8")).get("token")
    except Exception:
        return None


def activate(token: str) -> tuple[bool, str]:
    """Vérifie puis enregistre le jeton. Renvoie (succès, message)."""
    ok, reason, payload = verify_token(token)
    if not ok:
        return False, reason
    if payload.get("exp", 0) + GRACE_DAYS * _DAY < time.time():
        return False, "Cette clé est déjà expirée."
    ensure_dirs()
    LICENSE_FILE.write_text(json.dumps({"token": token.strip()}, indent=2), encoding="utf-8")
    return True, "Licence activée."


def get_status() -> dict[str, Any]:
    """État courant : state ∈ none|invalid|active|grace|expired (+ détails)."""
    token = _load()
    if not token:
        return {"state": "none"}
    ok, reason, payload = verify_token(token)
    if not ok:
        return {"state": "invalid", "reason": reason}
    now = time.time()
    exp = payload.get("exp", 0)
    days_left = int((exp - now) // _DAY)
    base = {
        "licensee": payload.get("licensee", "—"),
        "plan": payload.get("plan", "—"),
        "exp_unix": exp,
        "days_left": days_left,
    }
    if now < exp:
        return {"state": "active", **base}
    if now < exp + GRACE_DAYS * _DAY:
        base["grace_days_left"] = int((exp + GRACE_DAYS * _DAY - now) // _DAY)
        return {"state": "grace", **base}
    return {"state": "expired", **base}


def is_allowed() -> bool:
    """True si l'app peut fonctionner (active ou en période de grâce)."""
    return get_status().get("state") in ("active", "grace")
