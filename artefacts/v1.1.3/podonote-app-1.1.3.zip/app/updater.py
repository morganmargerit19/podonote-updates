"""Mise à jour à distance de PodoNote (vérification + téléchargement + bascule).

Principe
--------
L'installation lourde (Python `.venv`, ffmpeg, modèles ML) ne change quasiment
jamais entre deux versions ; seul le **code applicatif** évolue et il est léger.
Une mise à jour consiste donc à remplacer `app/`, `templates/`, `static/`… SANS
refaire l'installation des 15-40 min. `pip install` n'est relancé que si
`requirements.txt` a changé (détecté par empreinte).

Sécurité
--------
- Le paquet (.zip) ne contient QUE du code — jamais le `.env`/la clé API, jamais
  les données patient, jamais le `.venv`.
- Le **manifest est signé Ed25519** avec la clé privée de Studio Margerit (la
  même que les licences). La clé publique est embarquée (`app/license.py`). Un
  manifest trafiqué ou un paquet altéré (empreinte SHA-256 signée) est REJETÉ.
- Anti-retour arrière : on n'applique que des versions STRICTEMENT supérieures.

Tout est défensif : aucune erreur réseau/parse ne doit faire planter l'app.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import Any, Optional

from . import __version__
from .config import BASE_DIR, DATA_DIR, ensure_dirs, settings
from .license import _b64u_decode  # réutilise l'infra Ed25519 existante

# --- Clés publiques acceptées pour les MANIFESTS DE MISE À JOUR -------------- #
# Séparation des rôles (audit 2026-06-12) : la clé historique signe à la fois
# licences et mises à jour, et vit sur le serveur de licence (en ligne) — une
# compromission de ce serveur permettrait de pousser du code sur tous les
# postes. Transition : on accepte ICI la clé historique ET une clé dédiée aux
# updates (générée hors ligne par scripts/gen_update_keys.py, jamais chargée
# par le serveur de licence). Une fois tous les postes à jour, signer les
# manifests avec la clé dédiée puis RETIRER la clé historique de cette liste.
UPDATE_PUBLIC_KEYS_B64: tuple[str, ...] = (
    "4BtFnPdW+EjMlukFYI+xUa4oPKBurvDV566V0sWsB7g=",  # clé historique (licences)
    "RI6CmxkEeCfzGBhzuetQ6P+ariJnJUsx1HxmM7QWDJ4=",  # clé update dédiée (2026-06-12)
)

log = logging.getLogger("podonote.updater")

# --------------------------------------------------------------------------- #
# Constantes de diffusion
# --------------------------------------------------------------------------- #
# Repo PUBLIC dédié aux paquets de mise à jour (le code source reste privé).
# Surchargeable pour valider le cycle de mise à jour sur un dépôt de TEST sans
# exposer les postes en production :
#   - .env :   UPDATES_REPO=user/podonote-updates-test   (settings.updates_repo)
#   - ou env : PODONOTE_UPDATES_REPO=...                  (priorité, pour CI/ponctuel)
# Vide / absent → dépôt de prod.
UPDATES_REPO = (
    os.environ.get("PODONOTE_UPDATES_REPO", "").strip()
    or (settings.updates_repo or "").strip()
    or "morganmargerit19/podonote-updates"
)
# URL STABLE : "releases/latest/download/<asset>" pointe toujours vers le dernier
# release publié → l'app n'a pas besoin de connaître le numéro de version à venir.
MANIFEST_URL = f"https://github.com/{UPDATES_REPO}/releases/latest/download/manifest.json"

# Fenêtre de cache de la vérification automatique (évite de cogner le réseau à
# chaque chargement de page). Surchargée par PODONOTE_UPDATE_INTERVAL (secondes).
CHECK_INTERVAL_S = int(os.environ.get("PODONOTE_UPDATE_INTERVAL", str(6 * 3600)))

_CACHE_FILE = DATA_DIR / "update_check.json"
_TMP_DIR = DATA_DIR / "update_tmp"
_BACKUP_DIR = DATA_DIR / "update_backup"
_HTTP_TIMEOUT = 20.0
# Plafonds de sécurité (défense en profondeur, en plus de signature + empreinte).
_MAX_ZIP_BYTES = 200 * 1024 * 1024          # paquet téléchargé : 200 Mo
_MAX_UNCOMPRESSED_BYTES = 800 * 1024 * 1024  # contenu décompressé : 800 Mo
# Hôtes autorisés pour l'URL de téléchargement (le manifest est signé, mais on
# refuse par principe toute URL qui ne pointe pas vers GitHub Releases).
_ALLOWED_HOSTS = ("github.com", "objects.githubusercontent.com",
                  "release-assets.githubusercontent.com", "codeload.github.com")


# --------------------------------------------------------------------------- #
# Comparaison de versions (semver simple "x.y.z", tolérant)
# --------------------------------------------------------------------------- #
def _ver_tuple(v: str) -> tuple[int, ...]:
    parts = []
    for chunk in str(v).strip().split(".")[:4]:
        num = ""
        for ch in chunk:
            if ch.isdigit():
                num += ch
            else:
                break
        parts.append(int(num) if num else 0)
    return tuple(parts) or (0,)


def is_newer(candidate: str, current: str) -> bool:
    """True si `candidate` est strictement plus récent que `current`."""
    return _ver_tuple(candidate) > _ver_tuple(current)


def current_version() -> str:
    return __version__


# --------------------------------------------------------------------------- #
# Vérification de la signature du manifest
# --------------------------------------------------------------------------- #
def _verify_any_key(payload_b64: str, sig_b64: str) -> bool:
    """True si la signature est valide pour AU MOINS une clé update acceptée."""
    import base64

    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        sig = _b64u_decode(sig_b64)
        data = payload_b64.encode("ascii")
    except Exception:
        return False
    for pub_b64 in UPDATE_PUBLIC_KEYS_B64:
        try:
            Ed25519PublicKey.from_public_bytes(base64.b64decode(pub_b64)).verify(sig, data)
            return True
        except Exception:
            continue
    return False


def verify_manifest(raw_text: str) -> tuple[bool, str, Optional[dict[str, Any]]]:
    """Vérifie un manifest signé. Renvoie (ok, raison, payload).

    Format attendu : {"payload": "<b64url(json)>", "sig": "<b64url(signature)>"}.
    La signature couvre la chaîne `payload` exacte (mêmes octets ASCII).
    """
    try:
        obj = json.loads(raw_text)
        payload_b64 = obj["payload"]
        sig_b64 = obj["sig"]
    except Exception:
        return False, "Manifest illisible.", None
    if not _verify_any_key(payload_b64, sig_b64):
        return False, "Signature invalide (manifest non émis par Studio Margerit).", None
    try:
        payload = json.loads(_b64u_decode(payload_b64))
    except Exception:
        return False, "Contenu du manifest illisible.", None
    if not isinstance(payload, dict) or "version" not in payload:
        return False, "Manifest incomplet.", None
    return True, "OK", payload


# --------------------------------------------------------------------------- #
# Cache de l'état (pour l'affichage instantané du bandeau, sans réseau)
# --------------------------------------------------------------------------- #
def _read_cache() -> dict[str, Any]:
    try:
        return json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_cache(data: dict[str, Any]) -> None:
    try:
        ensure_dirs()
        _CACHE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        log.exception("Écriture du cache de mise à jour impossible.")


def cached_status() -> dict[str, Any]:
    """État connu sans appel réseau (pour le bandeau / l'UI). Toujours instantané.

    `available` est TOUJOURS réévalué contre la version réellement installée : sans
    ça, après une mise à jour, un résultat en cache (« vX disponible », écrit quand
    on était sur une version antérieure) continuerait d'afficher le bandeau alors
    qu'on est DÉJÀ en vX. On compare donc la version du cache à current_version()."""
    cache = _read_cache()
    result = cache.get("result") or {"available": False}
    result["current"] = current_version()
    result["checked_at"] = cache.get("checked_at")
    ver = result.get("version")
    result["available"] = bool(ver) and is_newer(ver, current_version())
    return result


# --------------------------------------------------------------------------- #
# Vérification en ligne
# --------------------------------------------------------------------------- #
def check_for_update(force: bool = False) -> dict[str, Any]:
    """Interroge le manifest distant et met le cache à jour.

    `force=False` respecte la fenêtre de cache (CHECK_INTERVAL_S) pour la vérif
    automatique ; le bouton manuel passe `force=True`. Ne lève jamais : en cas
    d'échec réseau, renvoie le dernier état connu enrichi d'un champ `error`.
    """
    cache = _read_cache()
    last = cache.get("checked_at") or 0
    if not force and (time.time() - last) < CHECK_INTERVAL_S and cache.get("result"):
        return cached_status()

    try:
        import httpx

        resp = httpx.get(MANIFEST_URL, timeout=_HTTP_TIMEOUT, follow_redirects=True)
        resp.raise_for_status()
        ok, reason, payload = verify_manifest(resp.text)
        if not ok:
            log.warning("Manifest de mise à jour rejeté : %s", reason)
            result = {"available": False, "error": reason}
        else:
            available = is_newer(payload["version"], current_version())
            result = {
                "available": available,
                "version": payload.get("version"),
                "notes": payload.get("notes", ""),
                "pub_date": payload.get("pub_date", ""),
                "url": payload.get("url", ""),
                "sha256": payload.get("sha256", ""),
                "requirements_sha256": payload.get("requirements_sha256", ""),
            }
    except Exception as exc:  # réseau coupé, GitHub indispo, etc. → silencieux
        log.info("Vérification de mise à jour impossible (réseau ?) : %s", exc)
        prev = cache.get("result") or {"available": False}
        prev["error"] = "Vérification impossible (connexion Internet ?)."
        result = prev

    _write_cache({"checked_at": int(time.time()), "result": result})
    return cached_status()


# --------------------------------------------------------------------------- #
# Téléchargement + mise en attente (staging) du paquet
# --------------------------------------------------------------------------- #
def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download_and_stage(payload: dict[str, Any]) -> Path:
    """Télécharge le zip, vérifie l'empreinte signée, l'extrait dans un dossier.

    Renvoie le chemin du dossier extrait (l'arborescence applicative : app/,
    templates/, static/…). Lève en cas d'échec (l'appelant gère le message).
    """
    import httpx

    from urllib.parse import urlparse

    url = payload.get("url")
    expected = (payload.get("sha256") or "").lower()
    if not url or not expected:
        raise ValueError("Manifest sans URL ou empreinte — mise à jour refusée.")
    # Allowlist d'hôte : même si le manifest est signé, on refuse toute URL hors
    # GitHub Releases (défense en profondeur contre un manifest forgé/altéré).
    host = (urlparse(url).hostname or "").lower()
    if host not in _ALLOWED_HOSTS:
        raise ValueError(f"Hôte de téléchargement non autorisé : {host}")

    ensure_dirs()
    if _TMP_DIR.exists():
        # PAS de ignore_errors : si un reste d'extraction précédente est
        # verrouillé (antivirus/indexeur), extraire par-dessus mélangerait deux
        # versions (un fichier supprimé de la nouvelle version ressusciterait).
        # Mieux vaut un échec propre et un nouvel essai plus tard.
        try:
            shutil.rmtree(_TMP_DIR)
        except OSError as exc:
            raise ValueError(
                "Impossible de nettoyer le dossier temporaire de mise à jour "
                f"({exc.strerror or exc}). Réessayez dans quelques instants."
            ) from exc
    _TMP_DIR.mkdir(parents=True, exist_ok=True)

    # Téléchargement avec PLAFOND de taille (anti-déni de service / disque plein).
    zip_path = _TMP_DIR / "package.zip"
    total = 0
    with httpx.stream("GET", url, timeout=120.0, follow_redirects=True) as resp:
        resp.raise_for_status()
        # L'allowlist a validé l'URL de départ ; on re-valide l'hôte FINAL après
        # redirections (sinon une 30x peut emmener le téléchargement n'importe
        # où — le contenu reste protégé par le SHA-256 signé, mais le contrôle
        # d'hôte ne doit pas être contournable).
        final_host = (resp.url.host or "").lower()
        if final_host not in _ALLOWED_HOSTS:
            raise ValueError(
                f"Redirection vers un hôte non autorisé : {final_host}"
            )
        with zip_path.open("wb") as f:
            for chunk in resp.iter_bytes(1 << 16):
                total += len(chunk)
                if total > _MAX_ZIP_BYTES:
                    raise ValueError("Paquet trop volumineux — téléchargement interrompu.")
                f.write(chunk)

    got = _sha256_file(zip_path).lower()
    if got != expected:
        raise ValueError(f"Empreinte du paquet incorrecte (attendu {expected[:12]}…, "
                         f"reçu {got[:12]}…) — téléchargement rejeté.")

    extract_dir = _TMP_DIR / "extracted"
    extract_dir.mkdir(parents=True, exist_ok=True)
    base = extract_dir.resolve()
    # Composants de tête INTERDITS dans un paquet de MAJ (jamais de secret/données).
    forbidden_top = {"data", ".env", ".venv", "incoming", "exports"}
    with zipfile.ZipFile(zip_path) as zf:
        uncompressed = 0
        for info in zf.infolist():
            name = info.filename
            # Anti zip-slip robuste (commonpath, pas startswith).
            dest = (extract_dir / name).resolve()
            try:
                if os.path.commonpath([str(dest), str(base)]) != str(base):
                    raise ValueError("Paquet suspect (chemin hors dossier).")
            except ValueError:
                raise ValueError("Paquet suspect (chemin invalide).")
            # Refus d'un paquet contenant des données/secrets.
            top = name.replace("\\", "/").split("/", 1)[0]
            if top in forbidden_top:
                raise ValueError(f"Paquet refusé : contient « {top} » (secret/données).")
            uncompressed += info.file_size
            if uncompressed > _MAX_UNCOMPRESSED_BYTES:
                raise ValueError("Paquet décompressé trop volumineux — refusé.")
        zf.extractall(extract_dir)

    root = _package_root(extract_dir)
    if not (root / "app" / "main.py").exists():
        raise ValueError("Le paquet ne ressemble pas à PodoNote (app/main.py absent).")
    return root


def _package_root(extract_dir: Path) -> Path:
    """Tolère un zip à plat (app/ à la racine) ou enveloppé dans un seul dossier."""
    if (extract_dir / "app").is_dir():
        return extract_dir
    subdirs = [p for p in extract_dir.iterdir() if p.is_dir()]
    if len(subdirs) == 1 and (subdirs[0] / "app").is_dir():
        return subdirs[0]
    return extract_dir


def _requirements_changed(staged_root: Path) -> bool:
    """Compare l'empreinte de requirements.txt installé vs celui du paquet."""
    cur = BASE_DIR / "requirements.txt"
    new = staged_root / "requirements.txt"
    if not new.exists():
        return False
    try:
        cur_h = _sha256_file(cur) if cur.exists() else ""
        return _sha256_file(new) != cur_h
    except Exception:
        return True  # dans le doute, on relance pip (sûr)


# --------------------------------------------------------------------------- #
# Application de la mise à jour (bascule via processus détaché)
# --------------------------------------------------------------------------- #
def apply_staged_update(staged_root: Path, on_shutdown=None) -> dict[str, Any]:
    """Lance le remplaçant détaché puis demande l'arrêt de l'app.

    Le swap des fichiers ne peut pas se faire pendant que le serveur tourne :
    on confie la bascule à `scripts/apply_update.py`, copié dans %TEMP% et lancé
    DÉTACHÉ. Il attend la fin de ce process, recopie le code, (re)lance pip si
    besoin, puis redémarre l'app. On déclenche ensuite l'arrêt propre.
    """
    venv_pyw = BASE_DIR / ".venv" / "Scripts" / "pythonw.exe"
    venv_py = BASE_DIR / ".venv" / "Scripts" / "python.exe"
    swapper_src = BASE_DIR / "scripts" / "apply_update.py"
    if not swapper_src.exists():
        raise FileNotFoundError("scripts/apply_update.py introuvable dans l'installation.")
    if not venv_py.exists():
        raise FileNotFoundError("Environnement Python (.venv) introuvable.")

    # Copie le swapper hors de l'arborescence remplacée (sinon il se fait écraser).
    tmp_swapper = Path(_TMP_DIR) / "apply_update.py"
    shutil.copy2(swapper_src, tmp_swapper)

    pip = "1" if _requirements_changed(staged_root) else "0"
    launcher = str(venv_pyw if venv_pyw.exists() else venv_py)

    args = [
        str(venv_py), str(tmp_swapper),
        "--staged", str(staged_root),
        "--root", str(BASE_DIR),
        "--pid", str(os.getpid()),
        "--launch", launcher,
        "--backup", str(_BACKUP_DIR),
        "--tmp", str(_TMP_DIR),
        "--pip", pip,
    ]

    # DÉTACHÉ : survit à l'arrêt de l'app, sans fenêtre console.
    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
    subprocess.Popen(
        args, cwd=str(BASE_DIR), close_fds=True, creationflags=creationflags,
    )
    log.info("Remplaçant de mise à jour lancé (pip=%s). Arrêt de l'app demandé.", pip)

    # Laisse au remplaçant le temps d'attacher, puis on s'arrête.
    if on_shutdown is not None:
        try:
            on_shutdown()
        except Exception:
            log.exception("Rappel d'arrêt en échec (non bloquant).")
    return {"ok": True, "restart": True, "pip": pip == "1"}


def update_now(force_payload: Optional[dict[str, Any]] = None, on_shutdown=None) -> dict[str, Any]:
    """Chaîne complète : (re)vérifie, télécharge, vérifie, applique.

    `force_payload` permet de réutiliser le résultat d'une vérif déjà faite.
    Renvoie un dict {ok, message, ...} ; ne lève pas (capture tout).
    """
    try:
        status = force_payload or check_for_update(force=True)
        if not status.get("available"):
            return {"ok": False, "message": "Aucune mise à jour disponible."}
        # On retélécharge le manifest signé pour récupérer url/sha (le cache ne
        # garde pas tout) — déjà présent dans `status`.
        staged = download_and_stage(status)
        return apply_staged_update(staged, on_shutdown=on_shutdown)
    except Exception as exc:
        log.exception("Échec de la mise à jour.")
        return {"ok": False, "message": f"Échec de la mise à jour : {exc}"}


# --------------------------------------------------------------------------- #
# Vérification périodique en arrière-plan (démarrée par l'app)
# --------------------------------------------------------------------------- #
def start_background_checks() -> None:
    """Thread quotidien discret qui rafraîchit le cache (le bandeau lit le cache)."""
    import threading

    def _loop() -> None:
        # Petit délai pour ne pas ralentir le démarrage à froid (vieux PC).
        time.sleep(15)
        while True:
            try:
                check_for_update(force=False)
            except Exception:
                log.exception("Vérification de mise à jour en arrière-plan en échec.")
            time.sleep(max(1800, CHECK_INTERVAL_S))

    if os.environ.get("PODONOTE_NO_UPDATE_CHECK"):
        return
    t = threading.Thread(target=_loop, daemon=True, name="podonote-update-check")
    t.start()
