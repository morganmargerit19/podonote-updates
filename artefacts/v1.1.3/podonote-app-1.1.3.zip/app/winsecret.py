"""Stockage chiffré de la clé API (Windows DPAPI).

Le `.env` posé par l'installeur contient la clé Anthropic en texte brut,
lisible par tout process de la session (et par quiconque copie le dossier).
Ce module permet de la stocker chiffrée via DPAPI (CryptProtectData, portée
utilisateur) dans data/anthropic.key.dpapi : le blob n'est déchiffrable que
par CE compte Windows sur CE poste.

Résolution de la clé (get_anthropic_api_key) :
  1. blob DPAPI data/anthropic.key.dpapi s'il existe et se déchiffre ;
  2. sinon ANTHROPIC_API_KEY du .env (compatibilité installations existantes).

Migration : scripts/protect_api_key.py (chiffre la clé du .env puis l'efface
du .env). Hors Windows (dev), seule la voie .env fonctionne.
"""
from __future__ import annotations

import logging
from pathlib import Path

from .config import DATA_DIR, settings

logger = logging.getLogger("podonote.winsecret")

BLOB_PATH = DATA_DIR / "anthropic.key.dpapi"

_CRYPTPROTECT_UI_FORBIDDEN = 0x01


def _dpapi(data: bytes, protect: bool) -> bytes | None:
    """CryptProtectData / CryptUnprotectData via ctypes. None en échec."""
    import ctypes
    import ctypes.wintypes as wt

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    buf_in = ctypes.create_string_buffer(data, len(data))
    blob_in = DATA_BLOB(len(data), ctypes.cast(buf_in, ctypes.POINTER(ctypes.c_char)))
    blob_out = DATA_BLOB()
    fn = (ctypes.windll.crypt32.CryptProtectData if protect
          else ctypes.windll.crypt32.CryptUnprotectData)
    ok = fn(ctypes.byref(blob_in), None, None, None, None,
            _CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out))
    if not ok:
        return None
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


def protect_bytes_to_file(path: Path, data: bytes) -> bool:
    """Chiffre `data` (DPAPI, portée utilisateur) et l'écrit dans `path`."""
    import os
    if os.name != "nt":
        return False
    blob = _dpapi(data, protect=True)
    if blob is None:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(blob)
    os.replace(tmp, path)
    return True


def unprotect_file(path: Path) -> bytes | None:
    """Déchiffre un blob DPAPI écrit par protect_bytes_to_file. None en échec."""
    import os
    if os.name != "nt" or not path.exists():
        return None
    try:
        return _dpapi(path.read_bytes(), protect=False)
    except Exception:
        logger.exception("Lecture d'un blob DPAPI impossible (%s).", path.name)
        return None


def protect_api_key(key: str) -> bool:
    """Chiffre la clé et l'écrit dans data/. False si DPAPI indisponible."""
    import os
    if os.name != "nt" or not key.strip():
        return False
    blob = _dpapi(key.strip().encode("utf-8"), protect=True)
    if blob is None:
        return False
    BLOB_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = BLOB_PATH.with_suffix(BLOB_PATH.suffix + ".tmp")
    tmp.write_bytes(blob)
    os.replace(tmp, BLOB_PATH)
    return True


def _unprotect() -> str:
    import os
    if os.name != "nt" or not BLOB_PATH.exists():
        return ""
    try:
        raw = _dpapi(BLOB_PATH.read_bytes(), protect=False)
    except Exception:
        logger.exception("Lecture du blob DPAPI impossible.")
        return ""
    return (raw or b"").decode("utf-8", errors="strict") if raw else ""


_cached: str | None = None


def get_anthropic_api_key() -> str:
    """Clé API effective : blob DPAPI prioritaire, repli sur le .env."""
    global _cached
    if _cached is None:
        _cached = _unprotect()
    return _cached or settings.anthropic_api_key.strip()
