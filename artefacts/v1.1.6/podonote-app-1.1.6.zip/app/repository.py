"""CRUD patients & consultations + sérialisation de la fiche-bilan."""
from __future__ import annotations

import json
import logging
import sqlite3
from typing import Any, Optional

from . import bilan, clinical, fiches
from .db import db_cursor, get_connection

logger = logging.getLogger("podonote.repository")


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _row_to_dict(row: Optional[sqlite3.Row]) -> Optional[dict[str, Any]]:
    return dict(row) if row is not None else None


def _decode_json_field(d: Optional[dict[str, Any]], field: str, default: Any) -> None:
    if d is None:
        return
    raw = d.get(field)
    if raw:
        try:
            d[field] = json.loads(raw)
            return
        except (json.JSONDecodeError, TypeError):
            logger.warning("Champ JSON corrompu ignoré : %s (id=%s).", field, d.get("id"))
    d[field] = default


def _decode_patient(d: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    _decode_json_field(d, "medical_flags", [])
    return d


def _decode_recap(d: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    """Désérialise les champs JSON d'une consultation (recap, tags, annotations)."""
    if d and d.get("recap"):
        try:
            # Normalisation à la LECTURE : les fiches enregistrées sous un ancien
            # schéma (ex. bassin en liste) sont migrées à la volée — templates,
            # édition et PDF ne voient ainsi QUE la structure courante. Le
            # normaliseur dépend du TYPE de fiche (registre) ; 'podologie' par
            # défaut (rétro-compat : les fiches sans bilan_type restent podologie).
            d["recap"] = fiches.get(d.get("bilan_type")).normalize(json.loads(d["recap"]))
        except (json.JSONDecodeError, TypeError):
            logger.warning("recap corrompu ignoré (consultation id=%s).", d.get("id"))
            d["recap"] = None
    _decode_json_field(d, "tags", [])
    _decode_json_field(d, "foot_annotations", {})
    # foot_annotations DOIT être un objet (le template y accède par clés).
    if d is not None and not isinstance(d.get("foot_annotations"), dict):
        d["foot_annotations"] = {}
    if d is not None and not isinstance(d.get("tags"), list):
        d["tags"] = []
    return d


# --------------------------------------------------------------------------- #
# Patients
# --------------------------------------------------------------------------- #
def _encode_flags(medical_flags: Optional[list[str]]) -> Optional[str]:
    keys = clinical.valid_flag_keys(medical_flags or [])
    return json.dumps(keys) if keys else None


def _norm_sexe(sexe: Optional[str]) -> Optional[str]:
    s = (sexe or "").strip().upper()
    return s if s in ("H", "F") else None


def _norm_cabinet(cabinet_id) -> Optional[int]:
    try:
        cid = int(cabinet_id)
        return cid if cid > 0 else None
    except (TypeError, ValueError):
        return None


def create_patient(
    nom: str,
    prenom: str,
    date_naissance: Optional[str] = None,
    notes: Optional[str] = None,
    medical_flags: Optional[list[str]] = None,
    sexe: Optional[str] = None,
    cabinet_id: Optional[int] = None,
) -> int:
    from .utils import normalize_dob
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO patients (nom, prenom, date_naissance, notes, medical_flags, sexe, cabinet_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (nom.strip(), prenom.strip(), normalize_dob(date_naissance), notes or None,
             _encode_flags(medical_flags), _norm_sexe(sexe), _norm_cabinet(cabinet_id)),
        )
        return cur.lastrowid


def update_patient(
    patient_id: int,
    nom: str,
    prenom: str,
    date_naissance: Optional[str] = None,
    notes: Optional[str] = None,
    medical_flags: Optional[list[str]] = None,
    sexe: Optional[str] = None,
    cabinet_id: Optional[int] = None,
) -> None:
    from .utils import normalize_dob
    with db_cursor() as cur:
        cur.execute(
            "UPDATE patients SET nom=?, prenom=?, date_naissance=?, notes=?, medical_flags=?, sexe=?, cabinet_id=? "
            "WHERE id=?",
            (nom.strip(), prenom.strip(), normalize_dob(date_naissance), notes or None,
             _encode_flags(medical_flags), _norm_sexe(sexe), _norm_cabinet(cabinet_id), patient_id),
        )


# Statuts de suivi « à recontacter (+1 an) ». '' (ou NULL) = à recontacter.
RECONTACT_STATUSES = ("", "attente", "fait")


def set_recontact_status(patient_id: int, status: str) -> None:
    """Met à jour le suivi de rappel d'un patient (onglet « À recontacter »).

    'attente' = recontacté, en attente d'un retour ; 'fait' = recontacté ;
    '' = à recontacter (valeur par défaut)."""
    value = status if status in RECONTACT_STATUSES else ""
    with db_cursor() as cur:
        cur.execute(
            "UPDATE patients SET recontact_status=? WHERE id=?",
            (value or None, patient_id),
        )


def _clear_recontact_status(cur: sqlite3.Cursor, patient_id: int) -> None:
    """Le patient vient d'être revu : son suivi de rappel n'a plus lieu d'être."""
    cur.execute(
        "UPDATE patients SET recontact_status=NULL WHERE id=? AND recontact_status IS NOT NULL",
        (patient_id,),
    )


def get_patient(patient_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
        return _decode_patient(_row_to_dict(row))
    finally:
        conn.close()


def set_archived(patient_id: int, archived: bool) -> None:
    """Archive (ou réactive) un dossier patient — retour Nico : sortir les
    dossiers des patients partis (déménagement, décès) sans les supprimer.
    Aucune donnée n'est effacée : le dossier reste consultable dans « Archivés »."""
    with db_cursor() as cur:
        cur.execute("UPDATE patients SET archived = ? WHERE id = ?",
                    (1 if archived else 0, patient_id))


def list_patients(
    search: Optional[str] = None, cabinet_id: Optional[int] = None,
    archived: bool = False,
) -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        sql = """
            SELECT p.*,
                   (SELECT COUNT(*) FROM consultations c WHERE c.patient_id = p.id)
                       AS nb_consultations,
                   (SELECT MAX(c.date) FROM consultations c WHERE c.patient_id = p.id)
                       AS derniere_consultation
            FROM patients p
        """
        # Les dossiers archivés sont EXCLUS partout par défaut (listes, relances,
        # sélecteurs) et ne s'affichent que dans le filtre « Archivés ».
        where: list[str] = ["COALESCE(p.archived, 0) = ?"]
        params: list = [1 if archived else 0]
        if search:
            where.append("(p.nom LIKE ? OR p.prenom LIKE ?)")
            like = f"%{search.strip()}%"
            params += [like, like]
        if cabinet_id:
            where.append("p.cabinet_id = ?")
            params.append(cabinet_id)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE"
        rows = conn.execute(sql, tuple(params)).fetchall()
        return [_decode_patient(dict(r)) for r in rows]
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# Cabinets (multi-sites)
# --------------------------------------------------------------------------- #
_CABINET_FIELDS = ("label", "nom", "titre", "adresse", "telephone", "num_am", "rpps")


def list_cabinets() -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT c.*, "
            "(SELECT COUNT(*) FROM patients p WHERE p.cabinet_id = c.id) AS nb_patients "
            "FROM cabinets c ORDER BY c.label COLLATE NOCASE"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_cabinet(cabinet_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM cabinets WHERE id=?", (cabinet_id,)).fetchone()
        return _row_to_dict(row)
    finally:
        conn.close()


def create_cabinet(values: dict[str, Any]) -> int:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO cabinets (label, nom, titre, adresse, telephone, num_am, rpps) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            tuple((values.get(f) or "").strip() or None for f in _CABINET_FIELDS),
        )
        return cur.lastrowid


def update_cabinet(cabinet_id: int, values: dict[str, Any]) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE cabinets SET label=?, nom=?, titre=?, adresse=?, telephone=?, num_am=?, rpps=? "
            "WHERE id=?",
            (*(((values.get(f) or "").strip() or None) for f in _CABINET_FIELDS), cabinet_id),
        )


def delete_cabinet(cabinet_id: int) -> None:
    """Supprime un cabinet ; les patients rattachés repassent en « non assigné »."""
    with db_cursor() as cur:
        cur.execute("UPDATE patients SET cabinet_id=NULL WHERE cabinet_id=?", (cabinet_id,))
        cur.execute("DELETE FROM cabinets WHERE id=?", (cabinet_id,))


# --------------------------------------------------------------------------- #
# Correspondants (annuaire pluridisciplinaire — contact médecin/kiné/chir…)
# --------------------------------------------------------------------------- #
CORRESPONDANT_TYPES = {
    "medecin": "Médecin",
    "kine": "Kinésithérapeute",
    "chirurgien": "Chirurgien",
    "podologue": "Pédicure-podologue",
    "osteo": "Ostéopathe",
    "autre": "Autre",
}


def list_correspondants() -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM correspondants ORDER BY nom COLLATE NOCASE"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_correspondant(correspondant_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM correspondants WHERE id=?", (correspondant_id,)
        ).fetchone()
        return _row_to_dict(row)
    finally:
        conn.close()


def _correspondant_values(values: dict[str, Any]) -> tuple:
    typ = (values.get("type") or "").strip()
    typ = typ if typ in CORRESPONDANT_TYPES else "medecin"
    nom = (values.get("nom") or "").strip()
    email, tel, adr, notes = (
        (values.get(f) or "").strip() or None
        for f in ("email", "telephone", "adresse", "notes")
    )
    return (typ, nom, email, tel, adr, notes)


def create_correspondant(values: dict[str, Any]) -> int:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO correspondants (type, nom, email, telephone, adresse, notes) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            _correspondant_values(values),
        )
        return cur.lastrowid


def update_correspondant(correspondant_id: int, values: dict[str, Any]) -> None:
    typ, nom, email, tel, adr, notes = _correspondant_values(values)
    with db_cursor() as cur:
        cur.execute(
            "UPDATE correspondants SET type=?, nom=?, email=?, telephone=?, adresse=?, notes=? "
            "WHERE id=?",
            (typ, nom, email, tel, adr, notes, correspondant_id),
        )


def delete_correspondant(correspondant_id: int) -> None:
    with db_cursor() as cur:
        cur.execute("DELETE FROM correspondants WHERE id=?", (correspondant_id,))


def delete_patient(patient_id: int) -> None:
    """Suppression définitive (droit à l'effacement RGPD). CASCADE sur consultations."""
    with db_cursor() as cur:
        cur.execute("DELETE FROM patients WHERE id=?", (patient_id,))


# --------------------------------------------------------------------------- #
# Ordonnances (journal de traçabilité)
# --------------------------------------------------------------------------- #
def add_ordonnance(
    patient_id: int,
    fichier: Optional[str] = None,
    ald: Optional[str] = None,
    lignes: Optional[list[str]] = None,
) -> int:
    """Enregistre qu'une ordonnance a été générée pour ce patient (date = maintenant).

    `ald` + `lignes` sont conservés pour pouvoir REGÉNÉRER le PDF plus tard (si le
    fichier disque a disparu) ; `fichier` permet, lui, de rouvrir le PDF déjà écrit.
    """
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO ordonnances (patient_id, fichier, ald, lignes) VALUES (?, ?, ?, ?)",
            (patient_id, fichier or None, ald or None,
             json.dumps(lignes, ensure_ascii=False) if lignes else None),
        )
        return cur.lastrowid


def _ordonnance_row(row: Optional[sqlite3.Row]) -> Optional[dict[str, Any]]:
    if row is None:
        return None
    d = dict(row)
    try:
        d["lignes"] = json.loads(d["lignes"]) if d.get("lignes") else []
    except (TypeError, ValueError):
        d["lignes"] = []
    return d


def get_ordonnance(ordonnance_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM ordonnances WHERE id=?", (ordonnance_id,)
        ).fetchone()
        return _ordonnance_row(row)
    finally:
        conn.close()


def list_ordonnances(patient_id: int) -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM ordonnances WHERE patient_id=? ORDER BY date DESC, id DESC",
            (patient_id,),
        ).fetchall()
        return [_ordonnance_row(r) for r in rows]
    finally:
        conn.close()


def delete_ordonnance(ordonnance_id: int, patient_id: Optional[int] = None) -> bool:
    """Supprime une ordonnance journalisée (retour Nico : corriger une erreur de
    saisie). Si `patient_id` est fourni, la suppression est bornée à ce patient
    (garde-fou anti-suppression croisée). Renvoie True si une ligne a été retirée."""
    with db_cursor() as cur:
        if patient_id is not None:
            cur.execute("DELETE FROM ordonnances WHERE id=? AND patient_id=?",
                        (ordonnance_id, patient_id))
        else:
            cur.execute("DELETE FROM ordonnances WHERE id=?", (ordonnance_id,))
        return cur.rowcount > 0


# --------------------------------------------------------------------------- #
# Journal des fiches d'exercices remises (retrouver une fiche prescrite).
# --------------------------------------------------------------------------- #
def _exercice_fiche_row(row: Optional[sqlite3.Row]) -> Optional[dict[str, Any]]:
    if row is None:
        return None
    d = dict(row)
    try:
        d["keys"] = json.loads(d["keys"]) if d.get("keys") else []
    except (TypeError, ValueError):
        d["keys"] = []
    return d


def add_exercice_fiche(patient_id: int, keys: list[str]) -> int:
    """Journalise une fiche d'exercices remise (clés conservées pour régénérer)."""
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO exercices_fiches (patient_id, keys) VALUES (?, ?)",
            (patient_id, json.dumps(keys, ensure_ascii=False) if keys else None),
        )
        return cur.lastrowid


def list_exercice_fiches(patient_id: int) -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM exercices_fiches WHERE patient_id=? ORDER BY date DESC, id DESC",
            (patient_id,),
        ).fetchall()
        return [_exercice_fiche_row(r) for r in rows]
    finally:
        conn.close()


def get_exercice_fiche(fiche_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM exercices_fiches WHERE id=?", (fiche_id,)).fetchone()
        return _exercice_fiche_row(row)
    finally:
        conn.close()


def delete_exercice_fiche(fiche_id: int, patient_id: Optional[int] = None) -> bool:
    with db_cursor() as cur:
        if patient_id is not None:
            cur.execute("DELETE FROM exercices_fiches WHERE id=? AND patient_id=?",
                        (fiche_id, patient_id))
        else:
            cur.execute("DELETE FROM exercices_fiches WHERE id=?", (fiche_id,))
        return cur.rowcount > 0


# --------------------------------------------------------------------------- #
# Photos cliniques (avant/après) — stockées en BLOB dans la base (cf. app/db.py) :
# incluses dans la sauvegarde, effacées par la purge RGPD (CASCADE+secure_delete).
# --------------------------------------------------------------------------- #
_PHOTO_KINDS = ("avant", "apres", "autre")


def add_photo(consultation_id: int, data: bytes, mime: str = "image/jpeg",
              kind: str = "autre", note: Optional[str] = None) -> int:
    """Ajoute une photo (BLOB) à une consultation. `kind` = 'avant'|'apres'|'autre'."""
    k = kind if kind in _PHOTO_KINDS else "autre"
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO photos (consultation_id, kind, note, mime, data) "
            "VALUES (?, ?, ?, ?, ?)",
            (consultation_id, k, (note or "").strip() or None, mime, sqlite3.Binary(data)),
        )
        return cur.lastrowid


def list_photos(consultation_id: int) -> list[dict[str, Any]]:
    """Métadonnées des photos d'une consultation (SANS le BLOB `data`, pour l'UI)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT id, consultation_id, kind, note, mime, created_at "
            "FROM photos WHERE consultation_id=? ORDER BY id",
            (consultation_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_photo(photo_id: int) -> Optional[dict[str, Any]]:
    """Une photo complète (avec le BLOB `data`) — pour la servir."""
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM photos WHERE id=?", (photo_id,)).fetchone()
        return _row_to_dict(row)
    finally:
        conn.close()


def delete_photo(photo_id: int) -> None:
    with db_cursor() as cur:
        cur.execute("DELETE FROM photos WHERE id=?", (photo_id,))


# --------------------------------------------------------------------------- #
# Consultations
# --------------------------------------------------------------------------- #
def create_consultation(
    patient_id: int,
    source: str,
    consent_obtained: bool,
    audio_path: Optional[str] = None,
    status: str = "pending",
    bilan_type: str = "podologie",
) -> int:
    """Crée une consultation. `status='queued'` = déposée en file d'attente
    (audio reçu mais transcription NON lancée — à déclencher en différé).
    `bilan_type` = type de fiche du registre (défaut 'podologie')."""
    st = status if status in ("pending", "queued") else "pending"
    bt = fiches.coerce_key(bilan_type)
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO consultations (patient_id, source, consent_obtained, audio_path, status, bilan_type) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (patient_id, source, 1 if consent_obtained else 0, audio_path, st, bt),
        )
        _clear_recontact_status(cur, patient_id)
        return cur.lastrowid


def create_blank_consultation(
    patient_id: int, source: str, bilan_type: str = "podologie"
) -> int:
    """Fiche VIERGE sans audio (patient refusant l'enregistrement) : créée
    directement en 'done' avec un bilan vide, à remplir à la main via Modifier.
    `bilan_type` = type de fiche du registre (défaut 'podologie')."""
    bt = fiches.coerce_key(bilan_type)
    recap = json.dumps(fiches.get(bt).normalize({}), ensure_ascii=False)
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO consultations (patient_id, source, consent_obtained, status, recap, bilan_type) "
            "VALUES (?, ?, 0, 'done', ?, ?)",
            (patient_id, source, recap, bt),
        )
        _clear_recontact_status(cur, patient_id)
        return cur.lastrowid


def create_consultation_from_previous(
    patient_id: int, source: str, bilan_type: Optional[str] = None
) -> Optional[int]:
    """Fiche de SUIVI pré-remplie à partir de la DERNIÈRE fiche terminée du patient
    (même type de fiche). Le praticien ne complète ensuite que ce qui a changé.
    Renvoie l'id de la nouvelle consultation, ou None si aucune fiche précédente."""
    prev = None
    for c in list_consultations(patient_id):
        if c.get("status") != "done" or not c.get("recap"):
            continue
        if bilan_type and c.get("bilan_type") != bilan_type:
            continue
        prev = c
        break
    if not prev:
        return None
    bt = fiches.coerce_key(prev.get("bilan_type"))
    seeded = fiches.get(bt).normalize(prev["recap"])  # copie normalisée du recap précédent
    # « Évolution depuis la dernière visite » décrit l'ANCIENNE transition : on ne
    # la recopie pas dans la nouvelle fiche.
    if isinstance(seeded, dict) and "evolution_depuis_derniere_visite" in seeded:
        seeded["evolution_depuis_derniere_visite"] = None
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO consultations (patient_id, source, consent_obtained, status, recap, bilan_type) "
            "VALUES (?, ?, 0, 'done', ?, ?)",
            (patient_id, source, json.dumps(seeded, ensure_ascii=False), bt),
        )
        _clear_recontact_status(cur, patient_id)
        return cur.lastrowid


def update_consultation_source(consultation_id: int, source: str) -> None:
    """Corrige le lieu (cabinet/domicile) — l'import QR le devinait mal."""
    if source not in ("cabinet", "domicile"):
        return
    with db_cursor() as cur:
        cur.execute("UPDATE consultations SET source=? WHERE id=?",
                    (source, consultation_id))


def consultations_per_year() -> list[dict[str, Any]]:
    """Nombre de consultations par année (la plus récente d'abord)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT substr(date, 1, 4) AS annee, COUNT(*) AS n "
            "FROM consultations GROUP BY annee ORDER BY annee DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_consultation(consultation_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM consultations WHERE id=?", (consultation_id,)
        ).fetchone()
        return _decode_recap(_row_to_dict(row))
    finally:
        conn.close()


def list_consultations(patient_id: int) -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM consultations WHERE patient_id=? ORDER BY date DESC, id DESC",
            (patient_id,),
        ).fetchall()
        return [_decode_recap(dict(r)) for r in rows]
    finally:
        conn.close()


def list_previous_consultations(
    patient_id: int, before_consultation_id: int
) -> list[dict[str, Any]]:
    """Consultations antérieures terminées (pour le contexte d'historique du LLM)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM consultations "
            "WHERE patient_id=? AND id<>? AND status='done' "
            "ORDER BY date DESC, id DESC",
            (patient_id, before_consultation_id),
        ).fetchall()
        return [_decode_recap(dict(r)) for r in rows]
    finally:
        conn.close()


def update_consultation_status(
    consultation_id: int,
    status: str,
    progress: Optional[str] = None,
    error_message: Optional[str] = None,
) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE consultations SET status=?, progress=?, error_message=? WHERE id=?",
            (status, progress, error_message, consultation_id),
        )


def vacuum() -> None:
    """Compacte la base et réécrit le fichier : combiné à PRAGMA secure_delete,
    garantit qu'un dossier « définitivement supprimé » ne reste pas lisible dans
    les pages libres du .db. Appelé après un effacement RGPD."""
    import sqlite3

    from .config import DB_PATH
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("VACUUM;")
    finally:
        conn.close()


def list_all_audio_paths() -> list[str]:
    """Tous les chemins audio encore référencés (pour le balayage des orphelins)."""
    with db_cursor() as cur:
        cur.execute(
            "SELECT audio_path FROM consultations WHERE audio_path IS NOT NULL"
        )
        return [r["audio_path"] for r in cur.fetchall() if r["audio_path"]]


def save_transcript(consultation_id: int, transcript_diarise: str) -> None:
    """Persiste le transcript dès la fin de l'ASR (avant le LLM) : en cas d'échec
    de la génération, le retry réutilise ce transcript au lieu de refaire ~10 min
    de transcription CPU."""
    with db_cursor() as cur:
        cur.execute(
            "UPDATE consultations SET transcript_diarise=? WHERE id=?",
            (transcript_diarise, consultation_id),
        )


def save_consultation_result(
    consultation_id: int,
    transcript_diarise: str,
    recap: dict[str, Any],
) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE consultations "
            "SET transcript_diarise=?, recap=?, status='done', progress=NULL, error_message=NULL, "
            "resume_attempts=0 "  # succès : on ne doit pas abandonner une fiche longue relancée plusieurs fois
            "WHERE id=?",
            (transcript_diarise, json.dumps(recap, ensure_ascii=False), consultation_id),
        )


def update_consultation_recap(
    consultation_id: int,
    recap: dict[str, Any],
    tags: Optional[list[str]] = None,
    foot_annotations: Optional[dict[str, Any]] = None,
    validated: Optional[bool] = None,
) -> None:
    """Édition manuelle de la fiche par le praticien (recap, étiquettes, schéma, validation)."""
    sets = ["recap=?"]
    vals: list[Any] = [json.dumps(recap, ensure_ascii=False)]
    if tags is not None:
        sets.append("tags=?")
        vals.append(json.dumps(clinical.valid_tag_keys(tags)))
    if foot_annotations is not None:
        sets.append("foot_annotations=?")
        vals.append(json.dumps(foot_annotations, ensure_ascii=False))
    if validated is not None:
        sets.append("validated=?")
        vals.append(1 if validated else 0)
    vals.append(consultation_id)
    with db_cursor() as cur:
        cur.execute(f"UPDATE consultations SET {', '.join(sets)} WHERE id=?", vals)


def set_validated(consultation_id: int, validated: bool = True) -> None:
    with db_cursor() as cur:
        cur.execute("UPDATE consultations SET validated=? WHERE id=?",
                    (1 if validated else 0, consultation_id))


def list_to_validate() -> list[dict[str, Any]]:
    """Fiches prêtes mais non encore relues/validées (tableau de bord)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT c.*, p.nom AS p_nom, p.prenom AS p_prenom "
            "FROM consultations c JOIN patients p ON p.id = c.patient_id "
            "WHERE c.status='done' AND COALESCE(c.validated,0)=0 "
            "ORDER BY c.date DESC"
        ).fetchall()
        return [_decode_recap(dict(r)) for r in rows]
    finally:
        conn.close()


def list_in_error() -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT c.*, p.nom AS p_nom, p.prenom AS p_prenom "
            "FROM consultations c JOIN patients p ON p.id = c.patient_id "
            "WHERE c.status='error' ORDER BY c.date DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def tags_in_use() -> set[str]:
    """Étiquettes de soin réellement portées par au moins une consultation.

    Sert à n'afficher le filtre « étiquette » que s'il a du sens (retour Nico :
    incohérent quand la plupart des soins n'en ont aucune)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT tags FROM consultations WHERE tags IS NOT NULL AND tags != ''"
        ).fetchall()
    finally:
        conn.close()
    used: set[str] = set()
    for r in rows:
        try:
            vals = json.loads(r["tags"]) or []
        except (TypeError, ValueError):
            continue
        if isinstance(vals, list):
            used.update(str(v) for v in vals)
    return used


def patient_ids_with_tag(tag: str) -> set[int]:
    """Ids des patients ayant au moins une consultation portant cette étiquette."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT DISTINCT patient_id FROM consultations WHERE tags LIKE ?",
            (f'%"{tag}"%',),
        ).fetchall()
        return {r["patient_id"] for r in rows}
    finally:
        conn.close()


def count_processing() -> int:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM consultations WHERE status IN ('pending','processing')"
        ).fetchone()
        return row["n"] if row else 0
    finally:
        conn.close()


def list_processing() -> list[dict[str, Any]]:
    """Consultations en cours de traitement (avec nom patient), pour le tableau de bord."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT c.*, p.nom AS p_nom, p.prenom AS p_prenom "
            "FROM consultations c JOIN patients p ON p.id = c.patient_id "
            "WHERE c.status IN ('pending','processing') ORDER BY c.date DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def list_queued() -> list[dict[str, Any]]:
    """Consultations DÉPOSÉES en file d'attente (audio reçu, transcription non
    lancée). À traiter en différé via « Lancer les transcriptions »."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT c.*, p.nom AS p_nom, p.prenom AS p_prenom "
            "FROM consultations c JOIN patients p ON p.id = c.patient_id "
            "WHERE c.status='queued' ORDER BY c.date"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def count_queued() -> int:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM consultations WHERE status='queued'"
        ).fetchone()
        return row["n"] if row else 0
    finally:
        conn.close()


def list_queued_ids() -> list[int]:
    """Ids des consultations en file d'attente (ordre de dépôt), pour lancement groupé."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT id FROM consultations WHERE status='queued' ORDER BY date, id"
        ).fetchall()
        return [r["id"] for r in rows]
    finally:
        conn.close()


def clear_audio_path(consultation_id: int) -> None:
    """Marque l'audio comme supprimé (RGPD)."""
    with db_cursor() as cur:
        cur.execute(
            "UPDATE consultations SET audio_path=NULL WHERE id=?", (consultation_id,)
        )


def delete_consultation(consultation_id: int) -> None:
    with db_cursor() as cur:
        cur.execute("DELETE FROM consultations WHERE id=?", (consultation_id,))


def increment_resume_attempts(consultation_id: int) -> int:
    """Incrémente le compteur de reprises automatiques au démarrage et renvoie sa
    nouvelle valeur. Garde-fou anti-boucle : une consultation qui replante à chaque
    démarrage (audio corrompu, etc.) ne doit pas être relancée indéfiniment."""
    with db_cursor() as cur:
        cur.execute(
            "UPDATE consultations SET resume_attempts = COALESCE(resume_attempts, 0) + 1 "
            "WHERE id=?", (consultation_id,),
        )
        row = cur.execute(
            "SELECT resume_attempts FROM consultations WHERE id=?", (consultation_id,)
        ).fetchone()
        return row["resume_attempts"] if row else 0


def reset_resume_attempts(consultation_id: int) -> None:
    """Remet à zéro le compteur de reprises (relance manuelle explicite par le praticien)."""
    with db_cursor() as cur:
        cur.execute(
            "UPDATE consultations SET resume_attempts = 0 WHERE id=?", (consultation_id,)
        )


def list_pending_consultations() -> list[dict[str, Any]]:
    """Consultations à traiter (reprise au démarrage)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM consultations WHERE status IN ('pending','processing') "
            "AND audio_path IS NOT NULL ORDER BY id"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def list_done_with_audio() -> list[dict[str, Any]]:
    """Consultations TERMINÉES dont l'audio est encore sur disque (orphelins RGPD :
    plantage entre 'done' et la suppression). À purger au démarrage."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT id, audio_path FROM consultations "
            "WHERE status='done' AND audio_path IS NOT NULL"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
