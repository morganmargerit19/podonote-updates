#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — mettre à jour le keyproxy DÉJÀ en service sur le Pi (nouveau code,
#  tableau de bord…) sans toucher à ses secrets (.env) ni à sa base de conso.
#
#  Depuis le Mac (le script envoie le code du dépôt et s'exécute sur le Pi) :
#      bash server/keyproxy/rpi/mettre-a-jour.sh --ssh admin@diktae-proxy.local
#
#  Sur le Pi, depuis un dossier contenant le keyproxy :
#      sudo bash <dossier>/rpi/mettre-a-jour.sh
# ============================================================================ #
set -euo pipefail

DEST=/opt/diktae-keyproxy
ICI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"     # …/keyproxy/rpi
SRC="$(cd "$ICI/.." && pwd)"                            # …/keyproxy
CIBLE=""

say()  { printf '\033[1;33m▶ %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --ssh) CIBLE="$2"; shift 2 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) fail "Option inconnue : $1" ;;
  esac
done

FICHIERS=(app.py admin.html requirements.txt Dockerfile)
for f in "${FICHIERS[@]}"; do [ -f "$SRC/$f" ] || fail "$f manquant dans $SRC"; done

# --------------------------------------------------------------------------- #
# Sur le Pi : recopier le code, reconstruire, vérifier
# --------------------------------------------------------------------------- #
if [ -z "$CIBLE" ]; then
  [ -f "$DEST/.env" ] || fail "$DEST/.env introuvable : ce n'est pas le Pi du keyproxy.
   Depuis le Mac, précisez la cible :  --ssh utilisateur@diktae-proxy.local"
  [ "$(id -u)" -eq 0 ] || fail "Lancez avec sudo : sudo bash $0"

  say "Copie du nouveau code vers ${DEST} (secrets et base conservés)…"
  cp "${FICHIERS[@]/#/$SRC/}" "$DEST/"
  mkdir -p "$DEST/rpi"
  cp "$SRC"/rpi/*.sh "$SRC"/rpi/*.yml "$DEST/rpi/" 2>/dev/null || true

  if grep -Eq "^TUNNEL_TOKEN=..+" "$DEST/.env"; then PROFIL=(--profile tunnel); else PROFIL=(); fi
  say "Reconstruction de l'image et redémarrage du proxy…"
  cd "$DEST"
  docker compose -f rpi/docker-compose.yml --project-directory . ${PROFIL[@]+"${PROFIL[@]}"} up -d --build

  for _ in $(seq 1 30); do
    sleep 2
    if curl -fsS http://127.0.0.1:8787/healthz >/dev/null 2>&1; then
      ok "Proxy à jour et en service."
      docker image prune -f >/dev/null 2>&1 || true
      exit 0
    fi
  done
  fail "Le proxy ne répond pas après la mise à jour — journal :
   docker compose -f $DEST/rpi/docker-compose.yml logs --tail 50 keyproxy"
fi

# --------------------------------------------------------------------------- #
# Sur le Mac : envoyer le code, puis tout faire sur le Pi en UNE session SSH
# --------------------------------------------------------------------------- #
CTL="${TMPDIR:-/tmp}/diktae-ssh-$$"
SSH_OPTS=(-o ControlMaster=auto -o "ControlPath=$CTL" -o ControlPersist=120)
trap 'ssh "${SSH_OPTS[@]}" -O exit "$CIBLE" >/dev/null 2>&1 || true' EXIT

say "Connexion à ${CIBLE}…"
DOSSIER="$(ssh "${SSH_OPTS[@]}" "$CIBLE" 'mktemp -d')"
[ -n "$DOSSIER" ] || fail "Connexion SSH impossible."
say "Envoi du code…"
# COPYFILE_DISABLE : pas de « ._fichier » macOS dans l'archive.
COPYFILE_DISABLE=1 tar -C "$SRC" -czf - "${FICHIERS[@]}" rpi/mettre-a-jour.sh rpi/docker-compose.yml \
  | ssh "${SSH_OPTS[@]}" "$CIBLE" "mkdir -p '$DOSSIER/keyproxy' && tar -xzf - -C '$DOSSIER/keyproxy'"
ssh "${SSH_OPTS[@]}" -t "$CIBLE" \
  "sudo bash '$DOSSIER/keyproxy/rpi/mettre-a-jour.sh'; code=\$?; rm -rf '$DOSSIER'; exit \$code"

cat <<'FIN'

Tableau de bord des dépenses :  https://api.studio-margerit.fr/admin
(jeton admin : ligne KEYPROXY_ADMIN_TOKEN du .env de ce Mac)
FIN
