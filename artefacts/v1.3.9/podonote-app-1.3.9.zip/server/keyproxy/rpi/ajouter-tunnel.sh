#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — brancher (ou changer) le tunnel Cloudflare d'un keyproxy DÉJÀ en
#  service, sans rien réinstaller.
#
#  Depuis le Mac (le script se copie sur le Pi et s'y exécute via SSH) :
#      bash server/keyproxy/rpi/ajouter-tunnel.sh --ssh morgan@diktae-proxy.local
#
#  Directement sur le Pi :
#      sudo bash /opt/diktae-keyproxy/rpi/ajouter-tunnel.sh
#
#  Le token (eyJ…) se trouve dans Cloudflare : Zero Trust → Networks → Tunnels
#  → votre tunnel → Configure. Il est demandé en saisie masquée.
# ============================================================================ #
set -euo pipefail

DEST=/opt/diktae-keyproxy
CIBLE=""
FICHIER_TOKEN=""

say()  { printf '\033[1;33m▶ %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --ssh) CIBLE="$2"; shift 2 ;;
    --token-fichier) FICHIER_TOKEN="$2"; shift 2 ;;
    -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
    *) fail "Option inconnue : $1" ;;
  esac
done

# --------------------------------------------------------------------------- #
# Sur le Pi : écrire le token dans le .env et allumer le conteneur cloudflared
# --------------------------------------------------------------------------- #
if [ -z "$CIBLE" ]; then
  [ -f "$DEST/.env" ] || fail "$DEST/.env introuvable : ce n'est pas le Pi du keyproxy.
   Depuis le Mac, précisez la cible :  --ssh utilisateur@diktae-proxy.local"
  [ "$(id -u)" -eq 0 ] || fail "Lancez avec sudo : sudo bash $0"

  if [ -n "$FICHIER_TOKEN" ]; then
    TOKEN="$(tr -d ' \r\n' < "$FICHIER_TOKEN")"
    rm -f "$FICHIER_TOKEN"
  else
    printf '   Token du tunnel Cloudflare (eyJ…) : '
    read -rs TOKEN; printf '\n'
  fi
  [ -n "$TOKEN" ] || fail "Token vide."

  tmp="$(mktemp)"
  grep -v '^TUNNEL_TOKEN=' "$DEST/.env" > "$tmp" || true
  printf 'TUNNEL_TOKEN=%s\n' "$TOKEN" >> "$tmp"
  install -m 600 "$tmp" "$DEST/.env"; rm -f "$tmp"
  ok "Token enregistré dans $DEST/.env"

  say "Démarrage du tunnel…"
  cd "$DEST"
  # --force-recreate : un changement de token doit relancer cloudflared.
  docker compose -f rpi/docker-compose.yml --project-directory . --profile tunnel \
    up -d --force-recreate cloudflared
  sleep 8
  if docker compose -f rpi/docker-compose.yml --project-directory . --profile tunnel \
       logs --tail 40 cloudflared 2>&1 | grep -q 'Registered tunnel connection'; then
    ok "Tunnel connecté à Cloudflare."
  else
    printf '\033[1;33m   Connexion pas encore confirmée — journal :\033[0m\n'
    printf '   docker compose -f %s/rpi/docker-compose.yml logs cloudflared\n' "$DEST"
  fi
  cat <<'FIN'

Côté Cloudflare, le tunnel doit avoir un « Public hostname » :
  api.studio-margerit.fr  →  Service HTTP  →  URL keyproxy:8787
FIN
  exit 0
fi

# --------------------------------------------------------------------------- #
# Sur le Mac : demander le token, puis tout faire sur le Pi en UNE session SSH
# (le mot de passe n'est demandé qu'une fois grâce au multiplexage).
# --------------------------------------------------------------------------- #
printf '   Token du tunnel Cloudflare (eyJ…) : '
read -rs TOKEN; printf '\n'
[ -n "$TOKEN" ] || fail "Token vide."
case "$TOKEN" in eyJ*) : ;; *) printf '\033[1;33m   (⚠️ ne commence pas par « eyJ » — je continue)\033[0m\n' ;; esac

CTL="${TMPDIR:-/tmp}/diktae-ssh-$$"
SSH_OPTS=(-o ControlMaster=auto -o "ControlPath=$CTL" -o ControlPersist=120)
trap 'ssh "${SSH_OPTS[@]}" -O exit "$CIBLE" >/dev/null 2>&1 || true' EXIT

say "Connexion à ${CIBLE}…"
DOSSIER="$(ssh "${SSH_OPTS[@]}" "$CIBLE" 'mktemp -d')"
[ -n "$DOSSIER" ] || fail "Connexion SSH impossible."
ssh "${SSH_OPTS[@]}" "$CIBLE" "umask 077; cat > '$DOSSIER/token'" <<<"$TOKEN"
ssh "${SSH_OPTS[@]}" "$CIBLE" "cat > '$DOSSIER/ajouter-tunnel.sh'" < "${BASH_SOURCE[0]}"
ssh "${SSH_OPTS[@]}" -t "$CIBLE" \
  "sudo bash '$DOSSIER/ajouter-tunnel.sh' --token-fichier '$DOSSIER/token'; rm -rf '$DOSSIER'"

cat <<'FIN'

Vérification publique (peut prendre une minute) :
    bash server/keyproxy/rpi/verifier.sh
FIN
