#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — préparation de la carte SD du keyproxy, depuis le Mac (ou Linux).
#
#  À lancer APRÈS avoir flashé la carte avec Raspberry Pi Imager (personnalisation
#  remplie : nom d'hôte, utilisateur, SSH), carte toujours branchée :
#
#      bash server/keyproxy/rpi/preparer-carte-sd.sh
#
#  Le script :
#    1. trouve la partition de démarrage de la carte (bootfs) et reconnaît la
#       façon dont Imager l'a personnalisée (cloud-init ou firstrun.sh) ;
#    2. demande les secrets (saisie masquée) et écrit le .env ;
#    3. copie le keyproxy sur la carte ;
#    4. installe l'AUTO-PROVISIONNEMENT : au premier démarrage, le Pi installe
#       Docker, construit l'image, lance le proxy (et le tunnel s'il est fourni)
#       — TOUT SEUL. Aucune connexion SSH n'est nécessaire.
#
#  Ensuite : éjecter, mettre la carte dans le Pi, brancher Ethernet + alim,
#  attendre ~15 min, puis `bash rpi/verifier.sh`.
# ============================================================================ #
set -euo pipefail

ICI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"     # …/keyproxy/rpi
SRC="$(cd "$ICI/.." && pwd)"                            # …/keyproxy
ENV_MAC="$(cd "$SRC/../.." && pwd)/.env"                # le .env de ce poste Diktae

say()  { printf '\033[1;33m▶ %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m   ⚠️ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

SD=""
while [ $# -gt 0 ]; do
  case "$1" in
    --sd) SD="$2"; shift 2 ;;
    -h|--help) sed -n '2,21p' "$0"; exit 0 ;;
    *) fail "Option inconnue : $1" ;;
  esac
done

# --------------------------------------------------------------------------- #
# 1. Trouver la partition de démarrage, et comment Imager l'a personnalisée
# --------------------------------------------------------------------------- #
if [ -z "$SD" ]; then
  for candidat in /Volumes/bootfs /Volumes/boot /media/*/bootfs /media/*/boot; do
    [ -d "$candidat" ] || continue
    SD="$candidat"
    break
  done
fi
[ -n "$SD" ] || fail "Carte SD introuvable. Flashez-la d'abord avec Raspberry Pi Imager
   et laissez-la branchée (ou rebranchez-la), ou indiquez le chemin :  --sd /Volumes/bootfs"
[ -d "$SD" ] || fail "$SD n'existe pas."
[ -f "$SD/config.txt" ] || fail "$SD ne ressemble pas à une carte Raspberry Pi (config.txt absent).
   Flashez la carte AVANT de lancer ce script."
ok "Carte trouvée : $SD"

# Un serveur sans écran ni clavier DOIT avoir été personnalisé dans Imager :
# sans compte utilisateur, Raspberry Pi OS attend qu'on le crée… au clavier.
PAS_PERSO="La carte a été flashée SANS personnalisation (ou avec un Imager trop ancien).
   Refaites le flash avec Raspberry Pi Imager 2 et remplissez les étapes
   « Personnalisation » : nom d'hôte diktae-proxy, utilisateur + mot de passe, SSH activé.
   Cf. server/keyproxy/rpi/README-RPI.md § 1."

if [ -f "$SD/user-data" ] && head -1 "$SD/user-data" | grep -q '^#cloud-config'; then
  MODE=cloudinit
  grep -Eq '^user:|^users:' "$SD/user-data" || fail "$PAS_PERSO"
  HOTE="$(sed -n 's/^hostname:[[:space:]]*//p' "$SD/user-data" | head -1)"
  UTILISATEUR="$(awk '/^user:/{u=1;next} u && /^[^ ]/{u=0} u && /^  name:/{print $2; exit}' "$SD/user-data")"
  grep -q 'enable, --now, ssh' "$SD/user-data" && SSH_OK=1 || SSH_OK=0
  [ -f "$SD/network-config" ] && grep -q 'wifis:' "$SD/network-config" && WIFI=1 || WIFI=0
elif [ -f "$SD/firstrun.sh" ]; then
  MODE=firstrun
  HOTE="$(sed -n 's/.*imager_custom set_hostname \([^ ]*\).*/\1/p' "$SD/firstrun.sh" | head -1)"
  UTILISATEUR="$(sed -n "s/.*userconf-pi\/userconf '\{0,1\}\([^' ]*\).*/\1/p" "$SD/firstrun.sh" | head -1)"
  grep -q 'enable_ssh\|systemctl enable ssh' "$SD/firstrun.sh" && SSH_OK=1 || SSH_OK=0
  grep -q 'set_wlan\|wpa_supplicant' "$SD/firstrun.sh" && WIFI=1 || WIFI=0
elif [ -f "$SD/rpi-preseed.toml" ]; then
  fail "Cette image se personnalise par rpi-preseed, que ce kit ne sait pas encore compléter.
   Choisissez « Raspberry Pi OS Lite (64-bit) » dans Imager et reflashez."
else
  fail "$PAS_PERSO"
fi
HOTE="${HOTE:-diktae-proxy}"
UTILISATEUR="${UTILISATEUR:-<utilisateur>}"
ok "Personnalisation Imager reconnue ($MODE) : hôte « $HOTE », utilisateur « $UTILISATEUR »"
[ "$SSH_OK" -eq 1 ] || warn "SSH n'a pas été activé dans Imager : le Pi s'installera quand même,
      mais sans SSH, pas de dépannage ni d'ajout du tunnel plus tard. Reflasher avec SSH est conseillé."
[ "$WIFI" -eq 1 ] || warn "Pas de Wi-Fi configuré : le Pi DOIT être branché en Ethernet."

# --------------------------------------------------------------------------- #
# 2. Les secrets (jamais affichés, jamais dans l'historique du shell)
# --------------------------------------------------------------------------- #
demander_secret() {                       # $1 = libellé
  local valeur=""
  printf '   %s : ' "$1" >&2
  read -rs valeur
  printf '\n' >&2
  printf '%s' "$valeur"
}

say "Secrets (la saisie ne s'affiche pas)"

CLE_MAC=""
if [ -f "$ENV_MAC" ]; then
  CLE_MAC="$(sed -n 's/^ANTHROPIC_API_KEY=//p' "$ENV_MAC" | tail -1 | tr -d '"'"'"' \r')"
fi
if [ -n "$CLE_MAC" ]; then
  CLE_ANTHROPIC="$(demander_secret "Clé Anthropic (Entrée = reprendre celle de ce Mac, …${CLE_MAC: -4})")"
  [ -n "$CLE_ANTHROPIC" ] || CLE_ANTHROPIC="$CLE_MAC"
else
  CLE_ANTHROPIC="$(demander_secret 'Clé Anthropic (sk-ant-…)')"
fi
[ -n "$CLE_ANTHROPIC" ] || fail "La clé Anthropic est obligatoire : c'est elle que le proxy protège."
case "$CLE_ANTHROPIC" in
  sk-ant-*) : ;;
  *) fail "Cette clé ne commence pas par « sk-ant- » — vérifiez le copier-coller." ;;
esac

TUNNEL_TOKEN="$(demander_secret 'Token du tunnel Cloudflare (eyJ…) — Entrée = plus tard')"
if [ -z "$TUNNEL_TOKEN" ]; then
  warn "Pas de tunnel pour l'instant : le proxy tournera sur le Pi sans être joignable
      depuis Internet. Il s'ajoutera plus tard :  bash server/keyproxy/rpi/ajouter-tunnel.sh"
else
  case "$TUNNEL_TOKEN" in
    eyJ*) : ;;
    *) warn "ce token ne commence pas par « eyJ » — inhabituel, je continue quand même" ;;
  esac
fi

# Le jeton admin n'a pas à être mémorisé par un humain : on le tire au sort.
if command -v openssl >/dev/null 2>&1; then
  JETON_ADMIN="$(openssl rand -hex 24)"
else
  JETON_ADMIN="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
fi
ok "Jeton admin engendré"

# --------------------------------------------------------------------------- #
# 3. Copier le keyproxy sur la carte
# --------------------------------------------------------------------------- #
DEST="$SD/keyproxy"
say "Copie du keyproxy vers ${DEST}…"
rm -rf "$DEST"
mkdir -p "$DEST/rpi"
for f in app.py requirements.txt Dockerfile README.md .env.example; do
  [ -f "$SRC/$f" ] || fail "$f manquant dans $SRC — dépôt incomplet ?"
  cp "$SRC/$f" "$DEST/"
done
cp "$ICI/docker-compose.yml" "$ICI/provision.sh" "$ICI/autoprovision-hook.sh" \
   "$ICI/ajouter-tunnel.sh" "$ICI/README-RPI.md" "$DEST/rpi/"

# Le .env : sur une FAT, les permissions n'existent pas — c'est pourquoi
# provision.sh l'efface de la carte dès qu'il l'a recopié en 600 sur le Pi.
umask 077
cat > "$DEST/.env" <<ENVFILE
# Écrit par rpi/preparer-carte-sd.sh — ce fichier sera DÉPLACÉ hors de la carte
# par le provisionnement (un secret n'a rien à faire sur une partition FAT).
ANTHROPIC_API_KEY=$CLE_ANTHROPIC
PROXY_ADMIN_TOKEN=$JETON_ADMIN
TUNNEL_TOKEN=$TUNNEL_TOKEN
ENVFILE
umask 022
# macOS sème des « ._fichier » (attributs étendus) sur les cartes FAT.
find "$DEST" -name '._*' -delete 2>/dev/null || true
ok "Keyproxy et secrets déposés sur la carte"

# --------------------------------------------------------------------------- #
# 4. Auto-provisionnement au premier démarrage (plus de SSH à faire)
# --------------------------------------------------------------------------- #
if [ "$MODE" = cloudinit ]; then
  # Raspberry Pi OS Trixie : Imager 2 écrit un user-data cloud-init, dont la
  # section `runcmd:` (toujours la dernière) s'exécute une fois, réseau monté.
  # On y AJOUTE une commande, sans toucher au reste (compte, SSH, Wi-Fi).
  command -v python3 >/dev/null 2>&1 || fail "python3 est nécessaire pour compléter le user-data."
  python3 - "$SD/user-data" <<'PYEOF'
import re, sys
chemin = sys.argv[1]
texte = open(chemin, encoding="utf-8").read()
if "autoprovision-hook" in texte:
    print("   (auto-provisionnement déjà présent dans user-data)")
    sys.exit(0)
cmd = ('bash /boot/firmware/keyproxy/rpi/autoprovision-hook.sh --demarrer'
       ' >>/var/log/diktae-provision.log 2>&1')
lignes = texte.splitlines()
debut = next((i for i, l in enumerate(lignes) if re.match(r"^runcmd:\s*$", l)), None)
if debut is None:
    while lignes and not lignes[-1].strip():
        lignes.pop()
    lignes += ["", "runcmd:", f'  - [ bash, -c, "{cmd}" ]']
else:
    # Fin du bloc runcmd = prochaine clé de premier niveau (ou fin de fichier).
    fin = next((i for i in range(debut + 1, len(lignes))
                if lignes[i] and not lignes[i][0].isspace() and not lignes[i].startswith(("-", "#"))),
               len(lignes))
    while fin > debut + 1 and not lignes[fin - 1].strip():
        fin -= 1
    items = [l for l in lignes[debut + 1:fin] if l.lstrip().startswith("-")]
    retrait = (len(items[0]) - len(items[0].lstrip())) if items else 2
    lignes.insert(fin, " " * retrait + f'- [ bash, -c, "{cmd}" ]')
nouveau = "\n".join(lignes) + "\n"
try:
    import yaml
except ImportError:
    yaml = None
if yaml is not None:
    doc = yaml.safe_load(nouveau)
    assert isinstance(doc, dict) and ("user" in doc or "users" in doc), "compte utilisateur perdu"
    assert any("autoprovision-hook" in str(c) for c in doc.get("runcmd") or []), "runcmd incomplet"
open(chemin, "w", encoding="utf-8").write(nouveau)
PYEOF
  ok "Auto-provisionnement ajouté au user-data cloud-init d'Imager"
else
  # Bookworm : Imager écrit firstrun.sh, lancé via `systemd.run=` de cmdline.txt.
  # On s'y greffe AVANT son ménage de fin (rm firstrun / exit 0), sinon notre
  # ligne ne serait jamais atteinte — firstrun nettoie lui-même cmdline.txt.
  HOOK='bash /boot/firmware/keyproxy/rpi/autoprovision-hook.sh || bash /boot/keyproxy/rpi/autoprovision-hook.sh || true'
  FIRSTRUN="$SD/firstrun.sh"
  if grep -q "autoprovision-hook" "$FIRSTRUN"; then
    ok "Auto-provisionnement déjà greffé sur firstrun.sh"
  else
    tmp="$(mktemp)"
    if grep -q '^rm -f /boot/firstrun.sh' "$FIRSTRUN"; then
      awk -v hook="$HOOK" '/^rm -f \/boot\/firstrun.sh/ && !done {print hook; done=1} {print}' \
        "$FIRSTRUN" > "$tmp"
    elif grep -q '^exit 0' "$FIRSTRUN"; then
      awk -v hook="$HOOK" '/^exit 0/ && !done {print hook; done=1} {print}' "$FIRSTRUN" > "$tmp"
    else
      cat "$FIRSTRUN" > "$tmp"; printf '%s\n' "$HOOK" >> "$tmp"
    fi
    cat "$tmp" > "$FIRSTRUN"; rm -f "$tmp"
    ok "Auto-provisionnement greffé sur le firstrun.sh d'Imager"
  fi
fi

# --------------------------------------------------------------------------- #
# 5. Garder le jeton admin sur ce Mac, puis récapituler
# --------------------------------------------------------------------------- #
if [ -f "$ENV_MAC" ]; then
  tmp="$(mktemp)"
  grep -v '^KEYPROXY_ADMIN_TOKEN=' "$ENV_MAC" > "$tmp" || true
  printf 'KEYPROXY_ADMIN_TOKEN=%s\n' "$JETON_ADMIN" >> "$tmp"
  cat "$tmp" > "$ENV_MAC"; rm -f "$tmp"
  ok "Jeton admin rangé dans $(basename "$(dirname "$ENV_MAC")")/.env (KEYPROXY_ADMIN_TOKEN)"
fi

cat <<RECAP

$(printf '\033[1;32m═══ Carte prête ═══\033[0m')

Jeton admin (aussi rangé dans le .env de ce Mac) :

    $JETON_ADMIN

Suite des opérations :
  1. Éjecter la carte, la mettre dans le Pi.
  2. Brancher l'Ethernet PUIS l'alimentation.
  3. Attendre ~15 min (le Pi se configure, installe Docker, construit l'image).
  4. Sur ce Mac :
RECAP
if [ -n "$TUNNEL_TOKEN" ]; then
  echo "       bash server/keyproxy/rpi/verifier.sh"
else
  echo "       bash server/keyproxy/rpi/verifier.sh --ssh $UTILISATEUR@$HOTE.local"
  echo
  echo "Le tunnel Cloudflare, quand il existera :"
  echo "       bash server/keyproxy/rpi/ajouter-tunnel.sh --ssh $UTILISATEUR@$HOTE.local"
fi
echo
echo "En cas de doute, sur le Pi :  ssh $UTILISATEUR@$HOTE.local"
echo "                              sudo cat /var/log/diktae-provision.log"
echo

if command -v diskutil >/dev/null 2>&1; then
  printf 'Éjecter la carte maintenant ? [O/n] '
  read -r rep || rep=n
  case "$rep" in
    n|N|non|NON) echo "Pensez à l'éjecter depuis le Finder avant de la retirer." ;;
    *) diskutil eject "$SD" >/dev/null && ok "Carte éjectée — vous pouvez la retirer." \
         || warn "Éjection refusée (fichier ouvert ?) — éjectez-la depuis le Finder." ;;
  esac
fi
