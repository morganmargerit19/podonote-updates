#!/usr/bin/env bash
# ============================================================================ #
# Provisionnement AUTONOME du keyproxy Diktae sur Raspberry Pi (une commande).
#
#   sudo bash /boot/firmware/keyproxy/rpi/provision.sh
#
# Prérequis (cf. README-RPI.md) : le dossier `server/keyproxy/` du repo copié
# sur la partition boot de la carte SD (visible depuis Windows après flash),
# avec un fichier `.env` rempli à sa racine (ANTHROPIC_API_KEY et
# PROXY_ADMIN_TOKEN obligatoires ; TUNNEL_TOKEN facultatif — sans lui, le proxy
# tourne en local et rpi/ajouter-tunnel.sh branchera le tunnel plus tard).
#
# Idempotent : relançable sans casse (réinstalle/redémarre proprement).
# ============================================================================ #
set -euo pipefail

DEST=/opt/diktae-keyproxy
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # …/keyproxy

say()  { echo -e "\033[1;33m▶ $*\033[0m"; }
fail() { echo -e "\033[1;31m✖ $*\033[0m" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Lancez avec sudo : sudo bash $0"
[ -f "$SRC/app.py" ] || fail "app.py introuvable à côté de rpi/ — copiez le dossier keyproxy COMPLET."
# Relance à la main après un premier provisionnement : le .env a déjà quitté la
# carte (il vit en 600 dans $DEST), c'est lui qui fait foi.
if [ -f "$SRC/.env" ]; then
  ENV_SOURCE="$SRC/.env"
elif [ -f "$DEST/.env" ]; then
  ENV_SOURCE="$DEST/.env"
else
  fail "Fichier .env manquant dans $SRC — copiez .env.example en .env et remplissez ANTHROPIC_API_KEY et PROXY_ADMIN_TOKEN."
fi

for var in ANTHROPIC_API_KEY PROXY_ADMIN_TOKEN; do
  grep -Eq "^${var}=..+" "$ENV_SOURCE" || fail "$var absent ou vide dans $ENV_SOURCE"
done
if grep -Eq "^TUNNEL_TOKEN=..+" "$ENV_SOURCE"; then
  PROFIL=(--profile tunnel)
else
  PROFIL=()
fi

# Au premier démarrage, cloud-init et les mises à jour automatiques d'apt peuvent
# tenir le verrou dpkg quelques minutes : on attend au lieu d'échouer.
export DEBIAN_FRONTEND=noninteractive
APT_OPTS=(-o DPkg::Lock::Timeout=600)

say "Mise à jour du système (peut prendre quelques minutes)…"
apt-get "${APT_OPTS[@]}" update -qq
apt-get "${APT_OPTS[@]}" install -y -qq curl ca-certificates >/dev/null

if ! command -v docker >/dev/null 2>&1; then
  say "Installation de Docker…"
  curl -fsSL https://get.docker.com | sh >/dev/null
else
  say "Docker déjà installé."
fi

say "Copie du keyproxy vers ${DEST}…"
mkdir -p "$DEST"
cp -r "$SRC/app.py" "$SRC/requirements.txt" "$SRC/Dockerfile" "$SRC/rpi" "$DEST/"
# .env : copie en 600 (racine seulement), puis retiré de la partition boot si
# c'est de là qu'on provisionne — un secret n'a rien à faire sur une FAT lisible.
if [ "$ENV_SOURCE" != "$DEST/.env" ]; then
  install -m 600 "$ENV_SOURCE" "$DEST/.env"
  case "$SRC" in /boot/*) say "Secrets déplacés hors de la partition boot."; rm -f "$SRC/.env" ;; esac
fi

if [ ${#PROFIL[@]} -gt 0 ]; then
  say "Construction et démarrage (keyproxy + tunnel Cloudflare)…"
else
  say "Construction et démarrage (keyproxy seul — pas encore de tunnel)…"
fi
cd "$DEST"
docker compose -f rpi/docker-compose.yml --project-directory . ${PROFIL[@]+"${PROFIL[@]}"} up -d --build

say "Vérification locale…"
for _ in $(seq 1 20); do
  sleep 2
  if curl -fsS http://127.0.0.1:8787/healthz >/dev/null 2>&1; then break; fi
done
curl -fsS http://127.0.0.1:8787/healthz || fail "Le proxy ne répond pas — voir : docker compose -f $DEST/rpi/docker-compose.yml logs"
echo

say "✅ Keyproxy en service sur ce Pi (redémarre tout seul avec la machine)."
if [ ${#PROFIL[@]} -eq 0 ]; then
  cat <<'EOF'

Pas de tunnel pour l'instant : le proxy ne répond que sur ce Pi. Pour l'ouvrir
sur Internet, depuis le Mac :  bash server/keyproxy/rpi/ajouter-tunnel.sh
EOF
  exit 0
fi
cat <<'EOF'

Dernière étape (une fois, dans le tableau de bord Cloudflare) :
  Zero Trust → Networks → Tunnels → votre tunnel → Public hostname
  → api.studio-margerit.fr  →  Service : HTTP  →  URL : keyproxy:8787

Puis testez depuis n'importe où :
  curl https://api.studio-margerit.fr/healthz
  → {"ok": true, ..., "key_configured": true}

Côté postes Diktae (.env) :
  LLM_BACKEND=sonnet
  LLM_PROXY_URL=https://api.studio-margerit.fr

Suivi de conso :
  curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
       "https://api.studio-margerit.fr/admin/usage?month=2026-08"
EOF
