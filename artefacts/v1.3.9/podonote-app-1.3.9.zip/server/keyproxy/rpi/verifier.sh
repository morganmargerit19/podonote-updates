#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — vérification du keyproxy depuis le Mac, après le premier démarrage.
#
#      bash server/keyproxy/rpi/verifier.sh
#      bash server/keyproxy/rpi/verifier.sh --url https://api.exemple.fr
#      bash server/keyproxy/rpi/verifier.sh --licence "AgIA…"   # test RÉEL
#      bash server/keyproxy/rpi/verifier.sh --ssh morgan@diktae-proxy.local
#                             # (pas encore de tunnel : on interroge le Pi en SSH)
#
#  Trois niveaux de preuve, du moins cher au plus probant :
#    1. /healthz            → le proxy répond et détient bien la clé Anthropic ;
#    2. /v1/messages        → un aller-retour complet avec une vraie licence
#                             (--licence), le proxy relayant vers Anthropic ;
#    3. /admin/usage        → la consommation est bien comptabilisée.
# ============================================================================ #
set -uo pipefail

URL="https://api.studio-margerit.fr"
LICENCE=""
JETON_ADMIN=""
CIBLE_SSH=""
ATTENTE=1200                                 # 20 min : premier démarrage + provisionnement

while [ $# -gt 0 ]; do
  case "$1" in
    --url)     URL="${2%/}"; shift 2 ;;
    --licence) LICENCE="$2"; shift 2 ;;
    --admin)   JETON_ADMIN="$2"; shift 2 ;;
    --attente) ATTENTE="$2"; shift 2 ;;
    --ssh)     CIBLE_SSH="$2"; shift 2 ;;
    -h|--help) sed -n '2,18p' "$0"; exit 0 ;;
    *) printf 'Option inconnue : %s\n' "$1" >&2; exit 2 ;;
  esac
done

say()  { printf '\033[1;33m▶ %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$*"; }
ko()   { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; }

# --------------------------------------------------------------------------- #
# Mode SSH : le proxy n'écoute que sur le Pi lui-même (127.0.0.1) tant qu'aucun
# tunnel n'existe. Une connexion multiplexée évite de retaper le mot de passe.
# --------------------------------------------------------------------------- #
if [ -n "$CIBLE_SSH" ]; then
  CTL="${TMPDIR:-/tmp}/diktae-ssh-$$"
  SSH_OPTS=(-o ControlMaster=auto -o "ControlPath=$CTL" -o ControlPersist=1500
            -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new)
  trap 'ssh "${SSH_OPTS[@]}" -O exit "$CIBLE_SSH" >/dev/null 2>&1 || true' EXIT
  say "Attente du Pi $CIBLE_SSH (il démarre, puis se configure)…"
  debut=$(date +%s)
  until ssh "${SSH_OPTS[@]}" "$CIBLE_SSH" true 2>/dev/null; do
    if [ $(( $(date +%s) - debut )) -ge "$ATTENTE" ]; then
      ko "Le Pi ne répond pas en SSH. Est-il branché en Ethernet ? Son nom est-il le bon ?"
      exit 1
    fi
    printf '.'; sleep 15
  done
  printf '\n'; ok "Pi joignable en SSH"
  interroger() { ssh "${SSH_OPTS[@]}" "$CIBLE_SSH" 'curl -fsS --max-time 10 http://127.0.0.1:8787/healthz' 2>/dev/null || true; }
else
  interroger() { curl -fsS --max-time 10 "$URL/healthz" 2>/dev/null || true; }
fi

# --------------------------------------------------------------------------- #
# 1. Santé — en patientant, car le Pi construit son image au premier démarrage
# --------------------------------------------------------------------------- #
say "Attente du proxy sur ${CIBLE_SSH:-$URL} (jusqu'à $((ATTENTE / 60)) min)…"
debut=$(date +%s)
reponse=""
while :; do
  reponse="$(interroger)"
  [ -n "$reponse" ] && break
  ecoule=$(( $(date +%s) - debut ))
  if [ "$ecoule" -ge "$ATTENTE" ]; then
    ko "Aucune réponse après $((ATTENTE / 60)) min."
    cat <<'AIDE'

Pistes, dans l'ordre :
  • Le tunnel Cloudflare a-t-il un « Public hostname » ? Zero Trust → Networks
    → Tunnels → votre tunnel → Public hostname → Service HTTP, URL keyproxy:8787
  • Sur le Pi (ssh) :   sudo cat /var/log/diktae-provision.log
                        sudo systemctl status diktae-keyproxy-provision
  • Le Pi a-t-il Internet ? (Ethernet branché, LED verte qui clignote)
AIDE
    exit 1
  fi
  printf '.'
  sleep 10
done
printf '\n'
ok "Proxy joignable"
printf '   %s\n' "$reponse"

case "$reponse" in
  *'"key_configured": true'*|*'"key_configured":true'*)
    ok "La clé Anthropic est bien présente côté serveur" ;;
  *)
    ko "key_configured = false : le .env du Pi n'a pas été lu (ANTHROPIC_API_KEY vide)."
    exit 1 ;;
esac

if [ -n "$CIBLE_SSH" ]; then
  cat <<FIN

$(printf '\033[1;32m═══ Le proxy tourne sur le Pi ═══\033[0m')

Il n'est pas encore joignable depuis Internet. Quand le tunnel Cloudflare existera :
    bash server/keyproxy/rpi/ajouter-tunnel.sh --ssh $CIBLE_SSH
puis :
    bash server/keyproxy/rpi/verifier.sh

FIN
  exit 0
fi

# --------------------------------------------------------------------------- #
# 2. Aller-retour réel (nécessite une licence valide)
# --------------------------------------------------------------------------- #
if [ -n "$LICENCE" ]; then
  say "Appel réel /v1/messages avec la licence fournie…"
  corps='{"model":"claude-sonnet-5","max_tokens":16,"messages":[{"role":"user","content":"Réponds exactement : OK"}]}'
  reponse2="$(curl -fsS --max-time 60 -X POST "$URL/v1/messages" \
      -H "x-api-key: $LICENCE" \
      -H "anthropic-version: 2023-06-01" \
      -H "content-type: application/json" \
      -d "$corps" 2>/dev/null || true)"
  if [ -z "$reponse2" ]; then
    ko "Pas de réponse — licence refusée, ou modèle non autorisé (PROXY_ALLOWED_MODELS)."
    ko "Détail :  curl -i -X POST $URL/v1/messages -H \"x-api-key: …\" -d '…'"
  else
    ok "Le proxy a relayé vers Anthropic"
    printf '   %s…\n' "$(printf '%s' "$reponse2" | cut -c1-160)"
  fi
else
  printf '\033[2m   (test réel ignoré : relancez avec --licence "…" pour un aller-retour complet)\033[0m\n'
fi

# --------------------------------------------------------------------------- #
# 3. Consommation
# --------------------------------------------------------------------------- #
if [ -n "$JETON_ADMIN" ]; then
  say "Consommation du mois…"
  mois="$(date +%Y-%m)"
  usage="$(curl -fsS --max-time 20 -H "Authorization: Bearer $JETON_ADMIN" \
      "$URL/admin/usage?month=$mois" 2>/dev/null || true)"
  if [ -n "$usage" ]; then
    ok "Rapport obtenu"
    printf '   %s\n' "$usage"
  else
    ko "Rapport refusé — jeton admin incorrect ?"
  fi
else
  printf '\033[2m   (conso ignorée : relancez avec --admin "…" pour le rapport)\033[0m\n'
fi

cat <<FIN

$(printf '\033[1;32m═══ Proxy opérationnel ═══\033[0m')

Pour brancher un poste Diktae dessus :
    bash server/keyproxy/rpi/basculer-poste.sh --url $URL

FIN
