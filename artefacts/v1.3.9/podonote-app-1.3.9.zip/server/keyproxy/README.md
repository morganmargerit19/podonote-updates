# Proxy de clés API — Studio Margerit

**But** : les postes Diktae des clients n'ont **aucune clé Anthropic**. Ils
appellent ce proxy avec leur **clé de licence** (jeton signé Ed25519 déjà en
place) ; le proxy vérifie la licence, relaie vers l'API Anthropic avec la vraie
clé (qui ne vit que sur ce serveur), et **compte la consommation par licencié**
(tokens, coût estimé) — jamais le contenu des messages.

```
Poste Diktae ──(clé de LICENCE en x-api-key)──▶  keyproxy  ──(vraie clé)──▶ api.anthropic.com
                                                   │
                                                   └─ keyproxy.db (conso par licencié)
```

## Déploiement rapide (VPS avec Docker — ~15 min)

Sur n'importe quel petit VPS (Scaleway/OVH/Hetzner, 1 vCPU suffit — le proxy ne
fait que relayer du JSON) :

```bash
git clone <repo> && cd podonote/server/keyproxy
cp .env.example .env          # puis renseigner ANTHROPIC_API_KEY + PROXY_ADMIN_TOKEN
docker build -t diktae-keyproxy .
docker run -d --name keyproxy --restart unless-stopped \
  --env-file .env -p 127.0.0.1:8787:8787 -v keyproxy-data:/data diktae-keyproxy
```

Mettre un **reverse-proxy TLS** devant (Caddy, le plus simple — certificat
automatique) :

```
# /etc/caddy/Caddyfile
api.studio-margerit.fr {
    reverse_proxy 127.0.0.1:8787
}
```

> ⚠️ **HTTPS obligatoire** en production : le texte (pseudonymisé) des
> consultations transite par ce proxy.

Sans Docker : `pip install -r requirements.txt` puis
`uvicorn app:app --host 127.0.0.1 --port 8787` derrière Caddy, avec les
variables du `.env` exportées (systemd `EnvironmentFile=` par exemple).

## Variante à ~0 € : Raspberry Pi 4 + Cloudflare Tunnel — kit « flash & go »

Le proxy ne fait que relayer du JSON (aucun ML) : un **RPi4 est largement
suffisant** pour des dizaines de praticiens. Coût : l'électricité (~2-3 €/an),
HTTPS via **Cloudflare Tunnel** gratuit (aucun port à ouvrir sur la box, pas
d'IP fixe). Tout est prêt dans **`rpi/`** : flash avec Raspberry Pi Imager,
copie du dossier sur la carte, puis **UNE commande** sur le Pi
(`sudo bash /boot/firmware/keyproxy/rpi/provision.sh`).
→ Pas-à-pas complet : **`rpi/README-RPI.md`** (migration VPS incluse — mêmes
fichiers, on copie `keyproxy.db`, les postes clients ne changent rien).

Limite à connaître (acceptable pour démarrer) : si le Pi ou la box tombe, la
**génération de fiche** échoue chez les clients le temps de la panne — la
transcription locale continue, le transcript est conservé et « Réessayer »
relance la fiche sans refaire l'ASR. Rien n'est perdu.

## Vérifier

```bash
curl https://api.studio-margerit.fr/healthz
# {"ok": true, "upstream": "https://api.anthropic.com", "key_configured": true}
```

## Côté poste client (Diktae)

**Rien à régler depuis la 1.3.1** : le proxy est la route par défaut du code
(`app/config.py`, `DEFAULT_LLM_PROXY_URL`). Un `.env` où `LLM_PROXY_URL` est
absente ou vide — c'est le cas de tous les postes installés — passe par
`https://api.studio-margerit.fr` ; il suffit d'une **licence activée** (c'est
elle qui sert d'accès). Les postes existants basculent donc **par l'OTA 1.3.1**,
Nico compris ; les installeurs n'intègrent plus de clé.

`LLM_PROXY_URL=direct` rétablit l'appel direct avec la clé locale (poste de
développement). Une fois tous les postes basculés (visibles dans `/admin/usage`),
**révoquer l'ancienne clé** Anthropic qui était intégrée aux paquets.

## Suivre la consommation

**Tableau de bord** : <https://api.studio-margerit.fr/admin> — coût du mois et
projection, coût par praticien et par génération, courbe jour par jour, erreurs,
dernières requêtes. La page ne contient aucune donnée : elle demande le jeton
admin (gardé dans le navigateur) puis interroge `/admin/stats`. Coûts estimés
d'après les tarifs publics, cache compris (la facture Anthropic fait foi).

En ligne de commande :

```bash
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  "https://api.studio-margerit.fr/admin/usage?month=2026-08"
```

Réponse : par licencié et par modèle — nombre de requêtes (`requests`, `ok`),
tokens entrée/sortie, tokens servis du cache, `cost_estimate_eur` (indicatif —
la facture Anthropic fait foi), dernière activité. C'est la base du comptage
des paliers d'abonnement (cf. `docs/TARIFS.md`).

## Retours des praticiens (bugs et suggestions)

Le même tableau de bord affiche la section **« Retours des praticiens »** :
chaque bug signalé et chaque suggestion envoyés depuis un poste, avec le
praticien, la version de l'app, le système, le moteur utilisé, et un bouton
« Marquer traité ».

Le poste dépose son retour sur `POST /feedback`, **authentifié par la clé de
licence** comme les appels Claude — aucun secret supplémentaire n'est distribué
avec l'app. Le texte arrive **déjà pseudonymisé** par le poste
(`app/feedback.py` : noms, prénoms, dates de naissance des patients remplacés
par des jetons, filet générique e-mail/téléphone/dates/longs nombres). Le
mapping reste sur le poste : **ce serveur ne peut pas ré-identifier**.

Un poste hors-ligne garde son retour dans une file locale et le réémet plus
tard ; le champ `ref` rend ces réémissions inoffensives (dédoublonnage).

**Captures d'écran.** Un retour peut porter une capture. Une image ne se
pseudonymise pas toute seule, et une capture de Diktae montre presque toujours
un nom de patient : le praticien masque donc lui-même les zones sensibles dans
l'app, et les rectangles sont **brûlés dans l'image avant l'envoi** (le fichier
d'origine ne quitte jamais son poste). Ici, on revérifie les octets magiques et
la taille. La capture n'est pas servie dans la liste — elle a sa propre route,
`GET /admin/feedback/{id}/image`, elle aussi sur jeton admin.

### Notification par mail (facultative)

Le Pi **n'est pas un serveur de mail** : il se contente de remettre le message
à un SMTP existant (Gmail, OVH, Infomaniak…) comme le ferait un client de
messagerie. Pas besoin de Resend, Mailgun ou d'un domaine dédié : le compte
mail que vous avez déjà suffit. (Faire tourner un vrai MTA sur une IP
résidentielle serait au contraire le mauvais choix — sans reverse DNS ni SPF,
les messages finiraient en indésirables.)

Dans le `.env` du Pi :

```bash
PROXY_SMTP_HOST=smtp.gmail.com
PROXY_SMTP_PORT=587
PROXY_SMTP_USER=votre.adresse@gmail.com
PROXY_SMTP_PASSWORD=<mot de passe d'application, 16 lettres>
PROXY_NOTIFY_TO=votre.adresse@gmail.com
```

- `PROXY_SMTP_PASSWORD` est un **mot de passe d'application** Google
  (myaccount.google.com → Sécurité → Validation en 2 étapes → Mots de passe des
  applications), pas le mot de passe du compte. La validation en 2 étapes doit
  être active pour pouvoir en créer un.
- `PROXY_NOTIFY_FROM` vaut par défaut `PROXY_SMTP_USER` : **laissez-le vide**.
  Mettre une autre adresse (`diktae@studio-margerit.fr`) suppose de l'avoir
  d'abord déclarée en « Envoyer des e-mails en tant que » dans Gmail, sinon
  l'adresse est réécrite ou le message refusé.
- `PROXY_NOTIFY_TO` accepte plusieurs adresses séparées par des virgules.
- Port 465 (TLS implicite) et 587 (STARTTLS) sont tous deux gérés — le port
  choisit le mode.

Puis relancer le conteneur et **vérifier tout de suite** :

```bash
curl -X POST -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  https://api.studio-margerit.fr/admin/test-mail
```

La réponse dit `ok: true` (un mail de test part) ou nomme précisément ce qui
cloche — variable absente, mot de passe refusé, serveur injoignable. Faites-le :
en fonctionnement normal, un échec d'envoi est **silencieux par conception**
(il ne doit pas faire échouer le dépôt d'un retour), donc sans ce test une
configuration fausse ne se verrait jamais.

L'envoi part dans un fil séparé et **ne peut pas faire échouer un dépôt** : un
SMTP en panne ne doit jamais faire croire à un praticien que son signalement
est perdu. La capture n'est **pas** jointe au mail — elle resterait chez
l'hébergeur de votre messagerie ; le mail renvoie au tableau de bord.

```bash
# Lire les retours en ligne de commande
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  "https://api.studio-margerit.fr/admin/feedback?status=nouveau"
```

Réglages : `PROXY_FEEDBACK_MAX_CHARS` (défaut 4000),
`PROXY_FEEDBACK_DAILY_LIMIT` (défaut 20 par licencié et par jour).

## Version en service (`/healthz`)

`GET /healthz` renvoie `version` : l'**empreinte du code en service** (`app.py`,
`admin.html`, `requirements.txt`, fins de ligne normalisées), calculée par le
proxy sur lui-même au démarrage. `scripts/deploy_update.py` la compare à celle du
dépôt avant chaque OTA et met le Pi à jour s'il est en retard — l'ordre *proxy
puis OTA* ne dépend plus de la mémoire de personne.

```bash
curl -s https://api.studio-margerit.fr/healthz      # {"ok": true, ..., "version": "a1b2c3d4e5f6"}
python scripts/deploy_update.py --check-proxy       # 0 = le Pi sert le code du dépôt
```

## Révoquer une clé de licence

Un jeton est signé hors ligne : sans liste de révocation, rien ne l'arrête
avant sa date d'expiration. Le proxy en tient une — c'est le seul endroit où
la couper serve à quelque chose, puisque c'est lui qui ouvre le robinet des
appels Claude.

```bash
# Les clés qui ont réellement appelé, et leur état
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
     https://api.studio-margerit.fr/admin/cles

# Annuler une clé (par empreinte, ou par `token` complet collé depuis le mail)
curl -X POST -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"token_fp":"<empreinte>","motif":"fuite"}' \
     https://api.studio-margerit.fr/admin/revoquer

# Lever une annulation posée par erreur
curl -X POST -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"token_fp":"<empreinte>","annuler":true}' \
     https://api.studio-margerit.fr/admin/revoquer
```

Plus simple : tableau de bord `/admin` → section **« Clés de licence »**.

- **Effet immédiat** sur toutes les routes authentifiées par licence :
  `/v1/messages`, `/quota`, `/feedback`, `/feedback/status`.
- **L'app continue de s'ouvrir** chez le praticien jusqu'à sa date : elle
  vérifie sa licence hors ligne. Ce qu'on coupe, c'est la dépense.
- On révoque **une clé, pas un praticien** : ses autres clés restent valables,
  sinon un renouvellement couperait le client.
- Le jeton n'est **jamais stocké** : seule son empreinte (`sha256` tronqué).
  La colonne `usage.token_fp` sert à savoir quelles clés circulent réellement.

## Forfaits (plafond mensuel de consultations)

Le jeton de licence ne porte QUE l'identité et l'échéance : il doit rester
vérifiable hors ligne. Le **palier de volume** vit donc ici, seul endroit
capable de compter. Conséquence voulue : faire passer un praticien d'une
formule à l'autre est un réglage — **pas une nouvelle clé à réémettre**.

```bash
# Voir tous les praticiens, leur palier et leur consommation du mois
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
     https://api.studio-margerit.fr/admin/forfaits

# Attribuer un palier (solo | standard | cabinet | illimite)
curl -X POST -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"licensee":"Nicolas Terranova","tier":"solo"}' \
     https://api.studio-margerit.fr/admin/forfait
```

Plus simple : le tableau de bord `/admin`, onglet **Dépenses** → tableau « Par
praticien » → colonne **Forfait** (liste déroulante, effet immédiat).

Réglages du `.env` :

| Variable | Défaut | Rôle |
|---|---|---|
| `PROXY_TIERS` | vide | Paliers posés au démarrage : `"Nicolas Terranova=solo, Cabinet X=standard"`. Évite d'avoir à penser au tableau de bord après un déploiement. |
| `PROXY_DEFAULT_TIER` | `standard` | Palier d'un licencié jamais réglé. Volontairement pas `illimite` : un oubli doit coûter, pas ouvrir le robinet. |
| `PROXY_QUOTA_WARN_RATIO` | `0.8` | Fraction du plafond à partir de laquelle l'app prévient le praticien. |

Le poste lit son propre compteur sur `GET /quota` (authentifié par sa licence,
cloisonné au licencié, comme `/feedback/status`) — c'est ce qui alimente le
bandeau d'alerte et la ligne « Forfait » des Réglages.

Détails du décompte :
- une consultation = **une requête aboutie** (`status < 400`) ; un refus de
  quota, une panne réseau ou une erreur amont ne brûlent rien ;
- le mois est celui du praticien (fuseau `PROXY_REPORT_TZ`), pas UTC : la
  remise à zéro tombe bien le 1er à 0 h à Paris ;
- les plans internes (`dev`) sont hors grille de volume.

## Une clé, un ordinateur (depuis la 1.3.7)

Une clé de licence ne doit servir qu'à une personne. Le jeton se vérifie hors
ligne et ne porte aucun identifiant de machine : c'est donc ce serveur qui
retient sur quel ordinateur chaque clé sert.

- L'app envoie à chaque appel l'identifiant anonyme de son poste (en-tête
  `x-diktae-poste` : empreinte du MachineGuid Windows ou de l'IOPlatformUUID du
  Mac, jamais un nom). C'est l'identifiant « DKT-… » de l'écran Licence.
- **Le premier ordinateur qui utilise une clé la garde.** Les suivants sont
  refusés (HTTP 403, code `poste_non_autorise`) sur toutes les routes :
  activation (`POST /licence/activer`, appelée quand le praticien colle sa
  clé), fiches, retours, compteur. L'app refuse alors la clé à l'activation,
  ou se bloque sur l'écran Licence avec « Clé déjà utilisée sur un autre
  ordinateur », et se débloque seule si le poste est libéré.
- Formule `dev` : sans limite (postes de test internes).
- Une app antérieure à la 1.3.7 (sans identifiant) passe tant que sa clé n'a
  encore aucun poste inscrit, le temps que l'OTA arrive ; dès qu'un poste est
  inscrit pour la clé, elle est refusée (« version trop ancienne »).

Au tableau de bord, section **Clés de licence** → colonne **Ordinateurs** :
- **Libérer** : le praticien change d'ordinateur. Le prochain qui utilise la clé
  prend la place.
- **Modifier** : praticien à deux postes (cabinet + maison). C'est
  toujours la même personne.

En ligne de commande :

```bash
curl -X POST -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"token_fp":"<empreinte>","liberer":true}' \
     https://api.studio-margerit.fr/admin/postes
```

| Variable | Défaut | Rôle |
|---|---|---|
| `PROXY_POSTES_PAR_CLE` | `1` | Ordinateurs autorisés par clé (dérogation clé par clé au tableau de bord). |
| `PROXY_POSTE_OBLIGATOIRE` | vide | `1` : refuser aussi les apps sans identifiant sur une clé jamais liée. À poser quand tous les postes sont en 1.3.7 ou plus. |

## Garde-fous intégrés

- **Licence obligatoire** : signature Ed25519 vérifiée contre la clé publique
  Diktae ; expiration avec grâce de 7 j (aucune grâce pour les plans `demo`).
- **Modèles bornés** (`PROXY_ALLOWED_MODELS`, défaut sonnet/haiku) et
  `max_tokens` plafonné (`PROXY_MAX_TOKENS`) : un jeton volé ne peut pas brûler
  du budget sur Opus.
- **Quota journalier** par licencié (`PROXY_DAILY_REQ_LIMIT`, défaut 250).
- **Forfait mensuel** par licencié : le plafond de consultations de sa formule
  (`solo` 40, `standard` 150, `cabinet` 300 — cf. `docs/TARIFS.md`). C'est ici,
  et nulle part ailleurs, que le volume d'un abonnement est opposable : un
  compteur posé dans l'app disparaîtrait avec un fichier effacé.
- **Aucun contenu stocké** : seuls des métadonnées (tokens, modèle, statut,
  durée) sont journalisées.
- **Retours bornés** : type et taille validés, quota journalier
  (`PROXY_FEEDBACK_DAILY_LIMIT`), dédoublonnage par `ref`. Le serveur ne fait
  jamais confiance au client : il retronque même un message déjà borné côté app.

## Tests

`python scripts/test_keyproxy.py` (à la racine du repo) : suite autonome —
clés Ed25519 éphémères + API Anthropic simulée, aucun réseau ni vraie clé.
