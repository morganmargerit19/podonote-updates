"""Proxy de clés API Studio Margerit — la clé Anthropic ne quitte JAMAIS ce serveur.

Problème résolu : distribuer Diktae à plusieurs podologues sans distribuer de
clé Anthropic (ni la clé perso de Morgan). Le poste client s'authentifie avec
sa CLÉ DE LICENCE Diktae (jeton Ed25519 déjà signé par Studio Margerit) passée
comme clé d'API (`x-api-key`) ; le proxy vérifie la signature et l'expiration,
relaie l'appel vers l'API Anthropic avec la vraie clé (variable d'env du
serveur), et JOURNALISE la consommation par licencié (tokens, modèle, coût
estimé) — jamais le contenu des messages (texte de santé pseudonymisé : il
transite, il n'est pas stocké).

Côté app : LLM_PROXY_URL=https://… dans le .env → `app/pipeline/llm.py` utilise
`anthropic.Anthropic(api_key=<jeton de licence>, base_url=<proxy>)`. Aucune
autre modification : le proxy parle le protocole de l'API Messages.

Lancement :  uvicorn app:app --host 0.0.0.0 --port 8787   (cf. README.md)
Variables :  ANTHROPIC_API_KEY (obligatoire), PROXY_ADMIN_TOKEN (obligatoire
pour /admin/usage), et les PROXY_* optionnelles ci-dessous.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import re
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import httpx
from fastapi import FastAPI, Header, Request, Response
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse

# --------------------------------------------------------------------------- #
# Configuration (env)
# --------------------------------------------------------------------------- #
# Clé PUBLIQUE des licences Diktae (même valeur que app/license.py). Surchargeable
# pour les tests ou une rotation de clé.
PUBLIC_KEY_B64 = os.environ.get(
    "PROXY_LICENSE_PUBLIC_KEY", "4BtFnPdW+EjMlukFYI+xUa4oPKBurvDV566V0sWsB7g=")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ADMIN_TOKEN = os.environ.get("PROXY_ADMIN_TOKEN", "")
UPSTREAM = os.environ.get("PROXY_UPSTREAM", "https://api.anthropic.com").rstrip("/")
DB_PATH = os.environ.get("PROXY_DB", "keyproxy.db")
# Modèles autorisés (préfixes, séparés par des virgules) : par défaut les tiers
# que Diktae utilise. Empêche un jeton volé de brûler du budget sur Opus.
ALLOWED_MODEL_PREFIXES = [p.strip() for p in os.environ.get(
    "PROXY_ALLOWED_MODELS", "claude-sonnet,claude-haiku").split(",") if p.strip()]
MAX_TOKENS_LIMIT = int(os.environ.get("PROXY_MAX_TOKENS", "32000"))
MAX_BODY_BYTES = int(os.environ.get("PROXY_MAX_BODY_BYTES", str(2 * 1024 * 1024)))
# Garde-fou anti-emballement : requêtes / jour / licencié (300 consult./mois du
# palier Cabinet ≈ 15/jour ouvré — 250 laisse une marge très large).
DAILY_REQ_LIMIT = int(os.environ.get("PROXY_DAILY_REQ_LIMIT", "250"))
USD_EUR = float(os.environ.get("PROXY_USD_EUR", "0.92"))
# Retours praticiens (bug / suggestion) : garde-fous de taille et de débit. Le
# message est du texte libre déjà pseudonymisé côté app (app/feedback.py) — on
# le borne ici aussi, un serveur ne fait jamais confiance à son client.
FEEDBACK_MAX_CHARS = int(os.environ.get("PROXY_FEEDBACK_MAX_CHARS", "4000"))
FEEDBACK_DAILY_LIMIT = int(os.environ.get("PROXY_FEEDBACK_DAILY_LIMIT", "20"))
FEEDBACK_KINDS = ("bug", "idee")
FEEDBACK_STATUSES = ("nouveau", "vu", "traite")
# Réponse écrite de Studio Margerit, relue par le praticien dans son app (« vu,
# corrigé en 1.3.3 »). Courte par nature : c'est un mot de suivi, pas un mail.
FEEDBACK_REPLY_MAX_CHARS = int(os.environ.get("PROXY_FEEDBACK_REPLY_MAX_CHARS", "600"))
# Références interrogeables en une fois par un poste (GET /feedback/status).
FEEDBACK_STATUS_MAX_REFS = 50
# Capture d'écran jointe : déjà bornée et masquée côté poste (l'app rogne à
# 1600 px et ré-encode en JPEG). On replafonne ici — le serveur ne fait jamais
# confiance à son client.
FEEDBACK_MAX_IMAGE_BYTES = int(os.environ.get(
    "PROXY_FEEDBACK_MAX_IMAGE_BYTES", str(3 * 1024 * 1024)))
IMAGE_MAGIC = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff")   # PNG, JPEG
# Corps d'un retour : la capture en base64 pèse ~4/3 de l'image.
FEEDBACK_MAX_BODY_BYTES = FEEDBACK_MAX_IMAGE_BYTES * 2

# --- Notification par mail (facultative : sans SMTP_HOST, rien n'est envoyé et
# le dépôt fonctionne exactement pareil). La capture N'EST PAS jointe au mail :
# elle reste sur ce serveur, le mail renvoie au tableau de bord.
SMTP_HOST = os.environ.get("PROXY_SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("PROXY_SMTP_PORT", "587"))
SMTP_USER = os.environ.get("PROXY_SMTP_USER", "")
SMTP_PASSWORD = os.environ.get("PROXY_SMTP_PASSWORD", "")
NOTIFY_FROM = os.environ.get("PROXY_NOTIFY_FROM", "") or SMTP_USER
NOTIFY_TO = [a.strip() for a in os.environ.get("PROXY_NOTIFY_TO", "").split(",") if a.strip()]
DASHBOARD_URL = os.environ.get("PROXY_DASHBOARD_URL", "https://api.studio-margerit.fr/admin")

GRACE_DAYS = 7                      # comme app/license.py
DEMO_PLANS = ("demo", "essai")      # démo : PAS de grâce
_DAY = 86400
PLAN_CODES = {0: "mensuel", 1: "annuel", 2: "dev", 3: "essai", 4: "trimestriel",
              5: "demo", 6: "ambassadeur"}
_FMT_COMPACT = 2

# --------------------------------------------------------------------------- #
# Plafond de CONSULTATIONS IA par mois (grille docs/TARIFS.md)
#
# L'unité facturée est LA CONSULTATION DICTÉE : une fiche rédigée par l'IA = une
# requête relayée ici. Le jeton de licence ne porte QUE l'identité et l'échéance
# (il est vérifiable hors ligne) ; le PALIER DE VOLUME vit dans ce serveur, seul
# endroit capable de compter. Conséquence voulue : changer un praticien de
# formule est un réglage du tableau de bord, pas une nouvelle clé à réémettre.
# --------------------------------------------------------------------------- #
TIER_CAPS = {
    "solo": 40,        # Pédicure / Solo léger
    "standard": 150,   # Standard
    "cabinet": 300,    # Cabinet / Pro
    "illimite": 0,     # 0 = aucun plafond (usage interne)
}
# Palier appliqué à un licencié encore inconnu du tableau de bord. « standard »
# par défaut : un oubli de réglage coûte au plus le palier du milieu, il ne
# bloque jamais un abonné qui a payé plus.
DEFAULT_TIER = os.environ.get("PROXY_DEFAULT_TIER", "standard")
# Plans hors grille de volume : l'interne, et la démo (bornée par ses minutes
# de transcription côté app, pas par un nombre de consultations).
UNMETERED_PLANS = ("dev",)

# --------------------------------------------------------------------------- #
# UNE CLÉ = UN ORDINATEUR (29/09/2026, demande de Morgan : « il ne faut pas que
# les clés de licence puissent servir à plusieurs personnes »).
#
# Le jeton se vérifie hors ligne et ne porte aucun identifiant de machine : seul
# ce serveur peut retenir sur quel(s) ordinateur(s) une clé sert. L'app envoie
# l'identifiant anonyme de son poste (en-tête `x-diktae-poste` : empreinte du
# MachineGuid Windows ou de l'IOPlatformUUID du Mac, jamais un nom). Les N
# premiers postes d'une clé sont inscrits, les suivants refusés — activation,
# rédaction IA, retours et compteur compris. Le tableau de bord libère les
# postes d'une clé (le praticien change d'ordinateur) ou en autorise davantage,
# clé par clé.
# --------------------------------------------------------------------------- #
POSTES_PAR_CLE = int(os.environ.get("PROXY_POSTES_PAR_CLE", "1"))
# Une app antérieure n'envoie pas l'en-tête : acceptée tant que sa clé n'a
# encore inscrit aucun poste (le temps que l'OTA passe), refusée dès qu'un poste
# l'est — sans quoi une vieille version suffirait à contourner la règle.
# PROXY_POSTE_OBLIGATOIRE=1 : refusée toujours, une fois tous les postes à jour.
POSTE_OBLIGATOIRE = os.environ.get(
    "PROXY_POSTE_OBLIGATOIRE", "").strip().lower() in ("1", "true", "oui", "yes")
POSTES_ILLIMITES_PLANS = ("dev",)       # usage interne : plusieurs postes de test
POSTE_REFUSE = "poste_non_autorise"
POSTE_REFUSE_MESSAGE = (
    "Cette clé de licence est déjà utilisée sur un autre ordinateur : une clé "
    "Diktae ne sert que sur le poste où elle a été activée. Pour l'utiliser sur "
    "cet ordinateur, contactez Studio Margerit.")
POSTE_ANCIEN = "version_trop_ancienne"
POSTE_ANCIEN_MESSAGE = (
    "Cette version de Diktae est trop ancienne pour cette clé de licence : "
    "installez la dernière mise à jour de Diktae.")
# Amorçage sans tableau de bord : « Nom Prénom=solo, Autre Cabinet=cabinet ».
# Posé dans le .env du Pi au déploiement, il garantit que le palier est correct
# dès la première requête — sans attendre que quelqu'un pense à le régler.
SEED_TIERS = os.environ.get("PROXY_TIERS", "")
# Seuil d'alerte (fraction du plafond) : l'app prévient le praticien AVANT le
# blocage. Personne ne doit découvrir son plafond en pleine consultation.
QUOTA_WARN_RATIO = float(os.environ.get("PROXY_QUOTA_WARN_RATIO", "0.8"))
# Une fiche TRONQUÉE (stop_reason « max_tokens ») n'est pas une fiche : l'app la
# relance aussitôt avec un plafond plus haut (app/pipeline/llm.py). Sans cette
# exception, une seule consultation coûterait DEUX unités au praticien — un
# forfait de 40 pouvant tomber à 20 sur un poste dont le .env plafonne bas.
# Le plancher empêche un client trafiqué d'obtenir des appels gratuits en
# demandant exprès max_tokens=1 : l'app n'envoie jamais moins de 4096.
TRUNCATION_FREE_MIN_TOKENS = int(os.environ.get("PROXY_TRUNCATION_FREE_MIN_TOKENS", "4096"))

# Tarifs indicatifs USD/M tokens pour l'estimation de coût du rapport admin
# (préfixe de modèle -> (entrée, sortie)). L'estimation est INDICATIVE : la
# facture Anthropic fait foi.
# Tarifs publics Anthropic, $ par million de tokens (entrée, sortie), le préfixe
# le plus SPÉCIFIQUE d'abord : « claude-sonnet-5 » doit passer avant
# « claude-sonnet » (Sonnet 4.x). Lecture de cache = 0,1 × l'entrée, écriture
# de cache (5 min) = 1,25 ×. Estimation seulement : la facture Anthropic fait foi.
PRICES_USD_PER_M = (
    ("claude-sonnet-5", 2.0, 10.0),
    ("claude-sonnet", 3.0, 15.0),
    ("claude-haiku", 1.0, 5.0),
    ("claude-opus", 5.0, 25.0),
)
CACHE_READ_FACTOR = 0.1
CACHE_WRITE_FACTOR = 1.25
# Fuseau des journées du tableau de bord (la base est en UTC).
REPORT_TZ = os.environ.get("PROXY_REPORT_TZ", "Europe/Paris")
ADMIN_PAGE = Path(__file__).with_name("admin.html")

# --------------------------------------------------------------------------- #
# Version du proxy = EMPREINTE DE SON PROPRE CODE
#
# Sert à scripts/deploy_update.py : avant de publier une OTA, il compare cette
# empreinte à celle du dépôt et met le Pi à jour s'il est en retard. Une
# empreinte plutôt qu'un numéro : un numéro, il faut penser à l'incrémenter, et
# c'est précisément l'oubli qu'on supprime. Mêmes fichiers, même calcul que
# deploy_update.keyproxy_fingerprint — un test garde les deux alignés.
# Fins de ligne normalisées : un dépôt extrait sous Windows (CRLF) doit donner
# la même empreinte que le code arrivé sur le Pi depuis le Mac (LF).
# --------------------------------------------------------------------------- #
CODE_FILES = ("app.py", "admin.html", "requirements.txt")


def code_fingerprint(folder: Path) -> str:
    h = hashlib.sha256()
    for name in CODE_FILES:
        f = folder / name
        data = f.read_bytes().replace(b"\r\n", b"\n") if f.exists() else b"<absent>"
        h.update(name.encode() + b"\0" + data + b"\0")
    return h.hexdigest()[:12]


CODE_VERSION = code_fingerprint(Path(__file__).parent)


# --------------------------------------------------------------------------- #
# Vérification d'une licence Diktae (copie autonome de app/license.py — ce
# serveur se déploie SANS le code de l'app).
# --------------------------------------------------------------------------- #
def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _decode_payload(raw: bytes) -> dict[str, Any]:
    if len(raw) >= 6 and raw[0] == _FMT_COMPACT:
        return {
            "plan": PLAN_CODES.get(raw[1], str(raw[1])),
            "exp": int.from_bytes(raw[2:6], "big") * _DAY,
            "licensee": raw[6:].decode("utf-8", "replace") or "—",
        }
    return json.loads(raw)


def verify_license(token: str) -> tuple[bool, str, Optional[dict[str, Any]]]:
    """Signature + expiration (grâce de 7 j, AUCUNE pour les plans démo)."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        payload_b64, sig_b64 = (token or "").strip().split(".")
    except ValueError:
        return False, "Clé de licence Diktae attendue (format invalide).", None
    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))
        pub.verify(_b64u_decode(sig_b64), payload_b64.encode("ascii"))
    except InvalidSignature:
        return False, "Licence non émise par Studio Margerit.", None
    except Exception:
        return False, "Clé de licence illisible.", None
    try:
        payload = _decode_payload(_b64u_decode(payload_b64))
    except Exception:
        return False, "Contenu de licence illisible.", None
    grace = 0 if payload.get("plan") in DEMO_PLANS else GRACE_DAYS
    if payload.get("exp", 0) + grace * _DAY < time.time():
        return False, "Licence expirée — renouvelez votre abonnement Diktae.", None
    return True, "OK", payload


# --------------------------------------------------------------------------- #
# Journal de consommation (métadonnées uniquement — JAMAIS le contenu).
# --------------------------------------------------------------------------- #
def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(
        "CREATE TABLE IF NOT EXISTS usage ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " ts TEXT NOT NULL DEFAULT (datetime('now')),"
        " licensee TEXT NOT NULL, plan TEXT,"
        " model TEXT, status INTEGER,"
        " input_tokens INTEGER DEFAULT 0, output_tokens INTEGER DEFAULT 0,"
        " cache_creation_tokens INTEGER DEFAULT 0, cache_read_tokens INTEGER DEFAULT 0,"
        " duration_ms INTEGER DEFAULT 0)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_usage_licensee_ts"
                 " ON usage(licensee, ts)")
    # Clés de licence ANNULÉES. Une licence est un jeton signé hors ligne : sans
    # cette liste, rien ne peut l'arrêter avant sa date d'expiration. Le proxy
    # est le seul endroit où la couper serve à quelque chose — c'est lui qui
    # ouvre le robinet des appels Claude facturés à Studio Margerit.
    # On stocke l'EMPREINTE du jeton, jamais le jeton : cette base n'a pas à
    # devenir un coffre à identifiants d'accès.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS revocations ("
        " token_fp TEXT PRIMARY KEY,"
        " licensee TEXT, motif TEXT,"
        " created_at TEXT NOT NULL DEFAULT (datetime('now')))"
    )
    # Palier de volume d'un licencié (cf. TIER_CAPS). Table à part du journal :
    # le palier est un fait commercial qui doit survivre à une purge d'usage, et
    # il doit exister AVANT la première requête d'un nouveau praticien.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS licensees ("
        " licensee TEXT PRIMARY KEY,"
        " tier TEXT NOT NULL DEFAULT '',"
        " monthly_cap INTEGER,"      # dérogation ponctuelle ; NULL = plafond du palier
        " note TEXT,"
        " updated_at TEXT NOT NULL DEFAULT (datetime('now')))"
    )
    # Retours praticiens. `ref` est un identifiant tiré par l'app : la file
    # d'attente locale réémet après une coupure réseau, et l'index UNIQUE rend
    # ces réémissions inoffensives (le doublon est ignoré, pas empilé).
    conn.execute(
        "CREATE TABLE IF NOT EXISTS feedback ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " ts TEXT NOT NULL DEFAULT (datetime('now')),"
        " ref TEXT, licensee TEXT NOT NULL, plan TEXT,"
        " kind TEXT NOT NULL, message TEXT NOT NULL,"
        " app_version TEXT, platform TEXT, context TEXT,"
        " status TEXT NOT NULL DEFAULT 'nouveau')"
    )
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_feedback_ref"
                 " ON feedback(ref) WHERE ref IS NOT NULL")
    # Capture d'écran (ajoutée après coup) : migration idempotente d'une base
    # déjà en service, plutôt qu'un CREATE qui ne rejouerait jamais.
    # Empreinte du jeton utilisé, ajoutée après coup : sans elle, le tableau de
    # bord ne peut pas proposer « révoquer CETTE clé-là » — on ne saurait pas
    # quelles clés sont réellement en circulation chez un praticien.
    ucols = {r["name"] for r in conn.execute("PRAGMA table_info(usage)").fetchall()}
    if "token_fp" not in ucols:
        conn.execute("ALTER TABLE usage ADD COLUMN token_fp TEXT")
        conn.commit()
    # Réponse tronquée relancée par l'app : journalisée (elle a coûté), mais pas
    # décomptée du forfait (le praticien n'a rien reçu d'utilisable).
    if "truncated" not in ucols:
        conn.execute("ALTER TABLE usage ADD COLUMN truncated INTEGER DEFAULT 0")
        conn.commit()
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(feedback)").fetchall()}
    if "image" not in cols:
        conn.execute("ALTER TABLE feedback ADD COLUMN image BLOB")
        conn.execute("ALTER TABLE feedback ADD COLUMN image_mime TEXT")
        conn.commit()
    # Suivi relu par le praticien dans son app (`GET /feedback/status`) : quand
    # le statut a bougé, et le mot de réponse éventuel. Même migration
    # idempotente — une base déjà en service ne rejoue jamais le CREATE.
    if "status_at" not in cols:
        conn.execute("ALTER TABLE feedback ADD COLUMN status_at TEXT")
        conn.execute("ALTER TABLE feedback ADD COLUMN reply TEXT")
        conn.commit()
    # Postes (ordinateurs) sur lesquels chaque clé sert — cf. POSTES_PAR_CLE.
    # Empreinte de la clé + identifiant anonyme du poste : ni jeton ni nom
    # d'ordinateur en clair.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS postes ("
        " token_fp TEXT NOT NULL, poste TEXT NOT NULL, licensee TEXT, plan TEXT,"
        " premier TEXT NOT NULL DEFAULT (datetime('now')),"
        " dernier TEXT NOT NULL DEFAULT (datetime('now')),"
        " PRIMARY KEY (token_fp, poste))"
    )
    # Dérogation au nombre de postes d'une clé (praticien à deux ordinateurs).
    conn.execute(
        "CREATE TABLE IF NOT EXISTS postes_max ("
        " token_fp TEXT PRIMARY KEY, max_postes INTEGER NOT NULL,"
        " updated_at TEXT NOT NULL DEFAULT (datetime('now')))"
    )
    # Toute clé qui s'est présentée ici : le tableau de bord la garde en vue même
    # si elle n'a jamais rédigé de fiche, y compris après « Libérer ».
    conn.execute(
        "CREATE TABLE IF NOT EXISTS cles_vues ("
        " token_fp TEXT PRIMARY KEY, licensee TEXT, plan TEXT,"
        " premiere TEXT NOT NULL DEFAULT (datetime('now')))"
    )
    return conn


def _record(licensee: str, plan: str, model: str, status: int,
            usage: dict[str, Any], duration_ms: int, token_fp: str = "",
            truncated: bool = False) -> None:
    conn = _db()
    try:
        conn.execute(
            "INSERT INTO usage (licensee, plan, model, status, input_tokens,"
            " output_tokens, cache_creation_tokens, cache_read_tokens, duration_ms,"
            " token_fp, truncated)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (licensee, plan, model, status,
             int(usage.get("input_tokens") or 0),
             int(usage.get("output_tokens") or 0),
             int(usage.get("cache_creation_input_tokens") or 0),
             int(usage.get("cache_read_input_tokens") or 0),
             duration_ms, token_fp or None, 1 if truncated else 0),
        )
        conn.commit()
    finally:
        conn.close()


def _requests_today(licensee: str) -> int:
    conn = _db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM usage"
            " WHERE licensee = ? AND ts >= date('now')", (licensee,)).fetchone()
        return int(row["n"]) if row else 0
    finally:
        conn.close()


def token_fingerprint(token: str) -> str:
    """Empreinte courte et stable d'un jeton de licence (jamais le jeton lui-même).

    Sert d'identifiant de clé partout : journal de conso, liste des révocations,
    tableau de bord. Une empreinte ne permet pas de reconstituer la clé, donc
    elle peut circuler dans une URL ou un écran sans risque."""
    return hashlib.sha256((token or "").strip().encode("utf-8")).hexdigest()[:16]


def _is_revoked(token_fp: str) -> bool:
    conn = _db()
    try:
        return conn.execute("SELECT 1 FROM revocations WHERE token_fp = ?",
                            (token_fp,)).fetchone() is not None
    finally:
        conn.close()


REVOKED_MESSAGE = (
    "Cette clé de licence a été annulée par Studio Margerit. "
    "Contactez-nous pour en obtenir une nouvelle."
)


def _check_license(token: str) -> tuple[bool, str, Optional[dict[str, Any]], str]:
    """Signature + expiration + RÉVOCATION. Renvoie (ok, raison, licence, empreinte).

    Point de passage unique de toutes les routes authentifiées par licence :
    une clé annulée doit fermer la porte partout, pas seulement là où on y a
    pensé."""
    ok, reason, lic = verify_license(token)
    fp = token_fingerprint(token)
    if not ok:
        return False, reason, None, fp
    if _is_revoked(fp):
        return False, REVOKED_MESSAGE, None, fp
    return True, "OK", lic, fp


def _poste_propre(poste: str) -> str:
    """Identifiant de poste tel que l'app l'envoie (empreinte hexadécimale),
    normalisé ; chaîne vide s'il est absent ou illisible."""
    poste = (poste or "").strip().lower()
    return poste if re.fullmatch(r"[0-9a-f]{8,64}", poste) else ""


def _max_postes(conn: sqlite3.Connection, token_fp: str) -> int:
    row = conn.execute("SELECT max_postes FROM postes_max WHERE token_fp = ?",
                       (token_fp,)).fetchone()
    return max(1, int(row["max_postes"]) if row else POSTES_PAR_CLE)


def _admettre_poste(token_fp: str, licensee: str, plan: str,
                    poste: str) -> Optional[tuple[str, str]]:
    """Inscrit le poste pour cette clé s'il reste une place.

    Renvoie None si le poste est admis, sinon (code, message) du refus.
    BEGIN IMMEDIATE : deux premiers appels simultanés depuis deux ordinateurs ne
    doivent pas trouver tous les deux la place libre."""
    poste = _poste_propre(poste)
    illimite = plan in POSTES_ILLIMITES_PLANS
    conn = _db()
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("INSERT OR IGNORE INTO cles_vues (token_fp, licensee, plan)"
                     " VALUES (?, ?, ?)", (token_fp, licensee, plan))
        n = conn.execute("SELECT COUNT(*) AS n FROM postes WHERE token_fp = ?",
                         (token_fp,)).fetchone()["n"]
        if not poste:
            conn.commit()
            if illimite or not (POSTE_OBLIGATOIRE or n):
                return None
            return POSTE_ANCIEN, POSTE_ANCIEN_MESSAGE
        if conn.execute("SELECT 1 FROM postes WHERE token_fp = ? AND poste = ?",
                        (token_fp, poste)).fetchone():
            conn.execute("UPDATE postes SET dernier = datetime('now')"
                         " WHERE token_fp = ? AND poste = ?", (token_fp, poste))
            conn.commit()
            return None
        if not illimite and n >= _max_postes(conn, token_fp):
            conn.commit()                  # la clé reste « vue », le poste est refusé
            return POSTE_REFUSE, POSTE_REFUSE_MESSAGE
        conn.execute("INSERT INTO postes (token_fp, poste, licensee, plan) VALUES (?, ?, ?, ?)",
                     (token_fp, poste, licensee, plan))
        conn.commit()
        return None
    finally:
        conn.close()


def _authentifier(token: str, poste: str) -> tuple[Optional[JSONResponse],
                                                   Optional[dict[str, Any]], str]:
    """Licence (signature, échéance, révocation) PUIS poste.

    Point de passage unique des routes authentifiées par licence. Renvoie
    (erreur à renvoyer telle quelle, licence, empreinte de la clé)."""
    ok, reason, lic, fp = _check_license(token)
    if not ok:
        return _api_error(401, "authentication_error", reason), None, fp
    refus = _admettre_poste(fp, lic["licensee"], lic.get("plan", "—"), poste)
    if refus:
        code, message = refus
        return _api_error(403, "permission_error", message, code=code), None, fp
    return None, lic, fp


def _month_start_utc() -> str:
    """Début du mois COURANT (fuseau du rapport) exprimé en UTC, format SQLite.

    Le journal est en UTC mais le mois d'un abonnement est celui du praticien :
    sans cette conversion, les consultations du 1er du mois avant 2 h du matin
    seraient décomptées sur le mois précédent."""
    tz = _report_tz()
    now_local = datetime.now(timezone.utc).astimezone(tz)
    start_local = now_local.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return start_local.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _next_month_local() -> str:
    """Date (AAAA-MM-JJ) de remise à zéro du compteur — le 1er du mois suivant."""
    tz = _report_tz()
    now_local = datetime.now(timezone.utc).astimezone(tz)
    year, month = now_local.year, now_local.month + 1
    if month > 12:
        year, month = year + 1, 1
    return f"{year:04d}-{month:02d}-01"


def _seed_tiers() -> None:
    """Applique PROXY_TIERS (« Nom=palier, Autre=palier ») à la base.

    Sert le déploiement : le palier d'un praticien est posé dans le .env du Pi
    et prend effet dès le démarrage, sans passer par le tableau de bord. Ne
    touche QUE le palier : une dérogation de plafond réglée à la main reste."""
    pairs = [p for p in SEED_TIERS.split(",") if "=" in p]
    if not pairs:
        return
    conn = _db()
    try:
        for pair in pairs:
            name, _, tier = pair.partition("=")
            name, tier = name.strip(), tier.strip().lower()
            if not name or tier not in TIER_CAPS:
                continue
            conn.execute(
                "INSERT INTO licensees (licensee, tier, note, updated_at)"
                " VALUES (?, ?, 'amorcé par PROXY_TIERS', datetime('now'))"
                " ON CONFLICT(licensee) DO UPDATE SET tier = excluded.tier,"
                " updated_at = datetime('now')", (name, tier))
        conn.commit()
    finally:
        conn.close()


def _tier_row(licensee: str) -> dict[str, Any]:
    conn = _db()
    try:
        row = conn.execute(
            "SELECT tier, monthly_cap, note FROM licensees WHERE licensee = ?",
            (licensee,)).fetchone()
    finally:
        conn.close()
    return dict(row) if row else {}


def _quota_for(licensee: str, plan: str) -> tuple[str, int]:
    """(palier, plafond mensuel) d'un licencié. Plafond 0 = illimité.

    Les plans internes ne sont jamais plafonnés ; un licencié inconnu du
    tableau de bord prend DEFAULT_TIER plutôt que l'illimité, pour qu'un oubli
    de réglage ne devienne pas un abonnement sans compteur."""
    if plan in UNMETERED_PLANS:
        return "illimite", 0
    row = _tier_row(licensee)
    tier = (row.get("tier") or "").strip().lower() or DEFAULT_TIER
    if tier not in TIER_CAPS:
        tier = DEFAULT_TIER
    cap = row.get("monthly_cap")
    cap = int(cap) if cap is not None else TIER_CAPS.get(tier, 0)
    return tier, max(0, cap)


def _consultations_this_month(licensee: str) -> int:
    """Consultations IA décomptées ce mois-ci pour ce licencié.

    Seules les requêtes ABOUTIES comptent (status < 400) : une panne réseau, un
    refus de modèle ou un blocage de quota ne doivent pas brûler le forfait du
    praticien. Une réponse TRONQUÉE non plus : l'app la relance aussitôt, et
    c'est la relance qui compte (cf. TRUNCATION_FREE_MIN_TOKENS) — une
    consultation = une unité, même quand il a fallu deux appels."""
    conn = _db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM usage"
            " WHERE licensee = ? AND status < 400 AND COALESCE(truncated, 0) = 0"
            " AND ts >= ?",
            (licensee, _month_start_utc())).fetchone()
        return int(row["n"]) if row else 0
    finally:
        conn.close()


def _quota_state(licensee: str, plan: str) -> dict[str, Any]:
    """État du forfait, tel que lu par l'app (GET /quota) et le tableau de bord."""
    tier, cap = _quota_for(licensee, plan)
    used = _consultations_this_month(licensee)
    left = max(0, cap - used) if cap else None
    return {
        "licensee": licensee,
        "plan": plan,
        "tier": tier,
        "monthly_cap": cap,                     # 0 = illimité
        "used": used,
        "left": left,                           # None = illimité
        "blocked": bool(cap) and used >= cap,
        "warn": bool(cap) and used >= int(cap * QUOTA_WARN_RATIO),
        "resets_on": _next_month_local(),
    }


def _cost_eur(model: str, tok_in: int, tok_out: int,
              cache_read: int = 0, cache_write: int = 0) -> float:
    for prefix, p_in, p_out in PRICES_USD_PER_M:
        if (model or "").startswith(prefix):
            usd = (tok_in * p_in + tok_out * p_out
                   + cache_read * p_in * CACHE_READ_FACTOR
                   + cache_write * p_in * CACHE_WRITE_FACTOR) / 1_000_000
            return round(usd * USD_EUR, 6)
    return 0.0


def _admin_ok(authorization: str) -> bool:
    given = authorization.removeprefix("Bearer ").strip()
    return bool(ADMIN_TOKEN) and hmac.compare_digest(given.encode(), ADMIN_TOKEN.encode())


def _report_tz():
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(REPORT_TZ)
    except Exception:                      # pas de base tz : UTC plutôt qu'une panne
        return timezone.utc


def _local(ts: str, tz) -> datetime:
    """`ts` SQLite (UTC, « AAAA-MM-JJ HH:MM:SS ») -> heure locale du rapport."""
    return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).astimezone(tz)


# --------------------------------------------------------------------------- #
# Application
# --------------------------------------------------------------------------- #
app = FastAPI(title="Diktae — proxy de clés API", docs_url=None, redoc_url=None)


def _api_error(status: int, err_type: str, message: str,
               code: str = "") -> JSONResponse:
    """Erreur au FORMAT de l'API Anthropic : le SDK côté app la transforme en
    exception typée avec un message lisible pour le praticien. `code` : motif
    que l'app sait reconnaître (ex. clé déjà prise par un autre ordinateur)."""
    error = {"type": err_type, "message": message}
    if code:
        error["code"] = code
    return JSONResponse({"type": "error", "error": error}, status_code=status)


_seed_tiers()   # paliers posés par le .env du Pi : effectifs dès le démarrage


@app.get("/healthz")
def healthz() -> dict[str, Any]:
    # `version` : empreinte du code en service (cf. CODE_VERSION). C'est ce que
    # deploy_update.py lit pour savoir si le Pi doit être mis à jour avant l'OTA.
    return {"ok": True, "upstream": UPSTREAM,
            "key_configured": bool(ANTHROPIC_API_KEY),
            "version": CODE_VERSION}


@app.post("/v1/messages")
async def messages(request: Request,
                   x_api_key: str = Header(default=""),
                   authorization: str = Header(default=""),
                   x_diktae_poste: str = Header(default=""),
                   anthropic_version: str = Header(default="2023-06-01"),
                   anthropic_beta: str = Header(default="")) -> Response:
    if not ANTHROPIC_API_KEY:
        return _api_error(503, "api_error",
                          "Proxy mal configuré : ANTHROPIC_API_KEY absente côté serveur.")
    # Le SDK envoie la « clé » (= jeton de licence Diktae) en x-api-key.
    token = x_api_key or authorization.removeprefix("Bearer ").strip()
    err, lic, token_fp = _authentifier(token, x_diktae_poste)
    if err:
        return err
    licensee = lic["licensee"]
    plan = lic.get("plan", "—")

    if DAILY_REQ_LIMIT and _requests_today(licensee) >= DAILY_REQ_LIMIT:
        return _api_error(429, "rate_limit_error",
                          "Quota journalier du proxy atteint — réessayez demain "
                          "ou contactez Studio Margerit.")

    # Forfait mensuel (docs/TARIFS.md) : c'est ICI que le nombre de
    # consultations d'une formule est réellement opposable. L'app ne peut pas
    # s'en charger — un compteur local se remet à zéro en effaçant un fichier.
    quota = _quota_state(licensee, plan)
    if quota["blocked"]:
        return _api_error(
            429, "rate_limit_error",
            f"Forfait {quota['tier']} : les {quota['monthly_cap']} consultations "
            f"du mois sont utilisées. Le compteur repart le "
            f"{quota['resets_on']}. Pour dicter dès maintenant, passez au "
            "forfait supérieur — écrivez à Studio Margerit.")

    body = await request.body()
    if len(body) > MAX_BODY_BYTES:
        return _api_error(413, "invalid_request_error", "Requête trop volumineuse.")
    try:
        payload = json.loads(body)
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")

    model = str(payload.get("model") or "")
    if ALLOWED_MODEL_PREFIXES and not any(model.startswith(p) for p in ALLOWED_MODEL_PREFIXES):
        return _api_error(403, "permission_error",
                          f"Modèle « {model} » non autorisé par le proxy Diktae.")
    if payload.get("stream"):
        return _api_error(400, "invalid_request_error",
                          "Le streaming n'est pas relayé par ce proxy.")
    try:
        if int(payload.get("max_tokens") or 0) > MAX_TOKENS_LIMIT:
            payload["max_tokens"] = MAX_TOKENS_LIMIT
    except (TypeError, ValueError):
        return _api_error(400, "invalid_request_error", "max_tokens invalide.")

    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": anthropic_version,
        "content-type": "application/json",
    }
    if anthropic_beta:
        headers["anthropic-beta"] = anthropic_beta

    t0 = time.monotonic()
    try:
        resp = await _upstream_post(f"{UPSTREAM}/v1/messages", headers, payload)
    except httpx.HTTPError as exc:
        _record(licensee, plan, model, 502, {}, int((time.monotonic() - t0) * 1000),
                token_fp)
        return _api_error(502, "api_error", f"API Anthropic injoignable : {exc}")
    duration_ms = int((time.monotonic() - t0) * 1000)

    usage: dict[str, Any] = {}
    truncated = False
    try:
        data = json.loads(resp.content)
        usage = data.get("usage") or {}
        truncated = (data.get("stop_reason") == "max_tokens"
                     and int(payload.get("max_tokens") or 0) >= TRUNCATION_FREE_MIN_TOKENS)
    except Exception:
        pass
    _record(licensee, plan, model, resp.status_code, usage, duration_ms, token_fp,
            truncated)
    return Response(content=resp.content, status_code=resp.status_code,
                    media_type="application/json")


async def _upstream_post(url: str, headers: dict[str, str],
                         payload: dict[str, Any]) -> httpx.Response:
    """Appel amont isolé — monkeypatché par les tests (aucun réseau requis)."""
    async with httpx.AsyncClient(timeout=600.0) as client:
        return await client.post(url, headers=headers, json=payload)


# --------------------------------------------------------------------------- #
# Retours praticiens (bug / suggestion)
# --------------------------------------------------------------------------- #
def _send_mail(mail) -> tuple[bool, str]:
    """Remet un message au serveur SMTP configuré. (ok, raison lisible).

    Le port décide du mode TLS : 465 = TLS implicite (SMTP_SSL), tout le reste
    = STARTTLS. Se tromper de couple port/mode est l'erreur de configuration la
    plus banale, et elle donnerait ici un échec silencieux."""
    import smtplib
    import ssl

    try:
        if SMTP_PORT == 465:
            smtp = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=20,
                                    context=ssl.create_default_context())
        else:
            smtp = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=20)
        with smtp:
            if SMTP_PORT != 465:
                smtp.starttls(context=ssl.create_default_context())
            if SMTP_USER:
                smtp.login(SMTP_USER, SMTP_PASSWORD)
            smtp.send_message(mail)
    except smtplib.SMTPAuthenticationError as exc:
        return False, (f"Authentification refusée par {SMTP_HOST} ({exc.smtp_code}). "
                       "Avec Gmail, PROXY_SMTP_PASSWORD doit être un MOT DE PASSE "
                       "D'APPLICATION, pas le mot de passe du compte.")
    except Exception as exc:
        return False, f"{exc.__class__.__name__} : {exc}"
    return True, "OK"


def _notify_feedback(item_id: int, licensee: str, kind: str, message: str,
                     app_version: str, has_image: bool) -> None:
    """Prévient Studio Margerit par mail qu'un retour vient d'arriver.

    Tout est facultatif et NON bloquant : sans SMTP configuré, ou si l'envoi
    échoue, le retour est déjà en base — on ne perd rien, on log et on passe.
    La capture n'est pas jointe : elle reste ici, le mail renvoie au tableau
    de bord (une pièce jointe la recopierait chez un tiers)."""
    if not (SMTP_HOST and NOTIFY_TO and NOTIFY_FROM):
        return
    from email.message import EmailMessage

    libelle = "Bug signalé" if kind == "bug" else "Amélioration suggérée"
    mail = EmailMessage()
    mail["Subject"] = f"[Diktae] {libelle} — {licensee}"
    mail["From"] = NOTIFY_FROM
    mail["To"] = ", ".join(NOTIFY_TO)
    mail.set_content(
        f"{libelle} par {licensee}"
        + (f" (Diktae {app_version})" if app_version else "") + "\n\n"
        + message + "\n\n"
        + ("Une capture d'écran est jointe au retour (visible sur le tableau "
           "de bord, pas dans ce mail).\n\n" if has_image else "")
        + f"Tableau de bord : {DASHBOARD_URL}\n"
        + f"Retour n°{item_id}\n\n"
        + "Ce message est envoyé par le proxy Diktae. Le texte ci-dessus est "
          "pseudonymisé par le poste émetteur : les noms, prénoms et dates de "
          "naissance des patients ont été remplacés par des jetons avant envoi."
    )
    ok, why = _send_mail(mail)
    if not ok:
        # Un mail perdu ne doit JAMAIS faire croire au praticien que son
        # retour n'est pas passé : il est en base, c'est ce qui compte.
        logging.getLogger("keyproxy").warning(
            "Notification du retour n°%s non envoyée (non bloquant) : %s",
            item_id, why)


def _feedback_today(licensee: str) -> int:
    conn = _db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM feedback"
            " WHERE licensee = ? AND ts >= date('now')", (licensee,)).fetchone()
        return int(row["n"]) if row else 0
    finally:
        conn.close()


@app.post("/feedback")
async def feedback(request: Request, x_api_key: str = Header(default=""),
                   authorization: str = Header(default=""),
                   x_diktae_poste: str = Header(default="")) -> Response:
    """Dépôt d'un retour praticien, authentifié par la CLÉ DE LICENCE — la même
    que pour /v1/messages : aucun secret supplémentaire sur le poste client.

    Le message arrive PSEUDONYMISÉ par l'app (app/feedback.py) ; ce serveur ne
    doit jamais recevoir de donnée de santé identifiante. Il ne fait ici que
    borner, dédoublonner (`ref`) et stocker."""
    token = x_api_key or authorization.removeprefix("Bearer ").strip()
    err, lic, token_fp = _authentifier(token, x_diktae_poste)
    if err:
        return err
    licensee, plan = lic["licensee"], lic.get("plan", "—")

    body = await request.body()
    if len(body) > FEEDBACK_MAX_BODY_BYTES:
        return _api_error(413, "invalid_request_error", "Retour trop volumineux.")
    try:
        payload = json.loads(body)
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")

    kind = str(payload.get("kind") or "").strip().lower()
    if kind not in FEEDBACK_KINDS:
        return _api_error(400, "invalid_request_error",
                          f"Type de retour inconnu (attendu : {', '.join(FEEDBACK_KINDS)}).")
    message = str(payload.get("message") or "").strip()
    if not message:
        return _api_error(400, "invalid_request_error", "Message vide.")
    message = message[:FEEDBACK_MAX_CHARS]

    ref = str(payload.get("ref") or "").strip()[:64] or None
    if ref:
        conn = _db()
        try:
            row = conn.execute("SELECT id FROM feedback WHERE ref = ?", (ref,)).fetchone()
        finally:
            conn.close()
        if row:                      # réémission après coupure : déjà reçu, on le redit.
            return JSONResponse({"ok": True, "id": int(row["id"]), "duplicate": True})

    if FEEDBACK_DAILY_LIMIT and _feedback_today(licensee) >= FEEDBACK_DAILY_LIMIT:
        return _api_error(429, "rate_limit_error",
                          "Trop de retours envoyés aujourd'hui — réessayez demain.")

    context = payload.get("context")
    context_json = None
    if isinstance(context, dict) and context:
        context_json = json.dumps(context, ensure_ascii=False)[:FEEDBACK_MAX_CHARS]

    # Capture d'écran : masquée et ré-encodée par le poste. On revérifie que
    # c'est bien une image (octets magiques, pas un nom de fichier) et qu'elle
    # tient dans le plafond — un `x-api-key` volé ne doit pas servir de
    # stockage de fichiers arbitraires.
    image = None
    if payload.get("image"):
        try:
            image = base64.b64decode(str(payload["image"]), validate=True)
        except Exception:
            return _api_error(400, "invalid_request_error", "Capture illisible (base64).")
        if len(image) > FEEDBACK_MAX_IMAGE_BYTES:
            return _api_error(413, "invalid_request_error", "Capture trop volumineuse.")
        if not image.startswith(IMAGE_MAGIC):
            return _api_error(400, "invalid_request_error",
                              "Capture refusée : seules les images PNG/JPEG sont acceptées.")

    app_version = str(payload.get("app_version") or "")[:40]
    conn = _db()
    try:
        cur = conn.execute(
            "INSERT INTO feedback (ref, licensee, plan, kind, message, app_version,"
            " platform, context, image, image_mime)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (ref, licensee, plan, kind, message, app_version,
             str(payload.get("platform") or "")[:120], context_json, image,
             "image/jpeg" if image and image.startswith(b"\xff\xd8\xff") else
             ("image/png" if image else None)))
        conn.commit()
        new_id = int(cur.lastrowid)
    finally:
        conn.close()

    # Le mail part à côté : le praticien ne doit pas attendre un SMTP lent.
    threading.Thread(target=_notify_feedback, daemon=True, args=(
        new_id, licensee, kind, message, app_version, image is not None)).start()
    return JSONResponse({"ok": True, "id": new_id})


@app.get("/quota")
def quota(x_api_key: str = Header(default=""),
          authorization: str = Header(default=""),
          x_diktae_poste: str = Header(default="")) -> Response:
    """Forfait du mois pour le poste qui appelle — lu par l'app (app/quota.py).

    Authentifiée par la clé de licence et cloisonnée au licencié, comme
    /feedback/status : une clé ne donne à voir que son propre compteur.

    Sans cette route, le praticien ne découvrirait son plafond qu'au moment
    d'être bloqué. Elle existe pour que l'app puisse prévenir AVANT.

    Lue toutes les deux minutes par un poste allumé : c'est aussi par elle
    qu'un poste apprend que sa clé est prise par un autre ordinateur."""
    token = x_api_key or authorization.removeprefix("Bearer ").strip()
    err, lic, token_fp = _authentifier(token, x_diktae_poste)
    if err:
        return err
    return JSONResponse(_quota_state(lic["licensee"], lic.get("plan", "—")))


@app.post("/licence/activer")
def licence_activer(x_api_key: str = Header(default=""),
                    authorization: str = Header(default=""),
                    x_diktae_poste: str = Header(default="")) -> Response:
    """Inscription du poste, au moment où le praticien colle sa clé dans l'app.

    L'app n'enregistre la clé QUE si cette route l'accepte : une clé déjà prise
    par un autre ordinateur est refusée dès l'activation, avec un message clair,
    au lieu de marcher à moitié (transcription oui, fiche non)."""
    if not _poste_propre(x_diktae_poste):
        return _api_error(400, "invalid_request_error",
                          "Identifiant de poste absent ou illisible.")
    token = x_api_key or authorization.removeprefix("Bearer ").strip()
    err, lic, token_fp = _authentifier(token, x_diktae_poste)
    if err:
        return err
    conn = _db()
    try:
        n = conn.execute("SELECT COUNT(*) AS n FROM postes WHERE token_fp = ?",
                         (token_fp,)).fetchone()["n"]
        maxi = _max_postes(conn, token_fp)
    finally:
        conn.close()
    return JSONResponse({"ok": True, "licensee": lic["licensee"],
                         "plan": lic.get("plan", "—"), "postes": int(n),
                         "max_postes": None if lic.get("plan") in POSTES_ILLIMITES_PLANS else maxi})


@app.get("/feedback/status")
def feedback_status(refs: str = "", x_api_key: str = Header(default=""),
                    authorization: str = Header(default=""),
                    x_diktae_poste: str = Header(default="")) -> Response:
    """Où en sont les retours d'un poste — lu par l'app (app/feedback.py).

    Sans cette route le praticien écrit dans le vide : il ne sait pas si son
    signalement est arrivé, lu, corrigé, et il cesse d'en envoyer. Elle ne rend
    que du SUIVI (statut, dates, mot de réponse) : jamais le message d'un autre,
    jamais une capture.

    Deux bornes : l'authentification est la clé de licence (comme le dépôt), et
    la requête est limitée aux références que le poste connaît DÉJÀ **et** qui
    appartiennent à ce licencié — une clé égarée n'ouvre pas une fenêtre sur les
    retours des autres cabinets."""
    token = x_api_key or authorization.removeprefix("Bearer ").strip()
    err, lic, token_fp = _authentifier(token, x_diktae_poste)
    if err:
        return err
    wanted =[r.strip()[:64] for r in refs.split(",") if r.strip()][:FEEDBACK_STATUS_MAX_REFS]
    if not wanted:
        return JSONResponse({"items": {}})
    tz = _report_tz()
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT ref, ts, status, status_at, reply FROM feedback"
            " WHERE licensee = ? AND ref IN (%s)" % ",".join("?" * len(wanted)),
            (lic["licensee"], *wanted)).fetchall()
    finally:
        conn.close()
    items = {}
    for r in rows:
        items[r["ref"]] = {
            "status": r["status"],
            "recu_le": _local(r["ts"], tz).strftime("%Y-%m-%dT%H:%M:%S"),
            "maj_le": (_local(r["status_at"], tz).strftime("%Y-%m-%dT%H:%M:%S")
                       if r["status_at"] else ""),
            "reply": r["reply"] or "",
        }
    return JSONResponse({"items": items})


@app.get("/admin/feedback")
def admin_feedback(authorization: str = Header(default=""),
                   status: str = "", limit: int = 200) -> Response:
    """Retours reçus, du plus récent au plus ancien (jeton admin requis)."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    limit = max(1, min(int(limit), 1000))
    where, params = "", []
    if status:
        where = " WHERE status = ?"
        params.append(status)
    tz = _report_tz()
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT id, ts, ref, licensee, plan, kind, message, app_version, platform,"
            " context, status, status_at, reply, image IS NOT NULL AS has_image"
            f" FROM feedback{where}"
            " ORDER BY id DESC LIMIT ?", (*params, limit)).fetchall()
        counts = {r["status"]: int(r["n"]) for r in conn.execute(
            "SELECT status, COUNT(*) AS n FROM feedback GROUP BY status").fetchall()}
    finally:
        conn.close()
    items = []
    for r in rows:
        d = dict(r)
        d["ts"] = _local(d["ts"], tz).strftime("%Y-%m-%dT%H:%M:%S")
        try:
            d["context"] = json.loads(d["context"]) if d["context"] else {}
        except Exception:
            d["context"] = {}
        d["has_image"] = bool(d.get("has_image"))
        items.append(d)
    return JSONResponse({"tz": REPORT_TZ, "counts": counts, "feedback": items})


@app.post("/admin/test-mail")
def admin_test_mail(authorization: str = Header(default="")) -> Response:
    """Envoie un mail de test à PROXY_NOTIFY_TO et DIT ce qui cloche.

    Sans cela, la seule façon de valider la configuration SMTP serait de faire
    remonter un vrai bug depuis un vrai poste — et un échec d'envoi est
    silencieux par conception (il ne doit pas faire échouer un dépôt)."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    manquantes = [nom for nom, val in (
        ("PROXY_SMTP_HOST", SMTP_HOST), ("PROXY_NOTIFY_FROM (ou PROXY_SMTP_USER)",
                                         NOTIFY_FROM), ("PROXY_NOTIFY_TO", NOTIFY_TO))
        if not val]
    if manquantes:
        return JSONResponse({"ok": False, "configured": False,
                             "detail": "Variables absentes du .env : "
                                       + ", ".join(manquantes)}, status_code=200)

    from email.message import EmailMessage

    mail = EmailMessage()
    mail["Subject"] = "[Diktae] Test de la notification des retours"
    mail["From"] = NOTIFY_FROM
    mail["To"] = ", ".join(NOTIFY_TO)
    mail.set_content(
        "Ceci est un test envoyé depuis le proxy Diktae.\n\n"
        "Si vous le recevez, les notifications de retours praticiens sont "
        "opérationnelles : chaque bug signalé et chaque suggestion arriveront "
        "sur cette adresse.\n\n"
        f"Tableau de bord : {DASHBOARD_URL}\n")
    ok, why = _send_mail(mail)
    return JSONResponse({"ok": ok, "configured": True, "to": NOTIFY_TO,
                         "from": NOTIFY_FROM, "host": f"{SMTP_HOST}:{SMTP_PORT}",
                         "detail": why}, status_code=200 if ok else 502)


@app.get("/admin/feedback/{item_id}/image")
def admin_feedback_image(item_id: int, authorization: str = Header(default=""),
                         token: str = "") -> Response:
    """Capture d'écran d'un retour. Servie à part de la liste : les octets ne
    doivent pas alourdir un JSON qu'on recharge toutes les deux minutes.

    `?token=` est accepté en plus de l'en-tête car une balise <img> ne peut pas
    porter d'en-tête ; le tableau de bord, lui, utilise l'en-tête (fetch)."""
    if not (_admin_ok(authorization) or (token and _admin_ok(f"Bearer {token}"))):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    conn = _db()
    try:
        row = conn.execute("SELECT image, image_mime FROM feedback WHERE id = ?",
                           (item_id,)).fetchone()
    finally:
        conn.close()
    if not row or not row["image"]:
        return _api_error(404, "not_found_error", "Aucune capture pour ce retour.")
    return Response(content=row["image"], media_type=row["image_mime"] or "image/jpeg",
                    headers={"Cache-Control": "private, max-age=600",
                             "X-Robots-Tag": "noindex, nofollow",
                             "Content-Security-Policy": "default-src 'none'"})


@app.post("/admin/feedback/{item_id}/status")
async def admin_feedback_status(item_id: int, request: Request,
                                authorization: str = Header(default="")) -> Response:
    """Marque un retour comme vu ou traité, avec un mot de réponse facultatif.

    Le statut ET la date du changement sont enregistrés : c'est ce couple que
    l'app du praticien relit (`GET /feedback/status`) pour lui dire où en est
    son signalement. `reply` n'est touché que s'il est présent dans le corps —
    un simple changement de statut n'efface pas une réponse déjà écrite."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    try:
        payload = json.loads(await request.body()) or {}
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")
    new_status = str(payload.get("status") or "").strip()
    if new_status not in FEEDBACK_STATUSES:
        return _api_error(400, "invalid_request_error",
                          f"Statut inconnu (attendu : {', '.join(FEEDBACK_STATUSES)}).")
    sets, params = ["status = ?", "status_at = datetime('now')"], [new_status]
    if "reply" in payload:
        sets.append("reply = ?")
        params.append(str(payload.get("reply") or "").strip()[:FEEDBACK_REPLY_MAX_CHARS])
    conn = _db()
    try:
        cur = conn.execute(f"UPDATE feedback SET {', '.join(sets)} WHERE id = ?",
                           (*params, item_id))
        conn.commit()
        found = cur.rowcount > 0
    finally:
        conn.close()
    if not found:
        return _api_error(404, "not_found_error", "Retour introuvable.")
    return JSONResponse({"ok": True, "id": item_id, "status": new_status})


@app.delete("/admin/feedback/{item_id}")
def admin_feedback_delete(item_id: int,
                          authorization: str = Header(default="")) -> Response:
    """Supprime un retour, capture comprise (la colonne `image` part avec la ligne).

    Irréversible : rien n'est archivé ailleurs. Le tableau de bord demande donc
    confirmation avant d'appeler cette route.
    """
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    conn = _db()
    try:
        cur = conn.execute("DELETE FROM feedback WHERE id = ?", (item_id,))
        conn.commit()
        found = cur.rowcount > 0
    finally:
        conn.close()
    if not found:
        return _api_error(404, "not_found_error", "Retour introuvable.")
    return JSONResponse({"ok": True, "id": item_id, "deleted": True})


@app.get("/admin/cles")
def admin_cles(authorization: str = Header(default="")) -> Response:
    """Clés de licence vues en circulation, et lesquelles sont annulées.

    Une licence est un jeton signé hors ligne : sans cette page, on ne sait pas
    quelles clés tournent réellement chez un praticien — seulement lesquelles on
    a émises. Ici on voit ce qui APPELLE, ce qui est le seul fait qui compte
    quand il s'agit d'argent."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    conn = _db()
    try:
        vues = [dict(r) for r in conn.execute(
            "SELECT token_fp, licensee, MAX(plan) AS plan, COUNT(*) AS requetes,"
            " MIN(ts) AS premiere, MAX(ts) AS derniere"
            " FROM usage WHERE token_fp IS NOT NULL"
            " GROUP BY token_fp, licensee ORDER BY MAX(ts) DESC").fetchall()]
        annulees = {r["token_fp"]: dict(r) for r in conn.execute(
            "SELECT token_fp, licensee, motif, created_at FROM revocations").fetchall()}
        postes: dict[str, list[dict[str, Any]]] = {}
        for r in conn.execute("SELECT token_fp, poste, licensee, plan, premier, dernier"
                              " FROM postes ORDER BY premier").fetchall():
            postes.setdefault(r["token_fp"], []).append(dict(r))
        maxis = {r["token_fp"]: int(r["max_postes"]) for r in conn.execute(
            "SELECT token_fp, max_postes FROM postes_max").fetchall()}
        vues_ici = {r["token_fp"]: dict(r) for r in conn.execute(
            "SELECT token_fp, licensee, plan FROM cles_vues").fetchall()}
    finally:
        conn.close()
    for v in vues:
        rev = annulees.pop(v["token_fp"], None)
        v["annulee"] = bool(rev)
        v["motif"] = (rev or {}).get("motif") or ""
        v["annulee_le"] = (rev or {}).get("created_at") or ""
    # Clés annulées avant d'avoir jamais servi (fuite signalée à temps) : elles
    # n'apparaissent dans aucun journal, elles doivent quand même se voir.
    for fp, rev in annulees.items():
        vues.append({"token_fp": fp, "licensee": rev.get("licensee") or "—",
                     "plan": "—", "requetes": 0, "premiere": "", "derniere": "",
                     "annulee": True, "motif": rev.get("motif") or "",
                     "annulee_le": rev.get("created_at") or ""})
    # Clés activées mais pas encore utilisées pour une fiche (ou postes libérés).
    connues = {v["token_fp"] for v in vues}
    for fp, cle in vues_ici.items():
        if fp not in connues:
            vues.append({"token_fp": fp, "licensee": cle.get("licensee") or "—",
                         "plan": "—", "requetes": 0, "premiere": "", "derniere": "",
                         "annulee": False, "motif": "", "annulee_le": ""})
    for v in vues:
        # Formule connue dès l'activation, avant toute fiche : sans elle, une clé
        # dev paraîtrait limitée à un ordinateur.
        if v.get("plan") in (None, "", "—") and vues_ici.get(v["token_fp"]):
            v["plan"] = vues_ici[v["token_fp"]].get("plan") or "—"
        v["postes"] = [{"poste": p["poste"], "premier": p["premier"],
                        "dernier": p["dernier"]} for p in postes.get(v["token_fp"], [])]
        v["max_postes"] = (None if v.get("plan") in POSTES_ILLIMITES_PLANS
                           else max(1, maxis.get(v["token_fp"], POSTES_PAR_CLE)))
    return JSONResponse({"cles": vues, "postes_par_cle": max(1, POSTES_PAR_CLE)})


@app.post("/admin/postes")
async def admin_postes(request: Request,
                       authorization: str = Header(default="")) -> Response:
    """Ordinateurs d'une clé : les libérer, ou en autoriser davantage.

    - `{"token_fp": …, "liberer": true}` : oublie les postes inscrits (tous, ou
      seulement `poste` s'il est donné). À faire quand le praticien change
      d'ordinateur : le prochain qui utilise la clé prend la place.
    - `{"token_fp": …, "max_postes": 2}` : nombre d'ordinateurs autorisés pour
      cette clé (praticien à deux postes). Par défaut : PROXY_POSTES_PAR_CLE."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    try:
        payload = json.loads(await request.body()) or {}
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")
    fp = str(payload.get("token_fp") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{16}", fp):
        return _api_error(400, "invalid_request_error", "`token_fp` attendu (tableau de bord).")
    conn = _db()
    try:
        if payload.get("liberer"):
            poste = _poste_propre(str(payload.get("poste") or ""))
            if poste:
                cur = conn.execute("DELETE FROM postes WHERE token_fp = ? AND poste = ?",
                                   (fp, poste))
            else:
                cur = conn.execute("DELETE FROM postes WHERE token_fp = ?", (fp,))
            conn.commit()
            return JSONResponse({"token_fp": fp, "liberes": cur.rowcount})
        if "max_postes" in payload:
            try:
                maxi = int(payload["max_postes"])
                assert 1 <= maxi <= 20
            except Exception:
                return _api_error(400, "invalid_request_error",
                                  "`max_postes` : un nombre entre 1 et 20.")
            conn.execute(
                "INSERT INTO postes_max (token_fp, max_postes, updated_at)"
                " VALUES (?, ?, datetime('now')) ON CONFLICT(token_fp) DO UPDATE"
                " SET max_postes = excluded.max_postes, updated_at = datetime('now')",
                (fp, maxi))
            conn.commit()
            return JSONResponse({"token_fp": fp, "max_postes": maxi})
    finally:
        conn.close()
    return _api_error(400, "invalid_request_error",
                      "Précisez `liberer: true` ou `max_postes`.")


@app.post("/admin/revoquer")
async def admin_revoquer(request: Request,
                         authorization: str = Header(default="")) -> Response:
    """Annule une clé de licence — ou lève l'annulation (`annuler: true`).

    Prend soit `token_fp` (repris de /admin/cles), soit `token` (le jeton
    complet, collé depuis le mail : utile pour une clé qui a fuité avant
    d'avoir jamais servi). Le jeton n'est JAMAIS stocké : seule son empreinte
    l'est.

    Portée, à ne pas se raconter d'histoire : l'app du praticien vérifie sa
    licence HORS LIGNE et continuera de s'ouvrir jusqu'à la date d'expiration.
    Ce qui s'arrête ici, immédiatement, c'est ce qui coûte de l'argent et ce qui
    touche au serveur : rédaction des fiches par l'IA, dépôt et suivi des
    retours, compteur de forfait."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    try:
        payload = json.loads(await request.body()) or {}
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")

    fp = str(payload.get("token_fp") or "").strip().lower()
    brut = str(payload.get("token") or "").strip()
    if not fp and brut:
        fp = token_fingerprint(brut)
    if not fp:
        return _api_error(400, "invalid_request_error",
                          "Fournissez `token_fp` (tableau de bord) ou `token` (jeton complet).")

    conn = _db()
    try:
        if payload.get("annuler"):          # lever l'annulation
            cur = conn.execute("DELETE FROM revocations WHERE token_fp = ?", (fp,))
            conn.commit()
            return JSONResponse({"token_fp": fp, "annulee": False,
                                 "trouvee": cur.rowcount > 0})
        # Le licencié est repris du journal quand la clé a déjà servi ; sinon on
        # accepte celui que l'admin indique — une clé jamais utilisée n'a pas
        # d'historique d'où le déduire.
        row = conn.execute(
            "SELECT licensee FROM usage WHERE token_fp = ? ORDER BY ts DESC LIMIT 1",
            (fp,)).fetchone()
        licensee = (row["licensee"] if row
                    else str(payload.get("licensee") or "").strip()[:200] or None)
        conn.execute(
            "INSERT INTO revocations (token_fp, licensee, motif, created_at)"
            " VALUES (?, ?, ?, datetime('now'))"
            " ON CONFLICT(token_fp) DO UPDATE SET motif = excluded.motif,"
            " created_at = datetime('now')",
            (fp, licensee, str(payload.get("motif") or "").strip()[:200] or None))
        conn.commit()
    finally:
        conn.close()
    return JSONResponse({"token_fp": fp, "licensee": licensee, "annulee": True})


@app.get("/admin/forfaits")
def admin_forfaits(authorization: str = Header(default="")) -> Response:
    """Forfait et consommation du mois de CHAQUE licencié connu.

    Réunit les praticiens déjà réglés (table `licensees`) et ceux qui sont
    seulement apparus dans le journal : un nouvel abonné doit être visible ici
    même si personne ne lui a encore attribué un palier."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    conn = _db()
    try:
        names = {r["licensee"] for r in conn.execute(
            "SELECT licensee FROM licensees").fetchall()}
        names |= {r["licensee"] for r in conn.execute(
            "SELECT DISTINCT licensee FROM usage").fetchall()}
        plans = {r["licensee"]: r["plan"] for r in conn.execute(
            "SELECT licensee, MAX(plan) AS plan FROM usage"
            " GROUP BY licensee").fetchall()}
    finally:
        conn.close()
    items = []
    for name in sorted(names):
        state = _quota_state(name, plans.get(name) or "—")
        row = _tier_row(name)
        state["reglé"] = bool((row.get("tier") or "").strip())
        state["note"] = row.get("note") or ""
        items.append(state)
    return JSONResponse({"tiers": TIER_CAPS, "defaut": DEFAULT_TIER, "items": items})


@app.post("/admin/forfait")
async def admin_set_forfait(request: Request,
                            authorization: str = Header(default="")) -> Response:
    """Attribue un palier (et, exceptionnellement, un plafond dérogatoire).

    C'est le geste qui remplace la réémission d'une clé quand un praticien
    change de formule : le jeton du poste reste valable, seul son plafond bouge.
    `monthly_cap: null` (ou absent) rend le plafond au palier."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    try:
        payload = json.loads(await request.body()) or {}
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")
    licensee = str(payload.get("licensee") or "").strip()[:200]
    tier = str(payload.get("tier") or "").strip().lower()
    if not licensee:
        return _api_error(400, "invalid_request_error", "Licencié manquant.")
    if tier not in TIER_CAPS:
        return _api_error(400, "invalid_request_error",
                          f"Palier inconnu (attendu : {', '.join(TIER_CAPS)}).")
    cap = payload.get("monthly_cap")
    try:
        cap = None if cap in (None, "") else max(0, int(cap))
    except (TypeError, ValueError):
        return _api_error(400, "invalid_request_error", "monthly_cap invalide.")
    note = str(payload.get("note") or "").strip()[:200]
    conn = _db()
    try:
        conn.execute(
            "INSERT INTO licensees (licensee, tier, monthly_cap, note, updated_at)"
            " VALUES (?, ?, ?, ?, datetime('now'))"
            " ON CONFLICT(licensee) DO UPDATE SET tier = excluded.tier,"
            " monthly_cap = excluded.monthly_cap, note = excluded.note,"
            " updated_at = datetime('now')", (licensee, tier, cap, note))
        conn.commit()
    finally:
        conn.close()
    return JSONResponse(_quota_state(licensee, str(payload.get("plan") or "—")))


@app.get("/admin/usage")
def admin_usage(authorization: str = Header(default=""),
                month: str = "") -> Response:
    """Consommation agrégée par licencié (et par mois via ?month=AAAA-MM).

    Auth : Authorization: Bearer <PROXY_ADMIN_TOKEN>. Renvoie requêtes, tokens
    et coût ESTIMÉ (la facture Anthropic fait foi)."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    where, params = "", []
    if month:
        where = " WHERE substr(ts, 1, 7) = ?"
        params.append(month)
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT licensee, plan, model,"
            " COUNT(*) AS requests, SUM(status < 400) AS ok,"
            " SUM(input_tokens) AS tok_in, SUM(output_tokens) AS tok_out,"
            " SUM(cache_read_tokens) AS tok_cache_read,"
            " SUM(cache_creation_tokens) AS tok_cache_write,"
            " MAX(ts) AS last_seen"
            f" FROM usage{where}"
            " GROUP BY licensee, plan, model ORDER BY licensee, model",
            tuple(params)).fetchall()
    finally:
        conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d["cost_estimate_eur"] = round(_cost_eur(
            d.get("model") or "", int(d.get("tok_in") or 0), int(d.get("tok_out") or 0),
            int(d.get("tok_cache_read") or 0), int(d.get("tok_cache_write") or 0)), 4)
        out.append(d)
    return JSONResponse({"month": month or "all", "usage": out})


@app.get("/admin/stats")
def admin_stats(authorization: str = Header(default=""), days: int = 400) -> Response:
    """Données du tableau de bord : agrégats par JOUR (heure de Paris) et par
    licencié, liste des licenciés, et les dernières requêtes. Métadonnées
    seulement, comme tout le journal — jamais le contenu des consultations."""
    if not _admin_ok(authorization):
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    days = max(1, min(int(days), 800))
    tz = _report_tz()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = _db()
    try:
        licensees = [dict(r) for r in conn.execute(
            "SELECT licensee, MAX(plan) AS plan, MIN(ts) AS first_seen, MAX(ts) AS last_seen"
            " FROM usage GROUP BY licensee ORDER BY MIN(ts)").fetchall()]
        rows = conn.execute(
            "SELECT ts, licensee, model, status, input_tokens, output_tokens,"
            " cache_creation_tokens, cache_read_tokens, duration_ms"
            " FROM usage WHERE ts >= ? ORDER BY ts", (since,)).fetchall()
    finally:
        conn.close()

    daily: dict[tuple[str, str], dict[str, Any]] = {}
    recent: list[dict[str, Any]] = []
    for r in rows:
        local = _local(r["ts"], tz)
        cost = _cost_eur(r["model"] or "", r["input_tokens"] or 0, r["output_tokens"] or 0,
                         r["cache_read_tokens"] or 0, r["cache_creation_tokens"] or 0)
        key = (local.strftime("%Y-%m-%d"), r["licensee"])
        d = daily.setdefault(key, {"day": key[0], "licensee": key[1], "requests": 0,
                                   "errors": 0, "tok_in": 0, "tok_out": 0,
                                   "cost_eur": 0.0, "duration_ms": 0})
        d["requests"] += 1
        d["errors"] += int((r["status"] or 0) >= 400)
        d["tok_in"] += r["input_tokens"] or 0
        d["tok_out"] += r["output_tokens"] or 0
        d["cost_eur"] += cost
        d["duration_ms"] += r["duration_ms"] or 0
        recent.append({"ts": local.strftime("%Y-%m-%dT%H:%M:%S"), "licensee": r["licensee"],
                       "model": r["model"], "status": r["status"],
                       "tok_in": r["input_tokens"], "tok_out": r["output_tokens"],
                       "duration_ms": r["duration_ms"], "cost_eur": round(cost, 5)})
    for d in daily.values():
        d["cost_eur"] = round(d["cost_eur"], 5)
    for lic in licensees:
        for k in ("first_seen", "last_seen"):
            lic[k] = _local(lic[k], tz).strftime("%Y-%m-%dT%H:%M:%S")
    return JSONResponse({
        "tz": REPORT_TZ, "days": days,
        "now": datetime.now(tz).strftime("%Y-%m-%dT%H:%M:%S"),
        "licensees": licensees,
        "daily": sorted(daily.values(), key=lambda d: (d["day"], d["licensee"])),
        "recent": list(reversed(recent[-50:])),
        "pricing": {"usd_eur": USD_EUR,
                    "usd_per_m": {p: [i, o] for p, i, o in PRICES_USD_PER_M}},
    })


@app.get("/admin", include_in_schema=False)
def admin_page() -> Response:
    """Tableau de bord des dépenses. La page elle-même ne contient aucune donnée :
    elle demande le jeton admin puis interroge /admin/stats."""
    return FileResponse(ADMIN_PAGE, media_type="text/html; charset=utf-8", headers={
        "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow",
        "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY"})


@app.get("/admin/", include_in_schema=False)
def admin_slash() -> Response:
    return RedirectResponse("/admin")
