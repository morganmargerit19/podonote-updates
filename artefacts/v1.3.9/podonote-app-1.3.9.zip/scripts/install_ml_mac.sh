#!/usr/bin/env bash
# =============================================================================
#  PodoNote — Installation des briques ML (macOS)
#  Appelé par install_mac.sh, ou exécutable seul pour réinstaller la partie ML.
#  Usage seul : bash scripts/install_ml_mac.sh
#
#  NB : sur macOS, on installe torch/torchaudio depuis l'index PyPI par défaut
#  (les roues macOS y sont publiées : CPU sur Intel, CPU+MPS sur Apple Silicon).
#  On n'utilise PAS l'index "/whl/cpu" qui ne sert qu'aux builds Windows/Linux.
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYEXE="${1:-$ROOT/.venv/bin/python}"

if [ ! -x "$PYEXE" ]; then
  echo "Environnement Python introuvable ($PYEXE). Lancez install_mac.sh d'abord." >&2
  exit 1
fi

# Python Intel (Mac Intel, ou Mac M sous Rosetta) : PyTorch s'y arrête à la
# 2.2.2, compilée pour numpy 1.x — avec numpy 2, chaque traitement échoue sur
# « Numpy is not available ». transformers 5 désactive PyTorch < 2.5. On le
# demande au Python lui-même : c'est son architecture qui choisit les roues.
CTR="$(mktemp)"
trap 'rm -f "$CTR"' EXIT
if [ "$("$PYEXE" -c 'import platform; print(platform.machine())')" = "x86_64" ]; then
  printf 'numpy<2\ntransformers<5\n' > "$CTR"
  echo "Python Intel : numpy < 2 et transformers < 5 (PyTorch 2.2)."
fi

echo "Installation de PyTorch (macOS : roues PyPI par défaut)…"
"$PYEXE" -m pip install -c "$CTR" torch torchaudio

echo "Installation de faster-whisper + WhisperX…"
"$PYEXE" -m pip install -c "$CTR" faster-whisper
"$PYEXE" -m pip install -c "$CTR" whisperx

echo "Installation de matplotlib…"
# pyannote.audio importe matplotlib sans le déclarer dans ses dépendances :
# sans lui, le chargement du pipeline de diarisation échoue (ModuleNotFoundError).
"$PYEXE" -m pip install -c "$CTR" matplotlib

echo "Briques ML installées."
