#!/usr/bin/env python3
"""Fabrique Diktae-Mac.zip : l'app Mac que le praticien télécharge et ouvre.

Aucun Mac requis pour la fabrication (tourne aussi dans le cloud) : le .app est
un dossier, son exécutable un script bash (`installer/mac/Diktae`). Au premier
lancement, il installe un Python autonome DANS l'app puis confie la suite à
`installer/mac/installer.py` (fenêtre de progression). Le zip garde les droits
d'exécution, que l'Utilitaire d'archive du Mac respecte.

Usage :
  python scripts/build_mac_installer.py                   # -> dist/Diktae-Mac.zip
  python scripts/build_mac_installer.py --publier-git /home/user/podonote-updates

`--publier-git` dépose le zip dans `installateurs/` du dépôt de publication et
le pousse : lien stable, sans Release (le workflow n'y réagit pas).
"""
from __future__ import annotations

import argparse
import io
import plistlib
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "installer" / "mac"
APP = "Diktae.app"
ZIP_NAME = "Diktae-Mac.zip"
LIEN_PUBLIC = ("https://github.com/morganmargerit19/podonote-updates/raw/main/"
               f"installateurs/{ZIP_NAME}")
# Même identité que scripts/build_macos_app.sh : macOS y rattache l'autorisation du micro.
BUNDLE_ID = "com.studiomargerit.podonote"


def version() -> str:
    ns: dict = {}
    exec((ROOT / "app" / "__init__.py").read_text(encoding="utf-8"), ns)
    return str(ns["__version__"])


def info_plist(ver: str) -> bytes:
    return plistlib.dumps({
        "CFBundleName": "Diktae",
        "CFBundleDisplayName": "Diktae",
        "CFBundleIdentifier": BUNDLE_ID,
        "CFBundleVersion": ver,
        "CFBundleShortVersionString": ver,
        "CFBundlePackageType": "APPL",
        "CFBundleExecutable": "Diktae",
        "CFBundleIconFile": "podonote.icns",
        "LSMinimumSystemVersion": "11.0",
        "LSApplicationCategoryType": "public.app-category.medical",
        "NSHighResolutionCapable": True,
        # Sans cette phrase, macOS (et WebKit) refusent le micro à la fenêtre.
        "NSMicrophoneUsageDescription": (
            "Diktae enregistre la consultation pour la transcrire sur ce Mac. "
            "L’audio ne quitte jamais l’ordinateur."),
        # La fenêtre charge l'app servie en local (http://127.0.0.1).
        "NSAppTransportSecurity": {"NSAllowsLocalNetworking": True},
    })


def logo_png() -> bytes | None:
    """Logo 64 px pour la fenêtre d'installation (Pillow facultatif)."""
    try:
        from PIL import Image
    except ImportError:
        return None
    buf = io.BytesIO()
    Image.open(ROOT / "static" / "podonote.png").resize((64, 64), Image.LANCZOS).save(buf, "PNG")
    return buf.getvalue()


def _ajouter(zf: zipfile.ZipFile, nom: str, data: bytes, mode: int) -> None:
    info = zipfile.ZipInfo(nom, date_time=(2026, 1, 1, 0, 0, 0))
    info.create_system = 3                       # Unix : droits pris en compte
    info.external_attr = (0o100000 | mode) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    zf.writestr(info, data)


def _dossier(zf: zipfile.ZipFile, nom: str) -> None:
    info = zipfile.ZipInfo(nom.rstrip("/") + "/", date_time=(2026, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.external_attr = (0o040755 << 16) | 0x10
    zf.writestr(info, b"")


def construire(dest: Path) -> Path:
    ver = version()
    dest.parent.mkdir(parents=True, exist_ok=True)
    c = f"{APP}/Contents"
    with zipfile.ZipFile(dest, "w") as zf:
        for d in (APP, c, f"{c}/MacOS", f"{c}/Resources"):
            _dossier(zf, d)
        _ajouter(zf, f"{c}/Info.plist", info_plist(ver), 0o644)
        _ajouter(zf, f"{c}/PkgInfo", b"APPL????", 0o644)
        _ajouter(zf, f"{c}/MacOS/Diktae", (SRC / "Diktae").read_bytes(), 0o755)
        _ajouter(zf, f"{c}/Resources/installer.py", (SRC / "installer.py").read_bytes(), 0o644)
        _ajouter(zf, f"{c}/Resources/podonote.icns", (ROOT / "static" / "podonote.icns").read_bytes(), 0o644)
        logo = logo_png()
        if logo:
            _ajouter(zf, f"{c}/Resources/logo.png", logo, 0o644)
    return dest


def publier_git(zip_path: Path, clone: Path) -> None:
    git = ["git", "-C", str(clone)]
    subprocess.run(git + ["pull", "-q", "--rebase", "origin", "main"], check=True)
    cible = clone / "installateurs" / ZIP_NAME
    cible.parent.mkdir(parents=True, exist_ok=True)
    cible.write_bytes(zip_path.read_bytes())
    subprocess.run(git + ["add", str(cible.relative_to(clone))], check=True)
    if subprocess.run(git + ["diff", "--cached", "--quiet"]).returncode == 0:
        print("  OK  installateur déjà à jour dans le dépôt de publication.")
        return
    subprocess.run(git + ["commit", "-q", "-m", f"Installateur Mac (Diktae {version()})"], check=True)
    subprocess.run(git + ["push", "-q", "origin", "HEAD:main"], check=True)
    print(f"  OK  publié : {LIEN_PUBLIC}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Fabrique Diktae-Mac.zip (app Mac à télécharger).")
    ap.add_argument("--out", type=Path, default=ROOT / "dist" / ZIP_NAME)
    ap.add_argument("--publier-git", type=Path, metavar="CLONE",
                    help="clone de podonote-updates où déposer et pousser le zip")
    args = ap.parse_args()
    z = construire(args.out)
    print(f"  OK  {z} ({z.stat().st_size / 1024:.0f} Ko)")
    if args.publier_git:
        publier_git(z, args.publier_git)
    return 0


if __name__ == "__main__":
    sys.exit(main())
