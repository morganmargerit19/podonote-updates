"""Tests du proxy de clés API (server/keyproxy) — AUTONOMES.

Clés Ed25519 éphémères + API Anthropic simulée (monkeypatch de l'appel amont) :
aucun réseau, aucune vraie clé, base SQLite dans un dossier temporaire.
"""
from __future__ import annotations

import base64
import importlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "server" / "keyproxy"))

from cryptography.hazmat.primitives import serialization as ser  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: E402
    Ed25519PrivateKey,
)

# --- Environnement du proxy AVANT import du module (il lit l'env au chargement).
_priv = Ed25519PrivateKey.generate()
_pub_b64 = base64.b64encode(
    _priv.public_key().public_bytes(ser.Encoding.Raw, ser.PublicFormat.Raw)).decode()
_tmp = Path(tempfile.mkdtemp())
os.environ.update({
    "PROXY_LICENSE_PUBLIC_KEY": _pub_b64,
    "ANTHROPIC_API_KEY": "sk-test-fake",
    "PROXY_ADMIN_TOKEN": "admin-secret",
    "PROXY_DB": str(_tmp / "keyproxy.db"),
    "PROXY_DAILY_REQ_LIMIT": "5",
})

import app as keyproxy  # noqa: E402  (server/keyproxy/app.py)

importlib.reload(keyproxy)  # relit l'env si le module était déjà chargé

from starlette.testclient import TestClient  # noqa: E402

_DAY = 86400


def mktok(licensee: str, plan_code: int, exp_in_days: float) -> str:
    """Jeton compact signé avec la clé éphémère (même format que l'app)."""
    exp = int(time.time() + exp_in_days * _DAY)
    raw = bytes([2, plan_code]) + (exp // _DAY).to_bytes(4, "big") + licensee.encode()
    payload = base64.urlsafe_b64encode(raw).decode().rstrip("=")
    sig = base64.urlsafe_b64encode(_priv.sign(payload.encode("ascii"))).decode().rstrip("=")
    return f"{payload}.{sig}"


# --- API Anthropic SIMULÉE : capture la requête, renvoie une réponse Messages.
_captured: dict = {}


class _FakeUpstreamResponse:
    status_code = 200
    content = json.dumps({
        "id": "msg_test", "type": "message", "role": "assistant",
        "content": [{"type": "text", "text": "{}"}],
        "usage": {"input_tokens": 1200, "output_tokens": 800,
                  "cache_read_input_tokens": 100},
    }).encode()


async def _fake_upstream(url, headers, payload):
    _captured.update(url=url, headers=headers, payload=payload)
    return _FakeUpstreamResponse()

keyproxy._upstream_post = _fake_upstream
c = TestClient(keyproxy.app)

# 1. Santé
r = c.get("/healthz")
assert r.status_code == 200 and r.json()["key_configured"]
print("HEALTHZ ok")

# 1 bis. VERSION du proxy = empreinte de son code, IDENTIQUE à celle que calcule
# scripts/deploy_update.py sur le dépôt. Si les deux calculs divergent, l'outil
# croirait le Pi toujours en retard (mise à jour en boucle) ou toujours à jour
# (OTA en avance sur son serveur) : c'est ce test qui les tient alignés.
# deploy_update.py importe le paquet `app` de l'application, que ce processus
# masque (le proxy y est chargé sous le nom `app`) : on l'interroge à part.
import subprocess  # noqa: E402


def _empreinte_deploy(dossier: Path) -> str:
    code = ("import sys; from pathlib import Path; sys.path.insert(0, %r);"
            "from scripts.deploy_update import keyproxy_fingerprint, KEYPROXY_CODE_FILES;"
            "print(keyproxy_fingerprint(Path(%r)), ','.join(KEYPROXY_CODE_FILES))"
            % (str(ROOT), str(dossier)))
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True,
                         cwd=str(ROOT), timeout=60)
    assert out.returncode == 0, out.stderr
    empreinte, fichiers = out.stdout.split()
    assert tuple(fichiers.split(",")) == keyproxy.CODE_FILES, fichiers
    return empreinte


assert r.json()["version"] == keyproxy.CODE_VERSION
assert _empreinte_deploy(ROOT / "server" / "keyproxy") == keyproxy.CODE_VERSION, (
    "empreinte du proxy ≠ empreinte calculée par deploy_update.py")
# Fins de ligne normalisées : un dépôt Windows (CRLF) = le code du Pi (LF).
_crlf = Path(tempfile.mkdtemp())
for _n in keyproxy.CODE_FILES:
    (_crlf / _n).write_bytes((ROOT / "server" / "keyproxy" / _n).read_bytes()
                             .replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
assert _empreinte_deploy(_crlf) == keyproxy.CODE_VERSION
assert keyproxy.code_fingerprint(_crlf) == keyproxy.CODE_VERSION
# Et toute modification du code change bien l'empreinte.
(_crlf / "app.py").write_bytes((_crlf / "app.py").read_bytes() + b"# modif\r\n")
assert _empreinte_deploy(_crlf) != keyproxy.CODE_VERSION
print("VERSION du proxy (empreinte du code, alignée sur deploy_update, CRLF neutre) ok")

# 2. Sans licence / licence falsifiée -> 401 au format d'erreur Anthropic
r = c.post("/v1/messages", json={"model": "claude-sonnet-5"}, headers={"x-api-key": ""})
assert r.status_code == 401 and r.json()["error"]["type"] == "authentication_error"
tok = mktok("Cabinet Nico", 0, 35)
bad = tok[:-4] + ("AAAA" if not tok.endswith("AAAA") else "BBBB")
r = c.post("/v1/messages", json={"model": "claude-sonnet-5"}, headers={"x-api-key": bad})
assert r.status_code == 401
print("AUTH licence (absente/falsifiée refusée) ok")

# 3. Licence expirée : mensuel -1 j = accepté (grâce 7 j) ; démo -1 j = refusé (sans grâce)
_body = {"model": "claude-sonnet-5", "max_tokens": 1000,
         "messages": [{"role": "user", "content": "bonjour"}]}
r = c.post("/v1/messages", json=_body, headers={"x-api-key": mktok("Grace SARL", 0, -1)})
assert r.status_code == 200, r.text
r = c.post("/v1/messages", json=_body, headers={"x-api-key": mktok("Demo X", 5, -1)})
assert r.status_code == 401 and "expirée" in r.json()["error"]["message"]
print("GRÂCE mensuel oui / démo non ok")

# 4. Relais nominal : la VRAIE clé part vers l'amont, la réponse revient telle
# quelle, la conso est journalisée SANS le contenu.
r = c.post("/v1/messages", json=_body, headers={"x-api-key": tok,
                                                "anthropic-version": "2023-06-01",
                                                "anthropic-beta": "beta-x"})
assert r.status_code == 200 and r.json()["usage"]["output_tokens"] == 800
assert _captured["headers"]["x-api-key"] == "sk-test-fake"       # vraie clé côté serveur
assert _captured["headers"]["anthropic-beta"] == "beta-x"        # en-tête beta relayé
assert _captured["payload"]["messages"][0]["content"] == "bonjour"
import sqlite3  # noqa: E402
_conn = sqlite3.connect(os.environ["PROXY_DB"]); _conn.row_factory = sqlite3.Row
_rows = _conn.execute("SELECT * FROM usage WHERE licensee = 'Cabinet Nico'").fetchall()
assert _rows and _rows[-1]["input_tokens"] == 1200 and _rows[-1]["output_tokens"] == 800
assert "content" not in _rows[-1].keys() and "prompt" not in _rows[-1].keys()
print("RELAIS + JOURNAL de conso (métadonnées seules) ok")

# 5. Garde-fous : modèle interdit, streaming refusé, max_tokens plafonné
r = c.post("/v1/messages", json={**_body, "model": "claude-opus-5"},
           headers={"x-api-key": tok})
assert r.status_code == 403 and "non autorisé" in r.json()["error"]["message"]
r = c.post("/v1/messages", json={**_body, "stream": True}, headers={"x-api-key": tok})
assert r.status_code == 400
c.post("/v1/messages", json={**_body, "max_tokens": 999999}, headers={"x-api-key": tok})
assert _captured["payload"]["max_tokens"] == keyproxy.MAX_TOKENS_LIMIT
print("GARDE-FOUS modèle/stream/max_tokens ok")

# 6. Quota journalier (limite de test = 5) : la 6e requête du licencié est 429.
for _ in range(6):
    last = c.post("/v1/messages", json=_body, headers={"x-api-key": tok})
assert last.status_code == 429 and "Quota" in last.json()["error"]["message"]
print("QUOTA journalier ok")

# 7. Rapport admin : agrégats par licencié + coût estimé ; jeton admin exigé.
r = c.get("/admin/usage")
assert r.status_code == 401
r = c.get("/admin/usage", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200
_usage = r.json()["usage"]
_nico = [u for u in _usage if u["licensee"] == "Cabinet Nico"]
assert _nico and _nico[0]["requests"] >= 5 and _nico[0]["tok_out"] >= 800
assert _nico[0]["cost_estimate_eur"] > 0
_month = time.strftime("%Y-%m")
r = c.get(f"/admin/usage?month={_month}", headers={"Authorization": "Bearer admin-secret"})
assert r.json()["month"] == _month and r.json()["usage"]
print("ADMIN /usage (agrégats + coût estimé + auth) ok")

# 8. Tarifs : Sonnet 5 (2 $ / 10 $) est plus spécifique que Sonnet 4.x (3 $ / 15 $),
# et le cache compte (lecture 0,1 ×, écriture 1,25 × le prix d'entrée).
_e = keyproxy.USD_EUR
assert abs(keyproxy._cost_eur("claude-sonnet-5", 1_000_000, 0) - 2.0 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-4-6", 1_000_000, 0) - 3.0 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-5", 0, 1_000_000) - 10.0 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-5", 0, 0, 1_000_000, 0) - 0.2 * _e) < 1e-9
assert abs(keyproxy._cost_eur("claude-sonnet-5", 0, 0, 0, 1_000_000) - 2.5 * _e) < 1e-9
# Sonnet 5.5 (modèle des fiches depuis 2026-09-29) : mêmes prix que Sonnet 5,
# couverts par le préfixe « claude-sonnet-5 » — rien à livrer sur le Pi.
assert abs(keyproxy._cost_eur("claude-sonnet-5-5", 1_000_000, 1_000_000) - 12.0 * _e) < 1e-9
assert any("claude-sonnet-5-5".startswith(p) for p in keyproxy.ALLOWED_MODEL_PREFIXES)
print("TARIFS Sonnet 5 / 5.5 + cache ok")

# 9. Tableau de bord : /admin/stats exige le jeton, agrège par jour et par
# licencié, liste les dernières requêtes ; /admin sert la page sans données.
r = c.get("/admin/stats")
assert r.status_code == 401
r = c.get("/admin/stats", headers={"Authorization": "Bearer mauvais"})
assert r.status_code == 401
r = c.get("/admin/stats", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
_st = r.json()
_names = [l["licensee"] for l in _st["licensees"]]
assert "Cabinet Nico" in _names and "Grace SARL" in _names
_d = [d for d in _st["daily"] if d["licensee"] == "Cabinet Nico"]
assert _d and sum(x["requests"] for x in _d) >= 5
_attendu = keyproxy._cost_eur("claude-sonnet-5", 1200, 800, 100, 0)
assert abs(_d[0]["cost_eur"] - _d[0]["requests"] * _attendu) < 1e-4, (_d[0], _attendu)
assert _st["recent"] and set(_st["recent"][0]) >= {"ts", "licensee", "status", "cost_eur"}
assert all("content" not in q and "messages" not in q for q in _st["recent"])
assert _st["tz"] == "Europe/Paris" and len(_st["daily"][0]["day"]) == 10
r = c.get("/admin")
assert r.status_code == 200 and "Dépenses Diktae" in r.text and "Cabinet Nico" not in r.text
assert r.headers["cache-control"] == "no-store"
print("ADMIN /stats + page tableau de bord ok")

# 10. Retours praticiens : même authentification par licence que /v1/messages,
# dédoublonnage des réémissions de la file locale, quota, et lecture admin.
r = c.post("/feedback", json={"kind": "bug", "message": "test"})
assert r.status_code == 401                                   # sans licence
r = c.post("/feedback", json={"kind": "bug", "message": "test"},
           headers={"x-api-key": "pas.unelicence"})
assert r.status_code == 401
_tok = mktok("Cabinet Nico", 0, 30)
r = c.post("/feedback", json={"kind": "sondage", "message": "x"},
           headers={"x-api-key": _tok})
assert r.status_code == 400 and "Type de retour" in r.text    # type inconnu
r = c.post("/feedback", json={"kind": "bug", "message": "   "},
           headers={"x-api-key": _tok})
assert r.status_code == 400 and "vide" in r.text
# Dépôt nominal, avec contexte technique.
r = c.post("/feedback", headers={"x-api-key": _tok}, json={
    "ref": "ref-aaa", "kind": "bug", "app_version": "1.3.4",
    "message": "La fiche de ‹NOM_1› est restée bloquée sur « transcription ».",
    "platform": "Windows 11", "context": {"llm_backend": "sonnet", "os": "Windows 11"}})
assert r.status_code == 200, r.text
_id = r.json()["id"]
# Réémission après coupure réseau : le même `ref` ne crée PAS un doublon.
r = c.post("/feedback", headers={"x-api-key": _tok}, json={
    "ref": "ref-aaa", "kind": "bug", "message": "La fiche de ‹NOM_1› est restée bloquée."})
assert r.status_code == 200 and r.json() == {"ok": True, "id": _id, "duplicate": True}
# Suggestion d'un autre licencié.
r = c.post("/feedback", headers={"x-api-key": mktok("Grace SARL", 0, 30)},
           json={"kind": "idee", "message": "Pouvoir dupliquer une ordonnance."})
assert r.status_code == 200
# Message surdimensionné : tronqué, jamais refusé (le praticien a écrit, ça part).
r = c.post("/feedback", headers={"x-api-key": _tok},
           json={"kind": "bug", "message": "z" * (keyproxy.FEEDBACK_MAX_CHARS + 500)})
assert r.status_code == 200

# Lecture admin : jeton exigé, tri du plus récent au plus ancien, contexte relu.
r = c.get("/admin/feedback")
assert r.status_code == 401
r = c.get("/admin/feedback", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
_fb = r.json()["feedback"]
assert len(_fb) == 3 and _fb[-1]["id"] == _id          # 3 entrées, pas 4 (dédoublonné)
_first = [f for f in _fb if f["id"] == _id][0]
assert _first["licensee"] == "Cabinet Nico" and _first["plan"] == "mensuel"
assert _first["kind"] == "bug" and _first["status"] == "nouveau"
assert _first["context"]["llm_backend"] == "sonnet" and _first["app_version"] == "1.3.4"
assert len(_fb[0]["message"]) == keyproxy.FEEDBACK_MAX_CHARS   # tronqué côté serveur
assert {f["kind"] for f in _fb} == {"bug", "idee"}
# Suivi : marquer traité, filtrer dessus, refuser un statut inventé.
r = c.post(f"/admin/feedback/{_id}/status", json={"status": "traite"},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
r = c.post(f"/admin/feedback/{_id}/status", json={"status": "archive"},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 400
r = c.post("/admin/feedback/99999/status", json={"status": "vu"},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 404
r = c.get("/admin/feedback?status=traite", headers={"Authorization": "Bearer admin-secret"})
assert [f["id"] for f in r.json()["feedback"]] == [_id]
assert r.json()["counts"]["traite"] == 1

# 10bis. SUIVI relu par le poste (GET /feedback/status) : sans lui le praticien
# écrit dans le vide. Clé de licence exigée, et STRICTEMENT limité aux retours
# du licencié qui la présente.
assert c.get("/feedback/status?refs=ref-aaa").status_code == 401       # sans licence
r = c.get("/feedback/status?refs=ref-aaa", headers={"x-api-key": _tok})
assert r.status_code == 200, r.text
_suivi = r.json()["items"]["ref-aaa"]
assert _suivi["status"] == "traite" and _suivi["recu_le"] and _suivi["maj_le"]
assert _suivi["reply"] == ""            # pas encore de mot de réponse
# Une référence inconnue ne renvoie rien (et surtout pas d'erreur bruyante).
r = c.get("/feedback/status?refs=ref-aaa,ref-jamais-vue", headers={"x-api-key": _tok})
assert set(r.json()["items"]) == {"ref-aaa"}
# Cloisonnement : la clé d'un AUTRE cabinet ne voit pas ce retour.
r = c.get("/feedback/status?refs=ref-aaa",
          headers={"x-api-key": mktok("Grace SARL", 0, 30)})
assert r.status_code == 200 and r.json()["items"] == {}, r.text
# Sans référence demandée, rien à dire (on n'énumère jamais les retours).
assert c.get("/feedback/status", headers={"x-api-key": _tok}).json()["items"] == {}

# Réponse écrite de Studio Margerit : elle redescend telle quelle dans l'app.
r = c.post(f"/admin/feedback/{_id}/status", json={"status": "vu", "reply": "Corrigé en 1.3.3."},
           headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200, r.text
_suivi = c.get("/feedback/status?refs=ref-aaa",
               headers={"x-api-key": _tok}).json()["items"]["ref-aaa"]
assert _suivi["status"] == "vu" and _suivi["reply"] == "Corrigé en 1.3.3."
# Changer le statut SANS toucher au champ n'efface pas la réponse déjà écrite.
c.post(f"/admin/feedback/{_id}/status", json={"status": "traite"},
       headers={"Authorization": "Bearer admin-secret"})
_suivi = c.get("/feedback/status?refs=ref-aaa",
               headers={"x-api-key": _tok}).json()["items"]["ref-aaa"]
assert _suivi["status"] == "traite" and _suivi["reply"] == "Corrigé en 1.3.3."
# Réponse surdimensionnée : tronquée, jamais refusée.
c.post(f"/admin/feedback/{_id}/status",
       json={"status": "traite", "reply": "z" * (keyproxy.FEEDBACK_REPLY_MAX_CHARS + 200)},
       headers={"Authorization": "Bearer admin-secret"})
_suivi = c.get("/feedback/status?refs=ref-aaa",
               headers={"x-api-key": _tok}).json()["items"]["ref-aaa"]
assert len(_suivi["reply"]) == keyproxy.FEEDBACK_REPLY_MAX_CHARS
# La référence remonte aussi au tableau de bord : Morgan et le praticien citent
# le même numéro.
_admin_row = [f for f in c.get("/admin/feedback",
                               headers={"Authorization": "Bearer admin-secret"}
                               ).json()["feedback"] if f["id"] == _id][0]
assert _admin_row["ref"] == "ref-aaa" and _admin_row["status_at"]
print("SUIVI des retours (statut par licence, cloisonné, réponse écrite) ok")
# Quota journalier : au-delà, on refuse proprement (429) sans perdre l'existant.
for _i in range(keyproxy.FEEDBACK_DAILY_LIMIT):
    _r = c.post("/feedback", headers={"x-api-key": _tok},
                json={"kind": "idee", "message": f"idée {_i}"})
    if _r.status_code == 429:
        break
else:
    raise SystemExit("ERREUR : quota de retours jamais atteint")
# Suppression définitive : jeton exigé, ligne réellement partie, 404 ensuite.
# Licence à part : le test de quota ci-dessus a épuisé celle de `_tok`.
_tok_del = mktok("Cabinet Suppr", 0, 30)
_del = c.post("/feedback", headers={"x-api-key": _tok_del},
              json={"ref": "a-supprimer", "kind": "bug", "message": "À supprimer.",
                    "image": base64.b64encode(b"\xff\xd8\xff" + b"\x00" * 64).decode()})
assert _del.status_code == 200, _del.text
_del_id = _del.json()["id"]
assert c.delete(f"/admin/feedback/{_del_id}").status_code == 401       # sans jeton
r = c.delete(f"/admin/feedback/{_del_id}", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200 and r.json()["deleted"] is True, r.text
r = c.get("/admin/feedback", headers={"Authorization": "Bearer admin-secret"})
assert _del_id not in [f["id"] for f in r.json()["feedback"]]
# La capture part avec la ligne : plus rien à servir.
assert c.get(f"/admin/feedback/{_del_id}/image",
             headers={"Authorization": "Bearer admin-secret"}).status_code == 404
assert c.delete(f"/admin/feedback/{_del_id}",
                headers={"Authorization": "Bearer admin-secret"}).status_code == 404
print("RETOURS praticiens (dépôt licencié + dédoublonnage + quota + admin + suppression) ok")

# 11. Capture d'écran jointe : stockée à part de la liste, servie sur jeton
# admin, et seules de vraies images sont acceptées.
import io as _io_kp  # noqa: E402

_jpeg = (b"\xff\xd8\xff" + b"\x00" * 512)          # en-tête JPEG + remplissage
_tok2 = mktok("Cabinet Shot", 0, 30)
r = c.post("/feedback", headers={"x-api-key": _tok2}, json={
    "ref": "shot-1", "kind": "bug", "message": "Voir la capture.",
    "image": base64.b64encode(_jpeg).decode()})
assert r.status_code == 200, r.text
_shot_id = r.json()["id"]
# Un PDF déguisé en capture est refusé (octets magiques, pas l'extension).
r = c.post("/feedback", headers={"x-api-key": _tok2}, json={
    "kind": "bug", "message": "x", "image": base64.b64encode(b"%PDF-1.7 pas une image").decode()})
assert r.status_code == 400 and "PNG/JPEG" in r.text, r.text
# Base64 invalide -> refus lisible, pas une 500.
r = c.post("/feedback", headers={"x-api-key": _tok2},
           json={"kind": "bug", "message": "x", "image": "pas~du~base64!"})
assert r.status_code == 400 and "base64" in r.text
# Au-delà du plafond -> 413.
r = c.post("/feedback", headers={"x-api-key": _tok2}, json={
    "kind": "bug", "message": "x",
    "image": base64.b64encode(b"\xff\xd8\xff" + b"\x00" * keyproxy.FEEDBACK_MAX_IMAGE_BYTES).decode()})
assert r.status_code == 413, r.status_code

# La liste admin annonce la capture sans transporter les octets.
r = c.get("/admin/feedback", headers={"Authorization": "Bearer admin-secret"})
_avec = [f for f in r.json()["feedback"] if f["id"] == _shot_id][0]
assert _avec["has_image"] is True and "image" not in _avec
assert all(f["has_image"] is False for f in r.json()["feedback"] if f["id"] != _shot_id)
# L'image elle-même : jeton exigé, en en-tête OU en ?token= (une balise <img>
# ne peut pas porter d'en-tête).
assert c.get(f"/admin/feedback/{_shot_id}/image").status_code == 401
r = c.get(f"/admin/feedback/{_shot_id}/image",
          headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200 and r.content == _jpeg
assert r.headers["content-type"].startswith("image/jpeg")
assert c.get(f"/admin/feedback/{_shot_id}/image?token=admin-secret").status_code == 200
assert c.get(f"/admin/feedback/{_shot_id}/image?token=faux").status_code == 401
# Un retour sans capture : 404 explicite, pas une image vide.
assert c.get(f"/admin/feedback/{_id}/image",
             headers={"Authorization": "Bearer admin-secret"}).status_code == 404
print("CAPTURE d'écran jointe (validée, stockée à part, servie sur jeton) ok")

# 12. Notification par mail : facultative, jamais bloquante, sans la capture.
_mails = []


class _FakeSMTP:
    def __init__(self, host, port, timeout=None):
        _mails.append({"host": host, "port": port})

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self, context=None):
        _mails[-1]["tls"] = True

    def login(self, user, password):
        _mails[-1]["login"] = user

    def send_message(self, mail):
        _mails[-1]["mail"] = mail


import smtplib as _smtplib  # noqa: E402

_saved_smtp = _smtplib.SMTP
_saved_conf = (keyproxy.SMTP_HOST, keyproxy.NOTIFY_FROM, keyproxy.NOTIFY_TO)
try:
    # SMTP non configuré (cas par défaut) : aucun envoi, aucune erreur.
    keyproxy.SMTP_HOST = ""
    keyproxy._notify_feedback(1, "X", "bug", "m", "1.3.4", False)
    assert _mails == []

    _smtplib.SMTP = _FakeSMTP
    keyproxy.SMTP_HOST = "smtp.exemple.fr"
    keyproxy.NOTIFY_FROM = "diktae@studio-margerit.fr"
    keyproxy.NOTIFY_TO = ["morgan@studio-margerit.fr"]
    keyproxy._notify_feedback(7, "Cabinet Nico", "bug",
                              "La fiche de ‹NOM_1› est bloquée.", "1.3.4", True)
    assert len(_mails) == 1 and _mails[0]["tls"] is True
    _mail = _mails[0]["mail"]
    assert "Bug signalé" in _mail["Subject"] and "Cabinet Nico" in _mail["Subject"]
    _corps = _mail.get_content()
    assert "‹NOM_1›" in _corps and "pseudonymisé" in _corps
    assert "capture d'écran est jointe" in _corps          # annoncée…
    assert not _mail.is_multipart()                        # …mais PAS attachée
    assert keyproxy.DASHBOARD_URL in _corps
    # Une suggestion porte l'autre libellé.
    keyproxy._notify_feedback(8, "X", "idee", "m", "", False)
    assert "Amélioration suggérée" in _mails[-1]["mail"]["Subject"]

    # SMTP en panne : le retour est déjà en base, l'exception ne remonte pas.
    class _BrokenSMTP:
        def __init__(self, *a, **k):
            raise OSError("smtp injoignable")

    _smtplib.SMTP = _BrokenSMTP
    # L'échec est journalisé (avec sa trace) : on le fait taire ici, sinon la
    # sortie des tests ressemble à une panne alors que c'est le cas nominal.
    import logging as _logging_kp
    _logging_kp.getLogger("keyproxy").setLevel(_logging_kp.CRITICAL)
    keyproxy._notify_feedback(9, "X", "bug", "m", "", False)   # ne doit pas lever
    _logging_kp.getLogger("keyproxy").setLevel(_logging_kp.NOTSET)
finally:
    _smtplib.SMTP = _saved_smtp
    keyproxy.SMTP_HOST, keyproxy.NOTIFY_FROM, keyproxy.NOTIFY_TO = _saved_conf
print("NOTIFICATION mail (facultative, sans la capture, jamais bloquante) ok")

# 13. Test de configuration SMTP : dire ce qui cloche AVANT qu'un praticien
# compte dessus (un échec d'envoi est silencieux par conception).
_saved_conf = (keyproxy.SMTP_HOST, keyproxy.SMTP_PORT, keyproxy.NOTIFY_FROM,
               keyproxy.NOTIFY_TO, keyproxy.SMTP_USER)
_saved_smtp = (_smtplib.SMTP, _smtplib.SMTP_SSL)
try:
    assert c.post("/admin/test-mail").status_code == 401        # jeton exigé
    _admin = {"Authorization": "Bearer admin-secret"}
    # Rien de configuré -> on NOMME les variables manquantes, sans tenter d'envoi.
    keyproxy.SMTP_HOST, keyproxy.NOTIFY_FROM, keyproxy.NOTIFY_TO = "", "", []
    _r = c.post("/admin/test-mail", headers=_admin).json()
    assert _r["ok"] is False and _r["configured"] is False
    assert "PROXY_SMTP_HOST" in _r["detail"] and "PROXY_NOTIFY_TO" in _r["detail"]

    # Configuré et joignable -> mail de test parti.
    _mails.clear()
    _smtplib.SMTP = _FakeSMTP
    keyproxy.SMTP_HOST, keyproxy.SMTP_PORT = "smtp.exemple.fr", 587
    keyproxy.NOTIFY_FROM = "diktae@studio-margerit.fr"
    keyproxy.NOTIFY_TO = ["morgan@studio-margerit.fr"]
    _r = c.post("/admin/test-mail", headers=_admin)
    assert _r.status_code == 200 and _r.json()["ok"] is True, _r.text
    assert "Test de la notification" in _mails[-1]["mail"]["Subject"]
    assert _r.json()["to"] == ["morgan@studio-margerit.fr"]

    # Port 465 -> TLS implicite (SMTP_SSL), PAS de starttls : se tromper de
    # couple port/mode est l'erreur de configuration la plus banale.
    _ssl_appels = []

    class _FakeSMTPS(_FakeSMTP):
        def __init__(self, host, port, timeout=None, context=None):
            _ssl_appels.append(port)
            super().__init__(host, port, timeout)

    _smtplib.SMTP_SSL = _FakeSMTPS
    keyproxy.SMTP_PORT = 465
    assert c.post("/admin/test-mail", headers=_admin).json()["ok"] is True
    assert _ssl_appels == [465] and "tls" not in _mails[-1]    # pas de STARTTLS

    # Mot de passe refusé -> message qui DIT quoi corriger (piège Gmail).
    class _RefusSMTP:
        def __init__(self, *a, **k):
            raise _smtplib.SMTPAuthenticationError(535, b"Username and Password not accepted")

    _smtplib.SMTP = _RefusSMTP
    keyproxy.SMTP_PORT = 587
    _r = c.post("/admin/test-mail", headers=_admin)
    assert _r.status_code == 502 and _r.json()["ok"] is False
    assert "MOT DE PASSE D'APPLICATION" in _r.json()["detail"], _r.text
finally:
    (keyproxy.SMTP_HOST, keyproxy.SMTP_PORT, keyproxy.NOTIFY_FROM,
     keyproxy.NOTIFY_TO, keyproxy.SMTP_USER) = _saved_conf
    _smtplib.SMTP, _smtplib.SMTP_SSL = _saved_smtp
print("TEST de configuration SMTP (variables manquantes, 465, mot de passe refusé) ok")

# --- FORFAIT MENSUEL (le nombre de consultations d'une formule) ------------
# C'est la règle commerciale de docs/TARIFS.md rendue opposable : au-delà du
# plafond du palier, le proxy refuse — un compteur local, lui, s'efface.
_forfait_tok = mktok("Cabinet Forfait", 0, 30)
_admin_h = {"Authorization": "Bearer admin-secret"}

# Palier réglé depuis le tableau de bord : plafond dérogatoire à 2 pour le test.
r = c.post("/admin/forfait", headers=_admin_h,
           json={"licensee": "Cabinet Forfait", "tier": "solo", "monthly_cap": 2})
assert r.status_code == 200 and r.json()["monthly_cap"] == 2, r.text

# Le poste voit son forfait AVANT d'être bloqué (route lue par app/quota.py).
r = c.get("/quota", headers={"x-api-key": _forfait_tok})
assert r.status_code == 200, r.text
_q = r.json()
assert _q["tier"] == "solo" and _q["left"] == 2 and _q["blocked"] is False, _q
assert _q["resets_on"].endswith("-01"), _q          # remise à zéro le 1er du mois

# Les 2 consultations du forfait passent, la 3e est refusée.
for _ in range(2):
    assert c.post("/v1/messages", json=_body,
                  headers={"x-api-key": _forfait_tok}).status_code == 200
_last = c.post("/v1/messages", json=_body, headers={"x-api-key": _forfait_tok})
assert _last.status_code == 429, _last.text
assert "consultations du mois" in _last.json()["error"]["message"], _last.text

# Un refus ne brûle PAS de consultation (seules les requêtes abouties comptent).
_q = c.get("/quota", headers={"x-api-key": _forfait_tok}).json()
assert _q["used"] == 2 and _q["left"] == 0 and _q["blocked"] and _q["warn"], _q

# Changer de formule = un réglage, PAS une nouvelle clé : le même jeton repasse.
r = c.post("/admin/forfait", headers=_admin_h,
           json={"licensee": "Cabinet Forfait", "tier": "standard"})
assert r.status_code == 200 and r.json()["monthly_cap"] == 150, r.text
assert c.post("/v1/messages", json=_body,
              headers={"x-api-key": _forfait_tok}).status_code == 200

# Palier par défaut pour un licencié jamais réglé : plafond, pas illimité.
_q = c.get("/quota", headers={"x-api-key": mktok("Cabinet Inconnu", 0, 30)}).json()
assert _q["tier"] == keyproxy.DEFAULT_TIER and _q["monthly_cap"] > 0, _q

# Plan interne (dev) : hors grille de volume.
_q = c.get("/quota", headers={"x-api-key": mktok("Studio Margerit", 2, 30)}).json()
assert _q["monthly_cap"] == 0 and _q["left"] is None and not _q["blocked"], _q

# /quota et /admin/forfait exigent leurs autorisations respectives.
assert c.get("/quota", headers={"x-api-key": "bidon"}).status_code == 401
assert c.post("/admin/forfait", json={"licensee": "X", "tier": "solo"}).status_code == 401
assert c.post("/admin/forfait", headers=_admin_h,
              json={"licensee": "X", "tier": "platine"}).status_code == 400

# Vue d'ensemble : chaque licencié du journal y figure, réglé ou non.
r = c.get("/admin/forfaits", headers=_admin_h)
assert r.status_code == 200, r.text
_items = {i["licensee"]: i for i in r.json()["items"]}
assert _items["Cabinet Forfait"]["reglé"] is True
assert _items["Cabinet Nico"]["reglé"] is False   # vu dans le journal, jamais réglé
print("FORFAIT mensuel (plafond par palier, alerte, changement de formule) ok")

# Amorçage par le .env du Pi : le palier est correct dès le démarrage, sans
# que personne n'ait à penser à le régler dans le tableau de bord.
os.environ["PROXY_TIERS"] = "Cabinet Amorcé=solo, Inconnu=palier-bidon"
keyproxy.SEED_TIERS = os.environ["PROXY_TIERS"]
keyproxy._seed_tiers()
_q = c.get("/quota", headers={"x-api-key": mktok("Cabinet Amorcé", 1, 300)}).json()
assert _q["tier"] == "solo" and _q["monthly_cap"] == 40, _q
print("AMORÇAGE des paliers par PROXY_TIERS ok")

# Une fiche TRONQUÉE que l'app relance ne doit coûter qu'UNE unité au praticien.
# Sans cela, un .env plafonnant bas (4096, d'avant la 1.0.15) ferait tomber un
# forfait de 40 consultations à 20 — le praticien paierait la relance.
class _TruncatedResponse:
    status_code = 200
    content = json.dumps({
        "id": "msg_trunc", "type": "message", "role": "assistant",
        "content": [{"type": "text", "text": "{\"partiel\""}],
        "stop_reason": "max_tokens",
        "usage": {"input_tokens": 1200, "output_tokens": 4096},
    }).encode()


async def _fake_truncated(url, headers, payload):
    return _TruncatedResponse()

_trunc_tok = mktok("Cabinet Tronqué", 0, 30)
c.post("/admin/forfait", headers=_admin_h,
       json={"licensee": "Cabinet Tronqué", "tier": "solo"})
_saved_up = keyproxy._upstream_post
try:
    # 1er appel : réponse tronquée (max_tokens=16000 : l'app légitime).
    keyproxy._upstream_post = _fake_truncated
    assert c.post("/v1/messages", json={**_body, "max_tokens": 16000},
                  headers={"x-api-key": _trunc_tok}).status_code == 200
    # Relance de l'app : réponse complète.
    keyproxy._upstream_post = _fake_upstream
    assert c.post("/v1/messages", json={**_body, "max_tokens": 16000},
                  headers={"x-api-key": _trunc_tok}).status_code == 200
    _q = c.get("/quota", headers={"x-api-key": _trunc_tok}).json()
    assert _q["used"] == 1, f"une consultation relancée = 1 unité, pas {_q['used']}"

    # Garde-fou : un client trafiqué qui demande max_tokens=1 pour obtenir des
    # réponses « tronquées » gratuites est décompté quand même.
    keyproxy._upstream_post = _fake_truncated
    assert c.post("/v1/messages", json={**_body, "max_tokens": 1},
                  headers={"x-api-key": _trunc_tok}).status_code == 200
    _q = c.get("/quota", headers={"x-api-key": _trunc_tok}).json()
    assert _q["used"] == 2, f"max_tokens=1 doit être décompté ({_q['used']})"
finally:
    keyproxy._upstream_post = _saved_up
# La réponse tronquée reste journalisée : elle a coûté, le tableau de bord la voit.
_n = _conn.execute("SELECT COUNT(*) FROM usage WHERE licensee = 'Cabinet Tronqué'").fetchone()[0]
assert _n == 3, _n
print("FORFAIT : une fiche tronquée puis relancée ne coûte qu'une unité ok")

# --- RÉVOCATION d'une clé -------------------------------------------------
# Une licence est un jeton signé hors ligne : sans liste de révocation, rien ne
# l'arrête avant sa date. Ce que ça ferme ici, c'est ce qui coûte de l'argent.
_rev_tok = mktok("Cabinet Fuite", 0, 300)

# La clé marche, et son empreinte apparaît dans le journal.
assert c.post("/v1/messages", json=_body,
              headers={"x-api-key": _rev_tok}).status_code == 200
_fp = keyproxy.token_fingerprint(_rev_tok)
r = c.get("/admin/cles", headers=_admin_h)
assert r.status_code == 200, r.text
_vue = {k["token_fp"]: k for k in r.json()["cles"]}
assert _fp in _vue and _vue[_fp]["licensee"] == "Cabinet Fuite" and not _vue[_fp]["annulee"]

# Révocation depuis le tableau de bord (par empreinte).
r = c.post("/admin/revoquer", headers=_admin_h,
           json={"token_fp": _fp, "motif": "clé publiée par erreur"})
assert r.status_code == 200 and r.json()["annulee"] is True, r.text

# Effet immédiat, et sur TOUTES les routes authentifiées par la licence.
for _appel in (
    lambda: c.post("/v1/messages", json=_body, headers={"x-api-key": _rev_tok}),
    lambda: c.get("/quota", headers={"x-api-key": _rev_tok}),
    lambda: c.get("/feedback/status", params={"refs": "DK-0000-0000"},
                  headers={"x-api-key": _rev_tok}),
    lambda: c.post("/feedback", headers={"x-api-key": _rev_tok},
                   json={"kind": "bug", "message": "test"}),
):
    _r = _appel()
    assert _r.status_code == 401, _r.text
    assert "annulée" in _r.json()["error"]["message"], _r.text

# Une AUTRE clé du même licencié n'est pas touchée : on révoque une clé, pas
# un praticien (sinon renouveler une licence couperait le client).
# (Un jour ENTIER de plus : l'échéance est au jour près, et une demi-journée
#  tombait le même jour avant midi UTC — même jeton, test faux le matin.)
_autre = mktok("Cabinet Fuite", 0, 301)
assert keyproxy.token_fingerprint(_autre) != _fp
assert c.post("/v1/messages", json=_body,
              headers={"x-api-key": _autre}).status_code == 200

# Révocation par jeton COMPLET collé (clé qui a fuité sans avoir jamais servi).
_jamais = mktok("Cabinet Jamais Vu", 0, 300)
r = c.post("/admin/revoquer", headers=_admin_h,
           json={"token": _jamais, "licensee": "Cabinet Jamais Vu", "motif": "fuite"})
assert r.status_code == 200, r.text
assert c.get("/quota", headers={"x-api-key": _jamais}).status_code == 401
# Elle se voit dans la liste bien qu'absente du journal de conso.
_vue = {k["token_fp"]: k for k in c.get("/admin/cles", headers=_admin_h).json()["cles"]}
_fp_jamais = keyproxy.token_fingerprint(_jamais)
assert _vue[_fp_jamais]["annulee"] and _vue[_fp_jamais]["requetes"] == 0, _vue[_fp_jamais]

# Annulation réversible (révocation posée par erreur).
r = c.post("/admin/revoquer", headers=_admin_h,
           json={"token_fp": _fp, "annuler": True})
assert r.status_code == 200 and r.json()["annulee"] is False and r.json()["trouvee"]
assert c.post("/v1/messages", json=_body,
              headers={"x-api-key": _rev_tok}).status_code == 200

# Le jeton n'est JAMAIS stocké : seule son empreinte l'est.
_lignes = _conn.execute("SELECT * FROM revocations").fetchall()
for _l in _lignes:
    assert _jamais not in str(tuple(_l)), "un jeton complet ne doit pas être en base"

# Autorisations et corps invalide.
assert c.post("/admin/revoquer", json={"token_fp": _fp}).status_code == 401
assert c.get("/admin/cles").status_code == 401
assert c.post("/admin/revoquer", headers=_admin_h, json={}).status_code == 400
print("RÉVOCATION (effet immédiat, par empreinte ou jeton, réversible, ciblée) ok")

# --- UNE CLÉ = UN ORDINATEUR --------------------------------------------------
# Le jeton ne porte aucun identifiant de machine : c'est le proxy qui retient le
# poste de chaque clé et refuse les autres, sur TOUTES les routes.
_pa, _pb, _pc = "a1" * 8, "b2" * 8, "c3" * 8
_cle = mktok("Cabinet Un Poste", 0, 300)


def _hp(poste: str) -> dict:
    return {"x-api-key": _cle, "x-diktae-poste": poste}


r = c.post("/licence/activer", headers=_hp(_pa))
assert r.status_code == 200 and (r.json()["postes"], r.json()["max_postes"]) == (1, 1), r.text
assert c.post("/licence/activer", headers=_hp(_pa)).status_code == 200      # idempotent
assert c.get("/quota", headers=_hp(_pa)).status_code == 200
assert c.post("/v1/messages", json=_body, headers=_hp(_pa)).status_code == 200
# Un autre ordinateur : refusé partout, avec un motif que l'app reconnaît.
for _methode, _url, _extra in (("post", "/licence/activer", {}), ("get", "/quota", {}),
                               ("post", "/v1/messages", {"json": _body}),
                               ("post", "/feedback", {"json": {"kind": "bug", "message": "x"}}),
                               ("get", "/feedback/status?refs=x", {})):
    r = getattr(c, _methode)(_url, headers=_hp(_pb), **_extra)
    assert r.status_code == 403, (_url, r.status_code, r.text)
    _err = r.json()["error"]
    assert _err["code"] == "poste_non_autorise" and "autre ordinateur" in _err["message"], _err
# Poste inscrit : une app sans identifiant (ancienne version) ne passe plus…
r = c.get("/quota", headers={"x-api-key": _cle})
assert r.status_code == 403 and r.json()["error"]["code"] == "version_trop_ancienne", r.text
# … mais une clé encore jamais liée, oui (le temps que l'OTA passe partout).
assert c.get("/quota", headers={"x-api-key": mktok("Cabinet Ancienne Version", 0, 300)}).status_code == 200
assert c.post("/licence/activer",
              headers={"x-api-key": _cle, "x-diktae-poste": "pas-hex!"}).status_code == 400
# Tableau de bord : postes de la clé ; deux ordinateurs autorisés -> B passe, C non.
_fpc = keyproxy.token_fingerprint(_cle)
_v = {k["token_fp"]: k for k in c.get("/admin/cles", headers=_admin_h).json()["cles"]}[_fpc]
assert [p["poste"] for p in _v["postes"]] == [_pa] and _v["max_postes"] == 1, _v
assert c.post("/admin/postes", headers=_admin_h,
              json={"token_fp": _fpc, "max_postes": 2}).status_code == 200
assert c.post("/licence/activer", headers=_hp(_pb)).status_code == 200
assert c.post("/licence/activer", headers=_hp(_pc)).status_code == 403
# Un poste libéré laisse sa place ; « libérer » sans poste les oublie tous.
r = c.post("/admin/postes", headers=_admin_h, json={"token_fp": _fpc, "liberer": True, "poste": _pa})
assert r.status_code == 200 and r.json()["liberes"] == 1, r.text
assert c.post("/licence/activer", headers=_hp(_pc)).status_code == 200
assert c.post("/licence/activer", headers=_hp(_pa)).status_code == 403
r = c.post("/admin/postes", headers=_admin_h, json={"token_fp": _fpc, "liberer": True})
assert r.status_code == 200 and r.json()["liberes"] == 2, r.text
assert c.post("/licence/activer", headers=_hp(_pa)).status_code == 200
# Une clé activée mais jamais utilisée pour une fiche apparaît quand même — et
# reste visible après « Libérer » (sinon on la croirait disparue).
_neuve = mktok("Cabinet Pas Encore Dicté", 0, 300)
_fpn = keyproxy.token_fingerprint(_neuve)
assert c.post("/licence/activer", headers={"x-api-key": _neuve, "x-diktae-poste": _pb}).status_code == 200
_v = {k["token_fp"]: k for k in c.get("/admin/cles", headers=_admin_h).json()["cles"]}
assert _v[_fpn]["licensee"] == "Cabinet Pas Encore Dicté" and _v[_fpn]["plan"] == "mensuel", _v[_fpn]
c.post("/admin/postes", headers=_admin_h, json={"token_fp": _fpn, "liberer": True})
_v = {k["token_fp"]: k for k in c.get("/admin/cles", headers=_admin_h).json()["cles"]}
assert _fpn in _v and _v[_fpn]["postes"] == [] and _v[_fpn]["max_postes"] == 1, _v.get(_fpn)
# Formule dev : postes de test internes, pas de limite.
_dev = mktok("Studio Test (dev)", 2, 300)
for _p in (_pa, _pb, _pc):
    assert c.post("/licence/activer", headers={"x-api-key": _dev, "x-diktae-poste": _p}).status_code == 200
# … et le tableau de bord la montre sans limite, même avant sa première fiche.
_v = {k["token_fp"]: k for k in c.get("/admin/cles", headers=_admin_h).json()["cles"]}
_vd = _v[keyproxy.token_fingerprint(_dev)]
assert (_vd["plan"], _vd["max_postes"], len(_vd["postes"])) == ("dev", None, 3), _vd
# Clé révoquée : refusée avant même de regarder le poste.
_rv = mktok("Cabinet Révoqué Poste", 0, 300)
c.post("/admin/revoquer", headers=_admin_h, json={"token": _rv, "licensee": "x"})
assert c.post("/licence/activer", headers={"x-api-key": _rv, "x-diktae-poste": _pa}).status_code == 401
# Autorisations et validations de l'admin ; jamais un jeton en base.
assert c.post("/admin/postes", json={"token_fp": _fpc, "liberer": True}).status_code == 401
assert c.post("/admin/postes", headers=_admin_h, json={"token_fp": "zz"}).status_code == 400
assert c.post("/admin/postes", headers=_admin_h,
              json={"token_fp": _fpc, "max_postes": 0}).status_code == 400
assert c.post("/admin/postes", headers=_admin_h, json={"token_fp": _fpc}).status_code == 400
for _l in _conn.execute("SELECT * FROM postes").fetchall():
    assert _cle not in str(tuple(_l)) and _dev not in str(tuple(_l))
# PROXY_POSTE_OBLIGATOIRE : même une clé jamais liée exige l'identifiant.
keyproxy.POSTE_OBLIGATOIRE = True
r = c.get("/quota", headers={"x-api-key": mktok("Cabinet Tout Neuf", 0, 300)})
assert r.status_code == 403 and r.json()["error"]["code"] == "version_trop_ancienne", r.text
keyproxy.POSTE_OBLIGATOIRE = False
print("UNE CLÉ = UN ORDINATEUR (inscription, refus partout, ancienne version, dérogation, "
      "libération, dev, révocation) ok")

print("=== TESTS KEYPROXY OK ===")
