"""Forfait mensuel de consultations IA — vue côté poste (lecture seule).

Le plafond d'une formule (40 / 150 / 300 consultations par mois, cf.
`docs/TARIFS.md`) est **appliqué par le proxy de clés** : lui seul sait compter,
et un compteur local disparaîtrait avec un fichier effacé. Ce module ne décide
donc rien — il va LIRE l'état du forfait (`GET /quota`) pour que l'app puisse
prévenir le praticien **avant** le blocage, au lieu de le laisser découvrir son
plafond au milieu d'une consultation.

Toutes les pannes sont muettes par conception : proxy injoignable, plus ancien
que la route, licence absente, appel direct sans proxy → aucune information
affichée, jamais une erreur à l'écran. L'app doit rester utilisable hors ligne.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import date
from typing import Any, Optional

from .config import settings

log = logging.getLogger("podonote.quota")

REQUEST_TIMEOUT_SECONDS = 3.0
# Le compteur ne bouge qu'à chaque consultation dictée : le relire à chaque
# affichage de page ajouterait un aller-retour réseau pour rien.
CACHE_SECONDS = 120
# Après un échec (proxy injoignable, réseau qui avale les paquets), on attend
# avant de réessayer : le compteur est affiché sur CHAQUE page (rail), et sans
# ce délai chaque clic paierait le délai d'attente réseau.
RETRY_SECONDS = 60

# Noms commerciaux des paliers (docs/TARIFS.md, page marketing) : le praticien
# a souscrit « Solo léger », pas « solo ».
TIER_LABELS = {
    "solo": "Solo léger",
    "standard": "Standard",
    "cabinet": "Cabinet / Pro",
    "illimite": "sans plafond",
}
_MOIS = ("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
         "septembre", "octobre", "novembre", "décembre")
# Au-delà de ce seuil (fraction du plafond), le compteur du rail passe en alerte.
# Même seuil que le proxy (PROXY_QUOTA_WARN_RATIO) : on prend son « warn » quand il le donne.
WARN_RATIO = 0.8

_lock = threading.Lock()
# « at » = -inf (et non 0) : time.monotonic() part de zéro au démarrage de la
# machine ; avec 0, un poste allumé depuis moins de CACHE_SECONDS ne relisait
# pas le compteur après invalidate().
_cache: dict[str, Any] = {"at": float("-inf"), "value": None, "failed_at": None}


def _quota_url() -> Optional[str]:
    base = settings.llm_proxy_url.strip().rstrip("/")
    # « direct » = appel Anthropic sans proxy (dev) : personne ne compte.
    if not base or base.lower() == "direct":
        return None
    return f"{base}/quota"


def _fetch() -> Optional[dict[str, Any]]:
    import httpx

    from . import license as license_mod

    url = _quota_url()
    if not url:
        return None
    token = license_mod.current_token()
    if not token:
        return None
    try:
        resp = httpx.get(url, timeout=REQUEST_TIMEOUT_SECONDS,
                         headers=license_mod.entetes_proxy(token))
    except httpx.HTTPError as exc:
        log.info("Forfait indisponible : %s", exc.__class__.__name__)
        return None
    if resp.status_code == 404:
        # Proxy antérieur à cette route : l'app est plus récente que le serveur.
        # On se tait plutôt que d'afficher un plafond inventé.
        return None
    if resp.status_code >= 400:
        try:
            corps = resp.json()
        except ValueError:
            corps = None
        refus = license_mod.refus_proxy(resp.status_code, corps)
        if refus:
            # Clé liée à un autre ordinateur : lu toutes les deux minutes, ce
            # compteur est ce qui bloque une clé partagée sur le poste qui l'a
            # reçue (cf. license.get_status, état « refused »).
            license_mod.marquer_refus_poste(refus)
        log.info("Forfait indisponible (HTTP %s).", resp.status_code)
        return None
    license_mod.effacer_refus_poste()
    try:
        data = resp.json()
    except ValueError:
        return None
    return data if isinstance(data, dict) and "monthly_cap" in data else None


def _reset_date(value: dict[str, Any]) -> Optional[date]:
    try:
        return date.fromisoformat(str(value.get("resets_on") or ""))
    except ValueError:
        return None


def _date_fr(d: date) -> str:
    """« 1er novembre », « 12 mars » : la date telle qu'un praticien la lit."""
    return f"{'1er' if d.day == 1 else d.day} {_MOIS[d.month - 1]}"


def _enrich(data: dict[str, Any]) -> dict[str, Any]:
    """Ajoute ce que l'écran affiche : nom commercial du palier, date en français."""
    out = dict(data)
    tier = str(out.get("tier") or "").strip().lower()
    out["label"] = TIER_LABELS.get(tier, tier or "—")
    d = _reset_date(out)
    out["resets_on_fr"] = _date_fr(d) if d else str(out.get("resets_on") or "")
    return out


def status(force: bool = False) -> Optional[dict[str, Any]]:
    """État du forfait du mois, ou None si l'information n'est pas disponible.

    Clés utiles : `tier`, `label` (nom commercial), `monthly_cap` (0 = illimité),
    `used`, `left`, `blocked`, `warn`, `resets_on` (AAAA-MM-JJ), `resets_on_fr`.
    """
    now = time.monotonic()
    with _lock:
        if not force:
            if _cache["value"] is not None and now - _cache["at"] < CACHE_SECONDS:
                return _current()
            if _cache["failed_at"] is not None and now - _cache["failed_at"] < RETRY_SECONDS:
                return _current()
    value = _fetch()
    with _lock:
        if value is not None:
            _cache.update(value=_enrich(value), at=now, failed_at=None)
        else:
            # Un échec ne remplace pas une valeur connue : mieux vaut un compteur
            # d'il y a dix minutes qu'un bandeau qui disparaît dès que le Wi-Fi tousse.
            _cache["failed_at"] = now
        return _current()


def _current() -> Optional[dict[str, Any]]:
    """La valeur mémorisée, sauf si elle date d'un mois révolu (poste resté hors
    ligne au changement de mois) : un compteur du mois dernier serait faux."""
    value = _cache["value"]
    if value is None:
        return None
    d = _reset_date(value)
    return None if d is not None and date.today() >= d else value


def invalidate() -> None:
    """Oublie l'état mémorisé (après une consultation dictée, un changement de clé)."""
    with _lock:
        _cache["at"] = float("-inf")
        _cache["failed_at"] = None


def counter() -> Optional[dict[str, Any]]:
    """Le petit compteur « 12/40 » du rail, présent sur toutes les pages.

    Contrairement au bandeau, il est TOUJOURS là dès que le forfait est connu :
    le praticien voit où il en est sans aller dans les Réglages. Rien (None) si
    l'information manque — jamais un chiffre inventé."""
    st = status()
    if not st:
        return None
    used = max(0, int(st.get("used") or 0))
    cap = max(0, int(st.get("monthly_cap") or 0))
    if cap:
        level = "full" if (st.get("blocked") or used >= cap) else (
            "warn" if (st.get("warn") or used >= int(cap * WARN_RATIO)) else "ok")
        pct = min(100, round(100 * used / cap))
        title = (f"Forfait {st['label']} : {used} consultation{'s' if used > 1 else ''} "
                 f"dictée{'s' if used > 1 else ''} sur {cap} ce mois-ci — remise à zéro le "
                 f"{st['resets_on_fr']}.")
    else:
        level, pct = "ok", 0
        title = f"Forfait {st['label']} : {used} consultation(s) dictée(s) ce mois-ci."
    return {"used": used, "cap": cap, "pct": pct, "level": level, "label": st["label"],
            "title": title}


def banner() -> Optional[dict[str, Any]]:
    """Forfait à signaler dans le bandeau (base.html), ou None.

    Ne renvoie quelque chose QUE lorsqu'il y a une décision à prendre : plafond
    proche ou atteint. En deçà, le praticien n'a pas à penser à son quota."""
    st = status()
    if not st or not st.get("monthly_cap"):
        return None
    return st if (st.get("warn") or st.get("blocked")) else None
