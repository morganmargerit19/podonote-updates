"""Profil du praticien — en-tête des ordonnances. Stocké dans data/praticien.json.

Ces informations (identité, coordonnées, n° AM / RPPS, signature) ne sont PAS des
données patient : elles décrivent le prescripteur et figurent en haut de chaque
ordonnance générée. Vide à l'installation : chaque praticien renseigne les
siennes dans Réglages (une ordonnance sans nom ni RPPS est refusée).
"""
from __future__ import annotations

import json
import os
import unicodedata
from pathlib import Path
from typing import Any, Optional

from .config import DATA_DIR, ensure_dirs

PROFILE_FILE = DATA_DIR / "praticien.json"

# Valeurs par défaut : AUCUNE identité. Chaque praticien saisit la sienne dans
# Réglages ; seul le titre de la profession est proposé.
DEFAULT_PROFILE: dict[str, Any] = {
    "nom": "",
    "titre": "Pédicure - Podologue D.E",
    "adresse": "",
    "telephone": "",
    "num_am": "",
    "rpps": "",
    "signature_path": "",  # nom de fichier relatif à data/ (ex. signature.png)
    # Lignes proposées par défaut dans l'ordonnance (Nico peut en ajouter/retirer).
    # Retour Nico : les semelles ne sont PLUS prescrites d'office — elles se
    # choisissent comme le reste (sélecteur « Semelles / orthèses » du hub).
    "lignes_defaut": [
        "1 BILAN PODOLOGIQUE",
    ],
    # Bibliothèque personnelle de lignes de prescription (retour Nico : pouvoir
    # prescrire le NOM EXACT des produits qu'il utilise). Éditable dans Réglages,
    # insérable en un clic dans l'ordonnance. Vide par défaut.
    "produits_favoris": [],
}

_TEXT_FIELDS = ("nom", "titre", "adresse", "telephone", "num_am", "rpps")

# Jusqu'à la 1.3.3, les valeurs par défaut étaient les coordonnées de Nico (l'app
# était « prête à l'emploi » chez lui) — et apparaissaient donc chez TOUT nouveau
# praticien. Ce relevé ne sert plus qu'à la migration ci-dessous : on les inscrit
# dans le fichier de Nico (rien ne change pour lui) et on les efface partout
# ailleurs. À retirer quand tous les postes seront passés par la 1.3.4.
_LEGACY_NICO = {
    "nom": "TERRANOVA Nicolas - EI",
    "adresse": "6b rue des lilas\n19490 SAINTE FORTUNADE",
    "telephone": "05 44 40 52 56",
    "num_am": "19 8001877",
    "rpps": "10106041121",
}


def load() -> dict[str, Any]:
    """Charge le profil (défauts complétés par le fichier s'il existe). Tolérant."""
    ensure_dirs()
    data = dict(DEFAULT_PROFILE)
    try:
        stored = json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
        if isinstance(stored, dict):
            data.update({k: v for k, v in stored.items() if k in DEFAULT_PROFILE})
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError, ValueError):
        pass
    if not isinstance(data.get("lignes_defaut"), list):
        data["lignes_defaut"] = list(DEFAULT_PROFILE["lignes_defaut"])
    if not isinstance(data.get("produits_favoris"), list):
        data["produits_favoris"] = list(DEFAULT_PROFILE["produits_favoris"])
    return data


def save(values: dict[str, Any]) -> None:
    """Écriture ATOMIQUE (.tmp puis os.replace) du profil mis à jour."""
    ensure_dirs()
    current = load()
    for f in _TEXT_FIELDS:
        if f in values:
            current[f] = (values[f] or "").strip()
    if "lignes_defaut" in values:
        current["lignes_defaut"] = [
            l.strip() for l in (values["lignes_defaut"] or []) if l and l.strip()
        ]
    if "produits_favoris" in values:
        current["produits_favoris"] = [
            l.strip() for l in (values["produits_favoris"] or []) if l and l.strip()
        ]
    if "signature_path" in values:
        current["signature_path"] = (values["signature_path"] or "").strip()
    tmp = PROFILE_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    # os.replace est atomique mais peut lever PermissionError sous Windows si le
    # fichier est momentanément ouvert (lecture concurrente). On retente une fois.
    try:
        os.replace(tmp, PROFILE_FILE)
    except PermissionError:
        import time
        time.sleep(0.1)
        try:
            os.replace(tmp, PROFILE_FILE)
        except OSError:
            tmp.unlink(missing_ok=True)
            raise


def _is_nico(licensee: Optional[str]) -> bool:
    """Le titulaire de la licence est-il Nico ? (« Nicolas Terranova », dans
    n'importe quel ordre, casse et accents ignorés.)"""
    txt = unicodedata.normalize("NFKD", licensee or "").encode("ascii", "ignore").decode()
    return {"nicolas", "terranova"} <= set(txt.lower().replace("-", " ").split())


def _same(a: Any, b: str) -> bool:
    """Même valeur à la mise en forme près (fins de ligne d'un textarea, espaces)."""
    norm = lambda v: "\n".join(l.strip() for l in str(v or "").replace("\r\n", "\n").split("\n")).strip()
    return norm(a) == norm(b)


def migrate_legacy_defaults(licensee: Optional[str]) -> str:
    """Migration 1.3.4 des anciennes valeurs par défaut (coordonnées de Nico).

    Appelée au démarrage, idempotente :
    - sur le poste de Nico (sa licence), chaque champ d'identité ABSENT de son
      fichier reçoit l'ancienne valeur : son en-tête d'ordonnance ne bouge pas,
      même s'il n'a jamais enregistré ses Réglages ;
    - sur tout autre poste, un champ IDENTIQUE à une coordonnée de Nico (Réglages
      enregistrés sans les modifier) est vidé.
    Renvoie « nico », « nettoyé » ou « » (rien à faire), pour le journal."""
    try:
        stored = json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        stored = {}
    except (json.JSONDecodeError, OSError, ValueError):
        return ""                                  # fichier illisible : on n'y touche pas
    if not isinstance(stored, dict):
        return ""
    if _is_nico(licensee):
        missing = {k: v for k, v in _LEGACY_NICO.items() if k not in stored}
        if not missing:
            return ""
        save(missing)
        return "nico"
    found = {k: "" for k, v in _LEGACY_NICO.items() if k in stored and _same(stored[k], v)}
    if not found:
        return ""
    save(found)
    return "nettoyé"


def effective_header(profile: dict[str, Any], cabinet: Optional[dict[str, Any]]) -> dict[str, Any]:
    """En-tête d'ordonnance effectif : les champs RENSEIGNÉS du cabinet remplacent
    ceux du profil praticien global (signature et lignes par défaut restent du profil).
    Sans cabinet, renvoie le profil tel quel."""
    h = dict(profile)
    if cabinet:
        for f in ("nom", "titre", "adresse", "telephone", "num_am", "rpps"):
            v = (cabinet.get(f) or "").strip()
            if v:
                h[f] = v
    return h


def is_complete(profile: Optional[dict[str, Any]] = None) -> bool:
    """Minimum requis pour une ordonnance valable : identité + RPPS."""
    p = profile or load()
    return bool((p.get("nom") or "").strip() and (p.get("rpps") or "").strip())


def signature_file(profile: Optional[dict[str, Any]] = None) -> Optional[Path]:
    """Chemin absolu de la signature si elle existe sur le disque, sinon None."""
    p = profile or load()
    sp = (p.get("signature_path") or "").strip()
    if not sp:
        return None
    path = DATA_DIR / sp
    # Garde-fou anti-traversal : la signature DOIT rester dans data/ (un
    # praticien.json trafiqué pourrait sinon pointer ../../un_fichier_sensible).
    try:
        path.resolve().relative_to(DATA_DIR.resolve())
    except ValueError:
        return None
    return path if path.exists() else None
