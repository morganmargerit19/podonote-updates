"""Système de licence (abonnement mensuel) — vérification côté app.

Modèle hybride : un serveur Studio Margerit (hors app) émet un JETON SIGNÉ
(Ed25519) valable ~35 jours, mis en cache localement. L'app vérifie la signature
avec la CLÉ PUBLIQUE embarquée ci-dessous, contrôle l'expiration, et tolère une
courte période de grâce. Aucune donnée de santé n'intervient ici.

Format du jeton : "<base64url(payload_json)>.<base64url(signature)>"
payload = {"licensee","plan","iat","exp"(unix s),"machine"(optionnel)}
"""
from __future__ import annotations

import base64
import json
import time
from typing import Any, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .config import DATA_DIR, ensure_dirs

# Clé publique de Studio Margerit (la clé privée signe les licences, hors app).
PUBLIC_KEY_B64 = "4BtFnPdW+EjMlukFYI+xUa4oPKBurvDV566V0sWsB7g="

LICENSE_FILE = DATA_DIR / "license.json"
GRACE_DAYS = 7
_DAY = 86400

# --- Licence DÉMO (podologues testeurs) : 7 jours OU un plafond de minutes de
# transcription, premier atteint. SANS période de grâce (l'essai s'arrête net,
# contrairement à un abonné payant qu'on ne bloque jamais sèchement). « essai »
# (plan historique) reçoit les mêmes règles.
DEMO_PLANS = ("demo", "essai")
DEMO_MINUTES_CAP = 120
DEMO_USAGE_FILE = DATA_DIR / "demo_usage.json"

# Formules connues, encodées sur 1 octet dans le jeton compact (gain de place).
# 5 = « demo » (7 j / plafond de minutes de transcription, SANS grâce) ;
# 6 = « ambassadeur » (tarif dédié Nico — fonctionnellement identique à mensuel).
PLAN_CODES = {0: "mensuel", 1: "annuel", 2: "dev", 3: "essai", 4: "trimestriel",
              5: "demo", 6: "ambassadeur"}
PLAN_IDS = {v: k for k, v in PLAN_CODES.items()}
_FMT_COMPACT = 2  # 1er octet de la charge utile binaire (distingue du JSON hérité)


# --------------------------------------------------------------------------- #
# base64url
# --------------------------------------------------------------------------- #
def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def b64u_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _public_key() -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))


# --------------------------------------------------------------------------- #
# Charge utile COMPACTE (binaire) — jeton bien plus court que l'ancien JSON.
# Format : [0]=2  [1]=code formule  [2:6]=exp en JOURS unix (uint32 BE)  [6:]=titulaire UTF-8
# La signature Ed25519 (64 o) reste le gros du jeton : incompressible hors-ligne.
# --------------------------------------------------------------------------- #
def encode_payload(licensee: str, plan: str, exp_unix: int) -> str:
    code = PLAN_IDS.get(plan, 0)
    exp_days = int(exp_unix) // _DAY
    raw = bytes([_FMT_COMPACT, code]) + exp_days.to_bytes(4, "big") + (licensee or "").encode("utf-8")
    return b64u_encode(raw)


def _decode_payload(raw: bytes) -> dict[str, Any]:
    """Décode une charge utile compacte (v2) OU l'ancien JSON (rétrocompat)."""
    if len(raw) >= 6 and raw[0] == _FMT_COMPACT:
        return {
            "plan": PLAN_CODES.get(raw[1], str(raw[1])),
            "exp": int.from_bytes(raw[2:6], "big") * _DAY,
            "licensee": raw[6:].decode("utf-8", "replace") or "—",
        }
    return json.loads(raw)  # jeton hérité (JSON)


# --------------------------------------------------------------------------- #
# Exigence de licence (au niveau du CODE, pas du .env) : se propage par OTA,
# contrairement au .env qui n'est jamais redistribué. Échappatoire pour le
# développement et les tests via la variable d'environnement PODONOTE_NO_LICENSE.
# --------------------------------------------------------------------------- #
def is_enforced() -> bool:
    import os
    return not os.environ.get("PODONOTE_NO_LICENSE")


# --------------------------------------------------------------------------- #
# Identifiant machine (binding optionnel, anonyme)
# --------------------------------------------------------------------------- #
def _machine_guid() -> Optional[str]:
    """MachineGuid Windows (stable, survit aux changements de carte réseau)."""
    import os
    if os.name != "nt":
        return None
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
            0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
        ) as k:
            val, _ = winreg.QueryValueEx(k, "MachineGuid")
            return str(val)
    except Exception:
        return None


def _mac_platform_uuid() -> Optional[str]:
    """IOPlatformUUID du Mac : identifiant matériel stable (survit au renommage
    du Mac, à un changement de réseau, à une réinstallation de Diktae). Le nom
    réseau de la machine, utilisé auparavant, change avec le Wi-Fi."""
    import re
    import subprocess
    import sys
    if sys.platform != "darwin":
        return None
    try:
        out = subprocess.run(["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                             capture_output=True, text=True, timeout=5).stdout
    except Exception:
        return None
    m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out or "")
    return m.group(1) if m else None


def _linux_machine_id() -> Optional[str]:
    from pathlib import Path
    for chemin in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            v = Path(chemin).read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if v:
            return v
    return None


_MACHINE_ID: Optional[str] = None


def machine_id() -> str:
    """Identifiant anonyme et STABLE de cet ordinateur (16 caractères hexa).

    Empreinte du MachineGuid (Windows), de l'IOPlatformUUID (Mac) ou du
    machine-id (Linux) : jamais le nom de la machine ni de l'utilisateur. C'est
    lui que le proxy retient pour lier une clé de licence à son ordinateur.

    Le dernier identifiant est gardé avec les données (`poste_id`) et ne sert
    que si l'identifiant matériel est un jour illisible : un identifiant qui
    changerait ferait passer le poste pour un autre ordinateur, donc le
    bloquerait. Un dossier de données recopié sur une autre machine n'en clone
    pas l'identité : l'identifiant matériel, quand il se lit, l'emporte."""
    global _MACHINE_ID
    if _MACHINE_ID is None:
        import hashlib
        import secrets
        fichier = DATA_DIR / "poste_id"
        try:
            memorise = fichier.read_text(encoding="utf-8").strip()
        except OSError:
            memorise = ""
        materiel = _machine_guid() or _mac_platform_uuid() or _linux_machine_id()
        if materiel:
            mid = hashlib.sha256(materiel.encode()).hexdigest()[:16]
        else:
            mid = memorise or secrets.token_hex(8)
        if mid != memorise:
            try:
                ensure_dirs()
                fichier.write_text(mid, encoding="utf-8")
            except OSError:
                pass
        _MACHINE_ID = mid
    return _MACHINE_ID


# --------------------------------------------------------------------------- #
# Une clé = un ordinateur (appliqué par le proxy Studio Margerit)
#
# Le jeton se vérifie hors ligne et ne porte aucun identifiant de machine : le
# proxy retient le poste de chaque clé et refuse les autres. L'app lui envoie
# donc son identifiant à chaque appel, inscrit le poste au moment où la clé est
# collée, et se bloque si le proxy lui répond que la clé est prise ailleurs.
# --------------------------------------------------------------------------- #
POSTE_HEADER = "x-diktae-poste"
POSTE_REFUSE = "poste_non_autorise"         # code d'erreur du proxy
REFUS_FILE = DATA_DIR / "licence_refusee.json"


def entetes_proxy(token: str) -> dict[str, str]:
    """En-têtes d'un appel au proxy : la clé de licence et l'identifiant du poste."""
    return {"x-api-key": token, POSTE_HEADER: machine_id()}


def _empreinte(token: str) -> str:
    import hashlib
    return hashlib.sha256((token or "").strip().encode("utf-8")).hexdigest()[:16]


def refus_proxy(status_code: int, corps: Any) -> Optional[str]:
    """Message du proxy si la réponse dit « clé prise par un autre ordinateur »
    (HTTP 403, code poste_non_autorise), sinon None."""
    if status_code != 403 or not isinstance(corps, dict):
        return None
    err = corps.get("error") if isinstance(corps.get("error"), dict) else corps
    if err.get("code") != POSTE_REFUSE:
        return None
    return str(err.get("message") or "") or (
        "Cette clé de licence est déjà utilisée sur un autre ordinateur.")


def marquer_refus_poste(message: str) -> None:
    """Le proxy refuse cette clé sur ce poste : Diktae se bloque (écran Licence)
    jusqu'à ce qu'il l'accepte de nouveau — poste libéré par Studio Margerit —
    ou qu'une autre clé soit activée."""
    token = _load()
    if not token:
        return
    ensure_dirs()
    REFUS_FILE.write_text(json.dumps({"cle": _empreinte(token), "message": message,
                                      "le": int(time.time())}), encoding="utf-8")


def effacer_refus_poste() -> None:
    try:
        REFUS_FILE.unlink()
    except OSError:
        pass


def _refus_poste(token: str) -> Optional[str]:
    """Message du refus enregistré pour CETTE clé (un refus visant une clé
    remplacée depuis ne compte plus)."""
    try:
        data = json.loads(REFUS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("cle") != _empreinte(token):
        return None
    return str(data.get("message") or "") or "Cette clé de licence est déjà utilisée sur un autre ordinateur."


def activer_en_ligne(token: str, timeout: float = 15.0) -> tuple[Optional[bool], str]:
    """Inscrit CE poste auprès du proxy pour cette clé.

    (True, "") : accepté — ou pas de proxy (appel direct, dev), ou proxy
    antérieur à cette route (il ne sait pas encore lier une clé à un poste :
    l'app plus récente que le serveur ne casse rien).
    (False, message) : refusé (clé prise ailleurs, révoquée, expirée).
    (None, message) : serveur injoignable — on ne peut pas vérifier."""
    import httpx

    from .config import settings

    base = settings.llm_proxy_url.strip().rstrip("/")
    if not base:
        return True, ""
    injoignable = ("Le serveur de licences Studio Margerit est injoignable : "
                   "vérifiez la connexion Internet, puis réessayez.")
    try:
        resp = httpx.post(f"{base}/licence/activer", headers=entetes_proxy(token),
                          timeout=timeout)
    except httpx.HTTPError:
        return None, injoignable
    if resp.status_code == 404 or resp.status_code < 400:
        return True, ""
    if resp.status_code >= 500:        # serveur arrêté derrière sa passerelle
        return None, injoignable
    try:
        corps = resp.json()
    except ValueError:
        corps = {}
    err = corps.get("error") if isinstance(corps, dict) else None
    message = (err or {}).get("message") if isinstance(err, dict) else ""
    return False, message or f"Clé refusée par le serveur (HTTP {resp.status_code})."


def activer(token: str) -> tuple[bool, str]:
    """Activation depuis l'écran Licence : contrôles hors ligne, PUIS inscription
    du poste auprès du serveur, PUIS enregistrement. Une clé déjà prise par un
    autre ordinateur n'est jamais enregistrée."""
    token = (token or "").strip()
    ok, reason, payload = verify_token(token)
    if not ok:
        return False, reason
    grace = 0 if payload.get("plan") in DEMO_PLANS else GRACE_DAYS
    if payload.get("exp", 0) + grace * _DAY < time.time():
        return False, "Cette clé est déjà expirée."
    accepte, message = activer_en_ligne(token)
    if not accepte:
        return False, message
    ok, msg = activate(token)
    if ok:
        effacer_refus_poste()
    return ok, msg


# --------------------------------------------------------------------------- #
# Vérification d'un jeton
# --------------------------------------------------------------------------- #
def machine_display(mid: str | None = None) -> str:
    """Présentation Diktae de l'identifiant machine : « DKT-XXXX-XXXX-XXXX-XXXX ».

    Pur AFFICHAGE : le calcul (machine_id) et le flux d'émission de licence sont
    inchangés — les clés déjà émises restent valables. Les tirets/le préfixe
    sont ignorés à la saisie côté support (l'hex sous-jacent suffit).
    """
    raw = (mid or machine_id()).upper()
    groups = [raw[i:i + 4] for i in range(0, len(raw), 4)]
    return "DKT-" + "-".join(groups)


def verify_token(token: str) -> tuple[bool, str, Optional[dict[str, Any]]]:
    """Vérifie la signature et le format. Renvoie (signature_ok, raison, payload).

    Ne juge PAS l'expiration ici (gérée par get_status) — seulement l'authenticité.
    """
    try:
        payload_b64, sig_b64 = token.strip().split(".")
    except ValueError:
        return False, "Format de clé invalide.", None
    try:
        sig = _b64u_decode(sig_b64)
        _public_key().verify(sig, payload_b64.encode("ascii"))
    except InvalidSignature:
        return False, "Signature invalide (clé non émise par Studio Margerit).", None
    except Exception:
        return False, "Clé illisible.", None
    try:
        payload = _decode_payload(_b64u_decode(payload_b64))
    except Exception:
        return False, "Contenu de clé illisible.", None
    if not isinstance(payload, dict):
        return False, "Contenu de clé invalide.", None
    # Binding machine optionnel
    if payload.get("machine") and payload["machine"] != machine_id():
        return False, "Cette clé est liée à un autre ordinateur.", None
    return True, "OK", payload


# --------------------------------------------------------------------------- #
# Stockage / statut
# --------------------------------------------------------------------------- #
def _load() -> Optional[str]:
    if not LICENSE_FILE.exists():
        return None
    try:
        return json.loads(LICENSE_FILE.read_text(encoding="utf-8")).get("token")
    except Exception:
        return None


def current_token() -> Optional[str]:
    """Jeton de licence actif (tel qu'enregistré), ou None. Sert aussi de clé
    d'authentification vers le proxy de clés API Studio Margerit."""
    return _load()


def activate(token: str) -> tuple[bool, str]:
    """Vérifie puis enregistre le jeton. Renvoie (succès, message)."""
    ok, reason, payload = verify_token(token)
    if not ok:
        return False, reason
    grace = 0 if payload.get("plan") in DEMO_PLANS else GRACE_DAYS
    if payload.get("exp", 0) + grace * _DAY < time.time():
        return False, "Cette clé est déjà expirée."
    ensure_dirs()
    LICENSE_FILE.write_text(json.dumps({"token": token.strip()}, indent=2), encoding="utf-8")
    return True, "Licence activée."


# --------------------------------------------------------------------------- #
# Compteur de minutes de transcription (plans démo uniquement)
# --------------------------------------------------------------------------- #
def demo_seconds_used() -> float:
    try:
        return float(json.loads(DEMO_USAGE_FILE.read_text(encoding="utf-8"))
                     .get("transcription_seconds", 0.0))
    except Exception:
        return 0.0


def add_demo_seconds(seconds: float) -> None:
    """Ajoute des secondes de transcription consommées au compteur démo.

    N'est appelé QUE lorsque le plan actif est une démo. Le compteur survit à
    une réactivation de la même clé (le fichier n'est pas remis à zéro par
    `activate`) : réémettre une clé démo ne rend pas des minutes."""
    if seconds <= 0:
        return
    ensure_dirs()
    total = demo_seconds_used() + float(seconds)
    DEMO_USAGE_FILE.write_text(
        json.dumps({"transcription_seconds": round(total, 1)}), encoding="utf-8")


def _demo_fields(plan: str) -> dict[str, Any]:
    """Champs supplémentaires du statut pour un plan démo (minutes)."""
    if plan not in DEMO_PLANS:
        return {}
    used_min = demo_seconds_used() / 60.0
    left = max(0, int(DEMO_MINUTES_CAP - used_min))
    return {
        "demo": True,
        "minutes_cap": DEMO_MINUTES_CAP,
        "minutes_used": int(used_min),
        "minutes_left": left,
    }


def get_status() -> dict[str, Any]:
    """État courant : state ∈ none|invalid|refused|active|grace|expired (+ détails).

    `refused` : le proxy a répondu que cette clé est liée à un autre ordinateur.

    Plans démo : PAS de période de grâce (active -> expired), et le statut
    porte le compteur de minutes (`minutes_left` etc.). Les minutes épuisées
    ne changent pas `state` : l'app reste consultable (fiches déjà produites),
    seule la transcription est bloquée (cf. demo_transcription_allowed)."""
    token = _load()
    if not token:
        return {"state": "none"}
    ok, reason, payload = verify_token(token)
    if not ok:
        return {"state": "invalid", "reason": reason}
    now = time.time()
    exp = payload.get("exp", 0)
    plan = payload.get("plan", "—")
    days_left = int((exp - now) // _DAY)
    base = {
        "licensee": payload.get("licensee", "—"),
        "plan": plan,
        "exp_unix": exp,
        "days_left": days_left,
        **_demo_fields(plan),
    }
    refus = _refus_poste(token)
    if refus:
        # Clé prise par un autre ordinateur (réponse du proxy) : bloquée ici
        # aussi, sinon une clé partagée servirait encore à transcrire.
        return {"state": "refused", "reason": refus, **base}
    if now < exp:
        return {"state": "active", **base}
    if plan not in DEMO_PLANS and now < exp + GRACE_DAYS * _DAY:
        base["grace_days_left"] = int((exp + GRACE_DAYS * _DAY - now) // _DAY)
        return {"state": "grace", **base}
    return {"state": "expired", **base}


def is_allowed() -> bool:
    """True si l'app peut fonctionner (active ou en période de grâce)."""
    return get_status().get("state") in ("active", "grace")


def demo_transcription_allowed() -> tuple[bool, str]:
    """(autorisé, raison) : une NOUVELLE transcription peut-elle démarrer ?

    Toujours autorisé hors plan démo (et quand la licence n'est pas exigée).
    En démo : refuse quand le plafond de minutes est atteint — l'app, elle,
    reste utilisable (consultation des fiches, compta…)."""
    if not is_enforced():
        return True, ""
    st = get_status()
    if not st.get("demo"):
        return True, ""
    if st.get("minutes_left", 0) <= 0:
        return False, (
            f"Version démo : le quota de {DEMO_MINUTES_CAP} minutes de "
            "transcription est épuisé. Contactez Studio Margerit pour "
            "passer à l'abonnement — vos fiches restent consultables."
        )
    return True, ""
