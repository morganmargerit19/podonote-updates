"""Configuration centralisée de PodoNote (lue depuis .env)."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Nom commercial affiché partout (gabarits, fenêtre native, Dock macOS). Le nom
# de code « PodoNote » subsiste dans les chemins et les paquets : ne pas confondre.
APP_DISPLAY_NAME = "Diktae"

# Racine du projet (…/Podonote)
BASE_DIR = Path(__file__).resolve().parent.parent

# Dossiers de travail (créés au démarrage)
DATA_DIR = BASE_DIR / "data"
INCOMING_DIR = BASE_DIR / "incoming"
EXPORTS_DIR = BASE_DIR / "exports"
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

DB_PATH = DATA_DIR / "podonote.db"

# Modèles ML EMBARQUÉS dans l'installeur (usage hors-ligne). Si l'installeur a livré
# le dossier `model_cache/`, on y redirige les caches HuggingFace et torch AVANT tout
# import de whisperx/torch — ainsi aucun téléchargement HuggingFace n'est tenté au 1er
# lancement (contourne un bridage/throttling HF observé chez certains FAI). Sans ce
# dossier (install depuis les sources / dev), comportement par défaut (~/.cache).
# setdefault : une variable d'environnement déjà posée par l'utilisateur reste prioritaire.
_BUNDLED_MODELS = BASE_DIR / "model_cache"
if _BUNDLED_MODELS.is_dir():
    os.environ.setdefault("HF_HOME", str(_BUNDLED_MODELS / "huggingface"))
    os.environ.setdefault("TORCH_HOME", str(_BUNDLED_MODELS / "torch"))


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Sécurité / accès : les identifiants (mot de passe + PIN) et le secret de session
    # sont créés au 1er lancement via /setup et stockés hachés dans data/auth.json.
    # (Voir app/security.py.) Plus aucun secret en clair ici.

    # Réseau
    host: str = "0.0.0.0"
    port: int = 8000
    # Périmètre LAN : par défaut, seuls /upload (page iPhone) et /static sont
    # servis hors loopback — les fiches patients ne transitent jamais en HTTP
    # clair sur le réseau du cabinet. true = rouvrir toute l'app au LAN (à ne
    # faire que derrière un VPN ou un reverse-proxy TLS).
    lan_full_access: bool = False

    # Transcription
    # large-v3-turbo : meilleur compromis mesuré sur vrai audio FR (RTF 0,63x sur
    # CPU, qualité ≈ medium, RAM ~4,5 Go) — corrige les fautes de small tout en
    # restant ~1,5x plus rapide que medium. Alternatives : small (le + rapide,
    # RTF 0,38x mais erreurs), medium (un peu + précis mais + lent et + de RAM).
    whisper_model: str = "large-v3-turbo"
    whisper_compute_type: str = "int8"
    whisper_language: str = "fr"
    # Threads CPU pour le moteur de calcul (CTranslate2). 0 = automatique (tous
    # les cœurs physiques). WhisperX plafonne à 4 par défaut : sur un CPU 8 cœurs,
    # l'ASR ne tournait que sur la moitié de la machine. Même calcul, même sortie,
    # juste plus de cœurs qui travaillent.
    whisper_cpu_threads: int = 0
    # Taille de lot de l'inférence batchée (tronçons VAD traités ensemble).
    # 8 = défaut historique ; n'affecte pas le texte produit, seulement
    # vitesse/RAM. À ajuster via banc (scripts/bench_pipeline.py).
    whisper_batch_size: int = 8
    # Chemin explicite de ffmpeg (sinon recherché dans le PATH). Utile si le PATH
    # n'est pas encore rafraîchi juste après l'installation. Vide = auto (PATH).
    ffmpeg_path: str = ""
    whisper_beam_size: int = 5
    # Repli de température de l'ASR : whisper réessaie aux températures suivantes
    # quand un segment est jugé peu fiable. Plus la liste est longue, plus c'est
    # robuste MAIS plus c'est lent sur passages difficiles. "0.0,0.2" est un bon
    # compromis vitesse/qualité ; "0.0,0.2,0.4,0.6,0.8,1.0" = max robustesse (lent).
    whisper_temperatures: str = "0.0,0.2,0.4,0.6,0.8,1.0"
    # Alignement mot-à-mot : utile UNIQUEMENT pour la diarisation (timestamps
    # précis). Sans diarisation, il ne change pas le texte → laisser True n'a
    # d'effet que si un token HuggingFace est aussi présent.
    whisper_align: bool = True
    # Garde les modèles (ASR + alignement + diarisation) chargés EN MÉMOIRE entre
    # consultations au lieu de les recharger du disque à chaque fiche. Gain net sur
    # disque lent ; sortie STRICTEMENT identique et même pic de RAM (les trois
    # modèles sont déjà chargés ensemble pendant une transcription). Mettre False
    # uniquement sur une machine à très faible RAM (rechargement à chaque fiche).
    whisper_keep_models_loaded: bool = True
    # VAD : silero ne nécessite pas de token HuggingFace (contrairement à pyannote).
    whisper_vad_method: str = "silero"
    # Nettoyage audio avant transcription (compense bruit ambiant / micro éloigné).
    whisper_normalize_audio: bool = True
    # Chaîne de filtres ffmpeg appliquée (réglable sans toucher au code) :
    #   highpass  : coupe les basses fréquences (ronflements, grondements)
    #   afftdn    : réduction de bruit ambiant (nf = niveau, moins agressif si proche de 0)
    #   loudnorm  : normalisation de la sonie (volume homogène)
    # Ajuster lors du test réel. Vide = pas de filtrage (juste rééchantillonnage 16k mono).
    whisper_audio_filters: str = "highpass=f=70,afftdn=nf=-20,loudnorm=I=-16:TP=-1.5:LRA=11"
    # Amorce métier : biaise la reconnaissance vers le français + le vocabulaire podologie.
    whisper_initial_prompt: str = (
        "Consultation de pédicure-podologie en français. Le praticien et le patient "
        "échangent. Vocabulaire : fascia plantaire, aponévrose plantaire, hallux valgus, "
        "ongle incarné, hyperkératose, durillon, cor, verrue plantaire, orthèse plantaire, "
        "semelle orthopédique, talon, voûte plantaire, métatarse, avant-pied, chaussage, "
        "épine calcanéenne, tendon d'Achille. Examen postural : épaule gauche plus basse, "
        "épaule droite plus haute, omoplate, EIPS, creux poplité, bassin, gibbosité."
    )

    # Diarisation — les modèles sont désormais EMBARQUÉS (récupérés tout seuls
    # au premier lancement, cf. app/diarization_models.py) : plus besoin de
    # compte HuggingFace côté client. Le jeton reste un REPLI pour les postes
    # historiques qui l'ont déjà.
    huggingface_token: str = ""
    # Dossier des modèles embarqués (vide = data/models/diarization).
    diarize_model_dir: str = ""
    diarize_min_speakers: Optional[int] = 2
    diarize_max_speakers: Optional[int] = 3

    # LLM — backend de génération de la fiche.
    #   "ollama" : 100 % local (aucune donnée ne sort), mais lourd en RAM/CPU.
    #   "sonnet" : Claude (cloud) — rapide, faible RAM. N'envoie QUE du texte
    #              PSEUDONYMISÉ (cf. app/pseudonymize.py). L'audio reste local
    #              dans les deux cas (l'ASR ne passe jamais par le cloud).
    llm_backend: str = "ollama"

    # Backend local (Ollama)
    ollama_host: str = "http://127.0.0.1:11434"
    ollama_model: str = "qwen2.5:7b"

    # Backend cloud (Anthropic / Claude). Clé via .env, jamais en dur.
    # NB : un ANTHROPIC_MODEL posé dans un .env installé PRIME sur ce défaut
    # (l'OTA ne réécrit jamais le .env, et install.ps1 copie .env.example →
    # les postes installés portent l'ancienne valeur en dur). La migration se
    # fait donc CÔTÉ CODE : les valeurs héritées qu'on a nous-mêmes livrées
    # sont remplacées au chargement (voir _migrate_anthropic_model). Une valeur
    # épinglée volontairement à un AUTRE modèle est respectée.
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-5"
    # 16000 : une consultation longue (anamnèse fournie + examens complets) a
    # déjà dépassé 4096 tokens en réel (fiche tronquée chez Nico, 2026-06-12).
    # NB : les .env déjà installés peuvent plafonner plus bas — llm.py retente
    # automatiquement avec un plafond relevé si la réponse est tronquée.
    anthropic_max_tokens: int = 16000
    # Timeout de l'appel cloud (secondes) : évite un pipeline pendu sur réseau
    # dégradé (l'appel Ollama local a déjà son propre timeout de 600 s).
    anthropic_timeout_seconds: float = 120.0
    # Proxy de clés Studio Margerit (cf. server/keyproxy/) : quand renseignée
    # (ex. https://api.studio-margerit.fr), les appels Claude passent par ce
    # relais — l'app s'authentifie avec sa CLÉ DE LICENCE (jamais de clé
    # Anthropic sur le poste client) et la consommation est comptée par
    # licencié. Vide = appel direct Anthropic avec la clé locale (historique).
    llm_proxy_url: str = ""

    # Pipeline
    delete_audio_after_transcription: bool = True
    auto_process: bool = True

    # Upload : taille max d'un fichier audio (Mo). ~1h en lossless ≈ 600 Mo.
    max_upload_mb: int = 1024

    # Licence : DÉPRÉCIÉ — l'exigence de licence est désormais décidée par le CODE
    # (app/license.py:is_enforced) pour se propager par OTA (le .env n'est jamais
    # redistribué). Pour DÉSACTIVER en dev/test : variable d'env PODONOTE_NO_LICENSE=1.
    # Ce champ est conservé pour compatibilité .env mais n'est plus lu par le portail.
    license_enforced: bool = False

    # Diffusion des mises à jour : dépôt GitHub des paquets signés. Vide = dépôt
    # de PROD (cf. app/updater.py). Renseigner dans .env (UPDATES_REPO=user/repo-test)
    # pour valider le cycle OTA sur un dépôt ISOLÉ sans exposer les postes en prod.
    updates_repo: str = ""

    @field_validator("anthropic_model", mode="after")
    @classmethod
    def _migrate_anthropic_model(cls, v: str) -> str:
        """Migration par OTA du modèle cloud : install.ps1 a copié .env.example
        dans le .env des postes installés, qui épinglent donc l'ANCIEN défaut en
        dur — et l'OTA ne réécrit jamais le .env. On remplace ici les seules
        valeurs que NOUS avons livrées ; un modèle choisi délibérément (autre
        valeur) est respecté."""
        legacy = {"claude-sonnet-4-6"}
        return "claude-sonnet-5" if v.strip() in legacy else v


settings = Settings()


def ensure_dirs() -> None:
    """Crée les dossiers de travail s'ils n'existent pas."""
    for d in (DATA_DIR, INCOMING_DIR, EXPORTS_DIR):
        d.mkdir(parents=True, exist_ok=True)
