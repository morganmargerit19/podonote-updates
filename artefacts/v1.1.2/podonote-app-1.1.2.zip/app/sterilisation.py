"""Traçabilité de stérilisation : cycles d'autoclave, sachets, recherche inverse.

Trois usages (écran Stérilisation) :
  - REGISTRE : journal des cycles (référence, programme, contrôles, conformité) ;
  - RATTACHER : lier un sachet issu d'un cycle à un patient/une consultation ;
  - RECHERCHE INVERSE : à partir d'un n° de cycle/lot, retrouver les patients
    exposés (indispensable si une charge se révèle non conforme a posteriori).

La conformité d'un cycle est TOUJOURS recalculée (test Helix conforme ET
intégrateur viré) — jamais saisie telle quelle. Les requêtes vivent ici (et non
dans app/repository.py, centré dossier patient) : la stérilisation est un
domaine matériel autonome, purgé indépendamment des dossiers.
"""
from __future__ import annotations

from datetime import date as _date, timedelta
from typing import Any, Optional

from .db import db_cursor, get_connection

PROGRAMMES = {
    "prion": "Prion",
    "standard": "Standard",
}
HELIX = {
    "conforme": "CONFORME",
    "echec": "ÉCHEC",
}
INTEGRATEURS = {
    "vire": "viré",
    "douteux": "douteux",
}


def est_conforme(helix: str, integrateur: str) -> bool:
    """Une charge est conforme si le test Helix passe ET l'intégrateur a viré."""
    return helix == "conforme" and integrateur == "vire"


def next_ref(when: Optional[_date] = None) -> str:
    """Référence humaine du prochain cycle : « C-AAMM · L » (lettre du mois).

    Exemple : 3ᵉ cycle de juillet 2026 → « C-2607 · C ».
    """
    when = when or _date.today()
    prefix = f"C-{when:%y%m}"
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM sterilisation_cycles WHERE ref LIKE ?",
            (f"{prefix}%",),
        ).fetchone()
    finally:
        conn.close()
    lettre = chr(ord("A") + min(row["n"], 25))
    return f"{prefix} · {lettre}"


# --------------------------------------------------------------------------- #
# Cycles
# --------------------------------------------------------------------------- #
def create_cycle(date: str, programme: str, temperature: str, duree: str,
                 nb_sachets: int, operateur: str, helix: str, integrateur: str,
                 notes: str = "") -> int:
    from datetime import datetime
    programme = programme if programme in PROGRAMMES else "prion"
    helix = helix if helix in HELIX else "conforme"
    integrateur = integrateur if integrateur in INTEGRATEURS else "vire"
    # Sans date saisie : maintenant (un NULL explicite contournerait le DEFAULT).
    date = (date or "").strip() or f"{datetime.now():%Y-%m-%d %H:%M:%S}"
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO sterilisation_cycles (ref, date, programme, temperature,"
            " duree, nb_sachets, operateur, helix, integrateur, conforme, notes)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (next_ref(), date, programme, temperature.strip(),
             duree.strip(), max(0, nb_sachets), operateur.strip(), helix,
             integrateur, int(est_conforme(helix, integrateur)), notes.strip()),
        )
        return int(cur.lastrowid)


def get_cycle(cycle_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM sterilisation_cycles WHERE id = ?", (cycle_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def list_cycles(limit: int = 60) -> list[dict[str, Any]]:
    """Cycles récents + nombre de sachets déjà rattachés (utilisés)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT c.*, COUNT(s.id) AS sachets_utilises "
            "FROM sterilisation_cycles c "
            "LEFT JOIN sterilisation_sachets s ON s.cycle_id = c.id "
            "GROUP BY c.id ORDER BY c.date DESC, c.id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def find_cycles(q: str) -> list[dict[str, Any]]:
    """Recherche inverse par référence de cycle/lot (« C-2604 », « 2604 · A »…)."""
    q = (q or "").strip()
    if not q:
        return []
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM sterilisation_cycles WHERE ref LIKE ? "
            "ORDER BY date DESC LIMIT 20",
            (f"%{q}%",),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# Sachets
# --------------------------------------------------------------------------- #
def next_numero(cycle_id: int) -> str:
    """Prochain n° de sachet du cycle : « S-01 », « S-02 », …"""
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM sterilisation_sachets WHERE cycle_id = ?",
            (cycle_id,),
        ).fetchone()
    finally:
        conn.close()
    return f"S-{row['n'] + 1:02d}"


def attach_sachet(cycle_id: int, numero: str, contenu: str,
                  patient_id: Optional[int], consultation_id: Optional[int]) -> int:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO sterilisation_sachets (cycle_id, numero, contenu,"
            " patient_id, consultation_id, date_utilisation)"
            " VALUES (?, ?, ?, ?, ?, datetime('now', 'localtime'))",
            (cycle_id, numero.strip() or next_numero(cycle_id), contenu.strip(),
             patient_id, consultation_id),
        )
        return int(cur.lastrowid)


def get_sachet(sachet_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM sterilisation_sachets WHERE id = ?", (sachet_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def update_sachet(sachet_id: int, numero: str, contenu: str) -> None:
    """Corrige le n° / le contenu d'un sachet déjà rattaché (retour Nico :
    erreur de saisie). Un numéro vidé retombe sur le prochain n° du cycle."""
    sachet = get_sachet(sachet_id)
    if not sachet:
        return
    numero = numero.strip() or next_numero(sachet["cycle_id"])
    with db_cursor() as cur:
        cur.execute(
            "UPDATE sterilisation_sachets SET numero = ?, contenu = ? WHERE id = ?",
            (numero, contenu.strip(), sachet_id),
        )


def delete_sachet(sachet_id: int) -> bool:
    """Supprime un sachet saisi par erreur (retour Nico). La charge du cycle
    (nb_sachets) n'est pas touchée : elle décrit la capacité, pas les
    rattachements. Renvoie True si une ligne a été supprimée."""
    with db_cursor() as cur:
        cur.execute("DELETE FROM sterilisation_sachets WHERE id = ?", (sachet_id,))
        return cur.rowcount > 0


def sachets_of_cycle(cycle_id: int) -> list[dict[str, Any]]:
    """Sachets utilisés d'un cycle, avec le patient rattaché (traçabilité)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT s.*, p.nom AS p_nom, p.prenom AS p_prenom "
            "FROM sterilisation_sachets s "
            "LEFT JOIN patients p ON p.id = s.patient_id "
            "WHERE s.cycle_id = ? ORDER BY s.id",
            (cycle_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def sachets_by_consultation(patient_id: int) -> dict[int, list[dict[str, Any]]]:
    """Poches de stérilisation rattachées à chaque soin d'un patient, avec le
    numéro de poche et la référence de cycle (retour Nico : voir le cycle + n° de
    poche dans la frise chrono). Renvoie {consultation_id: [{numero, contenu, ref}]}."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT s.consultation_id, s.numero, s.contenu, c.ref "
            "FROM sterilisation_sachets s "
            "JOIN sterilisation_cycles c ON c.id = s.cycle_id "
            "WHERE s.patient_id = ? AND s.consultation_id IS NOT NULL "
            "ORDER BY s.id",
            (patient_id,),
        ).fetchall()
    finally:
        conn.close()
    out: dict[int, list[dict[str, Any]]] = {}
    for r in rows:
        out.setdefault(int(r["consultation_id"]), []).append(
            {"numero": r["numero"], "contenu": r["contenu"], "ref": r["ref"]})
    return out


def patients_exposes(cycle_id: int) -> list[dict[str, Any]]:
    """Patients ayant reçu un sachet de ce cycle (recherche inverse)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT s.numero, s.contenu, s.date_utilisation, s.consultation_id, "
            "       p.id AS patient_id, p.nom, p.prenom, p.sexe "
            "FROM sterilisation_sachets s "
            "JOIN patients p ON p.id = s.patient_id "
            "WHERE s.cycle_id = ? ORDER BY s.date_utilisation DESC",
            (cycle_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# Tableau de bord
# --------------------------------------------------------------------------- #
def kpis() -> dict[str, Any]:
    """KPI de l'écran : cycles du mois, sachets disponibles, conformité 90 j."""
    today = _date.today()
    month_prefix = f"{today:%Y-%m}"
    d90 = (today - timedelta(days=90)).isoformat()
    conn = get_connection()
    try:
        cycles_mois = conn.execute(
            "SELECT COUNT(*) AS n FROM sterilisation_cycles WHERE date LIKE ?",
            (f"{month_prefix}%",),
        ).fetchone()["n"]
        # Disponibles = taille des charges CONFORMES − sachets déjà rattachés.
        row = conn.execute(
            "SELECT COALESCE(SUM(c.nb_sachets), 0) AS total, "
            "       (SELECT COUNT(*) FROM sterilisation_sachets s "
            "        JOIN sterilisation_cycles c2 ON c2.id = s.cycle_id "
            "        WHERE c2.conforme = 1) AS utilises "
            "FROM sterilisation_cycles c WHERE c.conforme = 1",
        ).fetchone()
        disponibles = max(0, row["total"] - row["utilises"])
        conf = conn.execute(
            "SELECT COUNT(*) AS n, COALESCE(SUM(conforme), 0) AS ok "
            "FROM sterilisation_cycles WHERE date >= ?",
            (d90,),
        ).fetchone()
        conformite = round(100 * conf["ok"] / conf["n"]) if conf["n"] else None
    finally:
        conn.close()
    return {"cycles_mois": cycles_mois, "disponibles": disponibles,
            "conformite_90j": conformite}
