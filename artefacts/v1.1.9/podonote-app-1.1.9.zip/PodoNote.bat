@echo off
REM ============================================================
REM  PodoNote - lanceur (double-cliquez sur ce fichier)
REM ============================================================
title PodoNote
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1"
pause
