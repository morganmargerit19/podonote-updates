"""Captures d'écran des pages clés (données de démo enrichies) via Playwright."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
OUT = ROOT / "docs" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)

from playwright.sync_api import sync_playwright  # noqa: E402

from app import repository as repo  # noqa: E402

BASE = "http://127.0.0.1:8000"


def run():
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 900}, device_scale_factor=2)
        pg.goto(f"{BASE}/login", wait_until="networkidle")
        pg.fill('input[name="password"]', "demonstration")
        pg.click('button[type="submit"]')
        pg.wait_for_load_state("networkidle")

        shots = {
            "1_home.png": f"{BASE}/",
            "2_fiche_patient.png": f"{BASE}/patients/1",
            "3_fiche_bilan.png": f"{BASE}/consultations/2",
            "4_nouvelle_consultation.png": f"{BASE}/consultations/new?patient_id=1",
        }
        for name, url in shots.items():
            pg.goto(url, wait_until="networkidle")
            pg.wait_for_timeout(600)
            pg.screenshot(path=str(OUT / name), full_page=True)

        # Écran de traitement (stepper / barre de progression) : on crée une
        # consultation "en cours" temporaire (sans audio à reprendre), on capture, on supprime.
        cid = repo.create_consultation(1, "cabinet", True, audio_path=None)
        repo.update_consultation_status(cid, "processing", "Transcription en cours…")
        try:
            pg.goto(f"{BASE}/consultations/{cid}", wait_until="domcontentloaded")
            pg.wait_for_timeout(700)
            pg.screenshot(path=str(OUT / "6_traitement.png"))
        finally:
            repo.delete_consultation(cid)

        # Page upload iPhone (vue mobile, déconnectée)
        ctx2 = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2)
        m = ctx2.new_page()
        m.goto(f"{BASE}/upload", wait_until="networkidle")
        m.wait_for_timeout(400)
        m.screenshot(path=str(OUT / "5_upload_iphone.png"), full_page=True)
        b.close()
    print("OK", OUT)


if __name__ == "__main__":
    run()
