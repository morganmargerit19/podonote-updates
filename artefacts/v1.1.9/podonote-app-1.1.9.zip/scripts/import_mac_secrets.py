#!/usr/bin/env python3
"""Range les secrets du Studio dans le Trousseau macOS — pendant Mac de
`scripts/export_cloud_secrets.ps1` (qui, lui, tourne sur le PC Windows).

Les clés de signature vivent normalement sur le PC Windows du Studio. Pour
travailler depuis le Mac (émettre une licence, publier une OTA), il faut les y
amener une bonne fois : ce script les range dans le **Trousseau**, d'où
`scripts/_signing.py` sait désormais les relire tout seul. Plus aucune variable
d'environnement à poser à chaque commande, et rien en clair sur le disque.

Marche à suivre :
  1. sur le PC Windows :  .\\scripts\\export_cloud_secrets.ps1
  2. sur ce Mac        :  python scripts/import_mac_secrets.py
     puis coller chaque valeur quand elle est demandée (saisie masquée : elle
     n'apparaît pas à l'écran et ne va pas dans l'historique du shell).

Chaque clé importée est **vérifiée contre la clé publique embarquée dans l'app**
(`app/license.py`, `app/updater.py`) : un mauvais copier-coller est refusé tout
de suite, au lieu de produire des licences ou des OTA que le parc rejettera.

Usage :
  python scripts/import_mac_secrets.py           # import interactif
  python scripts/import_mac_secrets.py --check   # état seul, ne demande rien
"""
from __future__ import annotations

import argparse
import base64
import getpass
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: E402
    Ed25519PrivateKey,
)

from scripts._signing import (  # noqa: E402
    KEYCHAIN_ACCOUNTS,
    KEYCHAIN_SERVICE,
    LICENSE_ENV,
    PASSPHRASE_ENV,
    UPDATE_ENV,
    _decode_pem,
    keychain_read,
    keychain_write,
)

# Comptes Trousseau (cf. _signing.KEYCHAIN_ACCOUNTS) + celui de la clé API.
ACCOUNT_LICENSE = KEYCHAIN_ACCOUNTS[LICENSE_ENV]
ACCOUNT_UPDATE = KEYCHAIN_ACCOUNTS[UPDATE_ENV]
ACCOUNT_PASSPHRASE = KEYCHAIN_ACCOUNTS[PASSPHRASE_ENV]
ACCOUNT_API_KEY = "anthropic-api-key"  # cf. app/secretstore.py


def _public_b64(priv: Ed25519PrivateKey) -> str:
    """Clé publique correspondante, en base64 — comparable à celles de l'app."""
    raw = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(raw).decode("ascii")


def _expected_license_pub() -> str:
    from app.license import PUBLIC_KEY_B64
    return PUBLIC_KEY_B64


def _expected_update_pubs() -> tuple[str, ...]:
    from app.updater import UPDATE_PUBLIC_KEYS_B64
    return UPDATE_PUBLIC_KEYS_B64


def _load(pem: bytes, passphrase: str | None) -> Ed25519PrivateKey:
    """Charge un PEM Ed25519, avec ou sans passphrase. Lève ValueError si KO."""
    pw = passphrase.encode("utf-8") if passphrase else None
    try:
        priv = serialization.load_pem_private_key(pem, password=pw)
    except TypeError:
        raise ValueError("cette clé est chiffrée : une passphrase est nécessaire")
    if not isinstance(priv, Ed25519PrivateKey):
        raise ValueError("ce n'est pas une clé Ed25519")
    return priv


def _ask(label: str) -> str:
    """Saisie masquée. Entrée vide = passer (on garde ce qui est déjà rangé)."""
    print(f"\n  {label}")
    return getpass.getpass("  > (collez, ou Entrée pour passer) : ").strip()


# --------------------------------------------------------------------------- #
# État
# --------------------------------------------------------------------------- #
def show_state() -> int:
    """Affiche ce que contient le Trousseau, sans jamais révéler les valeurs."""
    print(f"\nTrousseau macOS — service « {KEYCHAIN_SERVICE} »\n")
    rows = [
        ("Clé de licence", ACCOUNT_LICENSE),
        ("Clé de signature OTA", ACCOUNT_UPDATE),
        ("Passphrase de la clé OTA", ACCOUNT_PASSPHRASE),
        ("Clé API Anthropic", ACCOUNT_API_KEY),
    ]
    missing = 0
    for label, account in rows:
        present = bool(keychain_read(account))
        missing += 0 if present else 1
        print(f"  {'✅' if present else '❌'}  {label:<28} ({account})")

    # Contrôle de fond : les clés rangées correspondent-elles au parc installé ?
    lic = _decode_pem(keychain_read(ACCOUNT_LICENSE))
    if lic:
        try:
            got = _public_b64(_load(lic, None))
            ok = got == _expected_license_pub()
            print(f"\n  {'✅' if ok else '⚠️ '} Clé de licence "
                  f"{'conforme' if ok else 'NON CONFORME'} à app/license.py")
        except ValueError as exc:
            print(f"\n  ⚠️  Clé de licence illisible : {exc}")

    upd = _decode_pem(keychain_read(ACCOUNT_UPDATE))
    if upd:
        try:
            got = _public_b64(_load(upd, keychain_read(ACCOUNT_PASSPHRASE) or None))
            ok = got in _expected_update_pubs()
            print(f"  {'✅' if ok else '⚠️ '} Clé de signature OTA "
                  f"{'conforme' if ok else 'NON CONFORME'} à app/updater.py")
        except ValueError as exc:
            print(f"  ⚠️  Clé OTA illisible : {exc}")

    print()
    return 0 if missing == 0 else 1


# --------------------------------------------------------------------------- #
# Import
# --------------------------------------------------------------------------- #
def do_import() -> int:
    if sys.platform != "darwin":
        sys.stderr.write("Ce script ne sert que sur macOS (Trousseau).\n")
        return 2

    print(__doc__.split("Usage :")[0].strip())
    print("\n" + "=" * 70)
    print("  Les valeurs sont produites sur le PC Windows par :")
    print("      .\\scripts\\export_cloud_secrets.ps1")
    print("  Saisie masquée — rien ne s'affiche, rien n'entre dans l'historique.")
    print("=" * 70)

    stored: list[str] = []

    # --- 1. Clé de licence (non chiffrée) ---------------------------------- #
    raw = _ask("PODONOTE_LICENSE_KEY_B64  (clé d'émission des licences)")
    if raw:
        pem = _decode_pem(raw)
        if pem is None:
            sys.stderr.write("  ❌ Valeur illisible (ni PEM, ni base64 de PEM). Abandon.\n")
            return 1
        try:
            pub = _public_b64(_load(pem, None))
        except ValueError as exc:
            sys.stderr.write(f"  ❌ {exc}. Abandon.\n")
            return 1
        if pub != _expected_license_pub():
            sys.stderr.write(
                "  ❌ Cette clé ne correspond PAS à celle qu'attendent les postes\n"
                "     (app/license.py). Les licences émises seraient rejetées.\n"
                "     Rien n'a été rangé. Vérifiez le copier-coller.\n"
            )
            return 1
        if not keychain_write(ACCOUNT_LICENSE, raw):
            sys.stderr.write("  ❌ Écriture dans le Trousseau refusée.\n")
            return 1
        print("  ✅ Clé de licence rangée — conforme à app/license.py.")
        stored.append("licence")

    # --- 2. Passphrase, puis clé OTA (chiffrée) ---------------------------- #
    passphrase = _ask("PODONOTE_SIGN_PASSPHRASE  (passphrase de la clé OTA)")
    if passphrase:
        if not keychain_write(ACCOUNT_PASSPHRASE, passphrase):
            sys.stderr.write("  ❌ Écriture dans le Trousseau refusée.\n")
            return 1
        print("  ✅ Passphrase rangée.")
        stored.append("passphrase")

    raw = _ask("PODONOTE_SIGN_KEY_B64  (clé de signature des OTA)")
    if raw:
        pem = _decode_pem(raw)
        if pem is None:
            sys.stderr.write("  ❌ Valeur illisible (ni PEM, ni base64 de PEM). Abandon.\n")
            return 1
        # La passphrase vient de la saisie ci-dessus, sinon de ce qui est déjà rangé.
        pw = passphrase or keychain_read(ACCOUNT_PASSPHRASE)
        try:
            pub = _public_b64(_load(pem, pw or None))
        except ValueError as exc:
            sys.stderr.write(f"  ❌ {exc}. Abandon.\n")
            return 1
        if pub not in _expected_update_pubs():
            sys.stderr.write(
                "  ❌ Cette clé ne correspond PAS à celles qu'acceptent les postes\n"
                "     (app/updater.py). Les OTA signées seraient refusées.\n"
                "     Rien n'a été rangé. Vérifiez le copier-coller.\n"
            )
            return 1
        if not keychain_write(ACCOUNT_UPDATE, raw):
            sys.stderr.write("  ❌ Écriture dans le Trousseau refusée.\n")
            return 1
        print("  ✅ Clé de signature OTA rangée — conforme à app/updater.py.")
        stored.append("OTA")

    # --- 3. Clé API Anthropic (pour l'app elle-même) ----------------------- #
    raw = _ask("ANTHROPIC_API_KEY  (rédaction des fiches, mode hybride)")
    if raw:
        from app.secretstore import protect_api_key
        if not protect_api_key(raw):
            sys.stderr.write("  ❌ Écriture dans le Trousseau refusée.\n")
            return 1
        print("  ✅ Clé API rangée (l'app la lira sans passer par le .env).")
        stored.append("clé API")

    if not stored:
        print("\nRien à importer (aucune valeur saisie).")
    else:
        print(f"\n✅ Rangé dans le Trousseau : {', '.join(stored)}.")
        print("   Redémarrez Diktae pour qu'il relise la clé API.")
    return show_state()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="affiche l'état du Trousseau sans rien demander")
    args = ap.parse_args()
    return show_state() if args.check else do_import()


if __name__ == "__main__":
    raise SystemExit(main())
