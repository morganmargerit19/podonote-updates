#!/usr/bin/env python3
"""Simulateur de coût & marge PodoNote — pour cadrer la grille tarifaire.

Le SEUL coût cloud est l'appel Claude Sonnet qui rédige la fiche (la
transcription tourne en LOCAL = gratuit). Tarif Sonnet 5 : 3 $/M tokens en
entrée, 15 $/M en sortie (intro 2 $/10 $ jusqu'au 31/08/2026) ; Batch API = -50 %.

On modélise le coût d'UNE consultation puis on déroule une grille de paliers
(volume mensuel + prix d'abonnement) → COGS, marge €, marge %.

Usage :
  python scripts/pricing_sim.py                 # profil "central"
  python scripts/pricing_sim.py --profile large # compte plus large
  python scripts/pricing_sim.py --batch         # avec Batch API (-50 %)
  python scripts/pricing_sim.py --words 3500 --out 1800 --rate 0.92
"""
from __future__ import annotations

import argparse

# --------------------------------------------------------------------------- #
# Tarifs Sonnet 5 (USD / token) — à mettre à jour si Anthropic change.
# NB : nouveau tokenizer Sonnet 5 ≈ +30 % de tokens pour le même texte —
# TOK_PER_WORD ci-dessous est à re-mesurer si l'estimation doit être fine.
# --------------------------------------------------------------------------- #
PRICE_IN_USD = 3.0 / 1_000_000     # entrée
PRICE_OUT_USD = 15.0 / 1_000_000   # sortie

# Tokens FIXES par appel (mesurés / estimés dans le code).
SYSTEM_TOK = 1_100                 # prompt système (gabarit fiche) — mesuré
HISTORY_TOK = 450                  # historique + terrain patient (compact)
TOK_PER_WORD = 1.6                 # français : ~1,6 token / mot

# Profils d'hypothèse (mots de transcript + tokens de fiche en sortie).
PROFILES = {
    "central": {"words": 3_000, "out": 1_500},
    "large":   {"words": 4_500, "out": 2_048},   # bavard + fiche longue (plafond)
    "leger":   {"words": 2_000, "out": 1_000},
}

# Grille FIGÉE par Morgan (2026-08-26) : nom, volume max/mois, prix €/mois
# (TVA non applicable — micro-entreprise). Annuel = 10 mois payés (-2 mois),
# payable en une fois. Plan « ambassadeur » (Nico) hors grille : 12,99 €/mois.
# Réf : docs/TARIFS.md.
TIERS = [
    ("Pédicure / Solo léger", 40,  17.99),
    ("Standard",              150, 37.99),
    ("Cabinet / Pro",         300, 69.99),
]


def consult_cost_eur(words: float, out_tok: float, rate: float, batch: bool) -> tuple[float, int]:
    """Coût € d'une consultation + nb de tokens d'entrée."""
    in_tok = SYSTEM_TOK + HISTORY_TOK + words * TOK_PER_WORD
    usd = in_tok * PRICE_IN_USD + out_tok * PRICE_OUT_USD
    if batch:
        usd *= 0.5
    return usd * rate, int(in_tok)


def main() -> None:
    p = argparse.ArgumentParser(description="Simulateur coût/marge PodoNote.")
    p.add_argument("--profile", choices=PROFILES, default="central",
                   help="Hypothèse de longueur (central par défaut).")
    p.add_argument("--words", type=float, help="Mots de transcript / consult (override).")
    p.add_argument("--out", type=float, help="Tokens de sortie / fiche (override).")
    p.add_argument("--rate", type=float, default=0.92, help="Taux USD→EUR (défaut 0,92).")
    p.add_argument("--batch", action="store_true", help="Active le Batch API (-50 %).")
    args = p.parse_args()

    prof = PROFILES[args.profile]
    words = args.words if args.words is not None else prof["words"]
    out_tok = args.out if args.out is not None else prof["out"]

    unit, in_tok = consult_cost_eur(words, out_tok, args.rate, args.batch)
    print(f"\nHypothèse : profil={args.profile}  transcript={words:.0f} mots "
          f"(~{in_tok} tok entrée)  fiche={out_tok:.0f} tok sortie  "
          f"batch={'oui' if args.batch else 'non'}")
    print(f"Coût d'UNE consultation (30 min) : €{unit:.4f}  (~{unit*100:.2f} cts)\n")

    header = f"{'Palier':<24}{'Vol/mois':>9}{'COGS €':>9}{'Prix €':>8}{'Marge €':>9}{'Marge %':>9}"
    print(header)
    print("-" * len(header))
    for name, vol, price in TIERS:
        cogs = unit * vol
        margin = price - cogs
        pct = (margin / price * 100) if price else 0
        print(f"{name:<24}{vol:>9}{cogs:>9.2f}{price:>8}{margin:>9.2f}{pct:>8.0f}%")
    print("\nNB : COGS = coût cloud uniquement (la transcription locale est gratuite). "
          "Prix = proposition de départ, à ajuster selon valeur/marché.")


if __name__ == "__main__":
    main()
