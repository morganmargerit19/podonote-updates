"""Rend la présentation HTML en PDF A4 via Chromium (Playwright)."""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
HTML = ROOT / "docs" / "presentation" / "podonote_presentation.html"
PDF = ROOT / "docs" / "presentation" / "PodoNote_presentation_Studio-Margerit.pdf"


def run():
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.goto(HTML.as_uri(), wait_until="networkidle")
        pg.wait_for_timeout(1200)  # laisser les Google Fonts se charger
        pg.emulate_media(media="print")
        pg.pdf(path=str(PDF), format="A4", print_background=True,
               margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
        b.close()
    kb = PDF.stat().st_size // 1024
    print(f"PDF: {PDF} ({kb} Ko)")


if __name__ == "__main__":
    run()
