"""Assemble les captures en une seule image JPEG compacte + sort son base64."""
import base64
from pathlib import Path

from PIL import Image

OUT = Path(__file__).resolve().parent.parent / "docs" / "screenshots"
files = ["1_liste_patients.png", "2_fiche_patient.png", "3_fiche_bilan.png",
         "4_nouvelle_consultation.png", "5_upload_iphone.png"]

W = 760
gap = 16
imgs = []
for f in files:
    im = Image.open(OUT / f).convert("RGB")
    ratio = W / im.width
    im = im.resize((W, int(im.height * ratio)))
    imgs.append(im)

total_h = sum(im.height for im in imgs) + gap * (len(imgs) + 1)
canvas = Image.new("RGB", (W + 2 * gap, total_h), "#e9edec")
y = gap
for im in imgs:
    canvas.paste(im, (gap, y))
    y += im.height + gap

montage = OUT / "podonote_apercu.jpg"
canvas.save(montage, "JPEG", quality=62, optimize=True)
size = montage.stat().st_size
print(f"Montage: {montage} ({size//1024} Ko)")

b64 = base64.b64encode(montage.read_bytes()).decode()
(OUT / "podonote_apercu.b64").write_text(b64)
print(f"Base64: {len(b64)} caractères")
