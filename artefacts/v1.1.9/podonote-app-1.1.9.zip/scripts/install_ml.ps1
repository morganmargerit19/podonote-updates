﻿# =============================================================================
#  PodoNote — Installation des briques ML (CPU)
#  Appelé par install.ps1, ou exécutable seul pour réinstaller la partie ML.
#  Usage seul : .\scripts\install_ml.ps1
#  -Wheelhouse <dossier> : installe HORS-LIGNE depuis des wheels pré-téléchargés
#                          (bundle embarqué dans l'installeur) au lieu de PyPI.
# =============================================================================
param(
    [string]$PyExe = "",
    [string]$Wheelhouse = ""
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

if (-not $PyExe) { $PyExe = "$Root\.venv\Scripts\python.exe" }
if (-not (Test-Path $PyExe)) { throw "Environnement Python introuvable. Lancez install.ps1 d'abord." }

$offline = $Wheelhouse -and (Test-Path $Wheelhouse)

function Invoke-Pip([string[]]$Pkgs, [string[]]$OnlineSrc, [string]$Label) {
    if ($offline) {
        # Hors-ligne : uniquement les wheels embarqués, aucun accès réseau.
        & $PyExe -m pip install --no-index --find-links $Wheelhouse @Pkgs
    } else {
        # En ligne : --timeout/--retries pour robustesse sur réseau lent/instable.
        & $PyExe -m pip install @Pkgs @OnlineSrc --timeout 120 --retries 5
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Echec de l'installation : $Label (code $LASTEXITCODE)." -ForegroundColor Red
        exit 1
    }
}

if ($offline) { Write-Host "Installation ML HORS-LIGNE (wheels embarqués : $Wheelhouse)" -ForegroundColor Cyan }

Write-Host "Installation de PyTorch (CPU)…" -ForegroundColor Cyan
Invoke-Pip @("torch", "torchaudio") @("--index-url", "https://download.pytorch.org/whl/cpu") "PyTorch (CPU)"

Write-Host "Installation de faster-whisper + WhisperX…" -ForegroundColor Cyan
Invoke-Pip @("faster-whisper") @() "faster-whisper"
Invoke-Pip @("whisperx") @() "whisperx"

Write-Host "Installation de matplotlib…" -ForegroundColor Cyan
# pyannote.audio importe matplotlib sans le declarer dans ses dependances :
# sans lui, le chargement du pipeline de diarisation echoue (ModuleNotFoundError).
Invoke-Pip @("matplotlib") @() "matplotlib (dependance non declaree de pyannote)"

Write-Host "Briques ML installées." -ForegroundColor Green
exit 0
