#!/usr/bin/env python3
"""Lit/écrit une ligne « CLE=VALEUR » dans un fichier .env (préserve le reste).

Équivalent multiplateforme des fonctions Set-EnvVar/Get-EnvVar de install.ps1,
utilisé par scripts/install_mac.sh (robuste aux caractères spéciaux des clés).

Usage :
  python scripts/_envtool.py get <env_path> <KEY>
  python scripts/_envtool.py set <env_path> <KEY> <VALUE>
"""
from __future__ import annotations

import re
import sys
from pathlib import Path


def get(path: str, key: str) -> str:
    p = Path(path)
    if not p.exists():
        return ""
    for line in p.read_text(encoding="utf-8").splitlines():
        m = re.match(rf"^\s*{re.escape(key)}\s*=\s*(.*)$", line)
        if m:
            return m.group(1).strip().strip('"').strip("'")
    return ""


def set_(path: str, key: str, value: str) -> None:
    p = Path(path)
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    pat = re.compile(rf"^\s*{re.escape(key)}\s*=")
    out, found = [], False
    for line in lines:
        if pat.match(line):
            out.append(f"{key}={value}")
            found = True
        else:
            out.append(line)
    if not found:
        out.append(f"{key}={value}")
    # UTF-8 sans BOM (un BOM casserait la 1re clé lue par python-dotenv).
    p.write_text("\n".join(out) + "\n", encoding="utf-8")


def main() -> int:
    a = sys.argv[1:]
    if len(a) >= 3 and a[0] == "get":
        print(get(a[1], a[2]))
        return 0
    if len(a) >= 4 and a[0] == "set":
        set_(a[1], a[2], a[3])
        return 0
    print("usage: _envtool.py get|set <env> <KEY> [VALUE]", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
