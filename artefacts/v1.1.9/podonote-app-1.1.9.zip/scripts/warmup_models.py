"""Pré-télécharge les modèles ML pendant l'installation (pour un usage hors-ligne ensuite).

Télécharge : le modèle Whisper, le modèle d'alignement FR, et le VAD silero.
Le modèle de diarisation (pyannote) n'est téléchargé que si un token HF est configuré.
Non bloquant : si une étape échoue (pas d'internet), on l'indique sans planter l'install.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from app.config import settings  # noqa: E402


def main() -> int:
    try:
        import whisperx
    except Exception as exc:
        print(f"  ! whisperx indisponible, modèles non pré-chargés : {exc}")
        return 0

    device = "cpu"
    ok = True

    print(f"  • Modèle de transcription : {settings.whisper_model} (peut être long)…")
    try:
        whisperx.load_model(
            settings.whisper_model, device,
            compute_type=settings.whisper_compute_type,
            language=settings.whisper_language,
            vad_method=settings.whisper_vad_method,
        )
        print("    OK (Whisper + VAD silero)")
    except Exception as exc:
        ok = False
        print(f"    ! échec : {exc}")

    print(f"  • Modèle d'alignement ({settings.whisper_language})…")
    try:
        whisperx.load_align_model(language_code=settings.whisper_language, device=device)
        print("    OK")
    except Exception as exc:
        ok = False
        print(f"    ! échec : {exc}")

    token = settings.huggingface_token.strip()
    if token:
        print("  • Modèle de diarisation (pyannote)…")
        try:
            from app.pipeline.transcribe import _load_diarizer
            _load_diarizer(token, device)
            print("    OK")
        except Exception as exc:
            print(f"    ! échec (vérifiez le token HF et l'acceptation des conditions) : {exc}")
    else:
        print("  • Diarisation : pas de token HuggingFace -> ignorée pour l'instant.")

    print("  Modèles prêts." if ok else "  Certains modèles n'ont pas pu être téléchargés (réessayez en ligne).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
