# =============================================================================
#  PodoNote - Export des SECRETS de signature pour Claude Code cloud
#
#  A lancer UNE FOIS, sur CE PC Windows (la ou vivent les cles du Studio).
#  Affiche les 3 valeurs a coller dans les SECRETS de ton environnement
#  Claude Code cloud (jamais dans le repo, jamais dans un chat public).
#
#  Ces secrets permettent, DEPUIS le cloud (Linux ephemere), de :
#    - bumper l'OTA        : python scripts/deploy_update.py --notes "..."
#    - generer une licence : python scripts/issue_license.py "Nom" --registry ""
#
#  ASCII pur volontairement : PowerShell 5.1 lit les .ps1 en cp1252, un accent
#  en UTF-8 casserait le parsing (piege connu du projet).
#
#  Usage :  .\scripts\export_cloud_secrets.ps1
# =============================================================================
$ErrorActionPreference = "Stop"
$Root   = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$venvPy = Join-Path $Root ".venv\Scripts\python.exe"
$Studio = "C:\Users\Morgan\MyApps\Studio_Margerit"
$LicPem = Join-Path $Studio "podonote-license-private.pem"
$UpdPem = Join-Path $Studio "podonote-update-private.pem"
$Dpapi  = Join-Path $Studio "podonote-update-passphrase.dpapi"

function Die($m) { Write-Host "  !!  $m" -ForegroundColor Red; exit 1 }
if (-not (Test-Path $venvPy)) { Die ".venv introuvable - lance install.ps1 d'abord." }
foreach ($f in @($LicPem, $UpdPem, $Dpapi)) {
    if (-not (Test-Path $f)) { Die "Fichier cle introuvable : $f" }
}

# base64 mono-ligne des deux PEM
$licB64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($LicPem))
$updB64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($UpdPem))
# passphrase de la cle UPDATE (chiffree DPAPI, liee a cette session Windows)
$pass = & $venvPy -c @"
import sys; sys.path.insert(0, r'$Root')
from pathlib import Path
from app.winsecret import unprotect_file
raw = unprotect_file(Path(r'$Dpapi'))
sys.stdout.write(raw.decode('utf-8') if raw else '')
"@
if (-not $pass) { Die "Impossible de dechiffrer la passphrase DPAPI (mauvaise session Windows ?)." }

Write-Host ""
Write-Host "=============================================================" -ForegroundColor Yellow
Write-Host "  SECRETS pour l'environnement Claude Code cloud" -ForegroundColor Yellow
Write-Host "  (a coller dans les SECRETS/variables d'env du cloud, PAS dans le repo)" -ForegroundColor Yellow
Write-Host "=============================================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "PODONOTE_LICENSE_KEY_B64=" -NoNewline -ForegroundColor Cyan; Write-Host $licB64
Write-Host ""
Write-Host "PODONOTE_SIGN_KEY_B64="    -NoNewline -ForegroundColor Cyan; Write-Host $updB64
Write-Host ""
Write-Host "PODONOTE_SIGN_PASSPHRASE=" -NoNewline -ForegroundColor Cyan; Write-Host $pass
Write-Host ""
Write-Host "-------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "Il faut aussi que 'gh' soit authentifie cote cloud (GH_TOKEN avec"
Write-Host "droit 'repo' sur morganmargerit19/podonote-updates)."
Write-Host "Efface l'historique de ce terminal apres copie (ces 3 valeurs = cles de signature)." -ForegroundColor Yellow
