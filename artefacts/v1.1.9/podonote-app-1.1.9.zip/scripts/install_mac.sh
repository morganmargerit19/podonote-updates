#!/usr/bin/env bash
# =============================================================================
#  PodoNote — Installation automatique (macOS)
#  Équivalent macOS de install.ps1. Lance dans Terminal :
#      bash scripts/install_mac.sh
#  Installe : Python 3.12 (via Homebrew si absent), ffmpeg, l'environnement
#  Python (.venv), les dépendances web + les briques ML.
#
#  Mode HYBRIDE par défaut (fiche-bilan via Claude Sonnet — l'audio reste local,
#  seul du texte PSEUDONYMISÉ part au cloud). La clé Anthropic est rangée dans le
#  Trousseau (Keychain), pas en clair dans le .env.
#
#  Options :
#    --key "sk-ant-..."   clé Anthropic (sinon : valeur du .env, sinon demandée)
#    --mode local         100 % local (Ollama) — nécessite un GPU pour être utile
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

MODE="hybride"
KEY=""
while [ $# -gt 0 ]; do
  case "$1" in
    --key) KEY="${2:-}"; shift 2 ;;
    --mode) MODE="${2:-hybride}"; shift 2 ;;
    *) echo "Option inconnue : $1" >&2; exit 2 ;;
  esac
done

step() { printf "\n[%s] %s\n" "$1" "$2"; }
ok()   { printf "    OK  %s\n" "$1"; }
warn() { printf "    !!  %s\n" "$1"; }
has()  { command -v "$1" >/dev/null 2>&1; }

echo "============================================"
echo "        Installation de PodoNote (macOS)"
echo "============================================"
if [ "$MODE" = "hybride" ]; then
  echo "  Mode : HYBRIDE (fiche-bilan via Claude Sonnet)"
  echo "  -> L'audio reste local ; seul du texte PSEUDONYMISÉ part vers le cloud."
else
  echo "  Mode : LOCAL (fiche-bilan via Ollama, GPU recommandé)"
fi

# --- 0. Homebrew (gestionnaire de paquets macOS) -----------------------------
if ! has brew; then
  warn "Homebrew introuvable. Recommandé pour installer Python/ffmpeg automatiquement."
  warn "Installez-le depuis https://brew.sh puis relancez ce script."
fi

# --- 1. Python 3.12 ----------------------------------------------------------
step 1 "Vérification de Python 3.12"
find_python312() {
  if has python3.12; then command -v python3.12; return; fi
  if has python3 && python3 -c 'import sys; sys.exit(0 if sys.version_info[:2]==(3,12) else 1)'; then
    command -v python3; return
  fi
  for p in /opt/homebrew/opt/python@3.12/bin/python3.12 \
           /usr/local/opt/python@3.12/bin/python3.12; do
    [ -x "$p" ] && { echo "$p"; return; }
  done
  return 1
}
PY="$(find_python312 || true)"
if [ -z "${PY:-}" ] && has brew; then
  warn "Python 3.12 absent : installation via Homebrew…"
  brew install python@3.12
  PY="$(find_python312 || true)"
fi
if [ -z "${PY:-}" ]; then
  echo "Python 3.12 introuvable. Installez-le (https://www.python.org/downloads/) puis relancez." >&2
  exit 1
fi
ok "Python 3.12 disponible ($PY)"

# --- 2. ffmpeg (requis pour l'audio) -----------------------------------------
step 2 "Vérification de ffmpeg"
if has ffmpeg; then ok "ffmpeg déjà présent"
elif has brew; then warn "Installation de ffmpeg via Homebrew…"; brew install ffmpeg; ok "ffmpeg installé"
else warn "Installez ffmpeg manuellement (brew install ffmpeg)."; fi

# --- 3. Ollama (mode local uniquement) ---------------------------------------
if [ "$MODE" = "local" ]; then
  step 3 "Vérification d'Ollama (LLM local)"
  if has ollama; then ok "Ollama déjà présent"
  elif has brew; then warn "Installation d'Ollama via Homebrew…"; brew install ollama; ok "Ollama installé"
  else warn "Installez Ollama manuellement : https://ollama.com/download"; fi
  if has ollama; then
    step 3b "Téléchargement du modèle qwen2.5:7b (peut être long)"
    ollama pull qwen2.5:7b || warn "Téléchargez plus tard : ollama pull qwen2.5:7b"
  fi
else
  step 3 "LLM cloud (Claude Sonnet) — Ollama non requis, étape ignorée"
fi

# --- 4. Environnement Python -------------------------------------------------
step 4 "Création de l'environnement Python (.venv)"
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH 2>/dev/null || true
PYEXE="$ROOT/.venv/bin/python"
if [ ! -x "$PYEXE" ]; then
  [ -d "$ROOT/.venv" ] && rm -rf "$ROOT/.venv"
  "$PY" -m venv "$ROOT/.venv"
  [ -x "$PYEXE" ] || { echo "Échec de création du .venv." >&2; exit 1; }
  ok "Environnement créé"
else ok "Environnement déjà présent"; fi

step 4b "Mise à jour de pip"
"$PYEXE" -m pip install --upgrade pip --quiet --timeout 120 --retries 5
ok "pip à jour"

step 4c "Installation des dépendances de base"
"$PYEXE" -m pip install -r "$ROOT/requirements.txt" --timeout 120 --retries 5
ok "Dépendances web installées"

# --- 5. Briques ML -----------------------------------------------------------
step 5 "Installation des briques ML (torch, faster-whisper, whisperx)"
bash "$ROOT/scripts/install_ml_mac.sh" "$PYEXE"
if "$PYEXE" -c "import torch, whisperx, faster_whisper; import pyannote.audio.pipelines" 2>/dev/null; then
  ok "Briques ML installées et vérifiées"
else
  warn "Briques ML installées mais non importables. Relancez scripts/install_ml_mac.sh"
fi

# --- 6. Fichier .env ---------------------------------------------------------
step 6 "Configuration (.env)"
ENVP="$ROOT/.env"
[ -f "$ENVP" ] || { cp "$ROOT/.env.example" "$ENVP"; ok ".env créé"; }

# Lit/écrit une clé du .env via Python (robuste aux caractères spéciaux).
set_env() { "$PYEXE" "$ROOT/scripts/_envtool.py" set "$ENVP" "$1" "$2"; }
get_env() { "$PYEXE" "$ROOT/scripts/_envtool.py" get "$ENVP" "$1"; }

if [ "$MODE" = "hybride" ]; then
  step 6a "Backend de génération : Claude Sonnet (cloud)"
  set_env LLM_BACKEND sonnet
  ok "LLM_BACKEND=sonnet"

  EXISTING="$(get_env ANTHROPIC_API_KEY)"
  if [ -z "$KEY" ] && [ -n "$EXISTING" ]; then
    ok "Clé Anthropic déjà présente (rien à saisir)."
  elif [ -z "$KEY" ]; then
    printf "Clé API Anthropic (sk-ant-..., vide = à remplir plus tard) : "
    read -r KEY || true
  fi
  if [ -n "$KEY" ]; then
    set_env ANTHROPIC_API_KEY "$KEY"
    ok "Clé Anthropic enregistrée dans .env"
  elif [ -z "$EXISTING" ]; then
    warn "Aucune clé. Renseignez ANTHROPIC_API_KEY dans .env avant le 1er usage."
  fi

  # Range la clé dans le Trousseau (Keychain) et l'efface du .env.
  if "$PYEXE" "$ROOT/scripts/protect_api_key.py"; then
    ok "Clé API rangée dans le Trousseau (Keychain) — retirée du .env"
  else
    warn "Mise au Trousseau impossible : la clé reste dans .env (texte brut)."
  fi
else
  set_env LLM_BACKEND ollama
  ok "LLM_BACKEND=ollama (100 % local)"
fi

# --- 6b. Pré-téléchargement des modèles -------------------------------------
step 6b "Pré-téléchargement des modèles ML (peut être long)"
if "$PYEXE" "$ROOT/scripts/warmup_models.py"; then ok "Modèles pré-téléchargés"
else warn "Pré-téléchargement incomplet (réseau ?). Récupérés au 1er usage en ligne."; fi

# --- 6c. Auto-test : l'application démarre-t-elle ? --------------------------
step 6c "Vérification finale : l'application peut-elle démarrer ?"
if "$PYEXE" -c "import app.main; print('PODONOTE_IMPORT_OK')" >/dev/null 2>&1; then
  ok "L'application est prête à démarrer."
else
  warn "L'application ne peut PAS démarrer (dépendance manquante ?). Relancez l'installation."
fi

# --- 7. Lanceur double-cliquable --------------------------------------------
step 7 "Création du lanceur (start_mac.command)"
chmod +x "$ROOT/start_mac.command" 2>/dev/null || true
ok "Lanceur prêt : double-cliquez sur start_mac.command"

echo ""
echo "============================================"
echo "  Installation terminée !"
echo "============================================"
echo "  1. Double-cliquez sur 'start_mac.command' pour démarrer PodoNote."
echo "  2. Au premier lancement, l'application vous guide (mot de passe + PIN)."
echo "  3. Pensez à activer FileVault (chiffrement du disque) :"
echo "     Réglages Système → Confidentialité et sécurité → FileVault."
