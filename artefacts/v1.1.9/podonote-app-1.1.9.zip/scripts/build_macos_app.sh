#!/usr/bin/env bash
# =============================================================================
#  Diktae — Construction d'un .app (+ .dmg optionnel) pour macOS
#  À EXÉCUTER SUR UN MAC, après `bash scripts/install_mac.sh` (le .venv doit
#  exister : le .app est un LANCEUR qui pointe vers cette installation, comme le
#  raccourci Windows pointe vers .venv\Scripts\pythonw.exe).
#
#  SANS compte Apple Developer : on fait une **signature ad-hoc** (gratuite) et
#  on retire la mise en quarantaine. L'app reste « non notarisée » → au premier
#  lancement d'un .app téléchargé, faire **clic droit → Ouvrir** (une seule fois),
#  ou exécuter :  xattr -dr com.apple.quarantine /Applications/Diktae.app
#
#  Usage :
#    bash scripts/build_macos_app.sh                 # .app dans dist/
#    bash scripts/build_macos_app.sh --dmg           # + image .dmg
#    bash scripts/build_macos_app.sh --root /chemin/install --out /chemin/sortie
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/dist"
# Nom affiché par le Finder et le Dock (cf. APP_DISPLAY_NAME côté Python).
# L'identifiant de bundle, lui, ne bouge pas : c'est une identité technique.
APP_NAME="Diktae"
BUNDLE_ID="com.studiomargerit.podonote"
MAKE_DMG=0

while [ $# -gt 0 ]; do
  case "$1" in
    --root) ROOT="$(cd "$2" && pwd)"; shift 2 ;;
    --out) OUT="$2"; shift 2 ;;
    --bundle-id) BUNDLE_ID="$2"; shift 2 ;;
    --dmg) MAKE_DMG=1; shift ;;
    *) echo "Option inconnue : $1" >&2; exit 2 ;;
  esac
done

if [ "$(uname)" != "Darwin" ]; then
  echo "Ce script doit être exécuté sur macOS." >&2
  exit 1
fi
if [ ! -x "$ROOT/.venv/bin/python" ]; then
  echo "Installation introuvable ($ROOT/.venv). Lancez d'abord scripts/install_mac.sh." >&2
  exit 1
fi

# Version depuis app/__init__.py (__version__ = "x.y.z")
VERSION="$("$ROOT/.venv/bin/python" -c "import app; print(app.__version__)" 2>/dev/null || echo "0.0.0")"
APP="$OUT/$APP_NAME.app"
echo "Construction de $APP_NAME.app v$VERSION (install : $ROOT)"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

# --- Info.plist -------------------------------------------------------------
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>${APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
  <key>CFBundleVersion</key><string>${VERSION}</string>
  <key>CFBundleShortVersionString</key><string>${VERSION}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>${APP_NAME}</string>
  <key>CFBundleIconFile</key><string>podonote.icns</string>
  <key>NSHighResolutionCapable</key><true/>
  <!-- App d'arrière-plan UI (fenêtre WKWebView) sans icône Dock dupliquée. -->
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSMicrophoneUsageDescription</key>
  <string>${APP_NAME} n'enregistre pas le micro lui-même ; l'audio des consultations reste local.</string>
</dict>
</plist>
PLIST

# --- Lanceur (pointe vers l'installation, chemin absolu embarqué) -----------
# Comme le raccourci Windows : le .app lance « .venv/bin/python -m app.desktop »
# dans le dossier d'installation. Le chemin est figé au build (l'app peut donc
# être déplacée dans /Applications sans perdre l'installation).
cat > "$APP/Contents/MacOS/$APP_NAME" <<LAUNCHER
#!/bin/bash
ROOT="${ROOT}"
cd "\$ROOT" || exit 1
exec "\$ROOT/.venv/bin/python" -m app.desktop
LAUNCHER
chmod +x "$APP/Contents/MacOS/$APP_NAME"

# --- Icône ------------------------------------------------------------------
if [ -f "$ROOT/static/podonote.icns" ]; then
  cp "$ROOT/static/podonote.icns" "$APP/Contents/Resources/podonote.icns"
else
  echo "  !! static/podonote.icns absent (lancez scripts/make_icon.py) — app sans icône."
fi

# --- Signature ad-hoc (gratuite, sans Apple Developer) ----------------------
if codesign --force --deep --sign - "$APP" 2>/dev/null; then
  echo "  OK  Signature ad-hoc appliquée."
else
  echo "  !! Signature ad-hoc impossible (l'app fonctionnera quand même)."
fi
# Retire la quarantaine sur l'app fraîchement construite (build local).
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

echo "  OK  $APP"

# --- Image .dmg (distribution) ----------------------------------------------
if [ "$MAKE_DMG" = "1" ]; then
  echo "Construction du .dmg…"
  STAGE="$(mktemp -d)"
  cp -R "$APP" "$STAGE/"
  ln -s /Applications "$STAGE/Applications"   # glisser-déposer classique
  DMG="$OUT/$APP_NAME-$VERSION.dmg"
  rm -f "$DMG"
  hdiutil create -volname "$APP_NAME" -srcfolder "$STAGE" -ov -format UDZO "$DMG" >/dev/null
  rm -rf "$STAGE"
  echo "  OK  $DMG"
fi

echo ""
echo "Distribution SANS compte Apple Developer :"
echo "  • Au 1er lancement d'un .app/.dmg téléchargé : clic droit → Ouvrir."
echo "  • Ou : xattr -dr com.apple.quarantine /Applications/$APP_NAME.app"
