"""Empaquette les modèles de diarisation pour la diffusion SANS compte HuggingFace.

À lancer UNE fois par Studio Margerit (le seul moment où un jeton HF sert) :

  pip install huggingface_hub
  python scripts/package_diarization_models.py --token hf_xxx
  # ou : HUGGINGFACE_TOKEN=hf_xxx python scripts/package_diarization_models.py

Le script :
  1. télécharge les 3 briques du pipeline pyannote speaker-diarization-3.1
     (config + segmentation-3.0 + embedding wespeaker) — toutes sous licence
     MIT, donc redistribuables (vérifier les fiches des modèles si elles
     changent un jour) ;
  2. réécrit config.yaml pour pointer vers des fichiers LOCAUX (jeton
     __MODELS_DIR__ substitué au chargement par app/diarization_models.py) ;
  3. produit dist/diarization-v1.zip et affiche son SHA-256.

Publication : committer le zip dans podonote-updates sous models/diarization-v1.zip,
puis reporter le SHA-256 dans app/diarization_models.py (MODELS_SHA256).
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# (repo HF, fichier distant, nom local dans l'archive)
ASSETS = [
    ("pyannote/speaker-diarization-3.1", "config.yaml", "config.yaml"),
    ("pyannote/segmentation-3.0", "pytorch_model.bin", "segmentation.bin"),
    ("pyannote/wespeaker-voxceleb-resnet34-LM", "pytorch_model.bin", "embedding.bin"),
]
# Réécritures dans config.yaml : id Hub -> fichier embarqué.
CONFIG_REWRITES = {
    "pyannote/segmentation-3.0": "__MODELS_DIR__/segmentation.bin",
    "pyannote/wespeaker-voxceleb-resnet34-LM": "__MODELS_DIR__/embedding.bin",
}
VERSION = "diarization-v1"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--token", default=os.environ.get("HUGGINGFACE_TOKEN")
                    or os.environ.get("HF_TOKEN"))
    ap.add_argument("--out", default=str(ROOT / "dist" / f"{VERSION}.zip"))
    args = ap.parse_args()
    if not args.token:
        print("Jeton HuggingFace requis (--token ou $HUGGINGFACE_TOKEN). "
              "Prérequis : avoir accepté les conditions des 3 modèles sur le Hub.",
              file=sys.stderr)
        return 1

    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        print("pip install huggingface_hub", file=sys.stderr)
        return 1

    work = ROOT / "dist" / f"{VERSION}.work"
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True)

    for repo, remote, local in ASSETS:
        print(f"Téléchargement {repo}/{remote}…")
        got = hf_hub_download(repo_id=repo, filename=remote, token=args.token)
        shutil.copyfile(got, work / local)

    # config.yaml : les références Hub deviennent des fichiers embarqués.
    cfg_path = work / "config.yaml"
    cfg = cfg_path.read_text(encoding="utf-8")
    for hub_id, local_ref in CONFIG_REWRITES.items():
        if hub_id not in cfg:
            print(f"⚠️ '{hub_id}' absent de config.yaml — le pipeline amont a "
                  "peut-être changé : VÉRIFIER avant de publier.", file=sys.stderr)
        cfg = cfg.replace(hub_id, local_ref)
    cfg_path.write_text(cfg, encoding="utf-8")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name in ("config.yaml", "segmentation.bin", "embedding.bin"):
            z.write(work / name, name)
    shutil.rmtree(work, ignore_errors=True)

    digest = sha256_file(out)
    size_mb = out.stat().st_size / 1_048_576
    print(f"\n✅ {out}  ({size_mb:.1f} Mo)")
    print(f"SHA-256 : {digest}")
    print("\nÀ faire ensuite :")
    print("  1. committer le zip dans podonote-updates -> models/" + f"{VERSION}.zip")
    print("  2. reporter le SHA-256 dans app/diarization_models.py (MODELS_SHA256)")
    print("  3. rappel licences : pyannote (MIT) — conserver la mention dans la doc.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
