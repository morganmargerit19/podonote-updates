"""Remplaçant détaché de PodoNote — applique une mise à jour déjà téléchargée.

Lancé par `app/updater.py` (copié dans %TEMP% pour ne pas se faire écraser), ce
script tourne EN DEHORS de l'app : il attend que le process de l'app se ferme,
sauvegarde le code courant, recopie le nouveau code par-dessus l'installation
(SANS toucher au `.venv`, au `.env` ni au dossier `data`), relance `pip` si les
dépendances ont changé, puis redémarre l'application.

Volontairement autonome (stdlib seule + psutil optionnel) : il ne doit dépendre
d'aucun fichier de l'app puisque ceux-ci sont justement en train d'être remplacés.

Usage (interne) :
  python apply_update.py --staged <dir> --root <install> --pid <ppid>
                         --launch <pythonw.exe> --backup <dir> --pip 0|1
"""
from __future__ import annotations

import argparse
import logging
import os
import subprocess
import sys
import time
from pathlib import Path


def _setup_log(root: Path) -> logging.Logger:
    log = logging.getLogger("podonote.apply_update")
    log.setLevel(logging.INFO)
    try:
        (root / "data").mkdir(parents=True, exist_ok=True)
        h = logging.FileHandler(str(root / "data" / "update.log"), encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        log.addHandler(h)
    except Exception:
        pass
    return log


def _wait_for_exit(pid: int, log: logging.Logger, timeout: float = 60.0) -> None:
    """Attend la fin du process `pid` (l'app), avec repli si indisponible."""
    deadline = time.monotonic() + timeout
    # Voie privilégiée Windows : OpenProcess + WaitForSingleObject.
    if os.name == "nt":
        try:
            import ctypes

            SYNCHRONIZE = 0x00100000
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
            if not handle:
                log.info("Process %s déjà terminé.", pid)
                return
            ms = max(0, int((deadline - time.monotonic()) * 1000))
            rc = kernel32.WaitForSingleObject(handle, ms)  # 0 = sorti, 0x102 = timeout
            kernel32.CloseHandle(handle)
            if rc == 0x102 and _pid_alive(pid):
                log.warning("L'app (pid %s) ne s'est pas fermée dans le délai — "
                            "on poursuit malgré tout.", pid)
            return
        except Exception:
            log.exception("Attente via API Windows impossible — repli sur sondage.")
    # Repli générique : sondage psutil ou os.kill.
    while time.monotonic() < deadline:
        if not _pid_alive(pid):
            return
        time.sleep(0.3)


def _pid_alive(pid: int) -> bool:
    try:
        import psutil

        return psutil.pid_exists(pid)
    except Exception:
        pass
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


# Éléments JAMAIS écrasés par une bascule (base, clé, venv, données patient).
_EXCLUDE_DIRS = {"data", ".venv", "update_backup", "incoming", "exports"}
_EXCLUDE_FILES = {".env"}


def _copy_tree(src: Path, dst: Path, log: logging.Logger, exclude: bool = False) -> int:
    """Recopie `src`→`dst` SANS purge (laisse intacts .venv/.env/data absents de src).

    Multiplateforme : robocopy sous Windows (rapide, robuste aux verrous),
    shutil sous macOS/Linux. Code de retour façon robocopy : < 8 = succès.
    Avec exclude=True : exclut DÉFENSIVEMENT data/.venv/.env/update_backup même si
    un paquet mal fabriqué les contenait (ne JAMAIS écraser la base ni la clé)."""
    dst.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        args = ["robocopy", str(src), str(dst), "/E", "/NFL", "/NDL", "/NJH", "/NJS",
                "/NP", "/R:2", "/W:1"]
        if exclude:
            args += ["/XD", *_EXCLUDE_DIRS, "/XF", *_EXCLUDE_FILES]
        proc = subprocess.run(args, capture_output=True, text=True)
        # robocopy : codes < 8 = succès (0 rien, 1 copié, 3 copié+extra…).
        if proc.returncode >= 8:
            log.error("robocopy a échoué (code %s) : %s", proc.returncode, proc.stdout)
        return proc.returncode
    # macOS / Linux : recopie récursive en stdlib (pas de robocopy).
    import shutil
    try:
        for item in src.iterdir():
            if exclude and item.name in _EXCLUDE_DIRS:
                continue
            if exclude and item.is_file() and item.name in _EXCLUDE_FILES:
                continue
            target = dst / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
        return 0
    except Exception:
        log.exception("Copie (%s -> %s) en échec.", src, dst)
        return 8


def _mirror(src: Path, dst: Path, log: logging.Logger) -> int:
    """Rend `dst` IDENTIQUE à `src` (miroir, avec purge). Multiplateforme."""
    if os.name == "nt":
        args = ["robocopy", str(src), str(dst), "/MIR",
                "/NFL", "/NDL", "/NJH", "/NJS", "/NP", "/R:2", "/W:1"]
        proc = subprocess.run(args, capture_output=True, text=True)
        if proc.returncode >= 8:
            log.error("Miroir %s -> %s en échec (code %s).", src, dst, proc.returncode)
        return proc.returncode
    import shutil
    try:
        if dst.exists():
            shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst)
        return 0
    except Exception:
        log.exception("Miroir %s -> %s en échec.", src, dst)
        return 8


def _restore_backup(root: Path, backup: Path, log: logging.Logger) -> None:
    """Restaure la sauvegarde en MIROIR dossier par dossier : une recopie simple
    laisserait en place les fichiers déjà posés par la version partiellement
    appliquée (arborescence mixte, app potentiellement non démarrable)."""
    for name in ("app", "templates", "static", "scripts"):
        src = backup / name
        if not src.is_dir():
            continue
        _mirror(src, root / name, log)
    req = backup / "requirements.txt"
    if req.exists():
        import shutil

        shutil.copy2(req, root / "requirements.txt")


def _backup_current(root: Path, backup: Path, log: logging.Logger) -> None:
    """Sauvegarde le code courant (pour dépannage / rollback manuel)."""
    try:
        if backup.exists():
            import shutil

            shutil.rmtree(backup, ignore_errors=True)
        backup.mkdir(parents=True, exist_ok=True)
        for name in ("app", "templates", "static", "scripts", "requirements.txt"):
            src = root / name
            if not src.exists():
                continue
            if src.is_dir():
                _copy_tree(src, backup / name, log)
            else:
                import shutil

                shutil.copy2(src, backup / name)
        log.info("Sauvegarde du code courant -> %s", backup)
    except Exception:
        log.exception("Sauvegarde impossible (on poursuit quand même).")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--staged", required=True)
    ap.add_argument("--root", required=True)
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--launch", required=True)
    ap.add_argument("--backup", required=True)
    ap.add_argument("--tmp", default="")   # dossier de staging à nettoyer (data/update_tmp)
    ap.add_argument("--pip", default="0")
    args = ap.parse_args()

    root = Path(args.root)
    staged = Path(args.staged)
    log = _setup_log(root)
    log.info("=== Application d'une mise à jour ===")
    log.info("staged=%s root=%s pid=%s pip=%s", staged, root, args.pid, args.pip)

    # 1. Attendre la fermeture de l'app (sinon fichiers verrouillés / état mixte).
    _wait_for_exit(args.pid, log, timeout=90.0)
    time.sleep(1.5)  # marge pour la libération des handles

    if not (staged / "app" / "main.py").exists():
        log.error("Dossier mis en attente invalide (app/main.py absent). Abandon.")
        return 1

    # 2. Sauvegarde puis bascule du code (exclusions défensives data/.env/.venv).
    backup = Path(args.backup)
    _backup_current(root, backup, log)
    try:
        code = _copy_tree(staged, root, log, exclude=True)
    except Exception:
        log.exception("Bascule (copie) a levé — tentative de restauration.")
        code = 8
    if code >= 8:
        # Échec partiel : on RESTAURE depuis la sauvegarde pour ne pas laisser une
        # arborescence mixte non démarrable, puis on relance l'ancienne version.
        log.error("Bascule échouée (code %s) — restauration de la version précédente.", code)
        try:
            _restore_backup(root, backup, log)
        except Exception:
            log.exception("Restauration impossible.")
        _relaunch(args.launch, root, log)
        return 1
    log.info("Code applicatif remplacé.")

    # 3. Dépendances : pip seulement si requirements.txt a changé.
    if args.pip == "1":
        py = Path(args.launch)
        # Sous Windows on lance pip avec python.exe (pas pythonw) pour récupérer le
        # journal ; sous macOS/Linux l'interpréteur du venv (bin/python) convient.
        runner = str(py)
        if os.name == "nt":
            py_console = py.parent / "python.exe"
            if py_console.exists():
                runner = str(py_console)
        log.info("requirements.txt modifié — pip install…")
        try:
            res = subprocess.run(
                [runner, "-m", "pip", "install", "-r", str(root / "requirements.txt")],
                cwd=str(root), capture_output=True, text=True, timeout=1800,
            )
            log.info("pip terminé (code %s).", res.returncode)
            if res.returncode != 0:
                log.error("pip a échoué : %s", res.stderr[-2000:])
        except Exception:
            log.exception("pip install en échec (l'app peut malgré tout démarrer).")

    # 4. Nettoyage du staging + relance de l'app.
    try:
        import shutil

        tmp = Path(args.tmp) if args.tmp else None
        # Garde-fou : ne JAMAIS supprimer autre chose que le dossier de staging
        # attendu (data/update_tmp). Sinon on ne touche à rien.
        if tmp is not None and "update_tmp" in tmp.name:
            shutil.rmtree(tmp, ignore_errors=True)
    except Exception:
        log.exception("Nettoyage du staging impossible (non bloquant).")

    # Diagnostic : confirme que les données ont survécu à la bascule. Si l'app
    # rouvrait sur l'écran de configuration, ce journal révèle aussitôt un
    # auth.json/base absents (exclus de la copie, ils ne devraient JAMAIS manquer).
    try:
        data_dir = root / "data"
        log.info("Post-bascule : data=%s auth.json=%s podonote.db=%s",
                 data_dir, (data_dir / "auth.json").exists(),
                 (data_dir / "podonote.db").exists())
    except Exception:
        log.exception("Diagnostic post-bascule impossible (non bloquant).")

    _relaunch(args.launch, root, log)
    log.info("=== Mise à jour terminée, app relancée ===")
    return 0


def _relaunch(launch: str, root: Path, log: logging.Logger) -> None:
    """Relance l'app de façon robuste : repli sur python.exe si pythonw échoue.

    Une relance ratée laisserait l'app fermée ET le voile de l'UI à sonder dans le
    vide → on tente plusieurs interpréteurs avant d'abandonner.
    """
    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
    # Interpréteur principal d'abord, puis replis du même dossier (venv).
    targets = [launch]
    parent = Path(launch).parent
    if os.name == "nt":
        # pythonw → python.exe en repli (récupère un éventuel message console).
        alt = str(parent / "python.exe")
        if alt != launch:
            targets.append(alt)
    else:
        # macOS / Linux : bin/python ↔ bin/python3.
        for name in ("python3", "python"):
            alt = str(parent / name)
            if alt != launch and Path(alt).exists():
                targets.append(alt)
    for target in targets:
        try:
            subprocess.Popen(
                [target, "-m", "app.desktop"], cwd=str(root),
                close_fds=True, creationflags=creationflags,
            )
            log.info("Application relancée : %s -m app.desktop", target)
            return
        except Exception:
            log.exception("Relance via %s impossible — tentative suivante.", target)
    log.error("Toutes les tentatives de relance ont échoué — l'app reste fermée.")


if __name__ == "__main__":
    raise SystemExit(main())
