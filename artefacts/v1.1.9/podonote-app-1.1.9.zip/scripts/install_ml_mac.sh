#!/usr/bin/env bash
# =============================================================================
#  PodoNote — Installation des briques ML (macOS)
#  Appelé par install_mac.sh, ou exécutable seul pour réinstaller la partie ML.
#  Usage seul : bash scripts/install_ml_mac.sh
#
#  NB : sur macOS, on installe torch/torchaudio depuis l'index PyPI par défaut
#  (les roues macOS y sont publiées : CPU sur Intel, CPU+MPS sur Apple Silicon).
#  On n'utilise PAS l'index "/whl/cpu" qui ne sert qu'aux builds Windows/Linux.
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYEXE="${1:-$ROOT/.venv/bin/python}"

if [ ! -x "$PYEXE" ]; then
  echo "Environnement Python introuvable ($PYEXE). Lancez install_mac.sh d'abord." >&2
  exit 1
fi

echo "Installation de PyTorch (macOS : roues PyPI par défaut)…"
"$PYEXE" -m pip install torch torchaudio

echo "Installation de faster-whisper + WhisperX…"
"$PYEXE" -m pip install faster-whisper
"$PYEXE" -m pip install whisperx

echo "Installation de matplotlib…"
# pyannote.audio importe matplotlib sans le déclarer dans ses dépendances :
# sans lui, le chargement du pipeline de diarisation échoue (ModuleNotFoundError).
"$PYEXE" -m pip install matplotlib

echo "Briques ML installées."
