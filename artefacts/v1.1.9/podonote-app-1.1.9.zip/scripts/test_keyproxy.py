"""Tests du proxy de clés API (server/keyproxy) — AUTONOMES.

Clés Ed25519 éphémères + API Anthropic simulée (monkeypatch de l'appel amont) :
aucun réseau, aucune vraie clé, base SQLite dans un dossier temporaire.
"""
from __future__ import annotations

import base64
import importlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "server" / "keyproxy"))

from cryptography.hazmat.primitives import serialization as ser  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: E402
    Ed25519PrivateKey,
)

# --- Environnement du proxy AVANT import du module (il lit l'env au chargement).
_priv = Ed25519PrivateKey.generate()
_pub_b64 = base64.b64encode(
    _priv.public_key().public_bytes(ser.Encoding.Raw, ser.PublicFormat.Raw)).decode()
_tmp = Path(tempfile.mkdtemp())
os.environ.update({
    "PROXY_LICENSE_PUBLIC_KEY": _pub_b64,
    "ANTHROPIC_API_KEY": "sk-test-fake",
    "PROXY_ADMIN_TOKEN": "admin-secret",
    "PROXY_DB": str(_tmp / "keyproxy.db"),
    "PROXY_DAILY_REQ_LIMIT": "5",
})

import app as keyproxy  # noqa: E402  (server/keyproxy/app.py)

importlib.reload(keyproxy)  # relit l'env si le module était déjà chargé

from starlette.testclient import TestClient  # noqa: E402

_DAY = 86400


def mktok(licensee: str, plan_code: int, exp_in_days: float) -> str:
    """Jeton compact signé avec la clé éphémère (même format que l'app)."""
    exp = int(time.time() + exp_in_days * _DAY)
    raw = bytes([2, plan_code]) + (exp // _DAY).to_bytes(4, "big") + licensee.encode()
    payload = base64.urlsafe_b64encode(raw).decode().rstrip("=")
    sig = base64.urlsafe_b64encode(_priv.sign(payload.encode("ascii"))).decode().rstrip("=")
    return f"{payload}.{sig}"


# --- API Anthropic SIMULÉE : capture la requête, renvoie une réponse Messages.
_captured: dict = {}


class _FakeUpstreamResponse:
    status_code = 200
    content = json.dumps({
        "id": "msg_test", "type": "message", "role": "assistant",
        "content": [{"type": "text", "text": "{}"}],
        "usage": {"input_tokens": 1200, "output_tokens": 800,
                  "cache_read_input_tokens": 100},
    }).encode()


async def _fake_upstream(url, headers, payload):
    _captured.update(url=url, headers=headers, payload=payload)
    return _FakeUpstreamResponse()

keyproxy._upstream_post = _fake_upstream
c = TestClient(keyproxy.app)

# 1. Santé
r = c.get("/healthz")
assert r.status_code == 200 and r.json()["key_configured"]
print("HEALTHZ ok")

# 2. Sans licence / licence falsifiée -> 401 au format d'erreur Anthropic
r = c.post("/v1/messages", json={"model": "claude-sonnet-5"}, headers={"x-api-key": ""})
assert r.status_code == 401 and r.json()["error"]["type"] == "authentication_error"
tok = mktok("Cabinet Nico", 0, 35)
bad = tok[:-4] + ("AAAA" if not tok.endswith("AAAA") else "BBBB")
r = c.post("/v1/messages", json={"model": "claude-sonnet-5"}, headers={"x-api-key": bad})
assert r.status_code == 401
print("AUTH licence (absente/falsifiée refusée) ok")

# 3. Licence expirée : mensuel -1 j = accepté (grâce 7 j) ; démo -1 j = refusé (sans grâce)
_body = {"model": "claude-sonnet-5", "max_tokens": 1000,
         "messages": [{"role": "user", "content": "bonjour"}]}
r = c.post("/v1/messages", json=_body, headers={"x-api-key": mktok("Grace SARL", 0, -1)})
assert r.status_code == 200, r.text
r = c.post("/v1/messages", json=_body, headers={"x-api-key": mktok("Demo X", 5, -1)})
assert r.status_code == 401 and "expirée" in r.json()["error"]["message"]
print("GRÂCE mensuel oui / démo non ok")

# 4. Relais nominal : la VRAIE clé part vers l'amont, la réponse revient telle
# quelle, la conso est journalisée SANS le contenu.
r = c.post("/v1/messages", json=_body, headers={"x-api-key": tok,
                                                "anthropic-version": "2023-06-01",
                                                "anthropic-beta": "beta-x"})
assert r.status_code == 200 and r.json()["usage"]["output_tokens"] == 800
assert _captured["headers"]["x-api-key"] == "sk-test-fake"       # vraie clé côté serveur
assert _captured["headers"]["anthropic-beta"] == "beta-x"        # en-tête beta relayé
assert _captured["payload"]["messages"][0]["content"] == "bonjour"
import sqlite3  # noqa: E402
_conn = sqlite3.connect(os.environ["PROXY_DB"]); _conn.row_factory = sqlite3.Row
_rows = _conn.execute("SELECT * FROM usage WHERE licensee = 'Cabinet Nico'").fetchall()
assert _rows and _rows[-1]["input_tokens"] == 1200 and _rows[-1]["output_tokens"] == 800
assert "content" not in _rows[-1].keys() and "prompt" not in _rows[-1].keys()
print("RELAIS + JOURNAL de conso (métadonnées seules) ok")

# 5. Garde-fous : modèle interdit, streaming refusé, max_tokens plafonné
r = c.post("/v1/messages", json={**_body, "model": "claude-opus-5"},
           headers={"x-api-key": tok})
assert r.status_code == 403 and "non autorisé" in r.json()["error"]["message"]
r = c.post("/v1/messages", json={**_body, "stream": True}, headers={"x-api-key": tok})
assert r.status_code == 400
c.post("/v1/messages", json={**_body, "max_tokens": 999999}, headers={"x-api-key": tok})
assert _captured["payload"]["max_tokens"] == keyproxy.MAX_TOKENS_LIMIT
print("GARDE-FOUS modèle/stream/max_tokens ok")

# 6. Quota journalier (limite de test = 5) : la 6e requête du licencié est 429.
for _ in range(6):
    last = c.post("/v1/messages", json=_body, headers={"x-api-key": tok})
assert last.status_code == 429 and "Quota" in last.json()["error"]["message"]
print("QUOTA journalier ok")

# 7. Rapport admin : agrégats par licencié + coût estimé ; jeton admin exigé.
r = c.get("/admin/usage")
assert r.status_code == 401
r = c.get("/admin/usage", headers={"Authorization": "Bearer admin-secret"})
assert r.status_code == 200
_usage = r.json()["usage"]
_nico = [u for u in _usage if u["licensee"] == "Cabinet Nico"]
assert _nico and _nico[0]["requests"] >= 5 and _nico[0]["tok_out"] >= 800
assert _nico[0]["cost_estimate_eur"] > 0
_month = time.strftime("%Y-%m")
r = c.get(f"/admin/usage?month={_month}", headers={"Authorization": "Bearer admin-secret"})
assert r.json()["month"] == _month and r.json()["usage"]
print("ADMIN /usage (agrégats + coût estimé + auth) ok")

print("=== TESTS KEYPROXY OK ===")
