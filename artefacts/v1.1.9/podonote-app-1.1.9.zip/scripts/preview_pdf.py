from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT/"docs"/"presentation"/"podonote_presentation.html").as_uri()
OUT = ROOT/"docs"/"presentation"
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width":794,"height":1123}, device_scale_factor=1)
    pg.goto(HTML, wait_until="networkidle"); pg.wait_for_timeout(1200)
    secs = pg.query_selector_all("section.page")
    for i, s in enumerate(secs, 1):
        s.screenshot(path=str(OUT/f"preview_{i}.png"))
    b.close()
print("ok", len(secs))
