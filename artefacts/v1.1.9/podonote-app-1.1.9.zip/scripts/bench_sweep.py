#!/usr/bin/env python3
"""Sweep de configurations du pipeline — mesurer chaque levier (vitesse ET qualité).

Lance `scripts/bench_pipeline.py` sur LE MÊME audio avec plusieurs réglages
(beam, paliers de température, alignement on/off, variante de modèle…), chacun
dans un PROCESS PROPRE (env isolé, modèle rechargé proprement), puis :
  - affiche un tableau comparatif (durée totale, RTF, durée par étape, nb mots) ;
  - écrit le transcript de chaque config (lecture côte à côte = juge de qualité) ;
  - calcule le WER de chaque config si une transcription de référence (--ref) est
    fournie, OU par rapport à la config `baseline` (--wer-vs-baseline) pour
    repérer toute dérive de texte d'un réglage « rapide » vs l'actuel.

But : décider les optimisations SUR CHIFFRES, sur la machine cible (PC de cabinet
sans GPU), SANS modifier le pipeline de production. Ce script ne touche aucun
fichier de l'app.

⚠️ À LANCER SUR LA MACHINE CIBLE.

Exemples :
  # 1) (si besoin) générer un échantillon ~10 min
  python scripts/bench_pipeline.py --make-sample data/sample_10min.wav --minutes 10

  # 2) comparer les configurations, et mesurer la dérive de texte vs l'actuel
  python scripts/bench_sweep.py data/sample_10min.wav --wer-vs-baseline

  # 3) WER « vérité terrain » sur un VRAI audio + sa transcription humaine
  python scripts/bench_sweep.py mon_audio.m4a --ref reference.txt

  # 4) ne tester qu'un sous-ensemble
  python scripts/bench_sweep.py audio.wav --only baseline,fast_combo
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BENCH = ROOT / "scripts" / "bench_pipeline.py"

# --------------------------------------------------------------------------- #
# Configurations comparées (overrides d'environnement appliqués au banc).
# Chacune part des défauts du .env et ne surcharge QUE les clés indiquées.
# --------------------------------------------------------------------------- #
CONFIGS: dict[str, dict[str, str]] = {
    "baseline":       {},                                          # réglages actuels
    "beam1":          {"WHISPER_BEAM_SIZE": "1"},                  # greedy
    "temps_min":      {"WHISPER_TEMPERATURES": "0.0,0.2"},         # moins de paliers
    "noalign":        {"WHISPER_ALIGN": "false"},                  # diarisation niveau segment
    "beam1_noalign":  {"WHISPER_BEAM_SIZE": "1", "WHISPER_ALIGN": "false"},
    "fast_combo":     {"WHISPER_BEAM_SIZE": "1", "WHISPER_ALIGN": "false",
                       "WHISPER_TEMPERATURES": "0.0,0.2"},
}
# Note : on NE teste PAS de variante de modèle — large-v3-turbo est figé
# (vitesse/qualité déjà validées). Tous les leviers ci-dessus restent sur turbo.

# Étapes du banc à extraire (correspondance par sous-chaîne du libellé).
STEP_KEYS = {
    "load":    "Chargement modèle ASR",
    "asr":     "Transcription (ASR)",
    "align":   "Alignement",
    "diarize": "Diarisation",
}


def _norm(s: str) -> list[str]:
    """Normalise pour le WER : minuscules, ponctuation retirée, liste de mots."""
    s = s.lower()
    s = re.sub(r"[^0-9a-zàâäéèêëîïôöùûüç' ]+", " ", s)
    return s.split()


def wer(reference: str, hypothesis: str) -> float:
    """Word Error Rate = distance d'édition (mots) / nb de mots de référence."""
    r, h = _norm(reference), _norm(hypothesis)
    if not r:
        return float("nan")
    prev = list(range(len(h) + 1))
    for i, rw in enumerate(r, 1):
        cur = [i] + [0] * len(h)
        for j, hw in enumerate(h, 1):
            cost = 0 if rw == hw else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[len(h)] / len(r)


def run_one(name: str, overrides: dict[str, str], audio: str, tdir: Path) -> dict | None:
    """Lance le banc pour une config dans un process isolé ; renvoie le rapport
    (enrichi du chemin transcript)."""
    env = os.environ.copy()
    env.update(overrides)
    report_path = Path(tempfile.gettempdir()) / f"podo_bench_{name}.json"
    transcript_path = tdir / f"transcript_{name}.txt"
    cmd = [sys.executable, str(BENCH), audio,
           "--report", str(report_path),
           "--dump-transcript", str(transcript_path)]
    print(f"\n=== [{name}] {overrides or 'défauts'} ===", flush=True)
    proc = subprocess.run(cmd, env=env)
    if proc.returncode != 0:
        print(f"  !! échec (code {proc.returncode}) — config ignorée.")
        return None
    try:
        data = json.loads(report_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"  !! rapport illisible : {exc}")
        return None
    finally:
        report_path.unlink(missing_ok=True)
    data["_name"] = name
    data["_transcript_path"] = str(transcript_path)
    data["_transcript"] = (transcript_path.read_text(encoding="utf-8")
                           if transcript_path.exists() else "")
    return data


def step_seconds(report: dict, key_substr: str) -> float:
    return sum(float(s.get("seconds") or 0)
               for s in report.get("steps", [])
               if key_substr.lower() in (s.get("name") or "").lower())


def main() -> None:
    p = argparse.ArgumentParser(description="Sweep de configs du pipeline PodoNote.")
    p.add_argument("audio", help="Audio à mesurer (le même pour toutes les configs).")
    p.add_argument("--ref", metavar="TXT",
                   help="Transcription de référence (.txt) → WER « vérité terrain ».")
    p.add_argument("--wer-vs-baseline", action="store_true",
                   help="À défaut de référence : WER de chaque config vs la config baseline "
                        "(mesure la DÉRIVE de texte d'un réglage rapide vs l'actuel).")
    p.add_argument("--only", metavar="N1,N2",
                   help="Sous-ensemble de configs (noms séparés par des virgules).")
    p.add_argument("--out-dir", metavar="DIR", default="data/sweep",
                   help="Dossier des transcripts produits. Défaut : data/sweep.")
    args = p.parse_args()

    if not BENCH.exists():
        sys.exit(f"Banc introuvable : {BENCH}")

    names = list(CONFIGS)
    if args.only:
        wanted = {n.strip() for n in args.only.split(",")}
        names = [n for n in names if n in wanted]
        if not names:
            sys.exit(f"Configs inconnues : {args.only}. Connues : {', '.join(CONFIGS)}")

    reference = Path(args.ref).read_text(encoding="utf-8") if args.ref else None
    tdir = (ROOT / args.out_dir) if not os.path.isabs(args.out_dir) else Path(args.out_dir)
    tdir.mkdir(parents=True, exist_ok=True)

    results = [r for name in names if (r := run_one(name, CONFIGS[name], args.audio, tdir))]
    if not results:
        sys.exit("Aucune mesure exploitable.")

    by_name = {r["_name"]: r for r in results}
    base = by_name.get("baseline")

    def wer_for(r: dict) -> float | None:
        if reference is not None:
            return wer(reference, r["_transcript"])
        if args.wer_vs_baseline and base and r["_name"] != "baseline":
            return wer(base["_transcript"], r["_transcript"])
        return None

    header = (f"{'config':<16}{'total(s)':>10}{'RTF':>7}{'load':>7}{'ASR':>7}"
              f"{'align':>7}{'diar':>7}{'mots':>7}{'WER%':>8}")
    line = "=" * len(header)
    print(f"\n{line}\nRÉCAPITULATIF (machine courante)\n{line}\n{header}\n{'-'*len(header)}")
    for r in results:
        w = wer_for(r)
        wcell = "—" if w is None else f"{w*100:.1f}"
        print(f"{r['_name']:<16}{(r.get('total_seconds') or 0):>10.0f}"
              f"{(r.get('rtf') or 0):>7.2f}"
              f"{step_seconds(r, STEP_KEYS['load']):>7.0f}"
              f"{step_seconds(r, STEP_KEYS['asr']):>7.0f}"
              f"{step_seconds(r, STEP_KEYS['align']):>7.0f}"
              f"{step_seconds(r, STEP_KEYS['diarize']):>7.0f}"
              f"{(r.get('words') or 0):>7}{wcell:>8}")

    if base and base.get("total_seconds"):
        print("-" * len(header))
        for r in results:
            t = r.get("total_seconds") or 0
            if t and r["_name"] != "baseline":
                print(f"  {r['_name']:<16} ×{base['total_seconds']/t:.2f} plus rapide")

    print(f"\nTranscripts écrits dans : {tdir}  (à relire côte à côte pour juger la qualité)")
    if reference is None and not args.wer_vs_baseline:
        print("Astuce : ajoute --wer-vs-baseline pour quantifier la DÉRIVE de texte "
              "d'un réglage rapide vs l'actuel, ou --ref pour un WER vérité terrain.")
    print("Rappel : ces chiffres ne valent que sur CETTE machine. Refais le sweep "
          "sur le PC cible avant de figer le .env.")


if __name__ == "__main__":
    main()
