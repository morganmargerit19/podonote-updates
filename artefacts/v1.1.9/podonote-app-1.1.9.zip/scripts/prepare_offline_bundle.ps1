﻿# =============================================================================
#  PodoNote — Préparation du bundle HORS-LIGNE (pour Morgan)
#
#  À lancer sur une machine où PodoNote fonctionne DÉJÀ (venv installé + modèles
#  téléchargés dans le cache). Remplit le dossier de distribution avec :
#    - model_cache/  : modèles HuggingFace + torch (Whisper, alignement FR, VAD)
#    - wheels/       : (option -WithWheels) tous les paquets pip, pour une install
#                      sans PyPI. ⚠️ pousse l'installeur > 4,2 Go -> Inno exige le
#                      « disk spanning » (plusieurs fichiers). OFF par défaut.
#
#  Pourquoi modèles seuls par défaut : le blocage observé chez le praticien était le
#  téléchargement HuggingFace (bridé), PAS pip/PyPI (qui passe). Embarquer les modèles
#  suffit et garde un installeur en FICHIER UNIQUE (~2 Go).
#
#  Appelé automatiquement par build_installer.ps1 (sauf -NoOffline).
#  Usage seul : .\scripts\prepare_offline_bundle.ps1  [-WithWheels]
# =============================================================================
param(
    [string]$Stage = "",
    [string]$PyExe = "",
    [switch]$WithWheels
)
# 'Continue' (et NON 'Stop') : pip écrit ses messages de progression sur stderr ;
# sous 'Stop', PowerShell 5.1 transforme cette sortie en erreur terminante même quand
# pip réussit (code 0). On se fie donc au code de sortie ($LASTEXITCODE), vérifié
# explicitement après chaque appel natif ci-dessous.
$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
if (-not $Stage) { $Stage = Join-Path $Root "dist\PodoNote" }
if (-not $PyExe) { $PyExe = Join-Path $Root ".venv\Scripts\python.exe" }

function Info($m) { Write-Host $m -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  OK  $m" -ForegroundColor Green }
function Die($m)  { Write-Host "  !!  $m" -ForegroundColor Red; exit 1 }

if (-not (Test-Path $PyExe)) { Die "Python introuvable ($PyExe). Lance d'abord install.ps1 sur cette machine." }
if (-not (Test-Path $Stage)) { Die "Dossier de distribution absent ($Stage). Lance make_dist.ps1 d'abord." }

# --- 1. (Option) Wheels pip --------------------------------------------------
$wheels = Join-Path $Stage "wheels"
if (Test-Path $wheels) { Remove-Item $wheels -Recurse -Force }   # nettoie un ancien bundle
if ($WithWheels) {
    New-Item -ItemType Directory -Force -Path $wheels | Out-Null
    Info "`n[wheels] Téléchargement des paquets pip (web)…"
    & $PyExe -m pip download -r (Join-Path $Root "requirements.txt") -d $wheels --timeout 120 --retries 5
    if ($LASTEXITCODE -ne 0) { Die "pip download (requirements.txt) a échoué." }
    Info "[wheels] Téléchargement des briques ML (torch CPU + faster-whisper + whisperx)…"
    # matplotlib : dépendance non déclarée de pyannote.audio, requise par la diarisation.
    & $PyExe -m pip download torch torchaudio faster-whisper whisperx matplotlib -d $wheels `
        --index-url https://download.pytorch.org/whl/cpu `
        --extra-index-url https://pypi.org/simple `
        --timeout 120 --retries 5
    if ($LASTEXITCODE -ne 0) { Die "pip download (ML) a échoué." }
    Ok "Wheels embarqués ($((Get-ChildItem $wheels -File).Count) paquets) — ⚠️ installeur > 4,2 Go : build avec disk spanning requis."
} else {
    Info "`n[wheels] NON embarqués (défaut) : l'install fera le pip EN LIGNE (PyPI/pytorch — non bridé)."
}

# --- 2. Modèles STRICTEMENT nécessaires (toujours embarqués) -----------------
# On NE copie PAS tout le cache (il contient d'autres modèles Whisper + pyannote =
# plusieurs Go inutiles). On embarque seulement : Whisper large-v3-turbo + VAD silero
# + modèle d'alignement FR (torchaudio VOXPOPULI). Pas de diarisation (aucun token HF).
$mc = Join-Path $Stage "model_cache"
if (Test-Path $mc) { Remove-Item $mc -Recurse -Force }

$hfSrc = Join-Path $env:USERPROFILE ".cache\huggingface\hub"
$thSrc = Join-Path $env:USERPROFILE ".cache\torch\hub"
if (-not (Test-Path $hfSrc)) {
    Die "Cache HuggingFace introuvable ($hfSrc). Lance l'app une fois (warmup_models) pour télécharger les modèles, puis relance ce script."
}
$hfDst = Join-Path $mc "huggingface\hub"
$thDst = Join-Path $mc "torch\hub"
New-Item -ItemType Directory -Force -Path $hfDst, $thDst, (Join-Path $thDst "checkpoints") | Out-Null

# 2a. Whisper large-v3-turbo (faster-whisper) — le modèle de transcription
Info "`n[modèles] Copie de Whisper (large-v3-turbo)…"
$turbo = Get-ChildItem $hfSrc -Directory -Filter "models--*faster-whisper-large-v3-turbo" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $turbo) { Die "Modèle Whisper large-v3-turbo absent du cache HF. Lance l'app une fois (warmup) puis relance." }
& robocopy $turbo.FullName (Join-Path $hfDst $turbo.Name) /E /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Die "robocopy Whisper a échoué (code $LASTEXITCODE)." }
$global:LASTEXITCODE = 0
Ok "Whisper large-v3-turbo copié"

# 2b. VAD silero (torch hub) — détection d'activité vocale
$silero = Join-Path $thSrc "snakers4_silero-vad_master"
if (Test-Path $silero) {
    & robocopy $silero (Join-Path $thDst "snakers4_silero-vad_master") /E /NFL /NDL /NJH /NJS /NP | Out-Null
    $global:LASTEXITCODE = 0
    Ok "VAD silero copié"
} else { Write-Host "  !!  VAD silero absent (sera retéléchargé au 1er usage, petit)." -ForegroundColor Yellow }

# 2c. Alignement FR (torchaudio VOXPOPULI) — fichier .pt dans checkpoints
$align = Get-ChildItem (Join-Path $thSrc "checkpoints") -File -Filter "*voxpopuli*fr*.pt" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($align) {
    Copy-Item $align.FullName (Join-Path $thDst "checkpoints\$($align.Name)") -Force
    Ok "Modèle d'alignement FR copié ($($align.Name))"
} else { Write-Host "  !!  Modèle d'alignement FR absent — alignement retéléchargé au 1er usage." -ForegroundColor Yellow }

$mcSizeGb = [math]::Round((Get-ChildItem $mc -Recurse -File | Measure-Object Length -Sum).Sum / 1GB, 2)
Write-Host "`n============================================" -ForegroundColor Green
Write-Host "  Bundle hors-ligne prêt (modèles)." -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host "  model_cache\ ≈ $mcSizeGb Go"
Write-Host "  -> plus aucun téléchargement HuggingFace chez le praticien."
exit 0
