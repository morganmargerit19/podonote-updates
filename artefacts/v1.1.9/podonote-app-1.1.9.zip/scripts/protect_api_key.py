#!/usr/bin/env python3
"""Migre la clé Anthropic du .env (texte brut) vers le coffre du système.

À lancer UNE FOIS sur un poste installé (ou depuis install.ps1 / install_mac.sh) :
  python scripts/protect_api_key.py

Effet :
  1. lit ANTHROPIC_API_KEY dans le .env ;
  2. la range dans le coffre du système (Windows : DPAPI data/anthropic.key.dpapi ;
     macOS : Trousseau/Keychain) ;
  3. efface la valeur du .env (la ligne reste, vide, pour mémoire).

L'app lit d'abord le coffre puis, à défaut, le .env (app/secretstore.py) : le
script est donc sans risque — en cas d'échec, rien n'est effacé.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    from app.config import settings
    from app.platform_compat import IS_MAC, IS_WINDOWS
    from app.secretstore import protect_api_key

    key = settings.anthropic_api_key.strip()
    if not key:
        print("Aucune clé ANTHROPIC_API_KEY dans le .env : rien à migrer.")
        return 0
    if not protect_api_key(key):
        if IS_WINDOWS or IS_MAC:
            print("ÉCHEC de la mise au coffre (DPAPI / Trousseau). Le .env est inchangé.")
        else:
            print("Aucun coffre natif sur cette plateforme (Linux/dev) : "
                  "la clé reste dans le .env. Rien à migrer.")
        return 1
    print("Clé rangée dans le coffre du système (Windows DPAPI / macOS Keychain).")

    env_path = ROOT / ".env"
    try:
        text = env_path.read_text(encoding="utf-8")
        new = re.sub(r"(?m)^(ANTHROPIC_API_KEY=).*$",
                     r"\1   # migrée vers data/anthropic.key.dpapi", text)
        if new != text:
            env_path.write_text(new, encoding="utf-8")
            print("Clé effacée du .env.")
    except OSError as exc:
        print(f"AVERTISSEMENT : .env non modifiable ({exc}) — la clé y reste en clair.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
