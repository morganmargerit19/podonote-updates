# Handoff : Diktae (ex-PodoNote) — refonte complète du logiciel de bureau

## Overview
Refonte visuelle **complète et validée** de Diktae (anciennement PodoNote), application de bureau
**locale** (pywebview/WebView2 sous Windows, portage Mac prévu) pour pédicures-podologues :
dictée de la consultation → transcription 100 % locale (WhisperX + diarisation) → fiche
structurée par LLM → relecture/validation par le praticien. Le produit couvre aussi :
documents patient (ordonnance, exercices, courrier, certificat/CR/feuille de soins),
traçabilité de stérilisation, préférence motrice, gradation du pied diabétique,
compta/facturation (module planifié), réglages multi-cabinets et état du système.

Cible d'implémentation : le repo **`morganmargerit19/podonote`**, branche
`claude/podonote-multi-agent-plan-2tdk0k` — FastAPI + Jinja2 (`templates/*.html`) +
`static/app.css`, sans framework JS. La refonte doit s'implémenter dans CET environnement
(templates Jinja + CSS custom properties), pas en React.

## About the Design Files
Les fichiers de ce dossier sont des **références de design en HTML** (prototypes navigables
créés dans Claude Design, format « Design Component ») — ils montrent l'apparence et le
comportement voulus, mais ne sont **pas du code de production à copier tel quel**.
La tâche : **recréer ces écrans dans les templates Jinja2 + `static/app.css` existants**,
en respectant les routes et les vocabulaires du backend (déjà alignés, voir plus bas).

- `PodoNote.dc.html` — la maquette complète (16 écrans, navigation interne par état).
  S'ouvre dans un navigateur avec `support.js` à côté. Le balisage utile est dans `<x-dc>`
  (templates avec `{{ }}` de type moustache et blocs `<sc-if>`/`<sc-for>`) ; les styles sont
  **inline** — chaque valeur (couleur, padding, radius) est donc lisible directement sur l'élément.
- `Nom & icône.dc.html` — planche d'explorations naming/logo. Seule l'**Exploration 6** compte
  (Diktae) ; le logo validé est **6a « l'onde qui s'écrit »**.
- `support.js` — runtime nécessaire pour ouvrir les `.dc.html`. Ne rien y chercher.

## Fidelity
**Haute fidélité (hifi).** Couleurs, typo, espacements, rayons, ombres et copies FR sont finaux
et ont fait l'objet de passes de lisibilité/harmonisation validées par le client. Recréer au
pixel près avec les moyens du codebase (CSS custom properties + classes). Les données
patients/chiffres sont des données de démonstration.

## Marque : Diktae (décision finale, 09/07/2026)
- **Nom : « Diktae »** — marque ombrelle multi-métier (« Diktae Podologie » aujourd'hui,
  Diktae Kiné / Diktae Ostéo demain). Le métier est un simple descripteur en eyebrow.
  Concept : *on dicte, la fiche s'écrit*. Ne JAMAIS réintroduire « PodoNote ».
- **Logo validé : 6a « l'onde qui s'écrit »** — 3 barres de voix verticales en encre
  (hauteurs ~12/22/16 sur 24, extrémités arrondies) suivies d'une **ligne horizontale laiton**
  (l'écrit). Monochrome : tout en encre. Petits formats : mêmes 4 formes, favicon dès 16 px.
  Dans l'app, le logo est dessiné en HTML/SVG inline (pas d'asset bitmap).
- Déclinaisons dans la maquette à reproduire :
  - Rail (sidebar) : logo + « Diktae » + eyebrow « PODOLOGIE · LOCAL ».
  - Écran de connexion/setup : logo + « Diktae » + descripteur « PODOLOGIE » (letter-spacing .26em).
  - Page d'envoi iPhone : logo + « Diktae ».
  - **Micro-marque sur les PDF patient** : dans le coin des en-têtes papier, mini-onde
    (3 barres encre + ligne laiton) + « DIKTAE » en 7.5px, letter-spacing .16em, couleur #9a8e80.
  - Identifiant machine : préfixe `DKT-…`. Dossier de sortie : `Documents\Diktae`.
- ⚠️ **Jamais « Volodalen » dans l'UI** (marque tierce dont on s'inspire) : dire
  « Bilan préférence motrice » / « Préf. motrice ». Le mot ne survit que dans les clés
  techniques internes (`volodalen` comme type en base est toléré).

## Design Tokens — charte « Cabinet laiton » (validée)
Polices **système uniquement** (`-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, …`),
zéro ressource externe. Mono : `ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas`.
Papier (PDF patient) : serif `'Palatino Linotype', Palatino, Georgia, 'Times New Roman'`.

### Mode clair
| Token | Valeur | Usage |
|---|---|---|
| --bg | #efeae0 | canvas crème |
| --surface | #fbf9f4 | cartes |
| --surface-2 | #f4f0e6 | panneaux encastrés |
| --surface-3 | #ebe5d7 | hover / pistes |
| --ink | #221d15 | texte principal (encre charbon chaud) |
| --ink-2 | #544c3d | texte secondaire |
| --ink-3 | #7d7362 | texte tertiaire / eyebrows |
| --line | #e4ddcd / --line-2 #d4cab5 | bordures |
| --accent | #ac7a52 | **laiton** = pédicurie/soins + accent global |
| --accent-2 | #875732 | texte accent (AA sur clair) |
| --accent-tint | #f2e6d8 / --accent-tint-2 #e8d5bf | fonds laiton doux |
| --btn / --on-btn | #262019 / #f4efe6 | bouton primaire charbon |
| --acier | #3e5c6b / --acier-2 #2e4754 | **podologie/bilans** (tints #e4ecef / #d3e0e6) |
| --volo | #6a53a6 / --volo-2 #54408a | **préférence motrice** (tints #eeeaf7 / #e2daf2) |
| --ok | #1f8a5b (tints #e3f1e8/#d2e8dc) | succès + bandeau synthèse (tl;dr) |
| --warn | #a06a12 (tints #f6eeda/#efe1c1) | à valider / IA / grade 2 |
| --risk | #b8432f (tint #f8e7e2) | risque / grade 3 / suppression |
| --info | #2f6f9f (tint #e7f0f6) | file d'attente / devis |
| --focus | rgba(172,122,82,.35) | anneaux focus |
| shadows | sm `0 1px 2px rgba(38,30,18,.06)` · md `0 1px 2px rgba(38,30,18,.05),0 10px 26px -14px rgba(38,30,18,.16)` · lg `0 24px 60px -28px rgba(38,30,18,.34)` |

### Mode sombre (`[data-theme="dark"]`)
--bg #151210 · --surface #1d1913 · --surface-2 #242019 · --surface-3 #2c261d ·
--ink #efe9dd · --ink-2 #b9af9c · --ink-3 #938873 · --line #332c20 · --line-2 #453b2a ·
--accent #c79775 · --accent-2 #d9b593 · tints #31271b/#403119 · --btn #efe9dd / --on-btn #221d15
(bouton primaire inversé) · --acier #8fb0c0 (tints #1a2830/#22343e) · --volo #a892e2
(tints #231f33/#2d2743) · --ok #4bbd86 (#122a1f/#183627) · --warn #d6a445 (#2b2210/#372c14) ·
--risk #e0836b (#2f1b14) · --info #6aa6d4 (#13242e) · --focus rgba(199,151,117,.4).

### Charte alternative « vert clinique » (tweak, non retenue mais conservée en option)
Accent #0e7a5f/#0a5e49 (sombre #33b48f), bouton primaire vert, acier #2f6f9f. Voir la méthode
`applyOverrides()` dans la logique du DC pour les 2 mappings complets clair+sombre.

### Échelles
- Radius : 6-9px contrôles · 10-12px boutons/inputs · 13-14px cartes-lignes · 16-18px grandes cartes · 999px pastilles/chips.
- Type : 31/700 h1 écran (-.025em) · 27/700 h1 fiche · 16/650 titres de section · 14.5 corps ·
  13-13.5 corps dense · 11/700 eyebrow UPPERCASE +.09em · 12.5 méta. Nombres : `font-variant-numeric:tabular-nums`.
- Espacement : padding écran `30px 34px 48px` (max-width 1000-1220px selon écran, centré) ·
  cartes 20px · gaps 12-20px.
- Chips filtres : hauteur 36px, radius 999px. Boutons : padding 10-11px vert., 13-16px horiz.

### Règles dures de lisibilité (validées après audit)
1. **Jamais de texte coloré sur fond teinté.** Les panneaux sémantiques = fond carte (--surface
   ou --surface-2) + **tranche gauche colorée 3px** + texte encre. (Synthèse = tranche --ok,
   Réflexions IA = tranche --warn, alertes = tranche --risk, bulle live = tranche --volo…)
2. **Pastilles terrain/statut** (Diabète, AOMI, À relire, grade 2…) : fond --surface + bordure
   --line + **point de couleur 6px** + texte --ink-2 (ou couleur pour le texte de statut court).
3. Couleur pleine réservée aux ÉTATS : sélection (accent), statuts (Validée --ok, À valider
   --warn, En file --info, Non conforme --risk, Payée --ok, Devis --info), badges de grade.
4. Boutons : primaire charbon --btn/--on-btn (une action principale max par vue) ; tout le
   reste secondaire blanc à bordure ; danger = texte --risk sur blanc, hover tint.
5. Aperçus papier : fond #ffffff FIXE (ne suit pas le thème), texte #231f18, serif,
   `aspect-ratio:210/297` (vrai A4), en-têtes `white-space:nowrap`, une donnée par ligne
   (N° AM / RPPS / Tél. chacun sa ligne).

## Structure de l'app (shell)
- **Rail gauche 242px fixe** : logo Diktae + eyebrow « PODOLOGIE · LOCAL » ; nav principale
  (Patients [badge compteur à-relire, fond --accent-2, texte --surface], Consultation,
  Documents, Compta, Stérilisation) ; en bas : Réglages, État du système, [Design system] ;
  carte « 100 % local · Hors-ligne · RGPD » ; profil praticien + toggle thème clair/sombre.
  Item actif : fond --accent-tint, texte --accent-2, barre gauche 3px --accent.
- Contenu scrollable à droite, une « page » par route.

## Screens — 16 écrans, mapping vers les routes `app/main.py`
Chaque écran de la maquette (accessible via la nav du prototype) ↔ route(s) du backend :

1. **Patients (accueil)** ↔ `GET /` — sélecteur cabinet, 3 cartes (À relire & valider /
   En file d'attente + bouton « Lancer les transcriptions » ↔ `POST /queue/process` /
   compteur annuel discret en pointillé), chips filtres 36px (Tous · À valider · Terrain à
   risque · À recontacter), select étiquette, tri A–Z/Récents, recherche, liste patients
   (avatar initiales — laiton pour femmes, acier pour hommes —, âge, méta consultations,
   pastilles terrain), select de suivi recontact par patient en mode « À recontacter ».
   Modal **nouveau patient** ↔ `POST /patients/new` (prénom/nom requis, date naissance, sexe,
   cabinet, 7 flags terrain : diabète, AOMI, neuropathie, anticoagulant, immunodépression,
   allergie, grossesse ; notes).
2. **Dossier patient** ↔ `GET /patients/{id}` — en-tête (avatar 60px, nom 29px, ligne né(e) le/
   âge/cabinet), barre d'actions (Ordonnance · Exercices · Courrier · Fiche de suivi ·
   Modifier · Nouvelle consultation), encart risque (tranche --risk) si terrain, carte
   « En un coup d'œil » (pastilles + notes), cartes consultations/prochain contrôle,
   journal « Ordonnances générées », **frise chronologique split** : soins (laiton) à gauche ⟷
   bilans à droite (podologie acier, préf. motrice violet), colonne centrale 128px avec dates
   mono en pilule + nœuds colorés sur ligne verticale, badge de type sur CHAQUE carte
   (SOIN / PODOLOGIE / PRÉF. MOTRICE), statuts (Validée/À valider/En file), barre douleur n/10,
   bouton « consultations plus anciennes », bouton Comparer si ≥2 bilans validés, bloc RGPD
   (Export PDF ↔ `GET /patients/{id}/export.pdf`, Export JSON ↔ `…/export.json`,
   Supprimer ↔ `POST /patients/{id}/delete`).
3. **Bilan podologique (vue)** ↔ `GET /consultations/{id}` (type bilan) — bandeau synthèse
   (tranche --ok), sections numérotées 1-5 : Anamnèse (motif, histoire, habitudes 3 colonnes),
   Examen en décharge (localisation + slider intensité), Statique & dynamique (tableau
   Gauche/Droite, droite en tint laiton), Conclusion & CAT (liste cochée --ok), Plan semelles
   (chips acier + note) ; colonne droite : **Réflexions IA** (carte tranche --warn, items
   contexte/action, boutons Retenir [primaire]/Écarter [secondaire] ↔
   `POST /consultations/{id}/suggestions/{i}/keep|drop`), Schéma du pied (2 pieds SVG,
   marqueurs douleur/lésion/soin), modal « PDF de la fiche » à sections cochables ↔
   `GET /consultations/{id}/report.pdf`. Actions : Modifier ↔ `GET …/edit`, Valider ↔
   `POST …/validate`, Supprimer ↔ `POST …/delete`.
4. **Fiche de soin (vue + édition)** ↔ mêmes routes (type soin) + `consultation_edit_soin.html` —
   vue : actes numérotés en résumé composé (ex. « Soin d'ongle incarné (onychocryptose) —
   Pied droit, Hallux (1), Sillon latéral (externe) »), État des pieds (cutané/unguéal),
   Conseils & suivi, **Photos avant/après** (vignettes badge Avant --info / Après --ok + note +
   supprimer ; zone d'ajout type+note+fichier ↔ `POST /consultations/{id}/photos/add|delete`),
   carte **Gradation pied diabétique** (badge grade 0-3 : 0/1 vert, 2 ambre, 3 rouge ;
   séances remboursables 5 (gr.2) / 6 (gr.3) / 8 (gr.3+plaie) ; 4 critères avec coche/croix/
   pointillé), Réflexions IA. Édition : lignes d'actes dynamiques 7 colonnes
   (type·côté·orteil·sillon·zone·note·suppr) + « Ajouter un acte » ; gradation en 6 selects
   tri-état (Oui/Non/Non renseigné) avec **grade recalculé en direct** ; garde-fou
   (tranche --risk) « complétez la gradation avant de valider » si diabétique + neuropathie
   non renseignée ; case « fiche relue et validée ».
   Vocabulaire actes (copier depuis `app/soin.py`, EXACT) : Retrait d'hyperkératose · Retrait
   de cor / œil-de-perdrix · Retrait de durillon · Coupe des ongles · Fraisage / ponçage
   unguéal · Soin d'ongle incarné (onychocryptose) · Traitement de verrue plantaire · Pose /
   réglage d'orthonyxie · Orthoplastie (orthèse d'orteil) · Détersion de plaie · Pansement /
   protection. Côtés : Pied gauche/Pied droit/Bilatéral. Orteils : Hallux (1), 2ᵉ-5ᵉ orteil.
   Sillons : médial (interne)/latéral (externe).
5. **Bilan préférence motrice (vue + édition)** ↔ `consultation_edit_volodalen.html` /
   `app/volodalen.py` — vue : synthèse (mobilité classique Terrien/Aérien, mobilité excessive
   Hyper-mobile/Rigide, chaîne de respiration, assoc/dissoc + tendance calculée, épaule
   motrice, jambe d'extension), détail testing, anamnèse sportive, **cadran du mouvement 2×2**
   (cellules Haut gauche/Haut droite/Bas gauche/Bas droite ; **points 1 et 4 auto** :
   terrien+gauche→1 bas-G/4 haut-D ; terrien+droite→1 bas-D/4 haut-G ; aérien+gauche→1 haut-G/
   4 bas-G ; aérien+droite→1 haut-D/4 bas-D ; pt1 = disque --volo plein, pt4 = anneau --volo ;
   points 2/3 saisis par le praticien en texte), **exercices prioritaires 3 max numérotés**
   groupés Mobilité (La bulle, La vague, La croix, Le gainage du pied, L'arc-en-ciel) /
   Terrien (Mobilité, Gainage en flexion, Poussée verticale, Poussée horizontale) /
   Aérien (Étirements, Gainage en extension, Rebonds verticaux, Rebonds horizontaux).
   Édition : selects testing + **bulle latérale sticky « En un coup d'œil »** (tranche --volo)
   qui recalcule à chaque coche : excès, préférence, chaîne, jambe, latéralisation, cadran
   pt1/pt4, tendance assoc/dissoc (terrien+cuisse→Associé 80 % · terrien+pieds→Dissocié 95 % ·
   aérien+cuisse→Dissocié 95 % · aérien+pieds→Associé 80 %), compteur exos n/3 (chips au-delà
   de 3 désactivées en pointillé).
6. **Nouvelle consultation** ↔ `GET/POST /consultations/new` — sélecteur patient (+ création
   express sans quitter la page ↔ `POST /patients/quick`), **sélecteur type de fiche 3 cartes**
   (Bilan podologique [bordure acier] / Fiche de soin [laiton] / Préf. motrice [violet] —
   sélection = fond blanc + bordure 1.5px couleur + coche ronde), case consentement (tranche
   --warn), gros bouton micro rond 104px avec halo animé, barre niveau micro ; états :
   recording (timer mono 34px, onde animée, transcription live, Pause/Terminer) → paused →
   review (lecteur audio + Recommencer / **Ajouter à la file d'attente** ↔ `POST /queue/add` /
   Lancer le traitement) → queuedOk | processing (stepper 4 étapes : Préparation →
   Transcription → Identification des locuteurs → Fiche structurée) → done (Relire la fiche).
   Panneaux latéraux : conseils micro, Importer un fichier audio ↔ `POST /consultations/import`,
   Créer une fiche sans audio ↔ `POST /consultations/blank`.
7. **Consultation en cours / file / erreur** ↔ `GET /consultations/{id}` (statuts queued/
   processing/error) — 3 états : En file (icône horloge --info + « Lancer la transcription »),
   Traitement (barre de progression + stepper), Erreur (message --risk + Relancer ↔
   `POST /consultations/{id}/retry` + « Vérifier l'état du système »). Le switch de démo en
   haut à droite du prototype n'est PAS à implémenter.
8. **Comparer deux visites** ↔ `GET /patients/{id}/compare?a=&b=` — 2 selects Avant/Après
   (bilans validés), tableau 7 rubriques : Synthèse, Souci actuel, Douleur, Conclusion,
   Suivi & recommandations, Plan semelles, Évolution notée (colonne Avant --ink-2, Après --ink).
9. **Stérilisation** ↔ routes `/sterilisation…` — 3 KPI (cycles du mois, sachets disponibles,
   conformité 90j), onglets : **Registre** (liste cycles : réf mono type `C-2606 · A`, pastille
   conforme/non conforme, méta date·heure·programme·temp·durée, n sachets ; panneau détail
   sticky : test Helix, intégrateur, opérateur, alerte tranche --risk si non conforme,
   sachets utilisés → liens patients) · **Rattacher un sachet** (cycle d'origine → n° sachet →
   contenu → patient → consultation, panneau latéral « Chaîne de traçabilité » tranche laiton) ·
   **Recherche inverse** (recherche par n° de cycle/lot → patients exposés, badge
   « À recontacter » si non conforme).
10. **Documents** ↔ `/documents…` — 4 onglets :
    - **Ordonnance** ↔ `ordonnance.html` / `app/prescription.py` : patient + toggle ALD
      (En rapport/Sans rapport), carte **Suggestions cliniques** (tranche laiton) : select
      diagnostic → « Proposer l'ordo » [primaire] (onychomycose→vernis antifongique ;
      mycose cutanée→antifongique local+antiseptique ; verrue→verrucide ; hyperkératose→
      kératolytique ; ongle incarné→antiseptique+AINS local+compresses+sparadrap ;
      plaie diabétique→antiseptique+hydrocolloïde+alginate) ; select topique/pansement →
      « Ajouter » ; bouton « 5 séances de prévention [grade 2] » (pastille grade sur fond
      blanc) ; lignes éditables inline (input transparent, hover surface-2, suppr au survol)
      + « Ajouter une ligne » ; **aperçu papier A4 live** à droite (sticky) ; Générer le PDF ↔
      `POST /documents/ordonnance.pdf` (journalisée dans le dossier). Libellés des lignes :
      copier EXACTEMENT depuis `app/prescription.py`.
    - **Fiche d'exercices** ↔ `exercices.html` / `app/exercices.py` : banque de 10 exercices
      cochables groupés par catégorie (Étirements ×3, Mobilité ×1, Renforcement ×4,
      Proprioception ×1, Auto-massage ×1 — titres+descriptions EXACTS du module), Tout cocher/
      décocher, compteur latéral sticky + « Générer le PDF » (désactivé si 0).
    - **Courrier** ↔ `courrier.html` : patient, select correspondant (annuaire des Réglages),
      message libre, consultations cochables (date+type+tl;dr), ordonnances cochables (chips),
      photos cochables (vignettes), aperçu papier A4 live avec pièces jointes listées (puce
      losange laiton), « Générer le courrier (PDF) ». Mention : envoi e-mail = PDF joint à la
      main (pas d'envoi direct, décision RGPD).
    - **Certificat & CR & feuille de soins** : 3 types sélectionnables à gauche, aperçu A4 à
      droite (certificat de soins / compte-rendu au médecin traitant / feuille de soins avec
      tableau actes+honoraires).
11. **Compta (module planifié — pas encore de routes)** — badge « Module planifié » violet.
    3 onglets : **Tableau de bord** (3 KPI : encaissé --ok, en attente --warn, devis ; barres
    mensuelles CA laiton [mois courant en tint], toggle Par mois/Par année ; répartition par
    type d'acte en barres de progression ; carte « Télétransmission — À venir » en pointillé,
    type Anael, sans blocage) · **Factures & devis** (chips filtres Toutes/Payées/En attente/
    Devis ; tableau N° mono [F-2026-041 / D-2026-012], date, patient, montant, statut) ·
    **Nouvelle facture/devis** (toggle type, patient, numéro auto, lignes depuis le **catalogue
    d'actes tarifés** [Soin de pédicurie 35 € · Bilan podologique 60 € · Orthèses plantaires
    sur mesure 120 € · Bilan de gradation pied diabétique 20 € · Séance de prévention pied
    diabétique (POD) 30 € · Orthoplastie 45 € · Orthonyxie 40 €], total auto, aperçu papier A4
    avec mention TVA non applicable art. 261-4-1° CGI, Générer le PDF).
12. **Réglages** ↔ `GET/POST /reglages` — profil praticien (nom affiché, titre, tél, N° AM,
    RPPS, lignes d'ordonnance par défaut, signature image remplaçable) avec **aperçu en-tête
    papier live** (sticky, se met à jour à la frappe) ; Cabinets multi-sites (cartes + ajouter/
    éditer/supprimer — l'en-tête du cabinet remplace le profil sur les ordonnances de ses
    patients) ; **Correspondants** (annuaire : nom + type Médecin/Kinésithérapeute/Chirurgien/
    Pédicure-podologue/Ostéopathe/Autre + email/tél, éditer/supprimer, dialog d'ajout calqué
    sur Cabinets) ; **Catalogue d'actes tarifés** (badge Compta, libellé+prix éditables) ;
    Sauvegarde (.zip vers Documents\Diktae) / Restauration ; carte Licence → écran licence.
13. **État du système** ↔ `GET /system` — 3 lignes santé (Transcription WhisperX
    large-v3-turbo / Modèle d'analyse LLM [pseudonymisé, basculable Ollama] / Diarisation)
    avec badge OK ; Mises à jour OTA (v1.0.21, signées, « Vérifier maintenant ») ; Licence
    (active, jours restants) ; **Envoi depuis l'iPhone** : QR code (placeholder hachuré) +
    URL LAN `http://…:8765/upload` + lien vers la page d'envoi ; Configuration active
    (4 tuiles mono : modèle Whisper, backend LLM, suppression audio, modèles Ollama).
14. **Page d'envoi iPhone** ↔ `GET/POST /upload` (servie sur le LAN, protégée PIN) — étape 1
    code PIN (input central letter-spacing) → étape 2 formulaire : patient existant OU
    prénom/nom nouveau, lieu (Au cabinet/À domicile), consentement, fichier audio, case
    « Mettre en file d'attente », Envoyer. Mention « le fichier reste sur le réseau local ».
15. **Auth** ↔ `GET/POST /login`, `/setup`, `/license` — carte centrée 520px, logo Diktae +
    descripteur PODOLOGIE : Connexion (mot de passe + « Toutes les données restent sur cet
    ordinateur ») · Première config (mot de passe ×2 + PIN iPhone 6-8 chiffres + note
    « accès hachés, non récupérables ») · Licence (statut actif + jours, textarea clé,
    Activer, identifiant machine `DKT-XXXX-XXXX-XXXX`, contact Studio Margerit).
16. **Design system** (écran interne de référence, optionnel en prod) — palette, typo,
    boutons, badges de type de fiche, badges de grade 0-3, statuts, pastilles terrain,
    contrôles, mini-frise split, mini-cadran.

## Interactions & Behavior
- Navigation : sidebar → écrans ; fil d'Ariane retour en haut de chaque sous-écran
  (chevron gauche + nom parent).
- Transitions : apparition d'écran `fadeUp .24s ease` (translateY 7px→0) ; hover cartes
  cliquables : `box-shadow` élevée + `translateY(-1px)`, .16s ; boutons primaires hover
  `brightness(1.15)`, active `translateY(1px)`.
- Enregistrement : timer 1s, onde en `scaleY` animée (barres décalées), halo `box-shadow`
  pulsé sur le bouton micro ; stepper de traitement avance étape par étape.
- Calculs live (à implémenter en JS léger côté template) : grade diabétique (règles :
  non diabétique→N/A ; antécédent d'ulcération→grade 3 [séances 8 si plaie en cours, sinon 6] ;
  neuropathie + (AOMI ou déformation)→grade 2 [5 séances] ; neuropathie seule→grade 1 ;
  pas de neuropathie→grade 0 ; neuropathie non renseignée→garde-fou), cadran préf. motrice,
  tendance assoc/dissoc, total facture, aperçus papier (ordonnance/courrier/en-tête réglages)
  mis à jour à la saisie.
- Toggle thème : bouton lune/soleil dans le rail, attribut `data-theme` sur la racine,
  préférence persistée.
- Fenêtre native : les PDF/exports = boutons « Générer le PDF » (fichier écrit dans
  Documents\Diktae) — pas de logique de téléchargement navigateur.

## State Management
Côté backend existant (FastAPI + SQLite) : patients, consultations (types bilan/soin/
volodalen ; statuts queued/processing/error/généré/validé), file d'attente, photos, cycles de
stérilisation + sachets, correspondants, cabinets, profil, licence. Nouveau à créer pour la
compta : factures/devis (numérotation auto F-AAAA-NNN / D-AAAA-NNN), catalogue d'actes.
États UI locaux (JS) : onglets, filtres/recherche/tri, sélections cochables, calculs live,
état d'enregistrement.

## Assets
Aucun asset externe. Logo = HTML/SVG inline (4 formes). Icônes = sprite SVG `<symbol>` inline
(~40 icônes stroke 1.7-1.9, linecap round — réutiliser le bloc `<svg><defs>` en tête de
`PodoNote.dc.html`). Photos/QR = placeholders hachurés (`repeating-linear-gradient`) avec
étiquette mono — à remplacer par les vraies données.

## Files
- `PodoNote.dc.html` — maquette complète 16 écrans (référence principale ; malgré son nom de
  fichier, la marque à implémenter est **Diktae**).
- `Nom & icône.dc.html` — planche identité ; Exploration 6, logo 6a validé.
- `support.js` — runtime pour ouvrir les .dc.html dans un navigateur.
- Dans le repo cible : `templates/*.html`, `static/app.css`, `app/main.py` (routes),
  `app/soin.py` / `app/volodalen.py` / `app/prescription.py` / `app/exercices.py` /
  `app/clinical.py` (vocabulaires — source de vérité des libellés).
