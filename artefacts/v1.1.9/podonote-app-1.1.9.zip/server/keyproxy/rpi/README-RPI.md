# Keyproxy sur Raspberry Pi 4 — flash & go (~30 min, une seule commande sur le Pi)

Coût de fonctionnement : **~0 €** (2-3 €/an d'électricité). Le Pi relaie du
JSON, rien d'autre — il tiendra des dizaines de praticiens. Migration VPS
documentée en bas de page pour plus tard.

## 0. Ce qu'il faut préparer (sur le PC, 10 min)

1. **La vraie clé Anthropic** (console.anthropic.com) — elle ne vivra QUE sur le Pi.
2. **Un jeton admin** : `openssl rand -hex 24` (ou n'importe quelle longue chaîne).
3. **Un tunnel Cloudflare** (gratuit, HTTPS géré, AUCUN port à ouvrir sur la box) :
   - Le domaine `studio-margerit.fr` doit être géré par Cloudflare (offre Free —
     on ne change que les serveurs DNS chez le registrar, le site Vercel n'est
     pas impacté : ses enregistrements sont repris tels quels).
   - [dash.cloudflare.com](https://one.dash.cloudflare.com) → **Zero Trust →
     Networks → Tunnels → Create a tunnel** → type *Cloudflared* → nom
     `diktae-api` → **copier le TOKEN** (longue chaîne `eyJ…`).
   - Dans l'onglet **Public hostname** du tunnel : `api.studio-margerit.fr` →
     Service **HTTP** → URL **`keyproxy:8787`**.

## 1. Flasher la carte SD (Raspberry Pi Imager, 5 min)

- Modèle : Raspberry Pi 4 · OS : **Raspberry Pi OS Lite (64-bit)** · votre carte SD.
- Dans les réglages (⚙️ « Modifier réglages ») :
  - Nom d'hôte : `diktae-proxy`
  - **Activer SSH** (mot de passe) · utilisateur `morgan` + mot de passe
  - Wi-Fi si pas d'Ethernet (Ethernet recommandé pour un serveur)
- Écrire la carte.

## 2. Déposer le keyproxy sur la carte (encore sur le PC, 2 min)

La partition **`bootfs`** de la carte est visible dans l'Explorateur Windows :

1. Copier le dossier **`server/keyproxy/`** du repo **en entier** sur `bootfs`
   (→ `bootfs/keyproxy/`).
2. Dans `bootfs/keyproxy/`, copier `.env.example` → **`.env`** et remplir :
   ```
   ANTHROPIC_API_KEY=sk-ant-…
   PROXY_ADMIN_TOKEN=…            # le jeton admin de l'étape 0
   TUNNEL_TOKEN=eyJ…              # le token du tunnel Cloudflare
   ```
3. Éjecter la carte, la mettre dans le Pi, brancher (Ethernet + alim).

## 3. La commande unique (sur le Pi, ~10 min)

```bash
ssh morgan@diktae-proxy.local
sudo bash /boot/firmware/keyproxy/rpi/provision.sh
```

Le script fait tout : Docker, construction de l'image (arm64), démarrage du
proxy + du tunnel, services au boot, déplacement des secrets hors de la
partition boot, vérification `healthz`. Relançable sans risque.

## 4. Vérifier puis brancher les postes

```bash
curl https://api.studio-margerit.fr/healthz
# {"ok": true, "upstream": "https://api.anthropic.com", "key_configured": true}
```

Sur chaque poste Diktae (dont celui de Nico), dans le `.env` :

```
LLM_BACKEND=sonnet
LLM_PROXY_URL=https://api.studio-margerit.fr
```

`ANTHROPIC_API_KEY` peut être retirée des postes : la licence sert d'accès.

Conso par licencié :
```bash
curl -H "Authorization: Bearer <PROXY_ADMIN_TOKEN>" \
  "https://api.studio-margerit.fr/admin/usage?month=2026-08"
```

## Bon à savoir

- **Si le Pi ou la box tombe** : la génération de fiche échoue le temps de la
  panne ; la transcription locale continue, le transcript est conservé, le
  bouton « Réessayer » relance la fiche sans refaire l'ASR. Rien n'est perdu.
- **Mise à jour du proxy** : recopier `app.py` dans `/opt/diktae-keyproxy` puis
  `cd /opt/diktae-keyproxy && docker compose -f rpi/docker-compose.yml --project-directory . up -d --build`.
- **Logs** : `docker compose -f /opt/diktae-keyproxy/rpi/docker-compose.yml logs -f`.

## Migration vers un VPS (plus tard, ~20 min)

Mêmes fichiers, même compose — seule la base de conso est à emporter :

```bash
# Sur le Pi : exporter la base du volume
docker run --rm -v diktae-keyproxy_keyproxy-data:/data -v /tmp:/out alpine \
  cp /data/keyproxy.db /out/keyproxy.db
scp /tmp/keyproxy.db morgan@VPS:/tmp/

# Sur le VPS : copier /opt/diktae-keyproxy (avec son .env), réimporter la base,
# lancer le même compose, puis déplacer le TUNNEL (ou pointer le DNS) — les
# postes clients ne changent RIEN (même URL).
```
