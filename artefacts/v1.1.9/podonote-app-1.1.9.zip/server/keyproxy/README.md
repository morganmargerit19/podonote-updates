# Proxy de clés API — Studio Margerit

**But** : les postes Diktae des clients n'ont **aucune clé Anthropic**. Ils
appellent ce proxy avec leur **clé de licence** (jeton signé Ed25519 déjà en
place) ; le proxy vérifie la licence, relaie vers l'API Anthropic avec la vraie
clé (qui ne vit que sur ce serveur), et **compte la consommation par licencié**
(tokens, coût estimé) — jamais le contenu des messages.

```
Poste Diktae ──(clé de LICENCE en x-api-key)──▶  keyproxy  ──(vraie clé)──▶ api.anthropic.com
                                                   │
                                                   └─ keyproxy.db (conso par licencié)
```

## Déploiement rapide (VPS avec Docker — ~15 min)

Sur n'importe quel petit VPS (Scaleway/OVH/Hetzner, 1 vCPU suffit — le proxy ne
fait que relayer du JSON) :

```bash
git clone <repo> && cd podonote/server/keyproxy
cp .env.example .env          # puis renseigner ANTHROPIC_API_KEY + PROXY_ADMIN_TOKEN
docker build -t diktae-keyproxy .
docker run -d --name keyproxy --restart unless-stopped \
  --env-file .env -p 127.0.0.1:8787:8787 -v keyproxy-data:/data diktae-keyproxy
```

Mettre un **reverse-proxy TLS** devant (Caddy, le plus simple — certificat
automatique) :

```
# /etc/caddy/Caddyfile
api.studio-margerit.fr {
    reverse_proxy 127.0.0.1:8787
}
```

> ⚠️ **HTTPS obligatoire** en production : le texte (pseudonymisé) des
> consultations transite par ce proxy.

Sans Docker : `pip install -r requirements.txt` puis
`uvicorn app:app --host 127.0.0.1 --port 8787` derrière Caddy, avec les
variables du `.env` exportées (systemd `EnvironmentFile=` par exemple).

## Variante à ~0 € : Raspberry Pi 4 + Cloudflare Tunnel — kit « flash & go »

Le proxy ne fait que relayer du JSON (aucun ML) : un **RPi4 est largement
suffisant** pour des dizaines de praticiens. Coût : l'électricité (~2-3 €/an),
HTTPS via **Cloudflare Tunnel** gratuit (aucun port à ouvrir sur la box, pas
d'IP fixe). Tout est prêt dans **`rpi/`** : flash avec Raspberry Pi Imager,
copie du dossier sur la carte, puis **UNE commande** sur le Pi
(`sudo bash /boot/firmware/keyproxy/rpi/provision.sh`).
→ Pas-à-pas complet : **`rpi/README-RPI.md`** (migration VPS incluse — mêmes
fichiers, on copie `keyproxy.db`, les postes clients ne changent rien).

Limite à connaître (acceptable pour démarrer) : si le Pi ou la box tombe, la
**génération de fiche** échoue chez les clients le temps de la panne — la
transcription locale continue, le transcript est conservé et « Réessayer »
relance la fiche sans refaire l'ASR. Rien n'est perdu.

## Vérifier

```bash
curl https://api.studio-margerit.fr/healthz
# {"ok": true, "upstream": "https://api.anthropic.com", "key_configured": true}
```

## Côté poste client (Diktae)

Une seule ligne dans le `.env` du poste (et une licence activée — c'est elle
qui sert d'accès) :

```
LLM_BACKEND=sonnet
LLM_PROXY_URL=https://api.studio-margerit.fr
```

`ANTHROPIC_API_KEY` peut rester vide : plus aucune clé sur les postes.
Pour **Nico** : pousser cette ligne dans son `.env` (ou via l'installeur) et
retirer l'ancienne clé du coffre — sa licence existante suffit.

## Suivre la consommation

```bash
curl -H "Authorization: Bearer $PROXY_ADMIN_TOKEN" \
  "https://api.studio-margerit.fr/admin/usage?month=2026-08"
```

Réponse : par licencié et par modèle — nombre de requêtes (`requests`, `ok`),
tokens entrée/sortie, tokens servis du cache, `cost_estimate_eur` (indicatif —
la facture Anthropic fait foi), dernière activité. C'est la base du comptage
des paliers d'abonnement (cf. `docs/TARIFS.md`).

## Garde-fous intégrés

- **Licence obligatoire** : signature Ed25519 vérifiée contre la clé publique
  Diktae ; expiration avec grâce de 7 j (aucune grâce pour les plans `demo`).
- **Modèles bornés** (`PROXY_ALLOWED_MODELS`, défaut sonnet/haiku) et
  `max_tokens` plafonné (`PROXY_MAX_TOKENS`) : un jeton volé ne peut pas brûler
  du budget sur Opus.
- **Quota journalier** par licencié (`PROXY_DAILY_REQ_LIMIT`, défaut 250).
- **Aucun contenu stocké** : seuls des métadonnées (tokens, modèle, statut,
  durée) sont journalisées.

## Tests

`python scripts/test_keyproxy.py` (à la racine du repo) : suite autonome —
clés Ed25519 éphémères + API Anthropic simulée, aucun réseau ni vraie clé.
