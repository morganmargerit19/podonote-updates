"""Proxy de clés API Studio Margerit — la clé Anthropic ne quitte JAMAIS ce serveur.

Problème résolu : distribuer Diktae à plusieurs podologues sans distribuer de
clé Anthropic (ni la clé perso de Morgan). Le poste client s'authentifie avec
sa CLÉ DE LICENCE Diktae (jeton Ed25519 déjà signé par Studio Margerit) passée
comme clé d'API (`x-api-key`) ; le proxy vérifie la signature et l'expiration,
relaie l'appel vers l'API Anthropic avec la vraie clé (variable d'env du
serveur), et JOURNALISE la consommation par licencié (tokens, modèle, coût
estimé) — jamais le contenu des messages (texte de santé pseudonymisé : il
transite, il n'est pas stocké).

Côté app : LLM_PROXY_URL=https://… dans le .env → `app/pipeline/llm.py` utilise
`anthropic.Anthropic(api_key=<jeton de licence>, base_url=<proxy>)`. Aucune
autre modification : le proxy parle le protocole de l'API Messages.

Lancement :  uvicorn app:app --host 0.0.0.0 --port 8787   (cf. README.md)
Variables :  ANTHROPIC_API_KEY (obligatoire), PROXY_ADMIN_TOKEN (obligatoire
pour /admin/usage), et les PROXY_* optionnelles ci-dessous.
"""
from __future__ import annotations

import base64
import json
import os
import sqlite3
import time
from typing import Any, Optional

import httpx
from fastapi import FastAPI, Header, Request, Response
from fastapi.responses import JSONResponse

# --------------------------------------------------------------------------- #
# Configuration (env)
# --------------------------------------------------------------------------- #
# Clé PUBLIQUE des licences Diktae (même valeur que app/license.py). Surchargeable
# pour les tests ou une rotation de clé.
PUBLIC_KEY_B64 = os.environ.get(
    "PROXY_LICENSE_PUBLIC_KEY", "4BtFnPdW+EjMlukFYI+xUa4oPKBurvDV566V0sWsB7g=")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ADMIN_TOKEN = os.environ.get("PROXY_ADMIN_TOKEN", "")
UPSTREAM = os.environ.get("PROXY_UPSTREAM", "https://api.anthropic.com").rstrip("/")
DB_PATH = os.environ.get("PROXY_DB", "keyproxy.db")
# Modèles autorisés (préfixes, séparés par des virgules) : par défaut les tiers
# que Diktae utilise. Empêche un jeton volé de brûler du budget sur Opus.
ALLOWED_MODEL_PREFIXES = [p.strip() for p in os.environ.get(
    "PROXY_ALLOWED_MODELS", "claude-sonnet,claude-haiku").split(",") if p.strip()]
MAX_TOKENS_LIMIT = int(os.environ.get("PROXY_MAX_TOKENS", "32000"))
MAX_BODY_BYTES = int(os.environ.get("PROXY_MAX_BODY_BYTES", str(2 * 1024 * 1024)))
# Garde-fou anti-emballement : requêtes / jour / licencié (300 consult./mois du
# palier Cabinet ≈ 15/jour ouvré — 250 laisse une marge très large).
DAILY_REQ_LIMIT = int(os.environ.get("PROXY_DAILY_REQ_LIMIT", "250"))
USD_EUR = float(os.environ.get("PROXY_USD_EUR", "0.92"))

GRACE_DAYS = 7                      # comme app/license.py
DEMO_PLANS = ("demo", "essai")      # démo : PAS de grâce
_DAY = 86400
PLAN_CODES = {0: "mensuel", 1: "annuel", 2: "dev", 3: "essai", 4: "trimestriel",
              5: "demo", 6: "ambassadeur"}
_FMT_COMPACT = 2

# Tarifs indicatifs USD/M tokens pour l'estimation de coût du rapport admin
# (préfixe de modèle -> (entrée, sortie)). L'estimation est INDICATIVE : la
# facture Anthropic fait foi.
PRICES_USD_PER_M = {
    "claude-sonnet": (3.0, 15.0),
    "claude-haiku": (1.0, 5.0),
    "claude-opus": (5.0, 25.0),
}


# --------------------------------------------------------------------------- #
# Vérification d'une licence Diktae (copie autonome de app/license.py — ce
# serveur se déploie SANS le code de l'app).
# --------------------------------------------------------------------------- #
def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _decode_payload(raw: bytes) -> dict[str, Any]:
    if len(raw) >= 6 and raw[0] == _FMT_COMPACT:
        return {
            "plan": PLAN_CODES.get(raw[1], str(raw[1])),
            "exp": int.from_bytes(raw[2:6], "big") * _DAY,
            "licensee": raw[6:].decode("utf-8", "replace") or "—",
        }
    return json.loads(raw)


def verify_license(token: str) -> tuple[bool, str, Optional[dict[str, Any]]]:
    """Signature + expiration (grâce de 7 j, AUCUNE pour les plans démo)."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        payload_b64, sig_b64 = (token or "").strip().split(".")
    except ValueError:
        return False, "Clé de licence Diktae attendue (format invalide).", None
    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))
        pub.verify(_b64u_decode(sig_b64), payload_b64.encode("ascii"))
    except InvalidSignature:
        return False, "Licence non émise par Studio Margerit.", None
    except Exception:
        return False, "Clé de licence illisible.", None
    try:
        payload = _decode_payload(_b64u_decode(payload_b64))
    except Exception:
        return False, "Contenu de licence illisible.", None
    grace = 0 if payload.get("plan") in DEMO_PLANS else GRACE_DAYS
    if payload.get("exp", 0) + grace * _DAY < time.time():
        return False, "Licence expirée — renouvelez votre abonnement Diktae.", None
    return True, "OK", payload


# --------------------------------------------------------------------------- #
# Journal de consommation (métadonnées uniquement — JAMAIS le contenu).
# --------------------------------------------------------------------------- #
def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(
        "CREATE TABLE IF NOT EXISTS usage ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " ts TEXT NOT NULL DEFAULT (datetime('now')),"
        " licensee TEXT NOT NULL, plan TEXT,"
        " model TEXT, status INTEGER,"
        " input_tokens INTEGER DEFAULT 0, output_tokens INTEGER DEFAULT 0,"
        " cache_creation_tokens INTEGER DEFAULT 0, cache_read_tokens INTEGER DEFAULT 0,"
        " duration_ms INTEGER DEFAULT 0)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_usage_licensee_ts"
                 " ON usage(licensee, ts)")
    return conn


def _record(licensee: str, plan: str, model: str, status: int,
            usage: dict[str, Any], duration_ms: int) -> None:
    conn = _db()
    try:
        conn.execute(
            "INSERT INTO usage (licensee, plan, model, status, input_tokens,"
            " output_tokens, cache_creation_tokens, cache_read_tokens, duration_ms)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (licensee, plan, model, status,
             int(usage.get("input_tokens") or 0),
             int(usage.get("output_tokens") or 0),
             int(usage.get("cache_creation_input_tokens") or 0),
             int(usage.get("cache_read_input_tokens") or 0),
             duration_ms),
        )
        conn.commit()
    finally:
        conn.close()


def _requests_today(licensee: str) -> int:
    conn = _db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM usage"
            " WHERE licensee = ? AND ts >= date('now')", (licensee,)).fetchone()
        return int(row["n"]) if row else 0
    finally:
        conn.close()


def _cost_eur(model: str, tok_in: int, tok_out: int) -> float:
    for prefix, (p_in, p_out) in PRICES_USD_PER_M.items():
        if (model or "").startswith(prefix):
            usd = (tok_in * p_in + tok_out * p_out) / 1_000_000
            return round(usd * USD_EUR, 4)
    return 0.0


# --------------------------------------------------------------------------- #
# Application
# --------------------------------------------------------------------------- #
app = FastAPI(title="Diktae — proxy de clés API", docs_url=None, redoc_url=None)


def _api_error(status: int, err_type: str, message: str) -> JSONResponse:
    """Erreur au FORMAT de l'API Anthropic : le SDK côté app la transforme en
    exception typée avec un message lisible pour le praticien."""
    return JSONResponse(
        {"type": "error", "error": {"type": err_type, "message": message}},
        status_code=status,
    )


@app.get("/healthz")
def healthz() -> dict[str, Any]:
    return {"ok": True, "upstream": UPSTREAM,
            "key_configured": bool(ANTHROPIC_API_KEY)}


@app.post("/v1/messages")
async def messages(request: Request,
                   x_api_key: str = Header(default=""),
                   authorization: str = Header(default=""),
                   anthropic_version: str = Header(default="2023-06-01"),
                   anthropic_beta: str = Header(default="")) -> Response:
    if not ANTHROPIC_API_KEY:
        return _api_error(503, "api_error",
                          "Proxy mal configuré : ANTHROPIC_API_KEY absente côté serveur.")
    # Le SDK envoie la « clé » (= jeton de licence Diktae) en x-api-key.
    token = x_api_key or authorization.removeprefix("Bearer ").strip()
    ok, reason, lic = verify_license(token)
    if not ok:
        return _api_error(401, "authentication_error", reason)
    licensee = lic["licensee"]
    plan = lic.get("plan", "—")

    if DAILY_REQ_LIMIT and _requests_today(licensee) >= DAILY_REQ_LIMIT:
        return _api_error(429, "rate_limit_error",
                          "Quota journalier du proxy atteint — réessayez demain "
                          "ou contactez Studio Margerit.")

    body = await request.body()
    if len(body) > MAX_BODY_BYTES:
        return _api_error(413, "invalid_request_error", "Requête trop volumineuse.")
    try:
        payload = json.loads(body)
        assert isinstance(payload, dict)
    except Exception:
        return _api_error(400, "invalid_request_error", "Corps JSON invalide.")

    model = str(payload.get("model") or "")
    if ALLOWED_MODEL_PREFIXES and not any(model.startswith(p) for p in ALLOWED_MODEL_PREFIXES):
        return _api_error(403, "permission_error",
                          f"Modèle « {model} » non autorisé par le proxy Diktae.")
    if payload.get("stream"):
        return _api_error(400, "invalid_request_error",
                          "Le streaming n'est pas relayé par ce proxy.")
    try:
        if int(payload.get("max_tokens") or 0) > MAX_TOKENS_LIMIT:
            payload["max_tokens"] = MAX_TOKENS_LIMIT
    except (TypeError, ValueError):
        return _api_error(400, "invalid_request_error", "max_tokens invalide.")

    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": anthropic_version,
        "content-type": "application/json",
    }
    if anthropic_beta:
        headers["anthropic-beta"] = anthropic_beta

    t0 = time.monotonic()
    try:
        resp = await _upstream_post(f"{UPSTREAM}/v1/messages", headers, payload)
    except httpx.HTTPError as exc:
        _record(licensee, plan, model, 502, {}, int((time.monotonic() - t0) * 1000))
        return _api_error(502, "api_error", f"API Anthropic injoignable : {exc}")
    duration_ms = int((time.monotonic() - t0) * 1000)

    usage: dict[str, Any] = {}
    try:
        usage = json.loads(resp.content).get("usage") or {}
    except Exception:
        pass
    _record(licensee, plan, model, resp.status_code, usage, duration_ms)
    return Response(content=resp.content, status_code=resp.status_code,
                    media_type="application/json")


async def _upstream_post(url: str, headers: dict[str, str],
                         payload: dict[str, Any]) -> httpx.Response:
    """Appel amont isolé — monkeypatché par les tests (aucun réseau requis)."""
    async with httpx.AsyncClient(timeout=600.0) as client:
        return await client.post(url, headers=headers, json=payload)


@app.get("/admin/usage")
def admin_usage(authorization: str = Header(default=""),
                month: str = "") -> Response:
    """Consommation agrégée par licencié (et par mois via ?month=AAAA-MM).

    Auth : Authorization: Bearer <PROXY_ADMIN_TOKEN>. Renvoie requêtes, tokens
    et coût ESTIMÉ (la facture Anthropic fait foi)."""
    if not ADMIN_TOKEN or authorization.removeprefix("Bearer ").strip() != ADMIN_TOKEN:
        return _api_error(401, "authentication_error", "Jeton admin invalide.")
    where, params = "", []
    if month:
        where = " WHERE substr(ts, 1, 7) = ?"
        params.append(month)
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT licensee, plan, model,"
            " COUNT(*) AS requests, SUM(status < 400) AS ok,"
            " SUM(input_tokens) AS tok_in, SUM(output_tokens) AS tok_out,"
            " SUM(cache_read_tokens) AS tok_cache_read,"
            " MAX(ts) AS last_seen"
            f" FROM usage{where}"
            " GROUP BY licensee, plan, model ORDER BY licensee, model",
            tuple(params)).fetchall()
    finally:
        conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d["cost_estimate_eur"] = _cost_eur(d.get("model") or "",
                                           int(d.get("tok_in") or 0),
                                           int(d.get("tok_out") or 0))
        out.append(d)
    return JSONResponse({"month": month or "all", "usage": out})
