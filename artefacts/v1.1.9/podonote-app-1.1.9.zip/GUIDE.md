# 📖 Guide d'utilisation — PodoNote

Ce guide s'adresse au praticien. Trois choses à régler une fois, puis l'usage au quotidien.

---

## 1. Réglages à faire une seule fois

### a) Le jeton HuggingFace (pour identifier qui parle)

Sans ce jeton, PodoNote transcrit mais ne distingue pas le praticien du patient.
C'est **gratuit** et **n'envoie aucune donnée patient** (sert juste à télécharger les modèles).

1. Créez un compte sur https://huggingface.co (gratuit).
2. Allez sur https://huggingface.co/settings/tokens → **New token** (type *Read*) → copiez-le.
3. Acceptez les conditions des 2 modèles (une fois, en étant connecté) :
   - https://huggingface.co/pyannote/speaker-diarization-3.1
   - https://huggingface.co/pyannote/segmentation-3.0
4. Collez le jeton dans le fichier `.env` : `HUGGINGFACE_TOKEN=hf_xxxxxxxx`
5. Relancez PodoNote.

### b) Le micro du cabinet

Branchez un **micro USB de table omnidirectionnel** (~40–80 €), posé **entre vous et le patient**.
Windows le détecte automatiquement ; le navigateur l'utilisera lors de l'enregistrement.

### c) Réglages de l'iPhone (pour les enregistrements à domicile)

Dans **Réglages → Dictaphone** :
- **Qualité audio = « Sans perte »** (meilleure transcription).
- **Désactivez la synchro iCloud** du Dictaphone (Réglages → [votre compte] → iCloud → Dictaphone : OFF)
  → les enregistrements restent uniquement sur l'iPhone.

---

## 2. Au cabinet — enregistrer une consultation

1. Ouvrez PodoNote → **Nouvelle consultation**.
2. Choisissez le patient (ou créez-le).
3. Cochez **« consentement obtenu »** (idéalement, énoncez-le à voix haute au début).
4. Cliquez sur le **cercle** pour démarrer, reparlez normalement, **verbalisez vos constats**.
5. Cliquez à nouveau pour arrêter → **Lancer le traitement**.
6. La fiche-bilan apparaît après quelques minutes. Vous pouvez fermer la page entre-temps.

> 💡 L'IA ne capte **que ce qui est dit à voix haute**. Dites vos observations cliniques.

---

## 3. À domicile — enregistrer puis transférer

### Enregistrer
Ouvrez l'app **Dictaphone** de l'iPhone, enregistrez la consultation (avec l'accord du patient,
énoncé à voix haute de préférence).

### Transférer (de retour au cabinet, iPhone sur le Wi-Fi du cabinet)

1. Dans **Dictaphone** : sélectionnez l'enregistrement → **Partager** → **« Enregistrer dans Fichiers »**
   → emplacement **« Sur mon iPhone »**.
   *(Cette étape est nécessaire : Safari ne peut pas joindre un mémo vocal directement.)*
2. Sur le PC, ouvrez l'onglet **État** de PodoNote : un **QR code** y est affiché.
3. Scannez-le avec l'iPhone (appareil photo) → la page d'upload s'ouvre dans Safari.
4. Saisissez le **PIN**, choisissez le patient, cochez le consentement, **sélectionnez le(s) fichier(s)**, **Envoyez**.
5. Après confirmation : **supprimez les originaux** dans Dictaphone et dans Fichiers.

---

## 4. Le dossier patient

Chaque patient cumule ses consultations. À partir de la 2ᵉ visite, l'IA renseigne
l'**évolution depuis la dernière visite** et peut relier des éléments entre les visites.

Les **réflexions IA** sont des *pistes à vérifier* — **jamais des diagnostics**. Vous gardez la main.

---

## 5. RGPD — vos obligations & les outils fournis

PodoNote vous donne les **moyens techniques** de conformité :
- export PDF/JSON et suppression définitive d'un dossier (fiche patient → bas de page) ;
- audio supprimé après transcription ; consentement tracé ; audio et base **toujours locaux**.

> ☁️ **Rédaction de la fiche-bilan (mode par défaut).** Pour rédiger la fiche, le
> texte de la consultation est envoyé à **Claude (Anthropic, sous-traitant)**,
> mais **uniquement après pseudonymisation** : nom, prénom, dates et autres
> identifiants sont retirés en local, puis réinjectés dans la fiche reçue.
> L'audio, lui, **ne part jamais**. À **mentionner dans votre registre de
> traitement** (sous-traitant cloud). Si vous préférez ne rien envoyer du tout,
> une version **100 % locale** existe (réglage `LLM_BACKEND=ollama`).

En tant que responsable de traitement, il vous revient d'informer le patient, de recueillir
son consentement et de tenir votre registre. L'app ne remplace pas un conseil juridique.

---

## ❓ Problèmes courants

| Symptôme | Solution |
|----------|----------|
| « Micro inaccessible » | Autorisez le micro dans le navigateur (icône cadenas → Microphone). |
| Traitement en « Erreur » | Onglet **État** : vérifiez le backend de fiche (clé API Claude présente, ou Ollama si mode local) et la connexion Internet. Puis « Relancer ». |
| Pas de distinction des locuteurs | Renseignez le `HUGGINGFACE_TOKEN` (§1a). |
| La page iPhone ne s'ouvre pas | iPhone et PC doivent être sur le **même Wi-Fi**. Vérifiez le pare-feu. |
