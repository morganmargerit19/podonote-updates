"""Traitement des photos cliniques (avant/après) : validation + ré-encodage sûr.

Les photos sont stockées en BLOB dans la base (cf. app/db.py) : elles sont donc
incluses dans la sauvegarde et effacées par la purge RGPD (CASCADE +
secure_delete), et ne quittent jamais la machine — comme l'audio.

Le ré-encodage à l'upload :
  - refuse tout ce qui n'est pas une vraie image PNG/JPEG (magic bytes, pas le
    seul nom de fichier) ;
  - applique l'orientation EXIF puis SUPPRIME toutes les métadonnées EXIF (dont
    la géolocalisation GPS des photos prises au smartphone) — hygiène RGPD ;
  - normalise en JPEG et borne la définition (base légère, sauvegarde rapide).
"""
from __future__ import annotations

import io

# En-têtes magiques acceptés en entrée (on ré-encode toujours en JPEG en sortie).
_MAGIC = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff")  # PNG, JPEG

MAX_DIM = 1600          # px : borne du plus grand côté
JPEG_QUALITY = 85
# Garde-fou : au-delà, on refuse avant même de décoder (anti-« décompression bomb »).
MAX_INPUT_BYTES = 30 * 1024 * 1024


def is_supported_image(data: bytes) -> bool:
    """True si les octets commencent par un en-tête d'image PNG/JPEG connu."""
    return bool(data) and data.startswith(_MAGIC)


def reencode(data: bytes) -> bytes:
    """Ré-encode une image en JPEG borné, sans EXIF. Lève ValueError si illisible."""
    from PIL import Image, ImageOps

    try:
        img = Image.open(io.BytesIO(data))
        # Applique l'orientation EXIF (sinon photo « couchée ») PUIS repart d'une
        # image sans métadonnées : le JPEG produit ne contient aucun EXIF/GPS.
        img = ImageOps.exif_transpose(img)
        img = img.convert("RGB")
    except Exception as exc:  # PIL.UnidentifiedImageError, OSError…
        raise ValueError("Image illisible ou corrompue.") from exc

    w, h = img.size
    if max(w, h) > MAX_DIM:
        ratio = MAX_DIM / float(max(w, h))
        img = img.resize((max(1, int(w * ratio)), max(1, int(h * ratio))))

    out = io.BytesIO()
    img.save(out, format="JPEG", quality=JPEG_QUALITY, optimize=True)
    return out.getvalue()
