"""Compta / facturation : factures & devis, catalogue d'actes tarifés, CA.

Pensé pour brancher la télétransmission plus tard (type Anael) sans re-saisie :
les factures sont structurées (lignes JSON, totaux, statuts fermés) dès
aujourd'hui. Micro-entreprise paramédicale : TVA non applicable
(art. 261-4-1° du CGI), les montants sont des montants dus.

Numérotation AUTO, par année et par type : F-AAAA-NNN pour les factures,
D-AAAA-NNN pour les devis (NNN repart à 001 chaque année).
"""
from __future__ import annotations

import json
from datetime import date as _date, datetime
from typing import Any, Optional

from . import pdffont as _pdffont
from .db import db_cursor, get_connection
from .rgpd import _pdf_entete, _pdf_signature, _safe
from .utils import date_fr

TYPES = {"facture": "Facture", "devis": "Devis"}
STATUTS = {"payee": "Payée", "attente": "En attente", "devis": "Devis"}
# Moyens de règlement (retour Nico). Valeurs techniques -> libellés.
MOYENS_PAIEMENT = {"CB": "Carte bancaire", "CHQ": "Chèque", "ESP": "Espèces", "VIR": "Virement"}

# Catalogue validé (maquette) — semé au premier lancement, éditable dans Réglages.
DEFAULT_ACTES = [
    ("Soin de pédicurie", 35.0),
    ("Bilan podologique", 60.0),
    ("Orthèses plantaires sur mesure", 120.0),
    ("Bilan de gradation pied diabétique", 20.0),
    ("Séance de prévention pied diabétique (POD)", 30.0),
    ("Orthoplastie", 45.0),
    ("Orthonyxie", 40.0),
]


def euro(n: Any) -> str:
    """Format monétaire FR : 1 234,56 €."""
    try:
        v = float(n or 0)
    except (TypeError, ValueError):
        v = 0.0
    # Espace fine insécable (U+202F) pour les milliers — typographie FR.
    s = f"{v:,.2f}".replace(",", "\u202f").replace(".", ",")
    return f"{s} €"


# --------------------------------------------------------------------------- #
# Catalogue d'actes
# --------------------------------------------------------------------------- #
def ensure_seed() -> None:
    """Sème le catalogue validé si la table est vide (idempotent)."""
    conn = get_connection()
    try:
        n = conn.execute("SELECT COUNT(*) AS n FROM actes").fetchone()["n"]
    finally:
        conn.close()
    if n:
        return
    with db_cursor() as cur:
        for i, (libelle, prix) in enumerate(DEFAULT_ACTES):
            cur.execute("INSERT INTO actes (libelle, prix, ordre) VALUES (?, ?, ?)",
                        (libelle, prix, i))


def list_actes(actifs_seulement: bool = True) -> list[dict[str, Any]]:
    # Seed paresseux : couvre aussi les contextes où l'événement startup de
    # FastAPI n'a pas tourné (tests, scripts). Idempotent : ne resème jamais
    # une table non vide (les retraits « actif = 0 » restent des lignes).
    ensure_seed()
    conn = get_connection()
    try:
        where = "WHERE actif = 1" if actifs_seulement else ""
        rows = conn.execute(
            f"SELECT * FROM actes {where} ORDER BY ordre, id").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def create_acte(libelle: str, prix: float) -> int:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO actes (libelle, prix, ordre)"
            " VALUES (?, ?, (SELECT COALESCE(MAX(ordre), -1) + 1 FROM actes))",
            (libelle.strip(), max(0.0, prix)),
        )
        return int(cur.lastrowid)


def update_acte(acte_id: int, libelle: str, prix: float) -> None:
    with db_cursor() as cur:
        cur.execute("UPDATE actes SET libelle = ?, prix = ? WHERE id = ?",
                    (libelle.strip(), max(0.0, prix), acte_id))


def delete_acte(acte_id: int) -> None:
    """Désactive (pas de suppression physique : les factures y font référence
    par libellé, l'historique du prix pratiqué doit rester lisible)."""
    with db_cursor() as cur:
        cur.execute("UPDATE actes SET actif = 0 WHERE id = ?", (acte_id,))


# --------------------------------------------------------------------------- #
# Factures & devis
# --------------------------------------------------------------------------- #
def next_numero(kind: str, annee: Optional[int] = None) -> tuple[str, int, int]:
    """(numero, annee, seq) du prochain document du type demandé."""
    kind = kind if kind in TYPES else "facture"
    annee = annee or _date.today().year
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COALESCE(MAX(seq), 0) AS m FROM factures"
            " WHERE type = ? AND annee = ?",
            (kind, annee),
        ).fetchone()
    finally:
        conn.close()
    seq = row["m"] + 1
    prefixe = "F" if kind == "facture" else "D"
    return f"{prefixe}-{annee}-{seq:03d}", annee, seq


def _clean_lignes(lignes: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], float]:
    out, total = [], 0.0
    for ligne in lignes or []:
        libelle = str(ligne.get("libelle") or "").strip()
        if not libelle:
            continue
        try:
            prix = round(float(str(ligne.get("prix") or 0).replace(",", ".")), 2)
        except (TypeError, ValueError):
            prix = 0.0
        out.append({"libelle": libelle, "prix": prix})
        total = round(total + prix, 2)
    return out, total


def create_facture(kind: str, patient: Optional[dict[str, Any]],
                   lignes: list[dict[str, Any]], fichier: str = "",
                   statut: str = "", moyen_paiement: str = "",
                   cabinet_id: Optional[int] = None) -> dict[str, Any]:
    """Crée le document avec le prochain numéro du type.

    Statut : un devis est toujours « devis ». Pour une facture, le praticien
    peut choisir dès la création « payee » (payée) ou « attente » (à payer) —
    retour Nico : ne plus avoir à valider après coup. `moyen_paiement` (CB/CHQ/
    ESP/VIR) est facultatif. `cabinet_id` (compta par cabinet, retour Nico) :
    si absent, le cabinet du patient est retenu — figé à l'émission."""
    kind = kind if kind in TYPES else "facture"
    lignes, total = _clean_lignes(lignes)
    numero, annee, seq = next_numero(kind)
    patient_nom = f"{patient['prenom']} {patient['nom']}".strip() if patient else ""
    if kind == "devis":
        statut_final = "devis"
    else:
        statut_final = statut if statut in ("payee", "attente") else "attente"
    moyen = moyen_paiement if moyen_paiement in MOYENS_PAIEMENT else None
    cab = cabinet_id or (patient or {}).get("cabinet_id") or None
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO factures (type, annee, seq, numero, patient_id,"
            " patient_nom, lignes, total, statut, fichier, moyen_paiement, cabinet_id)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (kind, annee, seq, numero, patient["id"] if patient else None,
             patient_nom, json.dumps(lignes, ensure_ascii=False), total,
             statut_final, fichier or None, moyen, cab),
        )
        fid = int(cur.lastrowid)
    return {"id": fid, "numero": numero, "total": total}


def _decode(row: dict[str, Any]) -> dict[str, Any]:
    try:
        row["lignes"] = json.loads(row.get("lignes") or "[]")
    except (TypeError, ValueError):
        row["lignes"] = []
    return row


def get_facture(facture_id: int) -> Optional[dict[str, Any]]:
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM factures WHERE id = ?",
                           (facture_id,)).fetchone()
        return _decode(dict(row)) if row else None
    finally:
        conn.close()


def list_factures(statut: str = "", limit: int = 200) -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        if statut in STATUTS:
            rows = conn.execute(
                "SELECT * FROM factures WHERE statut = ?"
                " ORDER BY date DESC, id DESC LIMIT ?", (statut, limit)).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM factures ORDER BY date DESC, id DESC LIMIT ?",
                (limit,)).fetchall()
        return [_decode(dict(r)) for r in rows]
    finally:
        conn.close()


def _to_float(v: Any) -> Optional[float]:
    """Montant saisi par l'utilisateur (« 35 », « 35,50 ») -> float, sinon None."""
    s = str(v or "").strip().replace(",", ".")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


# Cabinet EFFECTIF d'une facture : celui figé à l'émission, sinon (factures
# antérieures à la colonne) le cabinet actuel du patient — nécessite le
# LEFT JOIN patients p.
_CABINET_EFFECTIF = "COALESCE(f.cabinet_id, p.cabinet_id)"


def _cabinet_clause(cabinet: Any) -> tuple[Optional[str], list[Any]]:
    """Clause SQL du filtre cabinet : '' = tous, 'none' = sans cabinet, id."""
    if cabinet == "none":
        return f"{_CABINET_EFFECTIF} IS NULL", []
    try:
        cid = int(cabinet)
    except (TypeError, ValueError):
        return None, []
    if cid <= 0:
        return None, []
    return f"{_CABINET_EFFECTIF} = ?", [cid]


def search_factures(statut: str = "", q: str = "", moyen: str = "",
                    montant_min: Any = "", montant_max: Any = "",
                    cabinet: Any = "", limit: int = 300) -> list[dict[str, Any]]:
    """Recherche de factures/devis (retour Nico) : par numéro ou patient, par
    moyen de paiement (« none » = non renseigné), par fourchette de montant et
    par cabinet (compta par cabinet ; « none » = sans cabinet)."""
    sql = "SELECT f.* FROM factures f LEFT JOIN patients p ON p.id = f.patient_id"
    where: list[str] = []
    params: list[Any] = []
    if statut in STATUTS:
        where.append("f.statut = ?")
        params.append(statut)
    if (q or "").strip():
        where.append("(f.numero LIKE ? OR f.patient_nom LIKE ?)")
        like = f"%{q.strip()}%"
        params += [like, like]
    if moyen == "none":
        where.append("(f.moyen_paiement IS NULL OR f.moyen_paiement = '')")
    elif moyen in MOYENS_PAIEMENT:
        where.append("f.moyen_paiement = ?")
        params.append(moyen)
    lo, hi = _to_float(montant_min), _to_float(montant_max)
    if lo is not None:
        where.append("f.total >= ?")
        params.append(lo)
    if hi is not None:
        where.append("f.total <= ?")
        params.append(hi)
    cab_clause, cab_params = _cabinet_clause(cabinet)
    if cab_clause:
        where.append(cab_clause)
        params += cab_params
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY f.date DESC, f.id DESC LIMIT ?"
    params.append(limit)
    conn = get_connection()
    try:
        return [_decode(dict(r)) for r in conn.execute(sql, tuple(params)).fetchall()]
    finally:
        conn.close()


def list_factures_patient(patient_id: int, limit: int = 100) -> list[dict[str, Any]]:
    """Factures & devis d'un patient (encart du dossier patient — retour Nico)."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM factures WHERE patient_id = ?"
            " ORDER BY date DESC, id DESC LIMIT ?", (patient_id, limit)).fetchall()
        return [_decode(dict(r)) for r in rows]
    finally:
        conn.close()


def set_statut(facture_id: int, statut: str, moyen_paiement: str = "") -> None:
    if statut not in STATUTS:
        return
    with db_cursor() as cur:
        if moyen_paiement in MOYENS_PAIEMENT:
            cur.execute("UPDATE factures SET statut = ?, moyen_paiement = ? WHERE id = ?",
                        (statut, moyen_paiement, facture_id))
        else:
            cur.execute("UPDATE factures SET statut = ? WHERE id = ?",
                        (statut, facture_id))


def set_moyen(facture_id: int, moyen_paiement: str) -> None:
    """Renseigne/modifie le moyen de règlement d'une facture EXISTANTE (retour
    Nico : pouvoir l'ajouter ou le corriger après coup, même une fois payée).
    Une valeur hors liste (ou vide) efface le moyen (NULL)."""
    moyen = moyen_paiement if moyen_paiement in MOYENS_PAIEMENT else None
    with db_cursor() as cur:
        cur.execute("UPDATE factures SET moyen_paiement = ? WHERE id = ?",
                    (moyen, facture_id))


def delete_facture(facture_id: int) -> bool:
    """Supprime définitivement une facture/un devis (retour Nico : corriger une
    erreur de saisie). La séquence n'est PAS réattribuée : un trou dans la
    numérotation est le témoin comptable normal d'une pièce annulée. Renvoie
    True si une ligne a été supprimée."""
    with db_cursor() as cur:
        cur.execute("DELETE FROM factures WHERE id = ?", (facture_id,))
        return cur.rowcount > 0


# --------------------------------------------------------------------------- #
# Tableau de bord (CA)
# --------------------------------------------------------------------------- #
def dashboard(annee: Optional[int] = None, cabinet: Any = "") -> dict[str, Any]:
    """KPI + barres de CA + répartition par type d'acte pour l'année donnée.

    `cabinet` (compta par cabinet, retour Nico) : '' = tous les cabinets (vue
    cumulée, comportement historique), 'none' = factures sans cabinet, ou l'id
    d'un cabinet pour sa compta distincte."""
    annee = annee or _date.today().year
    today_iso = _date.today().isoformat()
    sql = ("SELECT f.date, f.lignes, f.total, f.statut, f.type "
           "FROM factures f LEFT JOIN patients p ON p.id = f.patient_id")
    cab_clause, cab_params = _cabinet_clause(cabinet)
    if cab_clause:
        sql += f" WHERE {cab_clause}"
    conn = get_connection()
    try:
        rows = conn.execute(sql, tuple(cab_params)).fetchall()
    finally:
        conn.close()
    encaisse = attente = devis_total = ca_jour = 0.0
    devis_count = 0
    mois = [0.0] * 12
    par_annee: dict[int, float] = {}
    repartition: dict[str, float] = {}
    for r in rows:
        y = int(str(r["date"])[:4] or 0)
        total = float(r["total"] or 0)
        if r["statut"] == "devis":
            if y == annee:
                devis_count += 1
                devis_total = round(devis_total + total, 2)
            continue
        if r["statut"] == "payee":
            par_annee[y] = round(par_annee.get(y, 0) + total, 2)
            # CA du jour (retour Nico « data ») : factures payées datées d'aujourd'hui.
            if str(r["date"])[:10] == today_iso:
                ca_jour = round(ca_jour + total, 2)
        if y != annee:
            continue
        if r["statut"] == "payee":
            encaisse = round(encaisse + total, 2)
            m = int(str(r["date"])[5:7] or 0)
            if 1 <= m <= 12:
                mois[m - 1] = round(mois[m - 1] + total, 2)
        elif r["statut"] == "attente":
            attente = round(attente + total, 2)
        # Répartition (payées + en attente de l'année) par libellé d'acte.
        try:
            for ligne in json.loads(r["lignes"] or "[]"):
                lib = str(ligne.get("libelle") or "").strip()
                if lib:
                    repartition[lib] = round(
                        repartition.get(lib, 0) + float(ligne.get("prix") or 0), 2)
        except (TypeError, ValueError):
            pass
    total_rep = sum(repartition.values()) or 1
    repartition_pct = sorted(
        ({"libelle": k, "montant": v, "pct": round(100 * v / total_rep)}
         for k, v in repartition.items()),
        key=lambda x: -x["montant"])[:6]
    # Comparatif annuel (retour Nico) : encaissé N vs N-1 vs N-2 + variation.
    ca_n = par_annee.get(annee, 0.0)
    ca_n1 = par_annee.get(annee - 1, 0.0)
    ca_n2 = par_annee.get(annee - 2, 0.0)
    def _delta(cur: float, prev: float) -> Optional[int]:
        if not prev:
            return None
        return round(100 * (cur - prev) / prev)
    comparatif = {
        "n": {"annee": annee, "total": ca_n},
        "n1": {"annee": annee - 1, "total": ca_n1, "delta": _delta(ca_n, ca_n1)},
        "n2": {"annee": annee - 2, "total": ca_n2, "delta": _delta(ca_n, ca_n2)},
    }
    return {
        "annee": annee,
        "encaisse": encaisse,
        "attente": attente,
        "ca_jour": ca_jour,
        "devis_count": devis_count,
        "devis_total": devis_total,
        "mois": mois,
        "mois_courant": _date.today().month if annee == _date.today().year else None,
        "par_annee": sorted(par_annee.items()),
        "comparatif": comparatif,
        "repartition": repartition_pct,
    }


# --------------------------------------------------------------------------- #
# PDF (mêmes conventions que app/rgpd.py / app/papiers.py)
# --------------------------------------------------------------------------- #
def build_pdf(facture: dict[str, Any], header: dict[str, Any]) -> bytes:
    from fpdf import FPDF

    pdf = FPDF()
    _pdffont.setup(pdf)
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    titre = TYPES.get(facture["type"], "Facture").upper()
    _pdf_entete(pdf, header, f"{titre} {facture['numero']}",
                f"Le {date_fr(str(facture['date'])[:10])}")

    if facture.get("patient_nom"):
        pdf.set_font(_pdffont.FAMILY, "", 10.5)
        pdf.cell(0, 6, _safe(f"Pour {facture['patient_nom']}"),
                 new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    pdf.set_font(_pdffont.FAMILY, "B", 10)
    pdf.set_fill_color(244, 240, 230)
    pdf.cell(140, 8, _safe("Acte"), border=1, fill=True)
    pdf.cell(40, 8, _safe("Montant"), border=1, fill=True, align="R",
             new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(_pdffont.FAMILY, "", 10)
    for ligne in facture.get("lignes") or []:
        pdf.cell(140, 8, _safe(ligne["libelle"]), border=1)
        pdf.cell(40, 8, _safe(euro(ligne["prix"]).replace("\u202f", " ")),
                 border=1, align="R", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(_pdffont.FAMILY, "B", 10)
    pdf.cell(140, 8, _safe("Total"), border=1)
    pdf.cell(40, 8, _safe(euro(facture["total"]).replace("\u202f", " ")),
             border=1, align="R", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(6)
    # Statut de règlement + moyen de paiement (retour Nico) — factures seulement.
    if facture.get("type") != "devis":
        paye = facture.get("statut") == "payee"
        moyen = MOYENS_PAIEMENT.get(facture.get("moyen_paiement") or "")
        pdf.set_font(_pdffont.FAMILY, "B", 10.5)
        if paye:
            pdf.set_text_color(31, 138, 91)   # vert « payée »
            txt = "PAYÉE" + (f" — {moyen}" if moyen else "")
        else:
            pdf.set_text_color(160, 106, 18)  # ambre « à payer »
            txt = "À RÉGLER"
        pdf.cell(0, 6, _safe(txt), new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(34, 29, 21)
        pdf.ln(2)
    pdf.set_font(_pdffont.FAMILY, "", 9)
    pdf.set_text_color(110, 99, 88)
    pdf.cell(0, 5, _safe("TVA non applicable, art. 261-4-1° du CGI."),
             new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(34, 29, 21)
    _pdf_signature(pdf, header)
    return bytes(pdf.output())
