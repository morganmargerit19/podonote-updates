"""Helpers multiplateformes (Windows / macOS / Linux).

Centralise la détection d'OS et les opérations dépendantes du système — ouvrir un
fichier dans l'app par défaut, trouver le Bureau, afficher un dialogue d'erreur
natif, localiser l'interpréteur Python du `.venv` — afin que le reste du code
reste agnostique. PodoNote vise un **socle commun** + une couche « plateforme »
fine, pour tourner aussi bien sur Windows que sur macOS.
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path

log = logging.getLogger("podonote.platform")

IS_WINDOWS = os.name == "nt"
IS_MAC = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


# --------------------------------------------------------------------------- #
# Ouverture d'un fichier dans l'application par défaut (lecteur PDF…)
# --------------------------------------------------------------------------- #
def open_path(path) -> bool:
    """Ouvre `path` dans l'application par défaut du système. True si lancé."""
    p = str(path)
    try:
        if IS_WINDOWS:
            os.startfile(p)  # type: ignore[attr-defined]  # Windows uniquement
            return True
        if IS_MAC:
            subprocess.Popen(["open", p])
            return True
        subprocess.Popen(["xdg-open", p])  # Linux / freedesktop
        return True
    except Exception:
        log.exception("Ouverture du fichier dans l'app par défaut impossible.")
        # Dernier repli : navigateur (file://) — au moins le PDF s'affiche.
        try:
            import webbrowser
            return webbrowser.open(Path(p).as_uri())
        except Exception:
            return False


# --------------------------------------------------------------------------- #
# Dossier Bureau (dépôt d'un rapport de diagnostic « visible »)
# --------------------------------------------------------------------------- #
def desktop_dir() -> str:
    """Meilleur emplacement visible pour déposer un fichier (Bureau de l'utilisateur)."""
    home = Path.home()
    candidates: list[Path] = []
    if IS_WINDOWS:
        # OneDrive peut rediriger le Bureau ; on tente ses chemins d'abord.
        one = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
        up = os.environ.get("USERPROFILE")
        if one:
            candidates.append(Path(one) / "Desktop")
        if up:
            candidates.append(Path(up) / "Desktop")
    # Bureau standard (EN + FR) — valable macOS / Linux / Windows.
    candidates += [home / "Desktop", home / "Bureau"]
    for c in candidates:
        try:
            if c.is_dir():
                return str(c)
        except OSError:
            continue
    return str(home) if home.is_dir() else "."


# --------------------------------------------------------------------------- #
# Dialogue d'erreur natif (utile quand l'app est lancée sans console)
# --------------------------------------------------------------------------- #
def _as_applescript(s) -> str:
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def notify_error(text: str, title: str = "PodoNote") -> None:
    """Affiche une boîte de dialogue d'erreur native. Silencieux si indisponible."""
    try:
        if IS_WINDOWS:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)  # MB_ICONERROR
            return
        if IS_MAC:
            script = (
                f"display dialog {_as_applescript(text)} "
                f"with title {_as_applescript(title)} "
                'buttons {"OK"} default button "OK" with icon stop'
            )
            subprocess.run(["osascript", "-e", script], capture_output=True, timeout=30)
            return
    except Exception:
        log.exception("Affichage du dialogue d'erreur impossible.")
    # Linux / repli : pas de dialogue garanti → on journalise au moins.
    log.error("%s : %s", title, text)


# --------------------------------------------------------------------------- #
# Interpréteur Python du venv de l'installation (layout Windows vs POSIX)
# --------------------------------------------------------------------------- #
def venv_python(base_dir) -> Path | None:
    """Chemin de l'interpréteur du `.venv` de l'installation, ou None si absent."""
    base = Path(base_dir)
    for c in (
        base / ".venv" / "Scripts" / "python.exe",  # Windows
        base / ".venv" / "bin" / "python",          # macOS / Linux
        base / ".venv" / "bin" / "python3",
    ):
        if c.exists():
            return c
    return None


def venv_launcher(base_dir) -> Path | None:
    """Interpréteur à utiliser pour LANCER l'app sans console.

    Windows : `pythonw.exe` (pas de fenêtre console) si présent. POSIX : il n'y a
    pas de pythonw → on utilise l'interpréteur standard du venv.
    """
    base = Path(base_dir)
    pyw = base / ".venv" / "Scripts" / "pythonw.exe"
    if pyw.exists():
        return pyw
    return venv_python(base_dir)


def detached_creationflags() -> int:
    """Drapeaux `subprocess` pour détacher un process (Windows) ; 0 ailleurs."""
    if IS_WINDOWS:
        return (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
    return 0
