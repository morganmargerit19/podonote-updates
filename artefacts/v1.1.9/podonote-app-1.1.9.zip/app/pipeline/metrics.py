"""Instrumentation légère du pipeline : durée par étape + pic RAM.

Objectif (Phase 1) : mesurer, pas supposer. On chronomètre chaque étape
(transcription, alignement, diarisation, génération LLM…) et on échantillonne
la mémoire résidente (RSS) du process pour estimer le pic RAM.

Sans dépendance dure : utilise `psutil` s'il est présent (cross-platform,
indispensable sur Windows — la cible), sinon `resource` (Unix/macOS), sinon
renvoie None pour la RAM. N'altère JAMAIS le résultat du pipeline : en cas de
souci, l'instrumentation se contente de logguer "n/a".
"""
from __future__ import annotations

import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator, Optional

logger = logging.getLogger("podonote.metrics")


def rss_mb() -> Optional[float]:
    """Mémoire résidente du process courant, en Mo. None si indisponible."""
    try:
        import os

        import psutil  # type: ignore

        return psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)
    except Exception:
        pass
    try:
        import resource
        import sys

        ru = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux : ru_maxrss en kio ; macOS : en octets.
        return ru / 1024.0 if sys.platform != "darwin" else ru / (1024.0 * 1024.0)
    except Exception:
        return None


@dataclass
class StepTiming:
    name: str
    seconds: float
    rss_mb_end: Optional[float] = None


@dataclass
class PipelineMetrics:
    """Accumulateur de mesures pour UN traitement de consultation."""

    label: str = ""
    steps: list[StepTiming] = field(default_factory=list)
    peak_rss_mb: Optional[float] = None
    _stop: threading.Event = field(default_factory=threading.Event, repr=False)
    _thread: Optional[threading.Thread] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._observe()

    def _observe(self) -> None:
        v = rss_mb()
        if v is not None and (self.peak_rss_mb is None or v > self.peak_rss_mb):
            self.peak_rss_mb = v

    def start_peak_sampler(self, interval: float = 0.5) -> None:
        """Échantillonne le RSS en tâche de fond pour capter le vrai pic."""
        if rss_mb() is None or self._thread is not None:
            return

        def _run() -> None:
            while not self._stop.wait(interval):
                self._observe()

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()

    def stop_peak_sampler(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    @contextmanager
    def step(self, name: str) -> Iterator[None]:
        """Chronomètre un bloc et logue durée + RSS de fin."""
        t0 = time.perf_counter()
        try:
            yield
        finally:
            dt = time.perf_counter() - t0
            self._observe()
            v = rss_mb()
            self.steps.append(StepTiming(name, dt, v))
            logger.info(
                "[timing] %-32s %7.2fs   RSS~%s Mo",
                name,
                dt,
                f"{v:.0f}" if v is not None else "n/a",
            )

    def total_seconds(self) -> float:
        return sum(s.seconds for s in self.steps)

    def render_table(self) -> str:
        lines = [
            f"=== Mesures pipeline {('— ' + self.label) if self.label else ''} ===",
            f"{'Étape':<34}{'Durée (s)':>12}{'RSS fin (Mo)':>16}",
            "-" * 62,
        ]
        for s in self.steps:
            rss = f"{s.rss_mb_end:.0f}" if s.rss_mb_end is not None else "n/a"
            lines.append(f"{s.name:<34}{s.seconds:>12.2f}{rss:>16}")
        lines.append("-" * 62)
        lines.append(f"{'TOTAL':<34}{self.total_seconds():>12.2f}")
        peak = f"{self.peak_rss_mb:.0f} Mo" if self.peak_rss_mb is not None else "n/a"
        lines.append(f"Pic RAM (RSS) approximatif : {peak}")
        return "\n".join(lines)
