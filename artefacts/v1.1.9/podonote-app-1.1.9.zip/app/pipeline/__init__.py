"""Pipeline de traitement différé : transcription -> diarisation -> fiche-bilan."""
