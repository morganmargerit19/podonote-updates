"""Orchestration du pipeline différé + suppression de l'audio (RGPD)."""
from __future__ import annotations

import logging
import os
import threading
from pathlib import Path
from typing import Any

from .. import license, repository as repo
from ..config import settings
from . import llm
from .metrics import PipelineMetrics
from .transcribe import TranscriptionError, transcribe_and_diarize

logger = logging.getLogger("podonote.pipeline")

# Verrou global : on traite UNE consultation à la fois (CPU limité, séquentiel).
_pipeline_lock = threading.Lock()

# Garde anti-doublon : empêche d'enfiler deux fois la même consultation.
_inflight: set[int] = set()
_inflight_lock = threading.Lock()


def _set_progress(consultation_id: int, label: str) -> None:
    repo.update_consultation_status(consultation_id, "processing", progress=label)


def process_consultation(consultation_id: int) -> dict[str, Any]:
    """Traite une consultation de bout en bout. Renvoie un résumé du résultat.

    Étapes : transcription+diarisation -> fiche-bilan LLM -> persistance ->
    suppression de l'audio. Met à jour le statut en base à chaque étape.
    """
    with _pipeline_lock:
        consultation = repo.get_consultation(consultation_id)
        if not consultation:
            raise ValueError(f"Consultation {consultation_id} introuvable.")

        # Anti-doublon : si déjà traitée pendant l'attente du verrou, on ne refait rien.
        if consultation.get("status") == "done":
            logger.info("Consultation %s déjà traitée, ignorée.", consultation_id)
            return {"status": "done", "skipped": True}

        # L'audio n'est requis que si l'ASR doit tourner : un retry après échec
        # LLM peut repartir du transcript persisté, même sans fichier audio.
        audio_path = consultation.get("audio_path")
        has_transcript = bool((consultation.get("transcript_diarise") or "").strip())
        audio_ok = bool(audio_path) and Path(audio_path).exists()
        if not audio_ok and not has_transcript:
            repo.update_consultation_status(
                consultation_id, "error",
                error_message="Fichier audio introuvable.",
            )
            raise FileNotFoundError(f"Audio introuvable : {audio_path}")

        metrics = PipelineMetrics(label=f"consultation #{consultation_id}")
        metrics.start_peak_sampler()
        try:
            repo.update_consultation_status(consultation_id, "processing", "Démarrage…")

            # 0. Vérification du backend LLM AVANT l'ASR : si Ollama est éteint ou
            # la clé API absente, on échoue en 5 s au lieu de le découvrir après
            # ~10 min de transcription CPU.
            llm_ok, llm_msg = llm.check_llm()
            if not llm_ok:
                raise llm.LLMError(llm_msg)

            # 1 + 2. Transcription & diarisation — sautées si un transcript a déjà
            # été persisté lors d'une tentative précédente (échec LLM → le retry
            # ne refait pas l'ASR).
            existing_transcript = (consultation.get("transcript_diarise") or "").strip()
            if existing_transcript:
                logger.info(
                    "Consultation %s : transcript déjà présent, ASR sautée (retry).",
                    consultation_id,
                )

                class _Reused:
                    text_diarized = existing_transcript
                    diarized = "[SPEAKER_" in existing_transcript
                    num_speakers = 0

                result = _Reused()
            else:
                # Licence DÉMO : le plafond de minutes se vérifie AVANT de
                # lancer l'ASR (pas après 10 min de CPU). Un retry qui repart
                # d'un transcript déjà persisté n'est jamais bloqué ni recompté.
                demo_ok, demo_reason = license.demo_transcription_allowed()
                if not demo_ok:
                    raise TranscriptionError(demo_reason)
                result = transcribe_and_diarize(
                    audio_path,
                    progress=lambda msg: _set_progress(consultation_id, msg),
                    metrics=metrics,
                )
                # Persistance immédiate du transcript : un échec LLM plus loin ne
                # coûtera plus une re-transcription complète.
                repo.save_transcript(consultation_id, result.text_diarized)
                # Décompte démo : durée RÉELLE de l'audio traité. Une durée
                # illisible compte 0 (généreux) plutôt que de bloquer à tort.
                if license.get_status().get("demo"):
                    license.add_demo_seconds(_audio_duration_seconds(audio_path))

            # 3. Fiche-bilan via LLM (avec historique + terrain médical du patient)
            _set_progress(consultation_id, "Génération de la fiche-bilan…")
            history = repo.list_previous_consultations(
                consultation["patient_id"], consultation_id
            )
            from .. import clinical
            patient = repo.get_patient(consultation["patient_id"])
            patient_context = clinical.flags_context_text(
                (patient or {}).get("medical_flags", [])
            )
            _llm_label = (
                settings.anthropic_model
                if settings.llm_backend.strip().lower() == "sonnet"
                else settings.ollama_model
            )
            with metrics.step(f"Génération LLM ({_llm_label})"):
                recap = llm.generate_recap(
                    result.text_diarized, history=history,
                    patient_context=patient_context, patient=patient,
                    bilan_type=consultation.get("bilan_type"),
                )

            # 4. Persistance
            with metrics.step("Persistance (BDD)"):
                repo.save_consultation_result(
                    consultation_id,
                    transcript_diarise=result.text_diarized,
                    recap=recap,
                )

            # 5. Suppression de l'audio (RGPD). Le chemin n'est retiré de la base
            # QUE si la suppression disque a réussi : sinon on le conserve pour
            # que la purge au démarrage puisse réessayer (un fichier verrouillé
            # par l'antivirus ne doit pas devenir un orphelin éternel).
            if settings.delete_audio_after_transcription and audio_ok:
                if _delete_audio(audio_path, consultation_id):
                    repo.clear_audio_path(consultation_id)

            metrics.stop_peak_sampler()
            logger.info("\n%s", metrics.render_table())
            return {"status": "done", "diarized": result.diarized,
                    "num_speakers": result.num_speakers}

        except (TranscriptionError, llm.LLMError) as exc:
            repo.update_consultation_status(
                consultation_id, "error", error_message=str(exc)
            )
            raise
        except Exception as exc:  # filet de sécurité
            repo.update_consultation_status(
                consultation_id, "error", error_message=f"Erreur inattendue : {exc}"
            )
            raise
        finally:
            # Toujours arrêter le thread d'échantillonnage (évite toute fuite).
            metrics.stop_peak_sampler()


def _audio_duration_seconds(audio_path: str) -> float:
    """Durée d'un fichier audio en secondes via ffprobe (à côté de ffmpeg),
    pour le décompte des minutes de la licence démo. 0.0 si illisible."""
    import shutil
    import subprocess

    from .transcribe import _ffmpeg_exe

    ffmpeg = _ffmpeg_exe()
    candidates = []
    if ffmpeg:
        exe = Path(ffmpeg)
        candidates.append(str(exe.with_name("ffprobe" + exe.suffix)))
    which = shutil.which("ffprobe")
    if which:
        candidates.append(which)
    for probe in candidates:
        if not Path(probe).exists():
            continue
        try:
            out = subprocess.run(
                [probe, "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", audio_path],
                capture_output=True, text=True, timeout=30,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if out.returncode == 0:
                return max(0.0, float(out.stdout.strip()))
        except (OSError, ValueError, subprocess.TimeoutExpired):
            continue
    return 0.0


def _delete_audio(audio_path: str, consultation_id: int | None = None) -> bool:
    """Supprime un fichier audio. Renvoie True si le fichier n'existe plus.

    Les logs ne mentionnent QUE l'id de consultation, jamais le chemin : le nom
    de fichier peut contenir l'identité du patient et ces lignes finissent dans
    podonote.log puis dans le rapport de diagnostic envoyé au développeur.
    """
    ref = f"consultation {consultation_id}" if consultation_id else "fichier audio"
    try:
        os.remove(audio_path)
        logger.info("Audio supprimé (RGPD) : %s.", ref)
        return True
    except FileNotFoundError:
        return True
    except OSError as exc:
        logger.warning("Échec suppression audio (%s) : %s", ref, exc.strerror or exc)
        return False


def process_in_background(consultation_id: int) -> bool:
    """Lance le traitement dans un thread (déclenché par les routes web).

    Renvoie False (sans rien lancer) si la consultation est déjà en file/en
    cours : l'appelant ne doit alors PAS toucher au statut, sinon une course
    avec un traitement en train d'échouer laisse la fiche coincée en `pending`
    sans aucun thread pour la traiter."""
    with _inflight_lock:
        if consultation_id in _inflight:
            logger.info("Consultation %s déjà en file, ignorée.", consultation_id)
            return False
        _inflight.add(consultation_id)
    t = threading.Thread(target=_safe_process, args=(consultation_id,), daemon=True)
    t.start()
    return True


def _safe_process(consultation_id: int) -> None:
    try:
        process_consultation(consultation_id)
    except Exception:
        # L'erreur est déjà enregistrée en base ; on évite de tuer le thread silencieusement.
        logger.exception("Échec du pipeline pour la consultation %s", consultation_id)
    finally:
        with _inflight_lock:
            _inflight.discard(consultation_id)


# Nombre maximal de reprises automatiques au démarrage avant d'abandonner et de
# basculer la consultation en 'error' (évite une boucle de re-traitement si l'app
# redémarre en boucle ou si l'audio est définitivement illisible).
MAX_RESUME_ATTEMPTS = 3


def resume_pending() -> int:
    """Au démarrage : relance les consultations restées en attente. Renvoie le nombre relancé.

    Garde-fou anti-boucle : au-delà de MAX_RESUME_ATTEMPTS reprises, la consultation
    est marquée 'error' (le praticien pourra la relancer manuellement) au lieu d'être
    re-traitée à chaque démarrage."""
    pending = repo.list_pending_consultations()
    resumed = 0
    for c in pending:
        if (c.get("resume_attempts") or 0) >= MAX_RESUME_ATTEMPTS:
            repo.update_consultation_status(
                c["id"], "error",
                error_message="Reprise automatique abandonnée après plusieurs tentatives. "
                              "Relancez le traitement manuellement.",
            )
            logger.warning(
                "Consultation %s : reprise abandonnée (%d tentatives).",
                c["id"], c.get("resume_attempts") or 0,
            )
            continue
        repo.increment_resume_attempts(c["id"])
        if process_in_background(c["id"]):
            resumed += 1
    return resumed


def purge_orphan_audio() -> int:
    """Au démarrage : supprime les audios des consultations TERMINÉES restés sur
    disque (crash entre 'done' et la suppression). Respecte la politique RGPD.

    Les consultations en 'error' sont CONSERVÉES (l'audio est nécessaire au /retry).
    """
    if not settings.delete_audio_after_transcription:
        return 0
    n = 0
    for c in repo.list_done_with_audio():
        path = c.get("audio_path")
        if path and _delete_audio(path, c["id"]):
            repo.clear_audio_path(c["id"])
            n += 1
    n += _sweep_incoming_orphans()
    if n:
        logger.info("Purge RGPD au démarrage : %d audio(s) orphelin(s) supprimé(s).", n)
    return n


def _sweep_incoming_orphans(min_age_hours: float = 1.0) -> int:
    """Supprime les fichiers de incoming/ qui ne sont référencés par AUCUNE
    consultation (crash entre l'upload et l'insert en base, ou chemin perdu).

    Sans ce balayage, un audio orphelin — la donnée la plus sensible — peut
    rester sur disque indéfiniment, invisible de la purge basée sur la base.
    Les fichiers très récents sont épargnés (upload potentiellement en cours).
    """
    import time

    from ..config import INCOMING_DIR

    referenced = {
        os.path.normcase(os.path.abspath(p))
        for p in repo.list_all_audio_paths()
    }
    n = 0
    now = time.time()
    try:
        entries = list(Path(INCOMING_DIR).iterdir())
    except OSError:
        return 0
    for f in entries:
        if not f.is_file():
            continue
        if now - f.stat().st_mtime < min_age_hours * 3600:
            continue
        if os.path.normcase(str(f.resolve())) in referenced:
            continue
        try:
            f.unlink()
            n += 1
            logger.info("Audio orphelin purgé de incoming/ (non référencé en base).")
        except OSError as exc:
            logger.warning("Échec purge d'un orphelin incoming/ : %s", exc.strerror or exc)
    return n
