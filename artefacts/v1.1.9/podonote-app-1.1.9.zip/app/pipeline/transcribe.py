"""Transcription FR + diarisation via WhisperX (100% local, CPU).

Imports ML faits paresseusement : l'app web démarre même sans ces libs installées.
"""
from __future__ import annotations

import os
import shutil
import threading
from dataclasses import dataclass, field
from typing import Callable, Optional

from ..config import settings
from .metrics import PipelineMetrics

# Type d'un callback de progression (libellé) pour remonter l'avancement à l'UI.
ProgressCb = Optional[Callable[[str], None]]

# --------------------------------------------------------------------------- #
# Cache de modèles : réutilise l'ASR / l'alignement / le diariseur entre
# consultations au lieu de les recharger du disque à chaque fiche. Le pipeline
# est sérialisé (verrou global dans runner.py) ; le verrou ci-dessous protège
# en plus tout appel direct (bancs, scripts). Sortie strictement identique.
# --------------------------------------------------------------------------- #
_MODEL_CACHE: dict = {}
_CACHE_LOCK = threading.Lock()


def _cached_model(key: tuple, loader: Callable):
    """Renvoie l'objet en cache pour `key`, sinon le charge via `loader()` et le
    mémorise. Si le cache est désactivé (settings), charge toujours frais."""
    if not settings.whisper_keep_models_loaded:
        return loader()
    with _CACHE_LOCK:
        obj = _MODEL_CACHE.get(key)
        if obj is None:
            obj = loader()
            _MODEL_CACHE[key] = obj
        return obj


class TranscriptionError(RuntimeError):
    """Erreur survenue pendant la transcription/diarisation."""


@dataclass
class TranscriptResult:
    text_plain: str                       # transcript brut (sans locuteurs)
    text_diarized: str                    # transcript avec [SPEAKER_xx]
    segments: list[dict] = field(default_factory=list)
    num_speakers: int = 0
    diarized: bool = False                # True si la diarisation a tourné
    metrics: Optional["PipelineMetrics"] = None  # mesures de timing/RAM (Phase 1)


def _noop(_: str) -> None:
    pass


def check_dependencies() -> tuple[bool, str]:
    """Vérifie que whisperx est importable. (False, message) sinon."""
    try:
        import whisperx  # noqa: F401
        return True, "whisperx OK"
    except Exception as exc:  # ImportError ou erreur de chargement
        return False, f"whisperx indisponible : {exc}"


# Emplacements usuels hors PATH. Une app lancée depuis le Finder n'hérite PAS du
# PATH du terminal (launchd n'en fournit qu'un minimal, sans /opt/homebrew/bin) :
# `shutil.which("ffmpeg")` échoue alors que ffmpeg est bel et bien installé.
_FFMPEG_FALLBACKS = (
    "/opt/homebrew/bin/ffmpeg",   # Homebrew Apple Silicon
    "/usr/local/bin/ffmpeg",      # Homebrew Intel / installs manuelles
    "/opt/local/bin/ffmpeg",      # MacPorts
    "/usr/bin/ffmpeg",            # Linux / paquet système
)


def _accepts_kwarg(func, name: str) -> bool:
    """La fonction accepte-t-elle cet argument nommé ? (True si **kwargs.)

    Les briques ML sont installées SANS épinglage (`pip install whisperx`) : leur
    API varie d'un poste à l'autre. Plutôt que de supposer une version, on regarde
    ce que celle-ci sait recevoir."""
    import inspect
    try:
        params = inspect.signature(func).parameters
    except (TypeError, ValueError):
        return False
    if name in params:
        return True
    return any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())


def _ffmpeg_exe() -> Optional[str]:
    """Chemin de l'exécutable ffmpeg : settings.ffmpeg_path, puis PATH, puis
    emplacements usuels (cf. _FFMPEG_FALLBACKS)."""
    p = (settings.ffmpeg_path or "").strip()
    if p:
        if os.path.isfile(p):
            return p
        which = shutil.which(p)
        if which:
            return which
    found = shutil.which("ffmpeg")
    if found:
        return found
    for candidate in _FFMPEG_FALLBACKS:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _ensure_ffmpeg() -> str:
    """Garantit que ffmpeg est disponible (sinon message CLAIR au lieu d'un
    [WinError 2] cryptique de whisperx.load_audio). S'assure aussi que son dossier
    est dans le PATH du process (cas du PATH fraîchement modifié après installation).
    """
    exe = _ffmpeg_exe()
    if not exe:
        from ..config import APP_DISPLAY_NAME
        from ..platform_compat import IS_WINDOWS
        if IS_WINDOWS:
            remede = ("Fermez puis rouvrez votre session Windows (ou redémarrez le "
                      f"PC), puis réessayez. Si le problème persiste, relancez "
                      f"l'installation de {APP_DISPLAY_NAME}.")
        else:
            remede = ("Installez-le (`brew install ffmpeg` sur macOS), ou indiquez "
                      "son chemin complet dans FFMPEG_PATH (.env) puis relancez "
                      f"{APP_DISPLAY_NAME}.")
        raise TranscriptionError(f"ffmpeg est introuvable. {remede}")
    folder = os.path.dirname(exe)
    if folder and folder not in os.environ.get("PATH", "").split(os.pathsep):
        os.environ["PATH"] = folder + os.pathsep + os.environ.get("PATH", "")
    return exe


def _format_diarized(segments: list[dict]) -> tuple[str, str]:
    """Construit le transcript brut et le transcript diarisé groupé par locuteur."""
    plain_parts: list[str] = []
    diar_parts: list[str] = []
    current_speaker: Optional[str] = None
    buffer: list[str] = []

    def flush() -> None:
        if buffer:
            spk = current_speaker or "SPEAKER_??"
            diar_parts.append(f"[{spk}] {' '.join(buffer).strip()}")

    for seg in segments:
        txt = (seg.get("text") or "").strip()
        if not txt:
            continue
        plain_parts.append(txt)
        spk = seg.get("speaker")
        if spk != current_speaker:
            flush()
            buffer = []
            current_speaker = spk
        buffer.append(txt)
    flush()

    return " ".join(plain_parts).strip(), "\n".join(diar_parts).strip()


def transcribe_and_diarize(
    audio_path: str,
    progress: ProgressCb = None,
    metrics: Optional[PipelineMetrics] = None,
) -> TranscriptResult:
    """Transcrit + diarise un fichier audio. Lève TranscriptionError en cas d'échec.

    Si `metrics` est fourni, chaque étape est chronométrée (durée + RSS).
    """
    progress = progress or _noop
    metrics = metrics or PipelineMetrics(label="transcription")

    ok, msg = check_dependencies()
    if not ok:
        raise TranscriptionError(msg)

    _ensure_ffmpeg()  # message clair si ffmpeg absent (sinon erreur cryptique plus loin)

    import whisperx

    device = "cpu"
    compute_type = settings.whisper_compute_type
    language = settings.whisper_language

    # Liste de repli de température (configurable). Parse défensif : une valeur
    # mal saisie ne doit pas faire échouer toute la transcription.
    temperatures = []
    for t in settings.whisper_temperatures.split(","):
        t = t.strip()
        if not t:
            continue
        try:
            temperatures.append(float(t))
        except ValueError:
            pass
    if not temperatures:
        temperatures = [0.0]

    # Options ASR : robustesse aux accents / débit rapide / articulation imparfaite.
    asr_options = {
        "beam_size": settings.whisper_beam_size,
        # Repli progressif de température : récupère les passages difficiles.
        "temperatures": temperatures,
        # Évite les boucles d'hallucination sur parole spontanée.
        "condition_on_previous_text": False,
        # Amorce métier (français + vocabulaire podologie).
        "initial_prompt": settings.whisper_initial_prompt or None,
        "no_speech_threshold": 0.6,
        "log_prob_threshold": -1.0,
        "compression_ratio_threshold": 2.4,
    }

    # Threads CPU pour CTranslate2 : whisperx plafonne à 4 par défaut, ce qui
    # laisse la moitié d'un CPU 8 cœurs inutilisée. 0 = tous les cœurs.
    # N'affecte QUE la vitesse (même calcul, même texte produit).
    cpu_threads = settings.whisper_cpu_threads or (os.cpu_count() or 4)

    work_path = audio_path
    try:
        progress("Chargement du modèle de transcription…")
        with metrics.step(f"Chargement modèle ASR ({settings.whisper_model})"):
            # Clé = tous les paramètres qui « cuisent » dans le modèle chargé
            # (les réglages sont constants par process, mais on est explicite).
            asr_key = (
                "asr", settings.whisper_model, device, compute_type, language,
                settings.whisper_beam_size, settings.whisper_temperatures,
                settings.whisper_vad_method, settings.whisper_initial_prompt,
                cpu_threads,
            )
            # `vad_method` n'existe pas dans toutes les versions de whisperx
            # (absent en 3.3.1, présent ensuite) et les installeurs ne l'épinglent
            # pas : deux postes peuvent avoir deux API. On ne passe donc l'argument
            # que si la version installée le connaît, au lieu de planter en
            # « unexpected keyword argument » au moment de traiter un audio.
            load_kwargs = dict(
                device=device,
                compute_type=compute_type,
                language=language,
                asr_options=asr_options,
                threads=cpu_threads,
            )
            if _accepts_kwarg(whisperx.load_model, "vad_method"):
                load_kwargs["vad_method"] = settings.whisper_vad_method
            model = _cached_model(
                asr_key,
                lambda: whisperx.load_model(settings.whisper_model, **load_kwargs),
            )

        progress("Préparation de l'audio…")
        with metrics.step("Préparation audio (ffmpeg + chargement)"):
            if settings.whisper_normalize_audio:
                work_path = _normalize_audio(audio_path) or audio_path
            audio = whisperx.load_audio(work_path)

        progress("Transcription en cours… 0 %")
        # Remonte l'avancement réel (% des tronçons traités). throttlé au % entier
        # pour ne pas écrire en base à chaque appel.
        last_pct = {"v": -1}

        def _on_pct(pct: float) -> None:
            p = max(0, min(100, int(pct)))
            if p > last_pct["v"]:
                last_pct["v"] = p
                progress(f"Transcription en cours… {p} %")

        batch_size = settings.whisper_batch_size or 8
        with metrics.step("Transcription (ASR)"):
            try:
                result = model.transcribe(
                    audio, batch_size=batch_size, language=language,
                    progress_callback=_on_pct,
                )
            except TypeError:
                # Version de whisperx sans progress_callback : repli sans %.
                result = model.transcribe(audio, batch_size=batch_size, language=language)
        segments = result.get("segments", [])

        # --- Alignement (cale les horodatages mot-à-mot) ---
        # ⚠️ L'alignement ne sert QU'À la diarisation (qui a besoin de timestamps
        # précis pour attribuer chaque mot à un locuteur). Il ne modifie PAS le
        # texte de la fiche. Sans diarisation, c'est ~3-4 min de CPU gaspillées
        # (mesuré : ~216 s sur 10 min d'audio). On ne l'exécute donc que si la
        # diarisation va tourner et que l'option est active.
        # Diarisation possible via : 1) les modèles EMBARQUÉS (récupérés tout
        # seuls, aucun compte HuggingFace — cf. app/diarization_models.py), en
        # priorité ; 2) repli : un jeton HF présent dans le .env (postes
        # historiques). Sans l'un ni l'autre : transcript sans locuteurs.
        from .. import diarization_models

        token = settings.huggingface_token.strip()
        local_models = diarization_models.is_installed()
        do_align = (local_models or bool(token)) and settings.whisper_align
        if do_align:
            try:
                progress("Alignement temporel…")
                with metrics.step("Alignement temporel"):
                    model_a, metadata = _cached_model(
                        ("align", language, device),
                        lambda: whisperx.load_align_model(
                            language_code=language, device=device
                        ),
                    )
                    result = whisperx.align(
                        segments, model_a, metadata, audio, device,
                        return_char_alignments=False,
                    )
                    segments = result.get("segments", segments)
            except Exception:
                # L'alignement est un bonus : on continue sans si le modèle FR échoue.
                pass

        # --- Diarisation (qui parle) ---
        diarized = False
        num_speakers = 0
        if local_models or token:
            try:
                progress("Diarisation (identification des locuteurs)…")
                with metrics.step("Diarisation (locuteurs)"):
                    diarize_model = _cached_model(
                        ("diar", "local" if local_models else token, device),
                        lambda: _load_diarizer(token, device, local=local_models),
                    )
                    kwargs: dict = {}
                    if settings.diarize_min_speakers:
                        kwargs["min_speakers"] = settings.diarize_min_speakers
                    if settings.diarize_max_speakers:
                        kwargs["max_speakers"] = settings.diarize_max_speakers
                    diarize_segments = diarize_model(audio, **kwargs)
                    result = whisperx.assign_word_speakers(diarize_segments, result)
                    segments = result.get("segments", segments)
                    speakers = {s.get("speaker") for s in segments if s.get("speaker")}
                    num_speakers = len(speakers)
                    diarized = num_speakers > 0
            except Exception as exc:
                # Pas bloquant : on garde le transcript sans locuteurs.
                progress(f"Diarisation ignorée ({exc}).")
        else:
            progress("Modèles de diarisation absents : transcript sans locuteurs.")

        text_plain, text_diarized = _format_diarized(segments)
        if not diarized:
            text_diarized = text_plain

        if not text_plain:
            raise TranscriptionError("Transcription vide (audio inaudible ?).")

        return TranscriptResult(
            text_plain=text_plain,
            text_diarized=text_diarized,
            segments=segments,
            num_speakers=num_speakers,
            diarized=diarized,
            metrics=metrics,
        )
    except TranscriptionError:
        raise
    except Exception as exc:
        raise TranscriptionError(str(exc)) from exc
    finally:
        # Nettoyage du fichier normalisé temporaire (≠ original).
        if work_path != audio_path:
            try:
                os.remove(work_path)
            except OSError:
                pass


def _normalize_audio(audio_path: str) -> Optional[str]:
    """Nettoie l'audio via ffmpeg (coupe-bas + débruitage + loudnorm) vers un WAV
    16 kHz mono temporaire. La chaîne de filtres est configurable (settings.whisper_audio_filters).

    Compense bruit ambiant et voix éloignées. Renvoie le chemin du fichier nettoyé,
    ou None si ffmpeg échoue (la transcription continue alors sur l'original).
    """
    import subprocess
    import tempfile

    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()
    try:
        cmd = [_ffmpeg_exe() or "ffmpeg", "-y", "-i", audio_path]
        filters = settings.whisper_audio_filters.strip()
        if filters:
            cmd += ["-af", filters]
        cmd += ["-ar", "16000", "-ac", "1", tmp.name]
        proc = subprocess.run(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if proc.returncode == 0:
            return tmp.name
    except Exception:
        pass
    # Échec : on NE laisse PAS le WAV temporaire orphelin sur le disque.
    try:
        os.remove(tmp.name)
    except OSError:
        pass
    return None


def _load_diarizer(token: str, device: str, local: bool = False):
    """Charge le pipeline de diarisation (API variable selon version de whisperx).

    `local=True` : charge depuis les modèles EMBARQUÉS (config.yaml résolu vers
    des chemins absolus) — aucun jeton, aucun réseau. Sinon : téléchargement
    HuggingFace historique avec le jeton du .env."""
    try:
        from whisperx.diarize import DiarizationPipeline
    except Exception:
        from whisperx import DiarizationPipeline  # versions plus anciennes
    if local:
        from .. import diarization_models

        cfg = str(diarization_models.resolved_config())
        # pyannote accepte un chemin de config.yaml partout où il accepte un id
        # de modèle Hub — whisperx le lui transmet tel quel via model_name.
        try:
            return DiarizationPipeline(model_name=cfg, device=device)
        except TypeError:
            return DiarizationPipeline(model_name=cfg, use_auth_token=None, device=device)
    # whisperx >= 3.8 : argument `token=` ; versions antérieures : `use_auth_token=`.
    try:
        return DiarizationPipeline(token=token, device=device)
    except TypeError:
        return DiarizationPipeline(use_auth_token=token, device=device)
