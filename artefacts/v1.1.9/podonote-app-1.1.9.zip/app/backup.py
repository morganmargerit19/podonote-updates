"""Sauvegarde / restauration des données du cabinet (archive .zip).

Pensé pour changer de poste sans manipuler les dossiers à la main : « Sauvegarder »
télécharge une archive, « Restaurer » la réinjecte. Cas d'usage type : Nico met à
jour PodoNote sur ses deux PC, sauvegarde sur l'un, restaure sur l'autre.

Ce que contient l'archive :
  - podonote.db        : la base patients (snapshot COHÉRENT via l'API de
                         sauvegarde SQLite — consolide le WAL, pas besoin de
                         copier .db-wal/.db-shm) ;
  - praticien.json     : le profil praticien (en-tête d'ordonnance) ;
  - signature.(png|jpg): la signature, si présente ;
  - podonote-backup.json : un manifeste (marqueur + version) pour valider à la
                           restauration que c'est bien une sauvegarde PodoNote.

Ce que l'archive ne contient JAMAIS :
  - la clé API (data/anthropic.key.dpapi) : chiffrée pour CE poste (DPAPI),
    illisible ailleurs — la nouvelle install la fournit via son .env ;
  - les identifiants de connexion (data/auth.json) : ils restent propres à
    chaque poste (aucun mot de passe ne circule dans la sauvegarde).

La restauration échange les fichiers EN PLACE. La base étant rouverte à chaque
requête (cf. app/db.py), les données restaurées apparaissent immédiatement, sans
redémarrer l'app. Un filet de sécurité (data/restore_backup/) conserve l'état
précédent au cas où.
"""
from __future__ import annotations

import io
import json
import logging
import os
import shutil
import sqlite3
import time
import zipfile
from pathlib import Path
from typing import Any, Optional

from . import __version__, profile as practitioner
from .config import DATA_DIR, DB_PATH, ensure_dirs

log = logging.getLogger("podonote.backup")

MANIFEST_NAME = "podonote-backup.json"
_MARKER = "podonote-backup"
_DB_ARCNAME = "podonote.db"
_SIGNATURE_NAMES = ("signature.png", "signature.jpg", "signature.jpeg")

# En-tête d'un fichier SQLite valide (refuse un .db bidon dès la restauration).
_SQLITE_MAGIC = b"SQLite format 3\x00"
# En-têtes magiques d'image acceptés pour la signature : on ne se fie pas au seul
# nom du fichier dans l'archive (un .png pourrait masquer tout autre contenu).
_IMAGE_MAGIC = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff")
# Garde-fou anti-« zip bomb » : une vraie sauvegarde de cabinet pèse au plus
# quelques dizaines de Mo (base + signature). 2 Go laisse une marge confortable.
_MAX_UNCOMPRESSED_BYTES = 2 * 1024 * 1024 * 1024
_SAFETY_DIR = DATA_DIR / "restore_backup"


# --------------------------------------------------------------------------- #
# Sauvegarde
# --------------------------------------------------------------------------- #
def _snapshot_db() -> Optional[bytes]:
    """Copie COHÉRENTE de la base via l'API de sauvegarde SQLite.

    `Connection.backup` produit un fichier .db autonome même si l'app écrit en
    parallèle, et consolide le journal WAL dans la copie : pas besoin d'embarquer
    podonote.db-wal / podonote.db-shm. Renvoie None si la base n'existe pas encore.
    """
    if not DB_PATH.exists():
        return None
    tmp = DATA_DIR / f".backup-snapshot-{os.getpid()}.db"
    tmp.unlink(missing_ok=True)
    src = sqlite3.connect(str(DB_PATH))
    try:
        dst = sqlite3.connect(str(tmp))
        try:
            src.backup(dst)
        finally:
            dst.close()
        return tmp.read_bytes()
    finally:
        src.close()
        tmp.unlink(missing_ok=True)


def build_backup() -> tuple[bytes, str]:
    """Construit l'archive de sauvegarde en mémoire. Renvoie (octets, nom_fichier)."""
    ensure_dirs()
    db_bytes = _snapshot_db()
    included: list[str] = []
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if db_bytes is not None:
            zf.writestr(_DB_ARCNAME, db_bytes)
            included.append(_DB_ARCNAME)

        prof = DATA_DIR / "praticien.json"
        if prof.exists():
            zf.write(prof, "praticien.json")
            included.append("praticien.json")

        sig = practitioner.signature_file()
        if sig is not None and sig.exists() and sig.name in _SIGNATURE_NAMES:
            zf.write(sig, sig.name)
            included.append(sig.name)

        manifest = {
            "marker": _MARKER,
            "app": "podonote",
            "version": __version__,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "files": included,
        }
        zf.writestr(MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))

    # Nom visible utilisateur ; le marqueur interne du zip reste « podonote-backup »
    # pour que les sauvegardes déjà émises restent restaurables.
    filename = f"diktae-sauvegarde-{time.strftime('%Y-%m-%d')}.zip"
    log.info("Sauvegarde construite (%d fichier(s), %d octets).", len(included), buf.tell())
    return buf.getvalue(), filename


# --------------------------------------------------------------------------- #
# Restauration
# --------------------------------------------------------------------------- #
def _validate_sqlite(data: bytes) -> tuple[bool, str]:
    """Vérifie que `data` est une base PodoNote plausible (en-tête + table patients)."""
    if not data.startswith(_SQLITE_MAGIC):
        return False, "La base contenue dans la sauvegarde est illisible (format inattendu)."
    probe = DATA_DIR / f".restore-probe-{os.getpid()}.db"
    probe.unlink(missing_ok=True)
    try:
        probe.write_bytes(data)
        conn = sqlite3.connect(str(probe))
        try:
            row = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='patients'"
            ).fetchone()
        finally:
            conn.close()
        if not row:
            return False, "Ce fichier ne ressemble pas à une base Diktae (table patients absente)."
        return True, "OK"
    except sqlite3.DatabaseError as exc:
        return False, f"La base de la sauvegarde est corrompue ({exc})."
    finally:
        probe.unlink(missing_ok=True)


def _count_patients() -> int:
    try:
        conn = sqlite3.connect(str(DB_PATH))
        try:
            return int(conn.execute("SELECT COUNT(*) FROM patients").fetchone()[0])
        finally:
            conn.close()
    except Exception:
        return 0


def _replace_with_retry(src: Path, dst: Path, attempts: int = 6) -> None:
    """os.replace tolérant : sous Windows, un verrou transitoire (la base est
    rouverte très brièvement à chaque requête / par l'antivirus) peut faire échouer
    le remplacement. On réessaie quelques fois avant d'abandonner."""
    last: Optional[Exception] = None
    for _ in range(attempts):
        try:
            os.replace(src, dst)
            return
        except PermissionError as exc:
            last = exc
            time.sleep(0.2)
    raise last if last else OSError(f"Remplacement impossible : {dst}")


def _unlink_with_retry(path: Path, attempts: int = 6) -> None:
    for _ in range(attempts):
        try:
            path.unlink(missing_ok=True)
            return
        except PermissionError:
            time.sleep(0.2)
    # Best-effort : un journal WAL résiduel non supprimable est rare et sera
    # ignoré par SQLite si la base a changé d'identité — on n'échoue pas dessus.
    log.warning("Suppression impossible (verrou ?) : %s", path.name)


def _atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    _replace_with_retry(tmp, path)


def _safety_copy() -> None:
    """Recopie l'état COURANT (base + profil + signature) dans data/restore_backup/
    avant d'écraser : une restauration malencontreuse reste rattrapable."""
    try:
        if _SAFETY_DIR.exists():
            shutil.rmtree(_SAFETY_DIR, ignore_errors=True)
        _SAFETY_DIR.mkdir(parents=True, exist_ok=True)
        for name in (DB_PATH.name, "praticien.json", *_SIGNATURE_NAMES):
            src = DATA_DIR / name
            if src.exists():
                shutil.copy2(src, _SAFETY_DIR / name)
    except Exception:
        log.exception("Filet de sécurité (copie avant restauration) en échec — on continue.")


def _write_db(data: bytes) -> None:
    """Installe la base restaurée et purge les journaux WAL/SHM de l'ANCIENNE base
    (sinon SQLite tenterait de les rejouer sur la nouvelle → corruption)."""
    ensure_dirs()
    tmp = DATA_DIR / f".restore-{os.getpid()}.db"
    tmp.write_bytes(data)
    _replace_with_retry(tmp, DB_PATH)
    for ext in ("-wal", "-shm"):
        _unlink_with_retry(Path(str(DB_PATH) + ext))


def restore_backup(archive: bytes) -> dict[str, Any]:
    """Restaure une archive produite par build_backup(). Ne lève pas : renvoie
    {ok: bool, message: str}. En cas de refus, RIEN n'est modifié sur le disque."""
    ensure_dirs()
    try:
        zf = zipfile.ZipFile(io.BytesIO(archive))
    except zipfile.BadZipFile:
        return {"ok": False, "message": "Fichier illisible : ce n'est pas une archive .zip valide."}

    with zf:
        names = set(zf.namelist())
        if sum(info.file_size for info in zf.infolist()) > _MAX_UNCOMPRESSED_BYTES:
            return {"ok": False, "message": "Archive trop volumineuse — restauration refusée."}
        if MANIFEST_NAME not in names:
            return {"ok": False, "message": "Ce fichier n'est pas une sauvegarde Diktae."}
        try:
            manifest = json.loads(zf.read(MANIFEST_NAME))
        except Exception:
            manifest = {}
        if not isinstance(manifest, dict) or manifest.get("marker") != _MARKER:
            return {"ok": False, "message": "Ce fichier n'est pas une sauvegarde Diktae (marqueur absent)."}
        if _DB_ARCNAME not in names:
            return {"ok": False, "message": "Sauvegarde incomplète : la base patients est absente."}

        db_data = zf.read(_DB_ARCNAME)
        ok, why = _validate_sqlite(db_data)
        if not ok:
            return {"ok": False, "message": why}

        # On lit AUSSI les fichiers annexes avant de toucher au disque, pour ne
        # commencer à écraser qu'une fois tout validé / disponible.
        prof_data = zf.read("praticien.json") if "praticien.json" in names else None
        sig_name = next((n for n in _SIGNATURE_NAMES if n in names), None)
        sig_data = zf.read(sig_name) if sig_name else None

        # La signature n'est posée que si ses octets sont une vraie image PNG/JPG
        # (le nom dans l'archive ne suffit pas) — sinon on l'ignore sans échouer.
        if sig_name and not (sig_data and sig_data.startswith(_IMAGE_MAGIC)):
            log.warning("Signature de la sauvegarde ignorée (pas une image PNG/JPG valide).")
            sig_name = None

        try:
            _safety_copy()
            _write_db(db_data)
            # Met le schéma de la base restaurée à niveau (colonnes ajoutées depuis :
            # migration idempotente) au cas où la sauvegarde viendrait d'une version
            # un peu plus ancienne. Best-effort : n'invalide pas une restauration réussie.
            try:
                from .db import init_db
                init_db()
            except Exception:
                log.exception("Migration du schéma après restauration en échec (non bloquant).")
            if prof_data is not None:
                _atomic_write(DATA_DIR / "praticien.json", prof_data)
            if sig_name and sig_data is not None:
                # On retire d'abord toute ancienne signature (extension différente).
                for old in _SIGNATURE_NAMES:
                    _unlink_with_retry(DATA_DIR / old)
                _atomic_write(DATA_DIR / sig_name, sig_data)
        except Exception as exc:
            log.exception("Restauration en échec pendant l'écriture.")
            return {
                "ok": False,
                "message": ("La restauration a échoué pendant l'écriture des fichiers "
                            f"({exc}). Fermez les autres actions en cours et réessayez ; "
                            "vos données précédentes n'ont pas été perdues."),
            }

    n = _count_patients()
    log.info("Sauvegarde restaurée (%d patient(s)).", n)
    return {"ok": True, "message": f"Sauvegarde restaurée — {n} patient(s) dans la base.", "patients": n}
