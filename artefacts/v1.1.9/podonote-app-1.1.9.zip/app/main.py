"""PodoNote — application FastAPI (UI web locale + page upload iPhone)."""
from __future__ import annotations

import io
import secrets

from fastapi import FastAPI, Form, Request, UploadFile
from fastapi.responses import (
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    Response,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from . import (
    auth, backup, bilan, clinical, compta, exercices as exercices_mod, fiches,
    license, ordonnance, papiers, photos as photos_mod, prescription,
    produits, profile as practitioner, repository as repo, rgpd, security, soin,
    sterilisation as steril, updater, volodalen,
)
from .config import APP_DISPLAY_NAME, DATA_DIR, STATIC_DIR, TEMPLATES_DIR, settings
from .db import init_db
from .pipeline import llm
from .pipeline import runner
from .pipeline.transcribe import check_dependencies as check_whisper
from . import utils
from .utils import UploadTooLarge, date_fr, get_lan_ip, is_allowed_audio, save_upload

# Identifiant unique de CE démarrage : permet à l'UI de détecter de façon fiable
# qu'une mise à jour a bien redémarré l'app (le boot_id change), sans dépendre de
# l'observation fragile d'un « serveur tombé puis revenu ».
BOOT_ID = secrets.token_hex(8)

app = FastAPI(title="Diktae", docs_url=None, redoc_url=None)
app.add_middleware(
    SessionMiddleware,
    secret_key=security.get_or_create_secret(),
    max_age=86400 * 7,
    same_site="strict",   # app locale, aucune navigation cross-site légitime
    https_only=False,     # LAN en HTTP ; passer à True derrière un reverse-proxy HTTPS
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Chemins accessibles depuis le LAN (page d'upload iPhone + ses ressources).
# Tout le reste de l'app — fiches patients, réglages, exports — n'est servi
# qu'en loopback : la fenêtre WebView2 parle à 127.0.0.1, le LAN n'a pas à
# voir les données de santé transiter en HTTP clair.
_LAN_ALLOWED_PREFIXES = ("/upload", "/static", "/healthz")
# "testclient" : hôte que pose le TestClient de Starlette (smoke tests). Sans
# risque : request.client vient du socket TCP, pas d'un en-tête falsifiable.
_LOOPBACK_HOSTS = {"127.0.0.1", "::1", "localhost", "testclient"}


def _is_loopback(request: Request) -> bool:
    host = getattr(request.client, "host", "") or ""
    return host in _LOOPBACK_HOSTS


@app.middleware("http")
async def gate(request: Request, call_next):
    """Portail d'accès : 0) périmètre LAN, 1) configuration initiale, 2) licence."""
    path = request.url.path
    # 0. Hors loopback, seule la page d'upload (et ses ressources) est servie.
    #    Échappatoire .env (LAN_FULL_ACCESS=true) si un usage multi-poste
    #    assumé apparaît un jour — à ne PAS activer sans VPN/TLS.
    if (not _is_loopback(request)
            and not settings.lan_full_access
            and not any(path.startswith(p) for p in _LAN_ALLOWED_PREFIXES)):
        return Response("Accès réservé au poste local.", status_code=403)
    response = None
    if path.startswith("/static") or path == "/healthz":
        response = await call_next(request)
        _add_security_headers(response)
        return response
    # 1. Identifiants non créés -> assistant de configuration
    if not security.is_configured() and path != "/setup":
        return RedirectResponse("/setup", status_code=303)
    # 2. Licence exigée et absente/expirée -> écran d'activation.
    # L'exigence est décidée par le CODE (license.is_enforced) afin de se propager
    # par OTA : le .env du poste, lui, n'est jamais redistribué.
    if (license.is_enforced() and security.is_configured()
            and not license.is_allowed()
            and path not in ("/setup", "/license", "/logout")):
        return RedirectResponse("/license", status_code=303)
    response = await call_next(request)
    _add_security_headers(response)
    return response


def _add_security_headers(response) -> None:
    """Défense en profondeur : anti-clickjacking, anti-MIME-sniffing, CSP.

    'unsafe-inline' est requis par les scripts/styles inline des templates ;
    la CSP bloque néanmoins toute ressource externe (l'app est 100 % locale).
    frame-src/object-src incluent 'blob:' : l'aperçu PDF intégré (ordonnance,
    tiroir) charge le PDF généré dans une iframe via un object-URL `blob:` ;
    sans 'blob:', WebView2/Edge bloque l'affichage (« ce contenu a été bloqué »)."""
    h = response.headers
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("Referrer-Policy", "no-referrer")
    h.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
        "media-src 'self' blob:; frame-src 'self' blob:; object-src 'self' blob:; "
        "frame-ancestors 'none'",
    )


templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
templates.env.globals["app_name"] = APP_DISPLAY_NAME
templates.env.globals["bilan"] = bilan          # vocabulaires + helpers d'affichage du bilan
templates.env.globals["soin"] = soin            # vocabulaires + helpers de la fiche de soin
templates.env.globals["volodalen"] = volodalen  # vocabulaires + calculs préférence motrice
templates.env.globals["fiches"] = fiches        # registre des types de fiche
templates.env.globals["MEDICAL_FLAGS"] = clinical.MEDICAL_FLAGS
templates.env.globals["CARE_TAGS"] = clinical.CARE_TAGS
templates.env.globals["flags_detail"] = clinical.flags_detail
templates.env.globals["tags_detail"] = clinical.tags_detail
templates.env.globals["steril_programmes"] = steril.PROGRAMMES
templates.env.globals["steril_helix"] = steril.HELIX
templates.env.globals["steril_integrateurs"] = steril.INTEGRATEURS


def _bitlocker_warning() -> bool:
    """True si le volume système est CONFIRMÉ non chiffré (bandeau base.html).

    Multiplateforme : BitLocker (Windows) ou FileVault (macOS)."""
    from . import hostcheck
    return hostcheck.disk_encryption_protected() is False


def _disk_encryption_name() -> str:
    from . import hostcheck
    return hostcheck.encryption_name()


templates.env.globals["bitlocker_warning"] = _bitlocker_warning
templates.env.globals["disk_encryption_name"] = _disk_encryption_name


def _demo_status() -> dict | None:
    """Statut de la licence DÉMO pour le bandeau permanent (base.html).

    None hors démo (aucun bandeau). Sinon : jours restants + minutes restantes,
    le premier des deux épuisé mettant fin à l'essai."""
    try:
        st = license.get_status()
        return st if st.get("demo") else None
    except Exception:
        return None


templates.env.globals["demo_status"] = _demo_status


# --- Rail de navigation (base.html) ---------------------------------------- #
def _nav_badge() -> int:
    """Nombre de fiches à relire/valider — badge de l'item Patients du rail."""
    try:
        return len(repo.list_to_validate())
    except Exception:
        return 0


def _nav_user() -> dict:
    """Praticien affiché en bas du rail (nom, rôle, initiales)."""
    try:
        p = practitioner.load()
        name = (p.get("nom") or "").strip() or "Praticien"
        role = (p.get("titre") or "").strip() or "Pédicure-podologue"
    except Exception:
        name, role = "Praticien", "Pédicure-podologue"
    words = [w for w in name.replace("—", " ").replace("-", " ").split() if w[:1].isalpha()]
    initials = "".join(w[0] for w in words[:2]).upper() or "DK"
    return {"name": name, "role": role, "initials": initials}


templates.env.globals["nav_badge"] = _nav_badge
templates.env.globals["nav_user"] = _nav_user


# --- Filtres d'affichage (dates FR, âge) ----------------------------------- #
def _age(value):
    """Âge en années révolues à partir d'une date de naissance ISO. None si absent."""
    if not value:
        return None
    from datetime import date as _date
    try:
        y, m, d = (int(x) for x in str(value)[:10].split("-"))
        today = _date.today()
        return today.year - y - ((today.month, today.day) < (m, d))
    except (ValueError, TypeError):
        return None


templates.env.filters["date_fr"] = date_fr
templates.env.filters["age"] = _age
templates.env.filters["euro"] = compta.euro


def _setup_logging() -> None:
    import logging
    from .config import DATA_DIR, ensure_dirs
    ensure_dirs()
    handlers = [logging.StreamHandler()]
    try:
        handlers.append(logging.FileHandler(DATA_DIR / "podonote.log", encoding="utf-8"))
    except Exception:
        pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
    )


@app.on_event("startup")
def _startup() -> None:
    _setup_logging()
    import logging
    log = logging.getLogger("podonote")
    # Base : ne JAMAIS faire échouer le démarrage du serveur (sinon le port ne
    # s'ouvre pas et l'app paraît « ne pas démarrer »). On démarre en mode dégradé
    # plutôt que de planter sur une base verrouillée/corrompue.
    try:
        init_db()
        compta.ensure_seed()   # catalogue d'actes tarifés (validé, éditable)
    except Exception:
        log.exception("init_db a échoué — démarrage en mode dégradé.")
    # Diagnostic : trace l'emplacement des données et leur présence. Précieux si
    # l'app rouvrait sur l'écran de première configuration après une mise à jour
    # (révèle immédiatement un dossier `data/` introuvable ou un auth.json absent).
    try:
        log.info(
            "Démarrage boot_id=%s data=%s auth.json=%s podonote.db=%s",
            BOOT_ID, DATA_DIR, (DATA_DIR / "auth.json").exists(),
            (DATA_DIR / "podonote.db").exists(),
        )
    except Exception:
        log.exception("Diagnostic de démarrage impossible (non bloquant).")
    # Purge RGPD des audios orphelins + reprise des traitements en attente,
    # différées hors du chemin critique de démarrage et protégées.
    def _post_start() -> None:
        try:
            runner.purge_orphan_audio()
        except Exception:
            log.exception("Purge des audios orphelins en échec (non bloquant).")
        try:
            n = runner.resume_pending()
            log.info("Démarrage : %d consultation(s) reprise(s).", n)
        except Exception:
            log.exception("Reprise des consultations en échec (non bloquant).")
    import threading
    threading.Timer(3.0, _post_start).start()  # ne concurrence pas le démarrage (disque lent)
    # Vérification des mises à jour en tâche de fond (le bandeau lit le cache).
    updater.start_background_checks()
    # Modèles de diarisation embarqués : récupérés en tâche de fond au premier
    # lancement (aucun compte HuggingFace côté client — remarque de Nico).
    from . import diarization_models
    diarization_models.start_background_download()
    # Chiffrement au repos : la base repose sur BitLocker — on vérifie qu'il est
    # actif et on affiche un avertissement persistant dans l'UI sinon.
    from . import hostcheck
    hostcheck.start_background_check()


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def render(request: Request, name: str, **ctx) -> HTMLResponse:
    ctx["request"] = request
    # Messages flash : récupérés puis vidés à chaque rendu.
    ctx.setdefault("flashes", _pop_flashes(request))
    return templates.TemplateResponse(name, ctx)


def flash(request: Request, message: str, kind: str = "success") -> None:
    """Empile un message de confirmation affiché à la prochaine page."""
    request.session.setdefault("_flashes", []).append({"msg": message, "kind": kind})


def _pop_flashes(request: Request) -> list[dict]:
    try:
        return request.session.pop("_flashes", [])
    except Exception:
        return []


def _guard(request: Request):
    return auth.require_login(request)


def _guard_json(request: Request):
    """Garde d'authentification pour les endpoints appelés en fetch/XHR.

    Renvoie une erreur 401 JSON (au lieu de la redirection 303 HTML de `_guard`,
    qu'un `fetch` suit en silence pour récupérer la page de login en HTML — le JS
    plante alors sur `response.json()` au lieu d'inviter à se reconnecter)."""
    if not auth.is_authenticated(request):
        return JSONResponse(
            {"error": "unauthorized", "redirect": "/login"}, status_code=401
        )
    return None


def _ascii_filename(name: str) -> str:
    """Nom de fichier ASCII pour l'en-tête Content-Disposition (les accents d'un
    nom patient — Lefèvre… — produiraient un en-tête HTTP invalide)."""
    import unicodedata
    folded = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    return folded or "export"


# Dossier d'export PDF du patient : helpers partagés (app/utils.py) avec
# rgpd.py, qui doit supprimer ce dossier lors d'un effacement définitif.
_patient_export_dir = utils.patient_export_dir


def _save_pdf(patient: dict | None, fname: str, data: bytes):
    """Enregistre le PDF dans Documents\\<app>\\<patient> (retrouvable plus
    tard) — ou dans le sous-dossier « Compta » pour un document sans patient
    rattaché (facture libre). Renvoie le chemin écrit, ou None en cas d'échec."""
    import logging
    try:
        if patient:
            path = _patient_export_dir(patient) / fname
        else:
            root = utils.export_root(create=True) / "Compta"
            root.mkdir(parents=True, exist_ok=True)
            path = root / fname
        path.write_bytes(data)
        return path
    except Exception:
        logging.getLogger("podonote").exception("Enregistrement du PDF impossible.")
        return None


def _open_path(path) -> bool:
    """Ouvre un fichier dans l'application par défaut du système (lecteur PDF).

    Multiplateforme : `os.startfile` (Windows), `open` (macOS), `xdg-open` (Linux),
    avec repli navigateur (file://)."""
    import os
    # Contexte sans interface (tests automatisés, serveur headless) : on n'ouvre
    # rien mais on signale « pris en charge » pour ne pas déclencher de repli.
    if os.environ.get("PODONOTE_NO_OPEN") == "1":
        return True
    from .platform_compat import open_path
    return open_path(path)


def _deliver_pdf(request: Request, data: bytes, fname: str, patient: dict) -> Response:
    """Renvoie un PDF en gérant le piège de la fenêtre native.

    Dans la fenêtre WebView2, l'affichage *inline* en pleine page remplace l'app
    par la visionneuse PDF intégrée, qui ne se referme qu'en quittant PodoNote. Le
    front indique donc un mode via `?deliver=` quand il tourne dans la fenêtre
    native (window.pywebview) :
      - `open`    : on enregistre dans Documents\\Diktae et on ouvre dans le
                    lecteur système (fenêtre indépendante) → 204 (pas de navigation).
      - `preview` : on enregistre puis on RENVOIE le PDF, que le front affiche
                    dans un aperçu intégré (iframe en modale, refermable).
    Sans mode (vrai navigateur), affichage inline classique (onglet refermable)."""
    mode = request.query_params.get("deliver")
    if mode == "open":
        path = _save_pdf(patient, fname, data)
        if path is not None and _open_path(path):
            return Response(status_code=204)
        # Échec (Documents indisponible, lecteur absent) : réponse non-204 SANS
        # corps PDF → le front bascule sur window.open (fenêtre refermable),
        # au lieu de recevoir un PDF inline dans un fetch qu'il ignorerait.
        return JSONResponse(
            {"error": "Enregistrement/ouverture du PDF impossible."}, status_code=500
        )
    elif mode == "preview":
        _save_pdf(patient, fname, data)  # best-effort : reste retrouvable.
    return Response(
        content=data, media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{fname}"'},
    )


# --------------------------------------------------------------------------- #
# Authentification
# --------------------------------------------------------------------------- #
@app.get("/setup", response_class=HTMLResponse)
def setup_page(request: Request):
    # is_configured() est ROBUSTE : True si des identifiants existent OU si le
    # fichier est présent mais illisible (fail-closed) -> on n'autorise alors PAS
    # /setup à écraser des identifiants sans authentification. (Un fichier neuf
    # ne contenant que le secret de session reste, lui, « non configuré ».)
    if security.is_configured():
        return RedirectResponse("/login", status_code=303)
    return render(request, "setup.html", error=None)


@app.post("/setup")
def setup_submit(
    request: Request,
    password: str = Form(""),
    password2: str = Form(""),
    pin: str = Form(""),
):
    if security.is_configured():
        return RedirectResponse("/login", status_code=303)
    err = None
    if len(password) < 8:
        err = "Le mot de passe doit faire au moins 8 caractères."
    elif password != password2:
        err = "Les deux mots de passe ne correspondent pas."
    elif not (pin.isdigit() and 6 <= len(pin) <= 8):
        err = "Le code PIN doit comporter de 6 à 8 chiffres."
    if err:
        return render(request, "setup.html", error=err)
    security.configure(password, pin)
    auth.login_session(request)
    return RedirectResponse("/", status_code=303)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if auth.is_authenticated(request):
        return RedirectResponse("/", status_code=303)
    return render(request, "login.html", error=None)


@app.post("/login")
def login_submit(request: Request, password: str = Form("")):
    # Limiteur PAR IP : avec une clé globale, 5 mauvais mots de passe envoyés
    # par n'importe qui sur le LAN bloquaient la connexion du praticien (DoS).
    key = f"login:{getattr(request.client, 'host', '?')}"
    locked = security.login_limiter.locked_seconds(key)
    if locked:
        return render(request, "login.html",
                      error=f"Trop de tentatives. Réessayez dans {locked}s.")
    if auth.verify_password(password):
        security.login_limiter.reset(key)
        auth.login_session(request)
        return RedirectResponse("/", status_code=303)
    security.login_limiter.record_failure(key)
    return render(request, "login.html", error="Mot de passe incorrect.")


@app.post("/logout")
def logout(request: Request):
    # POST uniquement : en GET, un simple lien malveillant suffisait à déconnecter
    # le praticien (SameSite=lax laisse passer le cookie sur navigation GET).
    auth.logout_session(request)
    return RedirectResponse("/login", status_code=303)


@app.get("/license", response_class=HTMLResponse)
def license_page(request: Request):
    return render(request, "license.html",
                  status=license.get_status(), machine=license.machine_display(),
                  error=None, success=None)


@app.post("/license")
def license_submit(request: Request, token: str = Form("")):
    ok, msg = license.activate(token)
    if ok:
        return render(request, "license.html",
                      status=license.get_status(), machine=license.machine_display(),
                      error=None, success=msg)
    return render(request, "license.html",
                  status=license.get_status(), machine=license.machine_display(),
                  error=msg, success=None)


# --------------------------------------------------------------------------- #
# Accueil / liste patients
# --------------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse)
def home(request: Request, q: str = "", filter: str = "", sort: str = "nom",
         tag: str = "", cabinet: str = ""):
    if redirect := _guard(request):
        return redirect
    # Sélecteur de cabinet (multi-sites) : le choix est mémorisé en session.
    cabinets = repo.list_cabinets()
    cabinet_ids = {c["id"] for c in cabinets}
    if cabinet == "all":
        request.session.pop("cabinet_id", None)
    elif cabinet and cabinet.isdigit() and int(cabinet) in cabinet_ids:
        request.session["cabinet_id"] = int(cabinet)
    current_cabinet = request.session.get("cabinet_id")
    if current_cabinet not in cabinet_ids:   # cabinet supprimé / invalide
        current_cabinet = None
        request.session.pop("cabinet_id", None)

    # Filtre « Archivés » : dossiers des patients partis (déménagement, décès).
    # Ailleurs, les archivés sont exclus (listes, relances) — retour Nico.
    patients = repo.list_patients(search=q or None, cabinet_id=current_cabinet,
                                  archived=(filter == "archive"))
    to_validate = repo.list_to_validate()
    in_error = repo.list_in_error()
    processing = repo.list_processing()
    queued = repo.list_queued()

    # Compteurs du sous-titre (globaux au cabinet sélectionné, hors recherche).
    all_patients = repo.list_patients(cabinet_id=current_cabinet) if q else patients
    risk_flag_keys = {f["key"] for f in clinical.MEDICAL_FLAGS if f["severity"] == "high"}
    counts = {
        "total": len(all_patients),
        "relire": len(to_validate),
        "risk": sum(1 for p in all_patients
                    if risk_flag_keys & set(p.get("medical_flags") or [])),
    }

    # Filtres rapides
    if filter == "risk":
        risk_keys = {f["key"] for f in clinical.MEDICAL_FLAGS if f["severity"] == "high"}
        patients = [p for p in patients if risk_keys & set(p.get("medical_flags") or [])]
    elif filter == "tovalidate":
        ids = {c["patient_id"] for c in to_validate}
        patients = [p for p in patients if p["id"] in ids]
    elif filter == "recontact":
        # Patients vus pour la dernière fois il y a PLUS d'un an (à recontacter
        # pour un contrôle). Compare les dates au format AAAA-MM-JJ (10 car.).
        from datetime import date as _date, timedelta as _td
        cutoff = (_date.today() - _td(days=365)).isoformat()
        patients = [
            p for p in patients
            if (p.get("derniere_consultation") or "")[:10]
            and p["derniere_consultation"][:10] < cutoff
        ]
        # Le plus ancien d'abord : ceux à rappeler en priorité en haut.
        patients.sort(key=lambda p: p.get("derniere_consultation") or "")

    # Filtre par étiquette de soin
    if tag in {t["key"] for t in clinical.CARE_TAGS}:
        ids = repo.patient_ids_with_tag(tag)
        patients = [p for p in patients if p["id"] in ids]
    else:
        tag = ""

    # Tri (nom par défaut, ou dernière visite la plus récente)
    if sort == "recent":
        patients.sort(key=lambda p: p.get("derniere_consultation") or "", reverse=True)

    return render(request, "patients.html", patients=patients, q=q, counts=counts,
                  current_filter=filter, current_sort=sort, current_tag=tag,
                  cabinets=cabinets, current_cabinet=current_cabinet,
                  to_validate=([] if q else to_validate),
                  in_error=([] if q else in_error),
                  processing=([] if q else processing),
                  queued=([] if q else queued),
                  tags_used=repo.tags_in_use(),
                  annees=repo.consultations_per_year())


@app.post("/patients")
def create_patient(
    request: Request,
    nom: str = Form(...),
    prenom: str = Form(...),
    date_naissance: str = Form(""),
    sexe: str = Form(""),
    cabinet_id: str = Form(""),
    notes: str = Form(""),
    medical_flags: list[str] = Form(default=[]),
):
    if redirect := _guard(request):
        return redirect
    # Par défaut, rattache au cabinet actuellement sélectionné sur l'accueil.
    cid = cabinet_id or request.session.get("cabinet_id") or ""
    pid = repo.create_patient(nom, prenom, date_naissance, notes, medical_flags, sexe, cid)
    flash(request, f"Dossier de {prenom} {nom} créé.")
    return RedirectResponse(f"/patients/{pid}", status_code=303)


@app.post("/patients/quick")
def create_patient_quick(
    request: Request,
    nom: str = Form(...),
    prenom: str = Form(...),
    date_naissance: str = Form(""),
    sexe: str = Form(""),
):
    """Création EXPRESS d'un patient depuis la page d'enregistrement (fetch/XHR).

    Débloque le cas « je viens d'enregistrer une consultation mais le patient
    n'est pas encore dans ma base » : jusqu'ici, créer le patient obligeait à
    quitter la page, ce qui PERDAIT l'enregistrement (blob en mémoire du
    navigateur, jamais persisté). On crée donc le dossier sans navigation et on
    renvoie l'id + le libellé à injecter dans le sélecteur, pour attribuer l'audio
    déjà enregistré. Les champs médicaux / cabinet se complètent ensuite depuis la
    fiche patient."""
    if redirect := _guard_json(request):
        return redirect
    nom = (nom or "").strip()
    prenom = (prenom or "").strip()
    if not nom or not prenom:
        return JSONResponse({"error": "Nom et prénom sont obligatoires."}, status_code=400)
    # Rattache au cabinet actuellement sélectionné (comme la création classique).
    cabinet_id = request.session.get("cabinet_id") or ""
    pid = repo.create_patient(nom, prenom, date_naissance, None, None, sexe, cabinet_id)
    return JSONResponse({"id": pid, "label": f"{prenom} {nom}"})


@app.post("/patients/{patient_id}/archive")
def set_archive(request: Request, patient_id: int, archived: str = Form("1")):
    """Archive / réactive un dossier patient (retour Nico : patients partis, DCD).

    Rien n'est supprimé : le dossier sort simplement des listes courantes et des
    relances, et reste consultable dans le filtre « Archivés »."""
    if redirect := _guard(request):
        return redirect
    if not repo.get_patient(patient_id):
        return RedirectResponse("/", status_code=303)
    on = archived == "1"
    repo.set_archived(patient_id, on)
    flash(request, "Dossier archivé — il reste consultable dans « Archivés »."
          if on else "Dossier réactivé.")
    return RedirectResponse("/?filter=archive" if on else f"/patients/{patient_id}",
                            status_code=303)


@app.post("/patients/{patient_id}/recontact")
def set_recontact(request: Request, patient_id: int, status: str = Form("")):
    """Onglet « À recontacter (+1 an) » : marque le suivi du rappel.

    '' = à recontacter · 'attente' = recontacté, en attente d'un retour · 'fait' = recontacté."""
    if redirect := _guard(request):
        return redirect
    if repo.get_patient(patient_id):
        repo.set_recontact_status(patient_id, status)
    return RedirectResponse("/?filter=recontact", status_code=303)


@app.get("/patients/{patient_id}", response_class=HTMLResponse)
def patient_detail(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    consultations = repo.list_consultations(patient_id)
    cabinets = repo.list_cabinets()
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    ordonnances = repo.list_ordonnances(patient_id)
    exercice_fiches = repo.list_exercice_fiches(patient_id)
    # Poches de stérilisation rattachées à chaque soin (frise chrono, retour Nico).
    sachets_map = steril.sachets_by_consultation(patient_id)
    # Factures & devis du patient (encart du dossier — retour Nico).
    factures = compta.list_factures_patient(patient_id)
    # Prochain contrôle de SEMELLES : un an après le dernier bilan podologique ou
    # préférence motrice. Retour Nico : la relance annuelle n'a de sens que pour
    # l'appareillage — un simple soin de pédicurie ne la déclenche pas.
    next_control = None
    _bilan_types = ("podologie", "volodalen")
    _dernier_bilan = next((c for c in consultations
                           if (c.get("bilan_type") or "podologie") in _bilan_types), None)
    if _dernier_bilan:
        from datetime import date as _date, timedelta as _td
        try:
            y, m, d = (int(x) for x in _dernier_bilan["date"][:10].split("-"))
            next_control = (_date(y, m, d) + _td(days=365)).isoformat()
        except (ValueError, TypeError):
            pass
    # Grade de risque podologique (pied diabétique) du DERNIER bilan de soin qui
    # en porte un — affiché dans « En un coup d'œil » (retour Nico).
    diab_grade = None
    for c in consultations:
        if (c.get("bilan_type") == "soin") and isinstance(c.get("recap"), dict):
            g = (c["recap"].get("diabete") or {}).get("grade")
            if g is not None:
                diab_grade = g
                break
    # Fusion de doublons : tous les AUTRES dossiers (archivés compris — le
    # doublon a pu être archivé en attendant de savoir quoi en faire).
    autres_patients = sorted(
        (p for p in repo.list_patients() + repo.list_patients(archived=True)
         if p["id"] != patient_id),
        key=lambda p: (p["nom"].lower(), p["prenom"].lower()))
    return render(request, "patient_detail.html",
                  patient=patient, consultations=consultations,
                  cabinets=cabinets, cabinet=cabinet, ordonnances=ordonnances,
                  exercice_fiches=exercice_fiches, factures=factures,
                  sachets_map=sachets_map, next_control=next_control,
                  autres_patients=autres_patients,
                  diab_grade=diab_grade, grade_libelle=soin.GRADE_LIBELLE)


@app.get("/patients/{patient_id}/compare", response_class=HTMLResponse)
def compare_visits(request: Request, patient_id: int, a: int | None = None, b: int | None = None):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    done = [c for c in repo.list_consultations(patient_id)
            if c["status"] == "done" and c.get("recap")]
    if len(done) < 2:
        flash(request, "Il faut au moins deux fiches terminées pour comparer.", "error")
        return RedirectResponse(f"/patients/{patient_id}", status_code=303)
    by_id = {c["id"]: c for c in done}
    # Par défaut : avant = avant-dernière (done[1]), après = dernière (done[0]).
    ca = by_id.get(a) or done[1]
    cb = by_id.get(b) or done[0]
    return render(request, "compare.html", patient=patient, done=done, ca=ca, cb=cb)


@app.post("/patients/{patient_id}/edit")
def edit_patient(
    request: Request,
    patient_id: int,
    nom: str = Form(...),
    prenom: str = Form(...),
    date_naissance: str = Form(""),
    sexe: str = Form(""),
    cabinet_id: str = Form(""),
    notes: str = Form(""),
    medical_flags: list[str] = Form(default=[]),
):
    if redirect := _guard(request):
        return redirect
    old = repo.get_patient(patient_id)
    repo.update_patient(patient_id, nom, prenom, date_naissance, notes, medical_flags, sexe, cabinet_id)
    # Renommage : déplace le dossier d'export PDF pour qu'il reste retrouvable par
    # le nom courant (sinon des PDF nominatifs deviendraient orphelins, hors RGPD).
    new = repo.get_patient(patient_id)
    if old and new and (old.get("nom"), old.get("prenom")) != (new.get("nom"), new.get("prenom")):
        utils.migrate_patient_export_dir(old, new)
    flash(request, "Dossier mis à jour.")
    return RedirectResponse(f"/patients/{patient_id}", status_code=303)


@app.post("/patients/{patient_id}/delete")
def delete_patient(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    rgpd.delete_patient_record(patient_id)
    if patient:
        flash(request, f"Dossier de {patient['prenom']} {patient['nom']} supprimé définitivement.")
    return RedirectResponse("/", status_code=303)


@app.post("/patients/{patient_id}/merge")
def merge_patient(request: Request, patient_id: int, source_id: str = Form("")):
    """Fusionne un dossier DOUBLON dans le dossier courant (retour Nico : deux
    dossiers créés par erreur pour le même patient). Le dossier affiché est
    conservé ; tout l'historique du doublon lui est rattaché, puis le doublon
    est supprimé."""
    if redirect := _guard(request):
        return redirect
    target = repo.get_patient(patient_id)
    sid = int(source_id) if source_id.isdigit() else 0
    source = repo.get_patient(sid) if sid else None
    if not target:
        return RedirectResponse("/", status_code=303)
    if not source or sid == patient_id:
        flash(request, "Choisissez le dossier doublon à rattacher.", "error")
        return RedirectResponse(f"/patients/{patient_id}", status_code=303)
    moved = repo.merge_patients(sid, patient_id) or {}
    # Les PDF déjà exportés du doublon rejoignent le dossier d'export du patient
    # conservé (sinon ils deviendraient orphelins, hors du périmètre RGPD).
    utils.migrate_patient_export_dir(source, target)
    nb_consult = moved.get("consultations", 0)
    nb_docs = sum(moved.get(t, 0) for t in ("ordonnances", "exercices_fiches", "factures"))
    flash(request,
          f"Dossier de {source['prenom']} {source['nom']} fusionné dans celui-ci : "
          f"{nb_consult} consultation{'s' if nb_consult != 1 else ''} et "
          f"{nb_docs} document{'s' if nb_docs != 1 else ''} rattachés. "
          "Le doublon a été supprimé.")
    return RedirectResponse(f"/patients/{patient_id}", status_code=303)


# --------------------------------------------------------------------------- #
# Export RGPD
# --------------------------------------------------------------------------- #
@app.get("/patients/{patient_id}/export.json")
def export_patient_json(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    data = rgpd.export_json(patient_id)
    fname = _ascii_filename(f"dossier-{patient['nom']}-{patient['prenom']}.json")
    # Fenêtre native (WebView2) : un téléchargement `attachment` est IGNORÉ
    # (clic sans effet). Le lien porte `js-native-save` : le front demande alors
    # `deliver=save` → on écrit le fichier dans le dossier d'export du patient
    # et on l'ouvre dans l'Explorateur (même contrat que /reglages/sauvegarde).
    if request.query_params.get("deliver") == "save":
        import logging
        try:
            folder = _patient_export_dir(patient)
            path = folder / fname
            path.write_bytes(data if isinstance(data, bytes) else data.encode("utf-8"))
        except Exception:
            logging.getLogger("podonote.main").exception("Écriture de l'export JSON impossible.")
            return JSONResponse(
                {"error": "Enregistrement de l'export impossible."}, status_code=500
            )
        _open_path(folder)  # best-effort : l'échec d'ouverture n'invalide pas l'export.
        return JSONResponse({"ok": True, "name": fname, "path": str(path)})
    return Response(
        content=data, media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@app.get("/patients/{patient_id}/export.pdf")
def export_patient_pdf(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    data = rgpd.export_pdf(patient_id)
    import datetime
    fname = _ascii_filename(f"dossier-{datetime.date.today():%Y-%m-%d}.pdf")
    return _deliver_pdf(request, data, fname, patient)


# --------------------------------------------------------------------------- #
# Ordonnance (bilan + semelles orthopédiques)
# --------------------------------------------------------------------------- #
@app.get("/patients/{patient_id}/ordonnance", response_class=HTMLResponse)
def ordonnance_form(request: Request, patient_id: int):
    # Écran fusionné dans le hub Documents (onglet Ordonnance).
    if redirect := _guard(request):
        return redirect
    return RedirectResponse(f"/documents?tab=ordonnance&patient={patient_id}",
                            status_code=303)


def _ordonnance_ctx(patient: dict) -> dict:
    """Contexte de l'onglet Ordonnance du hub Documents (en-tête effectif,
    catalogue de prescription, suggestion de séances liée au grade)."""
    from datetime import date as _date
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    header = practitioner.effective_header(practitioner.load(), cabinet)
    # Suggestion « séances de prévention » : dernier bilan de soin gradé (2/3) du
    # patient -> propose le nombre de séances remboursables (lien C1 grade -> C2).
    seance_suggestion = None
    for cons in repo.list_consultations(patient["id"]):
        if cons.get("bilan_type") != "soin":
            continue
        diab = (cons.get("recap") or {}).get("diabete") or {}
        g = diab.get("grade")
        if g in (2, 3):
            n = soin.seances_remboursables(g, diab.get("plaie_en_cours"))
            seance_suggestion = {"grade": g, "n": n,
                                 "ligne": f"{n} séances de soins de prévention podologique "
                                          f"(pied diabétique grade {g})"}
            break  # list_consultations est trié du plus récent au plus ancien
    return dict(profile=header,
                profile_complete=practitioner.is_complete(header),
                cabinet=cabinet,
                default_lines="\n".join(header.get("lignes_defaut") or []),
                produits_favoris=header.get("produits_favoris") or [],
                produits=produits.list_produits(),
                today=f"{_date.today():%d/%m/%Y}",
                diagnostics=prescription.DIAGNOSTICS,
                topiques=prescription.TOPIQUES,
                pansements=prescription.PANSEMENTS,
                semelles=prescription.SEMELLES,
                diag_lines_map=prescription.diagnostic_lines_map(),
                line_map=prescription.line_map(),
                seance_suggestion=seance_suggestion)


@app.post("/patients/{patient_id}/ordonnance.pdf")
async def ordonnance_pdf(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    # En-tête effectif = profil praticien, surchargé par le cabinet du patient.
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    prof = practitioner.effective_header(practitioner.load(), cabinet)
    # Garde-fou serveur : pas d'ordonnance sans en-tête prescripteur valable
    # (nom + RPPS). Le formulaire affiche déjà un avertissement, mais l'avertissement
    # n'EMPÊCHE pas l'envoi — sinon on génèrerait une ordonnance médicalement invalide.
    if not practitioner.is_complete(prof):
        flash(request, "Profil praticien incomplet : renseignez le nom et le RPPS "
                       "dans Réglages (ou le cabinet) avant de générer une ordonnance.", "error")
        return RedirectResponse(f"/patients/{patient_id}/ordonnance", status_code=303)
    form = await request.form()
    ald = (form.get("ald") or "").strip()
    lignes = _lines(form.get("lignes") or "")
    if not lignes:
        lignes = list(prof.get("lignes_defaut") or [])
    data = ordonnance.build_ordonnance_pdf(patient, ald, lignes, prof)
    import datetime
    # Même convention de nommage que la fiche-bilan : « Ordonnance_NOM Prenom_Date »
    # (l'heure distingue deux ordonnances du même jour).
    fname = _ascii_filename(
        f"Ordonnance_{patient['nom'].upper()} {patient['prenom']}"
        f"_{datetime.datetime.now():%d-%m-%Y-%Hh%M}.pdf"
    )
    # Traçabilité : on note dans la fiche patient qu'une ordonnance a été générée.
    # On conserve aussi ALD + lignes pour pouvoir la REGÉNÉRER si le PDF disparaît.
    # `deliver=open` = réouverture dans le lecteur d'une ordonnance déjà prévisualisée
    # (bouton « Enregistrer / ouvrir ») : on ne crée PAS une 2ᵉ entrée au journal.
    if request.query_params.get("deliver") != "open":
        try:
            repo.add_ordonnance(patient_id, fname, ald=ald, lignes=lignes)
        except Exception:
            import logging
            logging.getLogger("podonote").exception("Journalisation de l'ordonnance impossible (non bloquant).")
    return _deliver_pdf(request, data, fname, patient)


@app.post("/patients/{patient_id}/ordonnance/{ordonnance_id}/delete")
def ordonnance_delete(request: Request, patient_id: int, ordonnance_id: int):
    """Supprime une ordonnance journalisée (retour Nico : corriger une erreur).

    Retire la ligne en base ET, si le PDF avait été écrit sur disque, le fichier
    associé (cohérence : plus visible dans la fiche = plus présent dans Documents)."""
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    ordo = repo.get_ordonnance(ordonnance_id)
    if ordo and ordo.get("patient_id") == patient_id:
        # Best-effort : retirer le PDF sur disque (ne bloque jamais la suppression).
        if ordo.get("fichier"):
            try:
                (_patient_export_dir(patient) / ordo["fichier"]).unlink(missing_ok=True)
            except OSError:
                logging.getLogger("podonote").warning(
                    "Suppression du PDF d'ordonnance impossible (non bloquant).")
        repo.delete_ordonnance(ordonnance_id, patient_id)
        flash(request, "Ordonnance supprimée.")
    else:
        flash(request, "Ordonnance introuvable.", "error")
    return RedirectResponse(f"/patients/{patient_id}", status_code=303)


@app.get("/patients/{patient_id}/ordonnance/{ordonnance_id}.pdf")
def ordonnance_view(request: Request, patient_id: int, ordonnance_id: int):
    """Revisualise une ordonnance déjà générée depuis la fiche patient.

    Stratégie « les deux » : on rouvre le PDF enregistré sur disque s'il existe
    encore ; sinon on le REGÉNÈRE à partir d'ALD + lignes conservés en base.
    """
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    ordo = repo.get_ordonnance(ordonnance_id)
    if not ordo or ordo.get("patient_id") != patient_id:
        flash(request, "Ordonnance introuvable.", "error")
        return RedirectResponse(f"/patients/{patient_id}", status_code=303)

    # 1) Le PDF d'origine est-il encore sur disque ? (réouverture sans régénérer)
    if ordo.get("fichier"):
        path = _patient_export_dir(patient) / ordo["fichier"]
        if path.is_file():
            data = path.read_bytes()
            return _deliver_pdf(request, data, ordo["fichier"], patient)

    # 2) Repli : régénérer depuis le contenu conservé (ALD + lignes).
    if ordo.get("lignes"):
        cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
        prof = practitioner.effective_header(practitioner.load(), cabinet)
        data = ordonnance.build_ordonnance_pdf(patient, ordo.get("ald") or "", ordo["lignes"], prof)
        fname = ordo.get("fichier") or _ascii_filename(f"ordonnance-{ordonnance_id}.pdf")
        return _deliver_pdf(request, data, fname, patient)

    # 3) Ni fichier ni contenu (ancienne ordonnance, avant cette fonctionnalité).
    flash(request, "Le PDF de cette ordonnance n'est plus disponible (générée avant "
                   "l'archivage). Les ordonnances créées désormais resteront consultables.", "error")
    return RedirectResponse(f"/patients/{patient_id}", status_code=303)


# --------------------------------------------------------------------------- #
# Fiche d'exercices à remettre au patient (banque d'exercices -> PDF combiné)
# --------------------------------------------------------------------------- #
@app.get("/patients/{patient_id}/exercices", response_class=HTMLResponse)
def exercices_form(request: Request, patient_id: int):
    # Écran fusionné dans le hub Documents (onglet Fiche d'exercices).
    if redirect := _guard(request):
        return redirect
    return RedirectResponse(f"/documents?tab=exercices&patient={patient_id}",
                            status_code=303)


@app.get("/patients/{patient_id}/exercices.pdf")
def exercices_pdf(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    # ?ids=k1,k2 : on ne garde que les clés connues (ignore toute valeur parasite).
    ids_param = request.query_params.get("ids") or ""
    keys = [k.strip() for k in ids_param.split(",") if exercices_mod.exists(k.strip())]
    if not keys:
        flash(request, "Sélectionnez au moins un exercice.", "error")
        return RedirectResponse(f"/patients/{patient_id}/exercices", status_code=303)
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    header = practitioner.effective_header(practitioner.load(), cabinet)
    data = rgpd.export_exercices_pdf(patient_id, header, keys)
    # Journalise la fiche remise (retour Nico : retrouver une fiche prescrite).
    # `journal=1` n'est posé QUE par le bouton « Générer » du hub Documents ; la
    # réouverture d'une fiche archivée passe par une autre route (pas de doublon).
    if request.query_params.get("journal") == "1":
        repo.add_exercice_fiche(patient_id, keys)
    import datetime
    date_part = f"{datetime.date.today():%d-%m-%Y}"
    fname = _ascii_filename(
        f"Exercices_{patient['nom'].upper()} {patient['prenom']}_{date_part}.pdf")
    return _deliver_pdf(request, data, fname, patient)


@app.get("/patients/{patient_id}/exercices/{fiche_id}.pdf")
def exercices_fiche_view(request: Request, patient_id: int, fiche_id: int):
    """Rouvre une fiche d'exercices déjà remise (régénérée depuis les clés
    conservées) — retour Nico : la retrouver dans le dossier patient."""
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    fiche = repo.get_exercice_fiche(fiche_id)
    if not fiche or fiche.get("patient_id") != patient_id:
        flash(request, "Fiche d'exercices introuvable.", "error")
        return RedirectResponse(f"/patients/{patient_id}", status_code=303)
    keys = [k for k in (fiche.get("keys") or []) if exercices_mod.exists(k)]
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    header = practitioner.effective_header(practitioner.load(), cabinet)
    data = rgpd.export_exercices_pdf(patient_id, header, keys)
    fname = _ascii_filename(f"Exercices_{patient['nom'].upper()} {patient['prenom']}.pdf")
    return _deliver_pdf(request, data, fname, patient)


@app.post("/patients/{patient_id}/exercices/{fiche_id}/delete")
def exercices_fiche_delete(request: Request, patient_id: int, fiche_id: int):
    """Supprime une fiche d'exercices journalisée (erreur de saisie)."""
    if redirect := _guard(request):
        return redirect
    if repo.get_patient(patient_id):
        if repo.delete_exercice_fiche(fiche_id, patient_id):
            flash(request, "Fiche d'exercices supprimée.")
    return RedirectResponse(f"/patients/{patient_id}", status_code=303)


# --------------------------------------------------------------------------- #
# Contact pluridisciplinaire : courrier à un correspondant depuis le dossier
# --------------------------------------------------------------------------- #
@app.get("/patients/{patient_id}/courrier", response_class=HTMLResponse)
def courrier_form(request: Request, patient_id: int):
    # Écran fusionné dans le hub Documents (onglet Courrier).
    if redirect := _guard(request):
        return redirect
    return RedirectResponse(f"/documents?tab=courrier&patient={patient_id}",
                            status_code=303)


def _courrier_ctx(patient: dict) -> dict:
    """Contexte de l'onglet Courrier du hub Documents (annuaire, pièces jointes)."""
    consultations = [c for c in repo.list_consultations(patient["id"])
                     if c.get("status") == "done"]
    photos = []
    for c in consultations:
        for ph in repo.list_photos(c["id"]):
            ph = dict(ph)
            ph["cdate"] = c.get("date")
            photos.append(ph)
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    return dict(profile=practitioner.effective_header(practitioner.load(), cabinet),
                correspondants=repo.list_correspondants(),
                correspondant_types=repo.CORRESPONDANT_TYPES,
                consultations=consultations,
                ordonnances=repo.list_ordonnances(patient["id"]),
                photos=photos)


@app.post("/patients/{patient_id}/courrier.pdf")
async def courrier_pdf(request: Request, patient_id: int):
    if redirect := _guard(request):
        return redirect
    patient = repo.get_patient(patient_id)
    if not patient:
        return RedirectResponse("/", status_code=303)
    form = await request.form()

    def _ints(name: str) -> list[int]:
        return [int(x) for x in form.getlist(name) if str(x).isdigit()]

    corr_raw = form.get("correspondant") or ""
    correspondant = repo.get_correspondant(int(corr_raw)) if corr_raw.isdigit() else None
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    header = practitioner.effective_header(practitioner.load(), cabinet)
    data = rgpd.export_courrier_pdf(
        patient_id, header, correspondant,
        _ints("visites"), _ints("ordos"), _ints("photos"),
        (form.get("message") or "").strip(),
        detail_complet=bool(form.get("detail_complet")),
    )
    import datetime
    date_part = f"{datetime.date.today():%d-%m-%Y}"
    fname = _ascii_filename(
        f"Courrier_{patient['nom'].upper()} {patient['prenom']}_{date_part}.pdf")
    return _deliver_pdf(request, data, fname, patient)


# --------------------------------------------------------------------------- #
# Consultations
# --------------------------------------------------------------------------- #
@app.get("/consultations/new", response_class=HTMLResponse)
def new_consultation(request: Request, patient_id: int | None = None):
    if redirect := _guard(request):
        return redirect
    patients = repo.list_patients()
    selected = repo.get_patient(patient_id) if patient_id else None
    return render(request, "consultation_new.html",
                  patients=patients, selected=selected,
                  fiche_types=fiches.selectable_types())


@app.post("/consultations")
async def create_consultation(
    request: Request,
    patient_id: int = Form(...),
    consent: str = Form(""),
    audio: UploadFile = Form(...),
    defer: str = Form(""),
    bilan_type: str = Form("podologie"),
):
    if redirect := _guard_json(request):
        return redirect
    if consent != "on":
        return JSONResponse(
            {"error": "Le consentement du patient est obligatoire."}, status_code=400
        )
    patient = repo.get_patient(patient_id)
    if not patient:
        # Sans ce contrôle : IntegrityError (clé étrangère) → 500 brut affiché
        # « Erreur réseau » côté front si le patient a été supprimé entre-temps.
        return JSONResponse({"error": "Patient introuvable."}, status_code=404)
    # Préfixe opaque : pas d'identité patient dans le nom du fichier audio.
    prefix = f"patient-{patient_id}"
    if not is_allowed_audio(audio.filename):
        return JSONResponse(
            {"error": "Format audio non supporté (m4a, wav, mp3, ogg…)."}, status_code=400
        )
    try:
        path = save_upload(audio, prefix=prefix)
    except UploadTooLarge as exc:
        return JSONResponse({"error": str(exc)}, status_code=413)
    # File d'attente : on dépose l'audio SANS lancer la transcription (utile pour
    # grouper les transcriptions le soir sur une machine lente).
    queued = (defer == "on")
    cid = repo.create_consultation(
        patient_id, source="cabinet", consent_obtained=True, audio_path=str(path),
        status="queued" if queued else "pending",
        bilan_type=fiches.coerce_key(bilan_type),
    )
    if queued:
        flash(request, "Enregistrement déposé en file d'attente — à transcrire plus tard.")
    else:
        if settings.auto_process:
            runner.process_in_background(cid)
        flash(request, "Consultation enregistrée — traitement en cours.")
    return JSONResponse({"consultation_id": cid, "redirect": f"/consultations/{cid}"})


@app.post("/consultations/blank")
def create_blank_consultation(
    request: Request,
    patient_id: int = Form(...),
    lieu: str = Form("cabinet"),
    bilan_type: str = Form("podologie"),
):
    """Fiche SANS audio (patient refusant l'enregistrement) : bilan vierge créé
    directement, à compléter à la main via les menus."""
    if redirect := _guard(request):
        return redirect
    if not repo.get_patient(patient_id):
        return RedirectResponse("/", status_code=303)
    source = "domicile" if lieu == "domicile" else "cabinet"
    cid = repo.create_blank_consultation(patient_id, source,
                                         bilan_type=fiches.coerce_key(bilan_type))
    flash(request, "Fiche vierge créée (sans audio) — complétez-la puis validez.")
    return RedirectResponse(f"/consultations/{cid}/edit", status_code=303)


# --------------------------------------------------------------------------- #
# Anamnèse DICTÉE sur la page d'édition (retour Nico) : dicter l'anamnèse pendant
# qu'on coche le testing préférence motrice à la main. Le résultat (champs
# anamnèse + pratique sportive UNIQUEMENT) est renvoyé au CLIENT, qui remplit les
# inputs ; AUCUNE écriture du recap → le testing saisi à la main n'est jamais
# écrasé. Job en mémoire (app locale mono-processus).
# --------------------------------------------------------------------------- #
_ANAMNESE_JOBS: dict[int, dict] = {}


def _run_anamnese_job(cid: int, audio_path: str, bilan_type: str,
                      patient: dict | None) -> None:
    import logging
    import os as _os
    from .pipeline.transcribe import transcribe_and_diarize as _transcribe
    try:
        res = _transcribe(audio_path)
        text = getattr(res, "text_diarized", "") or ""
        recap = llm.generate_recap(text, patient=patient, bilan_type=bilan_type)
        fields = volodalen.anamnese_form_fields(recap)
        _ANAMNESE_JOBS[cid] = {"status": "done", "fields": fields}
    except Exception as exc:  # jamais de mort muette : l'erreur remonte au client
        logging.getLogger("podonote").exception("Anamnèse dictée : échec du traitement.")
        _ANAMNESE_JOBS[cid] = {"status": "error", "message": str(exc)}
    finally:
        try:
            _os.remove(audio_path)   # RGPD : l'audio ne persiste pas
        except OSError:
            pass


@app.post("/consultations/{consultation_id}/audio-anamnese")
async def audio_anamnese_start(request: Request, consultation_id: int,
                               audio: UploadFile = Form(...)):
    """Reçoit un enregistrement audio et lance sa transcription + analyse pour
    remplir l'anamnèse (le client récupère le résultat via l'endpoint /status)."""
    import threading as _threading
    if redirect := _guard_json(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c:
        return JSONResponse({"error": "Consultation introuvable."}, status_code=404)
    if not is_allowed_audio(audio.filename):
        return JSONResponse(
            {"error": "Format audio non supporté (m4a, wav, mp3, ogg, webm…)."},
            status_code=400)
    # Backend LLM indisponible → message clair tout de suite (pas de faux espoir).
    ok, msg = llm.check_llm()
    if not ok:
        return JSONResponse(
            {"error": f"Transcription indisponible : {msg}"}, status_code=503)
    try:
        path = save_upload(audio, prefix=f"anamnese-{consultation_id}")
    except UploadTooLarge as exc:
        return JSONResponse({"error": str(exc)}, status_code=413)
    patient = repo.get_patient(c["patient_id"]) if c.get("patient_id") else None
    _ANAMNESE_JOBS[consultation_id] = {"status": "pending"}
    _threading.Thread(
        target=_run_anamnese_job,
        args=(consultation_id, str(path), c.get("bilan_type") or "volodalen", patient),
        daemon=True, name=f"anamnese-{consultation_id}",
    ).start()
    return JSONResponse({"ok": True})


@app.get("/consultations/{consultation_id}/audio-anamnese/status")
def audio_anamnese_status(request: Request, consultation_id: int):
    """État du job d'anamnèse dictée. « done » renvoie les champs à remplir (et
    consomme le job) ; « error » renvoie le message ; sinon « pending »/« idle »."""
    if redirect := _guard_json(request):
        return redirect
    job = _ANAMNESE_JOBS.get(consultation_id)
    if not job:
        return JSONResponse({"status": "idle"})
    if job["status"] in ("done", "error"):
        _ANAMNESE_JOBS.pop(consultation_id, None)   # consommé une seule fois
    return JSONResponse(job)


@app.post("/consultations/reprise")
def create_reprise_consultation(
    request: Request,
    patient_id: int = Form(...),
    lieu: str = Form("cabinet"),
):
    """Fiche de SUIVI pré-remplie depuis la dernière fiche du patient (1 clic) :
    repart de toutes les infos de la visite précédente, à compléter/éditer."""
    if redirect := _guard(request):
        return redirect
    if not repo.get_patient(patient_id):
        return RedirectResponse("/", status_code=303)
    source = "domicile" if lieu == "domicile" else "cabinet"
    cid = repo.create_consultation_from_previous(patient_id, source)
    if not cid:
        flash(request, "Aucune fiche précédente à reprendre pour ce patient.", "error")
        return RedirectResponse(f"/patients/{patient_id}", status_code=303)
    flash(request, "Fiche de suivi pré-remplie depuis la dernière visite — "
                   "complétez seulement ce qui a changé.")
    return RedirectResponse(f"/consultations/{cid}/edit", status_code=303)


@app.get("/consultations/{consultation_id}", response_class=HTMLResponse)
def consultation_detail(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c:
        return RedirectResponse("/", status_code=303)
    patient = repo.get_patient(c["patient_id"])
    # Le sélecteur de sections du PDF ne propose que les sections RENSEIGNÉES dans
    # cette fiche (pas de cases pour des examens absents). Repli sur la liste
    # complète si rien n'est encore rempli, pour ne pas afficher une modale vide.
    # Les fiches soin / préférence motrice n'ont pas de sélecteur de sections :
    # PDF complet direct (lien .pdf intercepté par base.html).
    if c.get("bilan_type") in ("soin", "volodalen"):
        cr_sections = []
    else:
        present = rgpd.sections_present(c) if c.get("recap") else set()
        cr_sections = [(k, l) for k, l in rgpd.COMPTE_RENDU_SECTIONS if k in present] \
            or rgpd.COMPTE_RENDU_SECTIONS
    photos = repo.list_photos(consultation_id) if c.get("bilan_type") == "soin" else []
    return render(request, "consultation_detail.html", c=c, patient=patient,
                  cr_sections=cr_sections, photos=photos)


@app.get("/consultations/{consultation_id}/export.pdf")
def export_consultation_pdf(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c:
        return RedirectResponse("/", status_code=303)
    patient = repo.get_patient(c["patient_id"])
    if not patient:
        # Consultation orpheline (dossier patient supprimé entre-temps / incohérence
        # référentielle) : on ne génère pas un PDF qui planterait, on revient à l'accueil.
        return RedirectResponse("/", status_code=303)
    # En-tête prescripteur (comme l'ordonnance) : profil praticien, surchargé
    # par le cabinet du patient. Permet de remettre la fiche à un confrère.
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    header = practitioner.effective_header(practitioner.load(), cabinet)
    # Fiches à PDF dédié (pas de sélecteur de sections).
    if c.get("bilan_type") == "soin":
        data = rgpd.export_soin_pdf(consultation_id, header=header)
        date_part = "-".join(reversed((c.get("date") or "")[:10].split("-")))
        fname = _ascii_filename(
            f"Fiche de soin_{patient['nom'].upper()} {patient['prenom']}_{date_part}.pdf"
        )
        return _deliver_pdf(request, data, fname, patient)
    if c.get("bilan_type") == "volodalen":
        data = rgpd.export_volodalen_pdf(consultation_id, header=header)
        date_part = "-".join(reversed((c.get("date") or "")[:10].split("-")))
        fname = _ascii_filename(
            f"Preference motrice_{patient['nom'].upper()} {patient['prenom']}_{date_part}.pdf"
        )
        return _deliver_pdf(request, data, fname, patient)
    # Sélection de sections (compte rendu allégé pour un médecin) : ?sections=a,b,c.
    # Absent → fiche complète (rétrocompatible). On normalise (espaces/casse) et on
    # filtre sur les clés connues pour ignorer toute valeur parasite sans planter.
    # Si rien de valide ne reste, OU si tout est coché → fiche complète (None) : « vide »
    # et « absent » se comportent pareil, et « tout coché » == export complet habituel.
    sections_param = request.query_params.get("sections")
    sections = None
    if sections_param is not None:
        allowed = {k for k, _ in rgpd.COMPTE_RENDU_SECTIONS}
        sections = {s.strip().lower() for s in sections_param.split(",")
                    if s.strip().lower() in allowed}
        if not sections or sections == allowed:
            sections = None
    data = rgpd.export_consultation_pdf(consultation_id, header=header, sections=sections)
    # Nom demandé par Nico : « Bilan podologique_NOM Prenom_Date » (date JJ-MM-AAAA).
    # Suffixe « _extrait » pour un compte rendu partiel : évite d'écraser le PDF complet
    # déjà enregistré dans Documents\PodoNote pour la même consultation (même date).
    date_part = "-".join(reversed((c.get("date") or "")[:10].split("-")))
    suffix = "_extrait" if sections is not None else ""
    fname = _ascii_filename(
        f"Bilan podologique_{patient['nom'].upper()} {patient['prenom']}_{date_part}{suffix}.pdf"
    )
    return _deliver_pdf(request, data, fname, patient)


# --- Photos cliniques (avant/après) : upload / affichage / suppression --------
@app.post("/consultations/{consultation_id}/photos")
async def add_consultation_photo(
    request: Request,
    consultation_id: int,
    photo: UploadFile = Form(...),
    kind: str = Form("autre"),
    note: str = Form(""),
):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c:
        return RedirectResponse("/", status_code=303)
    dest = f"/consultations/{consultation_id}"
    raw = await photo.read()
    if not raw:
        flash(request, "Aucune image reçue.", "error")
        return RedirectResponse(dest, status_code=303)
    if len(raw) > photos_mod.MAX_INPUT_BYTES:
        flash(request, "Image trop volumineuse (max 30 Mo).", "error")
        return RedirectResponse(dest, status_code=303)
    if not photos_mod.is_supported_image(raw):
        flash(request, "Format non supporté : choisissez une photo JPEG ou PNG.", "error")
        return RedirectResponse(dest, status_code=303)
    try:
        data = photos_mod.reencode(raw)  # JPEG borné + EXIF/GPS supprimé
    except ValueError:
        flash(request, "Image illisible ou corrompue.", "error")
        return RedirectResponse(dest, status_code=303)
    repo.add_photo(consultation_id, data, mime="image/jpeg", kind=kind, note=note)
    flash(request, "Photo ajoutée.")
    return RedirectResponse(dest, status_code=303)


@app.get("/consultations/{consultation_id}/photos/{photo_id}")
def get_consultation_photo(request: Request, consultation_id: int, photo_id: int):
    if redirect := _guard(request):
        return redirect
    p = repo.get_photo(photo_id)
    if not p or p.get("consultation_id") != consultation_id:
        return Response(status_code=404)
    # Image INLINE : contrairement aux PDF, une image ne « prend pas » la fenêtre
    # WebView2. Cache privé court (donnée de santé, locale).
    return Response(content=p["data"], media_type=p.get("mime") or "image/jpeg",
                    headers={"Cache-Control": "private, max-age=60"})


@app.post("/consultations/{consultation_id}/photos/{photo_id}/delete")
def delete_consultation_photo(request: Request, consultation_id: int, photo_id: int):
    if redirect := _guard(request):
        return redirect
    p = repo.get_photo(photo_id)
    if p and p.get("consultation_id") == consultation_id:
        repo.delete_photo(photo_id)  # secure_delete=ON écrase le BLOB à la suppression
    flash(request, "Photo supprimée.")
    return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)


@app.get("/consultations/{consultation_id}/status")
def consultation_status(request: Request, consultation_id: int):
    if not auth.is_authenticated(request):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    c = repo.get_consultation(consultation_id)
    if not c:
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse({
        "status": c["status"],
        "progress": c.get("progress"),
        "error_message": c.get("error_message"),
    })


@app.post("/consultations/{consultation_id}/retry")
def retry_consultation(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    # Relançable avec l'audio OU un transcript déjà persisté (échec LLM : le
    # retry saute l'ASR et repart du transcript).
    if c and (c.get("audio_path") or (c.get("transcript_diarise") or "").strip()):
        # On n'écrit `pending` QUE si le traitement a réellement été enfilé :
        # sinon (double-clic pendant qu'un thread se termine en erreur), la
        # fiche resterait `pending` sans thread jusqu'au redémarrage.
        if runner.process_in_background(consultation_id):
            repo.reset_resume_attempts(consultation_id)  # relance manuelle : on repart à zéro
            repo.update_consultation_status(consultation_id, "pending", "En attente…")
            flash(request, "Traitement relancé.")
        else:
            flash(request, "Un traitement est déjà en cours pour cette consultation.", "error")
    return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)


# --------------------------------------------------------------------------- #
# File d'attente de transcription (traitement différé)
# --------------------------------------------------------------------------- #
def _launch_queued(consultation_id: int) -> bool:
    """Sort une consultation de la file d'attente et lance sa transcription."""
    if runner.process_in_background(consultation_id):
        repo.reset_resume_attempts(consultation_id)
        repo.update_consultation_status(consultation_id, "pending", "En attente…")
        return True
    return False


@app.post("/consultations/queue/run")
def run_queue(request: Request):
    """Lance la transcription de TOUTE la file d'attente (le pipeline les traite
    une par une, en série). Idéal en fin de journée."""
    if redirect := _guard(request):
        return redirect
    launched = sum(1 for cid in repo.list_queued_ids() if _launch_queued(cid))
    if launched:
        flash(request, f"{launched} transcription(s) lancée(s) — traitement en cours.")
    else:
        flash(request, "La file d'attente est vide.", "error")
    return RedirectResponse("/", status_code=303)


@app.post("/consultations/{consultation_id}/queue/run")
def run_queued_one(request: Request, consultation_id: int):
    """Lance la transcription d'UNE consultation de la file d'attente."""
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if c and c.get("status") == "queued":
        if _launch_queued(consultation_id):
            flash(request, "Transcription lancée — traitement en cours.")
        else:
            flash(request, "Un traitement est déjà en cours pour cette consultation.", "error")
    return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)


@app.get("/consultations/{consultation_id}/edit", response_class=HTMLResponse)
def edit_consultation_page(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c or not c.get("recap"):
        return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)
    patient = repo.get_patient(c["patient_id"])
    template = {
        "soin": "consultation_edit_soin.html",
        "volodalen": "consultation_edit_volodalen.html",
    }.get(c.get("bilan_type"), "consultation_edit.html")
    return render(request, template, c=c, patient=patient)


_STATUTS = ("à vérifier", "à creuser", "écartée")


def _parse_reflexions(raw: str) -> list[dict]:
    """Chaque ligne 'constat :: piste :: details :: statut' devient une réflexion.

    "details" et "statut" sont facultatifs ; on reste rétrocompatible avec
    l'ancien format à 3 champs ('constat :: piste :: statut') en détectant si le
    dernier champ est un statut connu."""
    out = []
    for line in (raw or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [p.strip() for p in line.split("::")]
        constat = parts[0] if parts else ""
        piste = parts[1] if len(parts) > 1 else ""
        details = ""
        statut = "à vérifier"
        extras = parts[2:]
        # Si le dernier champ ressemble à un statut connu, c'est le statut ;
        # le reste (le cas échéant) constitue les détails.
        if extras and extras[-1] in _STATUTS:
            statut = extras[-1]
            extras = extras[:-1]
        details = " :: ".join(p for p in extras if p)
        if constat or piste:
            out.append({"constat": constat, "piste": piste,
                        "details": details, "statut": statut or "à vérifier"})
    return out


def _parse_operations(raw: str) -> list[dict]:
    """Chaque ligne 'intervention :: date :: kiné(oui/non) :: séquelles' -> opération."""
    out = []
    for line in (raw or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [p.strip() for p in line.split("::")]
        intervention = parts[0] if parts else ""
        date = parts[1] if len(parts) > 1 else ""
        kine_raw = (parts[2] if len(parts) > 2 else "").strip().lower()
        sequelles = parts[3] if len(parts) > 3 else ""
        suivi_kine = None
        if kine_raw in ("oui", "yes", "true", "x", "✓", "o"):
            suivi_kine = True
        elif kine_raw in ("non", "no", "false", "n"):
            suivi_kine = False
        if intervention or date or sequelles:
            out.append({"intervention": intervention, "date": date,
                        "suivi_kine": suivi_kine, "sequelles": sequelles})
    return out


def _lines(raw: str) -> list[str]:
    return [x.strip() for x in (raw or "").splitlines() if x.strip()]


def _parse_soin_form(form) -> dict:
    """Reconstruit une fiche de soin depuis le formulaire, puis normalise via le
    schéma app/soin.py (actes validés, grade diabétique RECALCULÉ)."""
    import json as _json

    def g(name: str) -> str:
        return (form.get(name) or "").strip()

    def tri(name: str):
        """Sélecteur à 3 états 'oui'/'non'/'' -> True/False/None."""
        v = g(name)
        return True if v == "oui" else (False if v == "non" else None)

    actes: list = []
    raw_actes = g("actes_json")
    if raw_actes:
        try:
            parsed = _json.loads(raw_actes)
            if isinstance(parsed, list):
                actes = parsed
        except ValueError:
            actes = []

    raw_recap = {
        "tl_dr": g("tl_dr"),
        "motif": g("motif"),
        "actes": actes,
        "etat_pieds": {"cutane": g("etat_cutane"), "ungueal": g("etat_ungueal")},
        "diabete": {
            "concerne": tri("diab_concerne"),
            "neuropathie": tri("diab_neuropathie"),
            "aomi": tri("diab_aomi"),
            "deformation": tri("diab_deformation"),
            "antecedent_ulcere_amputation": tri("diab_antecedent"),
            "plaie_en_cours": tri("diab_plaie"),
            "note": g("diab_note"),
        },
        "conseils": g("conseils"),
        "suivi": g("suivi"),
        "reflexions_ia": _parse_reflexions(g("reflexions_ia")),
        "evolution_depuis_derniere_visite": g("evolution_depuis_derniere_visite") or None,
    }
    return soin.normalize(raw_recap)


def _soin_grade_missing(recap: dict, patient_id: int) -> bool:
    """Garde-fou médico-légal : True si la fiche de soin NE PEUT PAS être validée
    car le patient est diabétique (flag patient OU fiche) et le bilan de gradation
    n'est pas abouti (grade non calculé — faute de neuropathie renseignée)."""
    diab = (recap or {}).get("diabete") or {}
    patient = repo.get_patient(patient_id) or {}
    flags = patient.get("medical_flags") or []
    diabetique = ("diabete" in flags) or (diab.get("concerne") is True)
    return diabetique and diab.get("grade") is None


def _parse_volodalen_form(form) -> dict:
    """Reconstruit une fiche préférence motrice depuis le formulaire, puis normalise
    (schéma app/volodalen.py : cadran et association recalculés à l'affichage)."""
    def g(name: str) -> str:
        return (form.get(name) or "").strip()

    raw = {
        "tl_dr": g("tl_dr"),
        "anamnese": {
            "motif": g("motif"),
            "plainte": {"localisation": g("plainte_localisation"), "depuis": g("plainte_depuis"),
                        "moment": g("plainte_moment"),
                        "modification_habitudes": g("plainte_modification_habitudes")},
            "pathologies_chroniques": g("pathologies_chroniques"),
            "operation_membre_inf": g("operation_membre_inf"),
            "operation_membre_sup_dos": g("operation_membre_sup_dos"),
            "poids": g("poids"), "taille": g("taille"),
            "activite_professionnelle": g("activite_professionnelle"),
        },
        "pratique_sportive": {
            "sports": g("sports"), "niveau": g("niveau"), "intensite": g("intensite"),
            "objectifs": g("objectifs"), "blessures_anterieures": g("blessures_anterieures"),
        },
        "flexion_extension": {"exces": g("fe_exces"), "preference": g("fe_preference"),
                              "chaine": g("fe_chaine")},
        "mouvement": {"jambe_extension": g("mv_jambe"), "lateralisation": g("mv_lateralisation")},
        "cadran": {"point2": g("cadran_point2"), "point3": g("cadran_point3")},
        "association": g("association"),
        "complementaire": {"axial_large": g("axial_large"), "epaule_motrice": g("epaule_motrice")},
        "reflexes_archaiques": g("reflexes_archaiques"),
        "exercices": form.getlist("exercices"),
        "synthese": {"note": g("synthese_note")},
        "reflexions_ia": _parse_reflexions(g("reflexions_ia")),
        "evolution_depuis_derniere_visite": g("evolution_depuis_derniere_visite") or None,
    }
    return volodalen.normalize(raw)


@app.post("/consultations/{consultation_id}/edit")
async def edit_consultation_submit(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c:
        return RedirectResponse("/", status_code=303)

    form = await request.form()

    # Fiche de soin (pédicurie) : parsing + normalisation dédiés (schéma app/soin.py).
    if c.get("bilan_type") == "soin":
        recap = _parse_soin_form(form)
        valider = (form.get("valider") or "").strip() == "on"
        lieu = (form.get("source_lieu") or "").strip()
        if lieu in ("cabinet", "domicile") and lieu != c.get("source"):
            repo.update_consultation_source(consultation_id, lieu)
        # Garde-fou : un patient diabétique ne peut être VALIDÉ sans gradation
        # aboutie. On enregistre la saisie (rien de perdu), mais sans valider, et
        # on renvoie vers l'édition avec un message.
        if valider and _soin_grade_missing(recap, c["patient_id"]):
            repo.update_consultation_recap(consultation_id, recap, validated=False)
            flash(request, "Patient diabétique : complétez le bilan de gradation "
                  "(au moins la neuropathie, via le monofilament) avant de valider la fiche.",
                  "error")
            return RedirectResponse(f"/consultations/{consultation_id}/edit", status_code=303)
        repo.update_consultation_recap(consultation_id, recap, validated=valider)
        flash(request, "Fiche de soin enregistrée et validée." if valider
              else "Fiche de soin enregistrée.")
        return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)

    # Fiche préférence motrice (Volodalen) : parsing + normalisation dédiés.
    if c.get("bilan_type") == "volodalen":
        recap = _parse_volodalen_form(form)
        valider = (form.get("valider") or "").strip() == "on"
        repo.update_consultation_recap(consultation_id, recap, validated=valider)
        lieu = (form.get("source_lieu") or "").strip()
        if lieu in ("cabinet", "domicile") and lieu != c.get("source"):
            repo.update_consultation_source(consultation_id, lieu)
        flash(request, "Bilan préférence motrice enregistré et validé." if valider
              else "Bilan préférence motrice enregistré.")
        return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)

    def g(name: str) -> str:
        return (form.get(name) or "").strip()

    def lr(prefix: str) -> dict:
        return {"gauche": g(f"{prefix}_gauche"), "droite": g(f"{prefix}_droite")}

    def lr_multi(prefix: str) -> dict:
        return {"gauche": form.getlist(f"{prefix}_gauche"),
                "droite": form.getlist(f"{prefix}_droite")}

    # Reconstruit la fiche depuis le formulaire structuré, puis on NORMALISE
    # (coercition des valeurs de menus, latéralité, types) via le schéma unique.
    raw_recap = {
        "tl_dr": g("tl_dr"),
        "anamnese": {
            "souci_actuel": g("souci_actuel"),
            "plainte": {
                "localisation": g("plainte_localisation"),
                "depuis": g("plainte_depuis"),
                "moment": g("plainte_moment"),
                "modification_habitudes": g("plainte_modification_habitudes"),
            },
            "atcd": {
                "pathologies_chroniques": _lines(g("pathologies_chroniques")),
                "operations_membre_inf": _parse_operations(g("operations_membre_inf")),
                "operations_dos": _parse_operations(g("operations_dos")),
                "blessures_repetition": g("blessures_repetition"),
            },
            "habitudes_vie": {
                "activite_sportive": g("activite_sportive"),
                "activite_professionnelle": g("activite_professionnelle"),
                "actif_maison": g("actif_maison"),
                "type_chaussant": g("type_chaussant"),
            },
        },
        "examen_decharge": {
            "douleur_localisation": g("douleur_localisation"),
            "douleur_intensite_sur_10": g("douleur_intensite_sur_10") or None,
            "mobilite_cheville": lr("mobilite_cheville"),
            "bilan_cutane": {key: g(f"bc_{key}") for key, _ in bilan.BILAN_CUTANE_CHAMPS},
        },
        "statique": {
            # Champ historique : présent dans le formulaire uniquement pour les
            # anciennes fiches qui l'avaient rempli (sinon chaîne vide).
            "description_generale": g("description_generale"),
            "type_empreinte": lr("type_empreinte"),
            "arriere_pied": lr("arriere_pied"),
            "mediopied": lr("mediopied"),
            "avant_pied": lr("avant_pied"),
            "deformations": lr_multi("deformations"),
            "genou": lr_multi("genou"),
            "tests_genou": {key: lr(f"tg_{key}") for key, _l, _o, _opts in bilan.TESTS_GENOU},
            "bassin_pulsion": lr("bassin_pulsion"),
            "bassin_version": g("bassin_version"),
            "tests_bassin": {key: lr(f"tb_{key}") for key, _l, _o, _opts in bilan.TESTS_BASSIN},
            "dos": {
                "creux_poplite": g("dos_creux_poplite"),
                "eips": g("dos_eips"),
                "pointe_scapulaire": g("dos_pointe_scapulaire"),
                "acromioclaviculaire": g("dos_acromioclaviculaire"),
            },
            "tests_dos": {
                "adams": g("td_adams"),
                "downing": {"jambe_gauche_cm": g("td_downing_g"),
                            "jambe_droite_cm": g("td_downing_d")},
                "fil_a_plomb": {"resultat": g("td_fap_resultat"),
                                "cale_mm": g("td_fap_cale_mm"),
                                "cale_cote": g("td_fap_cale_cote")},
            },
        },
        "dynamique": {
            "temps_du_pas": g("temps_du_pas"),
            "arriere_mediopied": lr("arriere_mediopied"),
            "angle_de_fick": lr("angle_de_fick"),
        },
        "conclusion": {
            "synthese": g("synthese"),
            "suivi": g("suivi"),
        },
        "reflexions_ia": _parse_reflexions(g("reflexions_ia")),
        "evolution_depuis_derniere_visite": g("evolution_depuis_derniere_visite") or None,
        "plan_semelles": {
            "pointure": g("plan_semelles_pointure"),
            "filament": g("plan_semelles_filament"),
            "base": g("plan_semelles_base"),
            "voute": g("plan_semelles_voute"),
            "supination": g("plan_semelles_supination"),
            "pronation": g("plan_semelles_pronation"),
            "elements_avp": g("plan_semelles_elements_avp"),
            "elements_arp": g("plan_semelles_elements_arp"),
            "notes": g("plan_semelles_notes"),
        },
    }
    recap = bilan.normalize(raw_recap)

    foot = None
    foot_raw = g("foot_annotations")
    if foot_raw:
        try:
            import json as _json
            foot = _json.loads(foot_raw)
        except ValueError:
            foot = None

    valider = g("valider")
    repo.update_consultation_recap(
        consultation_id, recap, tags=form.getlist("tags"), foot_annotations=foot,
        validated=(valider == "on"),
    )
    # Lieu de la consultation (cabinet/domicile) : corrigeable ici — l'import
    # par QR code marquait « domicile » à tort sans aucun moyen de le changer.
    lieu = g("source_lieu")
    if lieu in ("cabinet", "domicile") and lieu != c.get("source"):
        repo.update_consultation_source(consultation_id, lieu)
    flash(request, "Fiche enregistrée et validée." if valider == "on" else "Fiche enregistrée.")
    return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)


@app.post("/consultations/{consultation_id}/validate")
def validate_consultation(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c:
        # Évite un flash « Fiche validée » mensonger (UPDATE sur 0 ligne) si la
        # consultation n'existe pas/plus.
        return RedirectResponse("/", status_code=303)
    # Garde-fou médico-légal (fiche de soin, patient diabétique) : même règle que
    # via l'édition — pas de validation sans gradation aboutie.
    if c.get("bilan_type") == "soin" and _soin_grade_missing(c.get("recap") or {}, c["patient_id"]):
        flash(request, "Patient diabétique : complétez le bilan de gradation avant "
              "de valider cette fiche de soin.", "error")
        return RedirectResponse(f"/consultations/{consultation_id}/edit", status_code=303)
    repo.set_validated(consultation_id, True)
    flash(request, "Fiche validée.")
    return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)


@app.post("/consultations/{consultation_id}/reflexions/{index}/{action}")
def reflexion_action(request: Request, consultation_id: int, index: int, action: str):
    """Retenir (« retenue ») ou écarter (« écartée ») une réflexion IA.

    Les pistes proposées par l'IA restent « à vérifier » tant que le praticien
    n'a pas tranché ; sa décision est persistée dans le recap (vocabulaire fermé
    de app/bilan.py — jamais de diagnostic).
    """
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    if not c or c.get("status") != "done" or not c.get("recap"):
        return RedirectResponse("/", status_code=303)
    if action not in ("keep", "drop"):
        return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)
    recap = c["recap"]
    reflexions = recap.get("reflexions_ia") or []
    if 0 <= index < len(reflexions):
        reflexions[index]["statut"] = "retenue" if action == "keep" else "écartée"
        repo.update_consultation_recap(consultation_id, recap)
        flash(request, "Piste retenue." if action == "keep" else "Piste écartée.")
    return RedirectResponse(f"/consultations/{consultation_id}", status_code=303)


@app.post("/consultations/{consultation_id}/delete")
def delete_consultation(request: Request, consultation_id: int):
    if redirect := _guard(request):
        return redirect
    c = repo.get_consultation(consultation_id)
    pid = c["patient_id"] if c else None
    rgpd.delete_consultation_record(consultation_id)  # supprime aussi l'audio (RGPD)
    flash(request, "Consultation supprimée.")
    return RedirectResponse(f"/patients/{pid}" if pid else "/", status_code=303)


# --------------------------------------------------------------------------- #
# Page upload iPhone (LAN + PIN)
# --------------------------------------------------------------------------- #
# Durée de validité du déverrouillage PIN d'upload (puis re-saisie du PIN).
UPLOAD_SESSION_TTL = 45 * 60


def _upload_authed(request: Request) -> bool:
    """Déverrouillage upload valide ET non expiré (évite un accès de 7 jours)."""
    if not request.session.get("upload_ok"):
        return False
    import time as _t
    if _t.time() - request.session.get("upload_unlock_ts", 0) > UPLOAD_SESSION_TTL:
        request.session.pop("upload_ok", None)
        request.session.pop("upload_unlock_ts", None)
        return False
    return True


def _pin_key(request: Request) -> str:
    """Clé anti-bruteforce PAR IP (un tiers du LAN ne verrouille pas le praticien)."""
    host = request.client.host if request.client else "?"
    return f"upload:{host}"


def _grant_upload(request: Request) -> None:
    import time as _t
    request.session["upload_ok"] = True
    request.session["upload_unlock_ts"] = _t.time()


@app.get("/upload", response_class=HTMLResponse)
def upload_page(request: Request, mode: str = "audio"):
    authed = _upload_authed(request)
    patients = repo.list_patients() if authed else []
    return render(request, "upload.html",
                  authed=authed, patients=patients, error=None, success=None,
                  mode=("photos" if mode == "photos" else "audio"))


@app.post("/upload")
async def upload_submit(
    request: Request,
    step: str = Form(""),
    pin: str = Form(""),
    patient_id: str = Form(""),
    new_nom: str = Form(""),
    new_prenom: str = Form(""),
    consent: str = Form(""),
    lieu: str = Form("cabinet"),
    defer: str = Form(""),
    files: list[UploadFile] = Form(default=[]),
):
    # Étape 1 : déverrouillage par PIN (anti-bruteforce keyé par IP)
    if not _upload_authed(request):
        # Page d'envoi laissée ouverte > TTL puis fichiers envoyés : ce n'est
        # PAS une tentative de PIN — on ré-affiche l'écran PIN avec un message
        # clair au lieu de compter un échec (et de verrouiller l'IP du
        # praticien) sur un PIN vide.
        if step == "files":
            return render(request, "upload.html", authed=False, patients=[],
                          error="Session expirée : saisissez à nouveau le code "
                                "PIN, puis renvoyez vos fichiers.", success=None)
        pin_key = _pin_key(request)
        locked = security.pin_limiter.locked_seconds(pin_key)
        if locked:
            return render(request, "upload.html", authed=False, patients=[],
                          error=f"Trop de tentatives. Réessayez dans {locked}s.", success=None)
        if auth.verify_pin(pin):
            security.pin_limiter.reset(pin_key)
            _grant_upload(request)
            patients = repo.list_patients()
            return render(request, "upload.html",
                          authed=True, patients=patients, error=None, success=None)
        security.pin_limiter.record_failure(pin_key)
        return render(request, "upload.html",
                      authed=False, patients=[], error="Code PIN incorrect.",
                      success=None)

    # Étape 2 : envoi des fichiers
    def fail(msg: str):
        return render(request, "upload.html", authed=True,
                      patients=repo.list_patients(), error=msg, success=None)

    if consent != "on":
        return fail("Le consentement du patient est obligatoire.")

    # Patient existant ou création
    if patient_id and patient_id.isdigit():
        pid = int(patient_id)
    elif new_nom.strip() and new_prenom.strip():
        pid = repo.create_patient(new_nom, new_prenom)
    else:
        return fail("Choisissez un patient existant ou renseignez nom et prénom.")

    real_files = [f for f in files if f and f.filename]
    if not real_files:
        return fail("Aucun fichier sélectionné.")

    patient = repo.get_patient(pid)
    if not patient:
        return fail("Patient introuvable (supprimé entre-temps ?).")
    # Préfixe opaque : le nom du fichier audio ne doit pas porter l'identité du
    # patient (visible dans l'explorateur, les logs, la MFT après suppression).
    prefix = f"patient-{pid}"
    queued = (defer == "on")
    count = 0
    skipped_big = 0
    for f in real_files:
        if not is_allowed_audio(f.filename):
            continue
        try:
            path = save_upload(f, prefix=prefix)
        except UploadTooLarge:
            skipped_big += 1
            continue
        cid = repo.create_consultation(
            pid, source=("domicile" if lieu == "domicile" else "cabinet"),
            consent_obtained=True, audio_path=str(path),
            status="queued" if queued else "pending",
        )
        if not queued and settings.auto_process:
            runner.process_in_background(cid)
        count += 1

    if skipped_big and count == 0:
        return fail(f"Fichier(s) trop volumineux (max {settings.max_upload_mb} Mo).")

    if count == 0:
        return fail("Aucun fichier audio valide (formats : m4a, wav, mp3…).")

    msg = (f"{count} enregistrement(s) déposé(s) en file d'attente — la transcription "
           f"sera lancée depuis l'ordinateur du cabinet."
           if queued else
           f"{count} enregistrement(s) reçu(s) et en cours de traitement.")
    return render(request, "upload.html", authed=True,
                  patients=repo.list_patients(), error=None,
                  success=msg + " Pensez à supprimer les originaux sur l'iPhone.")


@app.post("/upload/photos")
async def upload_photos_submit(
    request: Request,
    patient_id: str = Form(""),
    kind: str = Form("avant"),
    note: str = Form(""),
    consent: str = Form(""),
    photos: list[UploadFile] = Form(default=[]),
):
    """Photos de soin depuis l'iPhone (même page Wi-Fi + PIN que l'audio).

    Rattachement : la fiche de SOIN DU JOUR du patient — créée vierge si elle
    n'existe pas encore (les photos « avant » précèdent souvent la dictée).
    Même hygiène qu'au bureau : ré-encodage JPEG borné, EXIF/GPS supprimés,
    stockage local en base (sauvegardé, purgé avec le dossier)."""
    if not _upload_authed(request):
        # Session PIN expirée pendant que la page était ouverte : ré-afficher
        # l'écran PIN sans compter d'échec (même logique que l'audio).
        return render(request, "upload.html", authed=False, patients=[],
                      error="Session expirée : saisissez à nouveau le code PIN, "
                            "puis renvoyez vos photos.", success=None, mode="photos")

    def fail(msg: str):
        return render(request, "upload.html", authed=True,
                      patients=repo.list_patients(), error=msg, success=None,
                      mode="photos")

    if consent != "on":
        return fail("Le consentement du patient est obligatoire.")
    if not (patient_id and patient_id.isdigit() and repo.get_patient(int(patient_id))):
        return fail("Choisissez le patient concerné.")
    pid = int(patient_id)
    real = [f for f in photos if f and f.filename]
    if not real:
        return fail("Aucune photo sélectionnée.")

    # Fiche cible : la fiche de soin la plus récente datée d'AUJOURD'HUI, sinon
    # une fiche de soin vierge (complétée ensuite au bureau, comme « sans audio »).
    import datetime as _dt
    today = _dt.date.today().isoformat()
    target = next((c for c in repo.list_consultations(pid)
                   if c.get("bilan_type") == "soin"
                   and str(c.get("date") or "").startswith(today)), None)
    created = target is None
    cid = repo.create_blank_consultation(pid, "cabinet", bilan_type="soin") \
        if created else target["id"]

    kind = kind if kind in ("avant", "apres", "autre") else "autre"
    count, rejected = 0, 0
    for f in real:
        raw = await f.read()
        if not raw or len(raw) > photos_mod.MAX_INPUT_BYTES \
                or not photos_mod.is_supported_image(raw):
            rejected += 1
            continue
        try:
            data = photos_mod.reencode(raw)  # JPEG borné + EXIF/GPS supprimé
        except ValueError:
            rejected += 1
            continue
        repo.add_photo(cid, data, mime="image/jpeg", kind=kind, note=note)
        count += 1

    if count == 0:
        if created:  # ne pas laisser une fiche vide créée pour rien
            repo.delete_consultation(cid)
        return fail("Aucune photo lisible (formats acceptés : JPEG, PNG). Sur "
                    "iPhone : Réglages → Appareil photo → Formats → "
                    "« Le plus compatible ».")
    patient = repo.get_patient(pid)
    msg = (f"{count} photo(s) ajoutée(s) à la fiche de soin du jour de "
           f"{patient['prenom']} {patient['nom']}"
           + (" (fiche créée, à compléter au bureau)" if created else "")
           + (f" — {rejected} fichier(s) ignoré(s)" if rejected else "") + ".")
    return render(request, "upload.html", authed=True,
                  patients=repo.list_patients(), error=None, success=msg,
                  mode="photos")


@app.get("/upload/qr.png")
def upload_qr(request: Request):
    # Réservé au praticien connecté (affiché sur /system) : sans auth, le QR
    # révélait l'IP LAN et le point d'entrée d'upload à n'importe qui.
    if redirect := _guard(request):
        return redirect
    import qrcode

    url = f"http://{get_lan_ip()}:{settings.port}/upload"
    img = qrcode.make(url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


# --------------------------------------------------------------------------- #
# État système (santé des dépendances)
# --------------------------------------------------------------------------- #
@app.get("/system", response_class=HTMLResponse)
def system_page(request: Request):
    if redirect := _guard(request):
        return redirect
    whisper_ok, whisper_msg = check_whisper()
    # Statut du backend LLM réellement configuré (ollama local ou sonnet cloud).
    ollama_ok, ollama_msg = llm.check_llm()
    # Diarisation : depuis la 1.1.8 les modèles sont EMBARQUÉS (aucun compte
    # HuggingFace). Ne juger que sur le token afficherait « inactive » à un
    # praticien chez qui elle marche — cf. app/diarization_models.py.
    from . import diarization_models
    diar_local = diarization_models.is_installed()
    hf_token = bool(settings.huggingface_token.strip())
    hf_ok = diar_local or hf_token
    if diar_local:
        hf_msg = "Modèles installés : identification des locuteurs active (aucun compte requis)."
    elif hf_token:
        hf_msg = "Token HuggingFace configuré : identification des locuteurs active."
    elif diarization_models.MODELS_SHA256:
        hf_msg = ("Modèles en cours de récupération (~29 Mo, en tâche de fond) : "
                  "l'identification des locuteurs s'activera d'elle-même. "
                  "En attendant, la transcription marche sans distinguer les voix.")
    else:
        hf_msg = ("Modèles de diarisation indisponibles : la transcription marche, "
                  "mais sans distinguer praticien et patient.")
    lan_url = f"http://{get_lan_ip()}:{settings.port}/upload"
    return render(request, "system.html",
                  whisper_ok=whisper_ok, whisper_msg=whisper_msg,
                  ollama_ok=ollama_ok, ollama_msg=ollama_msg,
                  hf_ok=hf_ok, hf_msg=hf_msg,
                  # En backend cloud (sonnet), inutile d'interroger Ollama (injoignable -> attente).
                  # `ollama_utilise` évite d'afficher « 0 modèle » alors qu'on n'a
                  # simplement pas posé la question : la tuile dirait faux.
                  ollama_utilise=settings.llm_backend.strip().lower() != "sonnet",
                  ollama_models=(llm.list_models()
                                 if settings.llm_backend.strip().lower() != "sonnet" else []),
                  lan_url=lan_url, settings=settings,
                  license_status=license.get_status(),
                  app_version=updater.current_version(),
                  update_status=updater.cached_status())


# --------------------------------------------------------------------------- #
# Réglages — profil praticien (en-tête des ordonnances)
# --------------------------------------------------------------------------- #
_ALLOWED_SIGNATURE_EXT = {".png", ".jpg", ".jpeg"}
# En-têtes magiques attendus : on ne se fie pas à l'extension seule (un fichier
# renommé .png pourrait être tout autre chose). Clé = extension, valeur = préfixes.
_SIGNATURE_MAGIC = {
    ".png": (b"\x89PNG\r\n\x1a\n",),
    ".jpg": (b"\xff\xd8\xff",),
    ".jpeg": (b"\xff\xd8\xff",),
}


def _looks_like_image(ext: str, content: bytes) -> bool:
    return any(content.startswith(sig) for sig in _SIGNATURE_MAGIC.get(ext, ()))


@app.get("/reglages", response_class=HTMLResponse)
def reglages_page(request: Request):
    if redirect := _guard(request):
        return redirect
    prof = practitioner.load()
    return render(request, "reglages.html", profile=prof,
                  has_signature=practitioner.signature_file(prof) is not None,
                  license_status=license.get_status(),
                  cabinets=repo.list_cabinets(),
                  correspondants=repo.list_correspondants(),
                  correspondant_types=repo.CORRESPONDANT_TYPES,
                  actes=compta.list_actes(),
                  produits=produits.list_produits(),
                  exercices_perso=exercices_mod.list_perso())


# --- Cabinets (multi-sites) ------------------------------------------------- #
def _cabinet_form_values(form) -> dict:
    return {f: (form.get(f) or "").strip()
            for f in ("label", "nom", "titre", "adresse", "telephone", "num_am", "rpps")}


@app.post("/reglages/cabinets")
async def cabinet_create(request: Request):
    if redirect := _guard(request):
        return redirect
    form = await request.form()
    values = _cabinet_form_values(form)
    if not values["label"]:
        flash(request, "Le nom du cabinet est requis.", "error")
        return RedirectResponse("/reglages", status_code=303)
    repo.create_cabinet(values)
    flash(request, f"Cabinet « {values['label']} » créé.")
    return RedirectResponse("/reglages", status_code=303)


@app.post("/reglages/cabinets/{cabinet_id}/edit")
async def cabinet_edit(request: Request, cabinet_id: int):
    if redirect := _guard(request):
        return redirect
    form = await request.form()
    values = _cabinet_form_values(form)
    if not values["label"]:
        flash(request, "Le nom du cabinet est requis.", "error")
        return RedirectResponse("/reglages", status_code=303)
    repo.update_cabinet(cabinet_id, values)
    flash(request, "Cabinet mis à jour.")
    return RedirectResponse("/reglages", status_code=303)


@app.post("/reglages/cabinets/{cabinet_id}/delete")
def cabinet_delete(request: Request, cabinet_id: int):
    if redirect := _guard(request):
        return redirect
    repo.delete_cabinet(cabinet_id)
    flash(request, "Cabinet supprimé (patients repassés en « non assigné »).")
    return RedirectResponse("/reglages", status_code=303)


# --- Correspondants (annuaire pluridisciplinaire) --------------------------- #
def _correspondant_form_values(form) -> dict:
    return {f: (form.get(f) or "").strip()
            for f in ("type", "nom", "email", "telephone", "adresse", "notes")}


@app.post("/reglages/correspondants")
async def correspondant_create(request: Request):
    if redirect := _guard(request):
        return redirect
    values = _correspondant_form_values(await request.form())
    if not values["nom"]:
        flash(request, "Le nom du correspondant est requis.", "error")
        return RedirectResponse("/reglages", status_code=303)
    repo.create_correspondant(values)
    flash(request, f"Correspondant « {values['nom']} » ajouté.")
    return RedirectResponse("/reglages", status_code=303)


@app.post("/reglages/correspondants/{correspondant_id}/edit")
async def correspondant_edit(request: Request, correspondant_id: int):
    if redirect := _guard(request):
        return redirect
    values = _correspondant_form_values(await request.form())
    if not values["nom"]:
        flash(request, "Le nom du correspondant est requis.", "error")
        return RedirectResponse("/reglages", status_code=303)
    repo.update_correspondant(correspondant_id, values)
    flash(request, "Correspondant mis à jour.")
    return RedirectResponse("/reglages", status_code=303)


@app.post("/reglages/correspondants/{correspondant_id}/delete")
def correspondant_delete(request: Request, correspondant_id: int):
    if redirect := _guard(request):
        return redirect
    repo.delete_correspondant(correspondant_id)
    flash(request, "Correspondant supprimé.")
    return RedirectResponse("/reglages", status_code=303)


@app.post("/reglages")
async def reglages_submit(
    request: Request,
    nom: str = Form(""),
    titre: str = Form(""),
    adresse: str = Form(""),
    telephone: str = Form(""),
    num_am: str = Form(""),
    rpps: str = Form(""),
    lignes_defaut: str = Form(""),
    produits_favoris: str = Form(""),
    signature: UploadFile | None = Form(None),
):
    if redirect := _guard(request):
        return redirect
    values = {
        "nom": nom, "titre": titre, "adresse": adresse, "telephone": telephone,
        "num_am": num_am, "rpps": rpps,
        "lignes_defaut": _lines(lignes_defaut),
        "produits_favoris": _lines(produits_favoris),
    }
    # Signature : image optionnelle, stockée dans data/ (pas une donnée patient).
    if signature is not None and signature.filename:
        import os as _os
        ext = _os.path.splitext(signature.filename)[1].lower()
        if ext not in _ALLOWED_SIGNATURE_EXT:
            flash(request, "Signature ignorée : format accepté PNG ou JPG.", "error")
        else:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            dest = DATA_DIR / f"signature{ext}"
            content = await signature.read()
            if len(content) > 5 * 1024 * 1024:  # 5 Mo : largement assez pour une signature
                flash(request, "Signature ignorée : image trop volumineuse (max 5 Mo).", "error")
            elif not _looks_like_image(ext, content):
                # L'extension ne suffit pas : on vérifie l'en-tête réel du fichier.
                flash(request, "Signature ignorée : le fichier n'est pas une image PNG/JPG valide.", "error")
            else:
                # Supprime d'abord la cible (neutralise un éventuel lien symbolique
                # piégé : write_bytes suivrait le lien -> on écrit alors un fichier neuf).
                dest.unlink(missing_ok=True)
                dest.write_bytes(content)
                # Nettoie une éventuelle ancienne signature d'une autre extension.
                for other in _ALLOWED_SIGNATURE_EXT - {ext}:
                    (DATA_DIR / f"signature{other}").unlink(missing_ok=True)
                values["signature_path"] = dest.name
    practitioner.save(values)
    flash(request, "Profil praticien enregistré.")
    return RedirectResponse("/reglages", status_code=303)


@app.post("/reglages/signature/delete")
def reglages_signature_delete(request: Request):
    if redirect := _guard(request):
        return redirect
    prof = practitioner.load()
    sig = practitioner.signature_file(prof)
    if sig:
        sig.unlink(missing_ok=True)
    practitioner.save({"signature_path": ""})
    flash(request, "Signature supprimée.")
    return RedirectResponse("/reglages", status_code=303)


@app.get("/reglages/signature")
def reglages_signature(request: Request):
    if redirect := _guard(request):
        return redirect
    sig = practitioner.signature_file()
    if not sig:
        return Response(status_code=404)
    media = "image/png" if sig.suffix.lower() == ".png" else "image/jpeg"
    return Response(content=sig.read_bytes(), media_type=media,
                    headers={"Cache-Control": "no-store"})


# --------------------------------------------------------------------------- #
# Sauvegarde / restauration des données (changement de poste)
# --------------------------------------------------------------------------- #
@app.get("/reglages/sauvegarde")
def reglages_backup(request: Request):
    """Télécharge une archive .zip (base patients + profil + signature)."""
    if redirect := _guard(request):
        return redirect
    try:
        data, filename = backup.build_backup()
    except Exception:
        import logging
        logging.getLogger("podonote.main").exception("Construction de la sauvegarde en échec.")
        flash(request, "La sauvegarde a échoué. Réessayez dans quelques instants.", "error")
        return RedirectResponse("/reglages", status_code=303)
    # Fenêtre native (WebView2) : un téléchargement `attachment` est IGNORÉ
    # silencieusement (clic sans effet — c'est le piège déjà rencontré pour les
    # PDF). Le front demande alors `deliver=save` : on écrit le .zip dans
    # Documents\PodoNote et on ouvre le dossier dans l'Explorateur, pour que le
    # praticien retrouve sa sauvegarde et la copie (clé USB, autre PC).
    if request.query_params.get("deliver") == "save":
        import logging
        try:
            folder = utils.export_root(create=True)
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / filename
            path.write_bytes(data)
        except Exception:
            logging.getLogger("podonote.main").exception("Écriture de la sauvegarde sur disque impossible.")
            return JSONResponse(
                {"error": "Enregistrement de la sauvegarde impossible."}, status_code=500
            )
        _open_path(folder)  # ouvre le dossier (best-effort ; l'échec n'invalide pas la sauvegarde)
        return JSONResponse({"ok": True, "name": filename, "path": str(path)})
    return Response(
        content=data,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store",
        },
    )


@app.post("/reglages/restauration")
async def reglages_restore(request: Request, archive: UploadFile | None = Form(None)):
    """Restaure une archive .zip produite par PodoNote (remplace les données en place)."""
    if redirect := _guard(request):
        return redirect
    if archive is None or not archive.filename:
        flash(request, "Choisissez d'abord un fichier de sauvegarde (.zip).", "error")
        return RedirectResponse("/reglages", status_code=303)
    content = await archive.read()
    # Plafond de taille : une vraie sauvegarde tient en quelques dizaines de Mo ;
    # on borne à la limite d'upload générale (settings.max_upload_mb).
    if len(content) > settings.max_upload_mb * 1024 * 1024:
        flash(request, "Fichier trop volumineux pour être une sauvegarde Diktae.", "error")
        return RedirectResponse("/reglages", status_code=303)
    result = backup.restore_backup(content)
    flash(request, result["message"], "success" if result.get("ok") else "error")
    return RedirectResponse("/reglages", status_code=303)


# --------------------------------------------------------------------------- #
# Hub Documents : ordonnance / fiche d'exercices / courrier / papiers officiels
# — 4 onglets sur un seul écran, patient sélectionnable, aperçu papier live.
# Les POST de génération restent sur les routes historiques par patient.
# --------------------------------------------------------------------------- #
_DOC_TABS = ("ordonnance", "exercices", "courrier", "papiers")


@app.get("/documents", response_class=HTMLResponse)
def documents_page(request: Request, tab: str = "ordonnance",
                   patient: int | None = None, papier: str = "cert"):
    if redirect := _guard(request):
        return redirect
    if tab not in _DOC_TABS:
        tab = "ordonnance"
    if papier not in papiers.TYPES:
        papier = "cert"
    patients = repo.list_patients()
    # Patient courant : paramètre explicite, sinon le premier de la liste.
    current = repo.get_patient(patient) if patient else None
    if current is None and patients:
        current = repo.get_patient(patients[0]["id"])

    ctx: dict = dict(tab=tab, patients=patients, patient=current, papier=papier)
    if current:
        if tab == "ordonnance":
            ctx.update(_ordonnance_ctx(current))
        elif tab == "exercices":
            ctx.update(categories=exercices_mod.by_category())
        elif tab == "courrier":
            ctx.update(_courrier_ctx(current))
        else:  # papiers
            cabinet = repo.get_cabinet(current["cabinet_id"]) if current.get("cabinet_id") else None
            header = practitioner.effective_header(practitioner.load(), cabinet)
            ctx.update(profile=header,
                       papier_types=papiers.TYPES,
                       papier_defaults=papiers.defaults(papier, current, header))
    return render(request, "documents.html", **ctx)


@app.post("/documents/papiers.pdf")
async def papiers_pdf(request: Request):
    """Génère le papier demandé (certificat / CR / feuille de soins).

    Le contenu vient du formulaire (textes édités librement, lignes d'actes) ;
    le PDF est enregistré dans le dossier du patient (contrat deliver natif).
    """
    if redirect := _guard(request):
        return redirect
    form = await request.form()
    pid_raw = str(form.get("patient_id") or "")
    patient = repo.get_patient(int(pid_raw)) if pid_raw.isdigit() else None
    if not patient:
        flash(request, "Choisissez un patient.", "error")
        return RedirectResponse("/documents?tab=papiers", status_code=303)
    kind = str(form.get("type") or "cert")
    if kind not in papiers.TYPES:
        kind = "cert"
    cabinet = repo.get_cabinet(patient["cabinet_id"]) if patient.get("cabinet_id") else None
    header = practitioner.effective_header(practitioner.load(), cabinet)
    paragraphs = [p for p in str(form.get("texte") or "").split("\n\n") if p.strip()]
    lignes = []
    for lib, prix in zip(form.getlist("acte_libelle"), form.getlist("acte_prix")):
        if str(lib).strip():
            lignes.append({"libelle": str(lib).strip(), "prix": str(prix).strip() or "0"})
    data = papiers.build_pdf(kind, patient, header, paragraphs=paragraphs, lignes=lignes)
    import datetime
    date_part = f"{datetime.date.today():%d-%m-%Y}"
    fname = _ascii_filename(
        f"{papiers.TYPES[kind]}_{patient['nom'].upper()} {patient['prenom']}_{date_part}.pdf")
    return _deliver_pdf(request, data, fname, patient)


# --------------------------------------------------------------------------- #
# Compta : tableau de bord CA / factures & devis / nouvelle facture
# --------------------------------------------------------------------------- #
@app.get("/compta", response_class=HTMLResponse)
def compta_page(request: Request, tab: str = "bord", filter: str = "",
                type: str = "facture", patient: int | None = None,
                q: str = "", moyen: str = "", min: str = "", max: str = "",
                cabinet: str = ""):
    if redirect := _guard(request):
        return redirect
    if tab not in ("bord", "factures", "nouvelle"):
        tab = "bord"
    kind = type if type in compta.TYPES else "facture"
    if filter not in compta.STATUTS:
        filter = ""
    # Compta par cabinet (retour Nico : EHPAD / 2ᵉ cabinet distincts). '' = vue
    # cumulée (tous les cabinets), 'none' = sans cabinet, sinon id valide.
    cabinets = repo.list_cabinets()
    cabinet_ids = {str(c["id"]) for c in cabinets}
    if cabinet not in cabinet_ids and cabinet != "none":
        cabinet = ""
    ctx: dict = dict(tab=tab, current_filter=filter, kind=kind,
                     cabinets=cabinets, current_cabinet=cabinet)
    if tab == "bord":
        ctx.update(dash=compta.dashboard(cabinet=cabinet))
    elif tab == "factures":
        # Recherche (retour Nico) : numéro/patient, moyen de paiement, montant.
        factures = compta.search_factures(statut=filter, q=q, moyen=moyen,
                                          montant_min=min, montant_max=max,
                                          cabinet=cabinet)
        ctx.update(factures=factures, moyens=compta.MOYENS_PAIEMENT,
                   q_compta=q, current_moyen=moyen,
                   montant_min=min, montant_max=max)
    else:  # nouvelle
        numero, _, _ = compta.next_numero(kind)
        selected_patient = repo.get_patient(patient) if patient else None
        # Cabinet par défaut : « Automatique » (= celui du patient, résolu à
        # l'enregistrement — reste juste même si on change de patient dans le
        # formulaire). Sans patient : le cabinet sélectionné sur l'accueil.
        default_cabinet = (None if selected_patient
                           else request.session.get("cabinet_id") or None)
        ctx.update(patients=repo.list_patients(),
                   selected_patient=selected_patient,
                   actes=compta.list_actes(),
                   numero=numero,
                   moyens=compta.MOYENS_PAIEMENT,
                   default_cabinet=default_cabinet,
                   profile=practitioner.effective_header(practitioner.load(), None))
    return render(request, "compta.html", **ctx)


@app.post("/compta/factures.pdf")
async def compta_new_facture(request: Request):
    """Crée la facture/le devis (numéro auto) puis renvoie son PDF.

    Même contrat natif que l'ordonnance : `deliver=preview|open` intercepté
    par base.html ; le document est journalisé dans l'onglet Factures & devis.
    """
    if redirect := _guard(request):
        return redirect
    form = await request.form()
    kind = str(form.get("type") or "facture")
    statut = str(form.get("statut") or "")
    moyen = str(form.get("moyen_paiement") or "")
    pid_raw = str(form.get("patient_id") or "")
    patient = repo.get_patient(int(pid_raw)) if pid_raw.isdigit() else None
    cab_raw = str(form.get("cabinet_id") or "")
    cabinet_id = int(cab_raw) if cab_raw.isdigit() else None  # sinon : cabinet du patient
    lignes = [{"libelle": lib, "prix": prix}
              for lib, prix in zip(form.getlist("ligne_libelle"),
                                   form.getlist("ligne_prix"))]
    lignes = [l for l in lignes if str(l["libelle"]).strip()]
    if not lignes:
        flash(request, "Ajoutez au moins un acte à facturer.", "error")
        return RedirectResponse("/compta?tab=nouvelle", status_code=303)
    # deliver=preview (aperçu natif) NE journalise PAS : seule la génération
    # réelle crée le document — même logique anti-doublon que l'ordonnance.
    deliver = request.query_params.get("deliver")
    header = practitioner.effective_header(practitioner.load(), None)
    if deliver == "preview":
        numero, annee, seq = compta.next_numero(kind)
        from datetime import date as _d
        preview = {"type": kind, "numero": numero, "date": _d.today().isoformat(),
                   "patient_nom": (f"{patient['prenom']} {patient['nom']}" if patient else ""),
                   "statut": ("payee" if (kind != "devis" and statut == "payee") else
                              ("devis" if kind == "devis" else "attente")),
                   "moyen_paiement": moyen,
                   "lignes": compta._clean_lignes(lignes)[0],
                   "total": compta._clean_lignes(lignes)[1]}
        data = compta.build_pdf(preview, header)
        return Response(content=data, media_type="application/pdf")
    created = compta.create_facture(kind, patient, lignes, statut=statut,
                                    moyen_paiement=moyen, cabinet_id=cabinet_id)
    facture = compta.get_facture(created["id"])
    data = compta.build_pdf(facture, header)
    fname = _ascii_filename(f"{compta.TYPES[kind]} {facture['numero']}"
                            + (f"_{patient['nom'].upper()} {patient['prenom']}" if patient else "")
                            + ".pdf")
    if patient:
        return _deliver_pdf(request, data, fname, patient)
    # Sans patient rattaché : mêmes modes de livraison, dossier racine Documents.
    return _deliver_pdf(request, data, fname, None)


@app.post("/compta/factures")
async def compta_new_facture_nopdf(request: Request):
    """Crée la facture/le devis SANS générer de PDF (retour Nico : « pouvoir
    créer la facture, sans forcément l'imprimer ou la Print to PDF »). Le
    document existe alors dans « Factures & devis » (PDF rouvrable à la demande)."""
    if redirect := _guard(request):
        return redirect
    form = await request.form()
    kind = str(form.get("type") or "facture")
    statut = str(form.get("statut") or "")
    moyen = str(form.get("moyen_paiement") or "")
    pid_raw = str(form.get("patient_id") or "")
    patient = repo.get_patient(int(pid_raw)) if pid_raw.isdigit() else None
    cab_raw = str(form.get("cabinet_id") or "")
    cabinet_id = int(cab_raw) if cab_raw.isdigit() else None  # sinon : cabinet du patient
    lignes = [{"libelle": lib, "prix": prix}
              for lib, prix in zip(form.getlist("ligne_libelle"),
                                   form.getlist("ligne_prix"))]
    lignes = [l for l in lignes if str(l["libelle"]).strip()]
    if not lignes:
        flash(request, "Ajoutez au moins un acte à facturer.", "error")
        return RedirectResponse("/compta?tab=nouvelle", status_code=303)
    created = compta.create_facture(kind, patient, lignes, statut=statut,
                                    moyen_paiement=moyen, cabinet_id=cabinet_id)
    flash(request, f"{compta.TYPES[kind]} {created['numero']} enregistrée "
                   "(sans PDF). Vous pourrez la rouvrir à tout moment.")
    return RedirectResponse("/compta?tab=factures", status_code=303)


@app.get("/compta/factures/{facture_id}.pdf")
def compta_facture_pdf(request: Request, facture_id: int):
    """Rouvre / régénère le PDF d'un document existant (numéro conservé)."""
    if redirect := _guard(request):
        return redirect
    facture = compta.get_facture(facture_id)
    if not facture:
        flash(request, "Document introuvable.", "error")
        return RedirectResponse("/compta?tab=factures", status_code=303)
    header = practitioner.effective_header(practitioner.load(), None)
    data = compta.build_pdf(facture, header)
    patient = repo.get_patient(facture["patient_id"]) if facture.get("patient_id") else None
    fname = _ascii_filename(f"{compta.TYPES.get(facture['type'], 'Facture')} "
                            f"{facture['numero']}.pdf")
    return _deliver_pdf(request, data, fname, patient)


def _compta_liste_url(filter: str = "", q: str = "", moyen: str = "",
                      min: str = "", max: str = "", cabinet: str = "",
                      anchor: int | None = None) -> str:
    """URL de retour vers la liste Factures & devis en CONSERVANT le contexte
    (retour Nico : changer un moyen de paiement le renvoyait sur « Toutes » en
    haut de liste → 800 clics pour retrouver sa ligne). `anchor` = id de la
    facture modifiée : la page rouvre directement sur cette ligne."""
    from urllib.parse import urlencode
    keep: dict[str, str] = {}
    if filter in compta.STATUTS:
        keep["filter"] = filter
    for key, val in (("q", q), ("moyen", moyen), ("min", min),
                     ("max", max), ("cabinet", cabinet)):
        val = str(val or "").strip()
        if val:
            keep[key] = val
    url = "/compta?tab=factures"
    if keep:
        url += "&" + urlencode(keep)
    if anchor:
        url += f"#f{anchor}"
    return url


@app.post("/compta/factures/{facture_id}/statut")
def compta_set_statut(request: Request, facture_id: int, statut: str = Form(...),
                      moyen_paiement: str = Form(""), filter: str = Form(""),
                      q: str = Form(""), moyen: str = Form(""),
                      min: str = Form(""), max: str = Form(""),
                      cabinet: str = Form("")):
    if redirect := _guard(request):
        return redirect
    if compta.get_facture(facture_id) and statut in compta.STATUTS:
        compta.set_statut(facture_id, statut, moyen_paiement)
        flash(request, f"Document marqué « {compta.STATUTS[statut]} ».")
    return RedirectResponse(
        _compta_liste_url(filter, q, moyen, min, max, cabinet, anchor=facture_id),
        status_code=303)


@app.post("/compta/factures/{facture_id}/moyen")
def compta_set_moyen(request: Request, facture_id: int,
                     moyen_paiement: str = Form(""), filter: str = Form(""),
                     q: str = Form(""), moyen: str = Form(""),
                     min: str = Form(""), max: str = Form(""),
                     cabinet: str = Form("")):
    """Ajoute/modifie le moyen de règlement d'une facture existante (retour
    Nico), indépendamment du statut — corrigeable même une fois payée."""
    if redirect := _guard(request):
        return redirect
    if compta.get_facture(facture_id):
        compta.set_moyen(facture_id, moyen_paiement)
        lbl = compta.MOYENS_PAIEMENT.get(moyen_paiement)
        flash(request, f"Moyen de paiement mis à jour : {lbl}." if lbl
              else "Moyen de paiement retiré.")
    return RedirectResponse(
        _compta_liste_url(filter, q, moyen, min, max, cabinet, anchor=facture_id),
        status_code=303)


@app.post("/compta/factures/{facture_id}/delete")
def compta_delete_facture(request: Request, facture_id: int, filter: str = Form(""),
                          q: str = Form(""), moyen: str = Form(""),
                          min: str = Form(""), max: str = Form(""),
                          cabinet: str = Form("")):
    """Supprime une facture/un devis saisi par erreur (retour Nico)."""
    if redirect := _guard(request):
        return redirect
    facture = compta.get_facture(facture_id)
    if facture and compta.delete_facture(facture_id):
        flash(request, f"{compta.TYPES.get(facture['type'], 'Document')} "
                       f"{facture['numero']} supprimé.")
    else:
        flash(request, "Document introuvable.", "error")
    # Pas d'ancre : la ligne n'existe plus.
    return RedirectResponse(_compta_liste_url(filter, q, moyen, min, max, cabinet),
                            status_code=303)


# --- Catalogue d'actes tarifés (édité dans Réglages, consommé par la compta) --
@app.post("/reglages/actes")
def reglages_acte_create(request: Request, libelle: str = Form(...),
                         prix: str = Form("0")):
    if redirect := _guard(request):
        return redirect
    try:
        prix_val = float(prix.replace(",", "."))
    except ValueError:
        prix_val = 0.0
    if libelle.strip():
        compta.create_acte(libelle, prix_val)
        flash(request, "Acte ajouté au catalogue.")
    return RedirectResponse("/reglages#actes", status_code=303)


@app.post("/reglages/actes/{acte_id}/edit")
def reglages_acte_edit(request: Request, acte_id: int, libelle: str = Form(...),
                       prix: str = Form("0")):
    if redirect := _guard(request):
        return redirect
    try:
        prix_val = float(prix.replace(",", "."))
    except ValueError:
        prix_val = 0.0
    if libelle.strip():
        compta.update_acte(acte_id, libelle, prix_val)
        flash(request, "Acte mis à jour.")
    return RedirectResponse("/reglages#actes", status_code=303)


@app.post("/reglages/actes/{acte_id}/delete")
def reglages_acte_delete(request: Request, acte_id: int):
    if redirect := _guard(request):
        return redirect
    compta.delete_acte(acte_id)
    flash(request, "Acte retiré du catalogue (l'historique facturé est conservé).")
    return RedirectResponse("/reglages#actes", status_code=303)


# --- Produits d'ordonnance (nom exact + posologie, consommés par l'ordonnance) -
@app.post("/reglages/produits")
def reglages_produit_create(request: Request, nom: str = Form(...),
                            posologie: str = Form("")):
    if redirect := _guard(request):
        return redirect
    if nom.strip():
        produits.create_produit(nom, posologie)
        flash(request, "Produit ajouté au catalogue d'ordonnance.")
    return RedirectResponse("/reglages#produits", status_code=303)


@app.post("/reglages/produits/{produit_id}/edit")
def reglages_produit_edit(request: Request, produit_id: int, nom: str = Form(...),
                          posologie: str = Form("")):
    if redirect := _guard(request):
        return redirect
    if nom.strip():
        produits.update_produit(produit_id, nom, posologie)
        flash(request, "Produit mis à jour.")
    return RedirectResponse("/reglages#produits", status_code=303)


@app.post("/reglages/produits/{produit_id}/delete")
def reglages_produit_delete(request: Request, produit_id: int):
    if redirect := _guard(request):
        return redirect
    produits.delete_produit(produit_id)
    flash(request, "Produit retiré du catalogue d'ordonnance.")
    return RedirectResponse("/reglages#produits", status_code=303)


# --- Exercices personnels (retour Nico : ajouter ses propres exercices) --------
@app.post("/reglages/exercices")
def reglages_exercice_create(request: Request, titre: str = Form(...),
                             categorie: str = Form("Mes exercices"),
                             description: str = Form("")):
    if redirect := _guard(request):
        return redirect
    if titre.strip():
        exercices_mod.create_perso(titre, categorie, description)
        flash(request, "Exercice ajouté à votre banque.")
    return RedirectResponse("/reglages#exercices", status_code=303)


@app.post("/reglages/exercices/{exo_id}/edit")
def reglages_exercice_edit(request: Request, exo_id: int, titre: str = Form(...),
                           categorie: str = Form("Mes exercices"),
                           description: str = Form("")):
    if redirect := _guard(request):
        return redirect
    if titre.strip():
        exercices_mod.update_perso(exo_id, titre, categorie, description)
        flash(request, "Exercice mis à jour.")
    return RedirectResponse("/reglages#exercices", status_code=303)


@app.post("/reglages/exercices/{exo_id}/image")
async def reglages_exercice_image(request: Request, exo_id: int,
                                  image: UploadFile | None = Form(None),
                                  retirer: str = Form("")):
    """Illustration d'un exercice (retour Nico : « imager chaque étirement »).

    L'image vient DU PRATICIEN — aucun visuel sous droits n'est embarqué. Elle
    est ré-encodée en JPEG borné et sans EXIF (même traitement que les photos
    cliniques), puis stockée en base : incluse dans la sauvegarde, jamais écrite
    dans Documents."""
    if redirect := _guard(request):
        return redirect
    if retirer == "1":
        exercices_mod.set_image(exo_id, None)
        flash(request, "Illustration retirée.")
        return RedirectResponse("/reglages#exercices", status_code=303)
    if image is None or not image.filename:
        return RedirectResponse("/reglages#exercices", status_code=303)
    raw = await image.read()
    if len(raw) > photos_mod.MAX_INPUT_BYTES:
        flash(request, "Image trop volumineuse.", "error")
        return RedirectResponse("/reglages#exercices", status_code=303)
    if not photos_mod.is_supported_image(raw):
        flash(request, "Image illisible (formats acceptés : JPEG, PNG).", "error")
        return RedirectResponse("/reglages#exercices", status_code=303)
    try:
        data = photos_mod.reencode(raw)            # JPEG borné, EXIF supprimé
    except Exception:
        flash(request, "Image illisible (formats acceptés : JPEG, PNG).", "error")
        return RedirectResponse("/reglages#exercices", status_code=303)
    exercices_mod.set_image(exo_id, data, "image/jpeg")
    flash(request, "Illustration enregistrée — elle apparaîtra sur le PDF du patient.")
    return RedirectResponse("/reglages#exercices", status_code=303)


@app.get("/reglages/exercices/{exo_id}/image")
def reglages_exercice_image_get(request: Request, exo_id: int):
    """Sert l'illustration d'un exercice (aperçu dans Réglages)."""
    if redirect := _guard(request):
        return redirect
    img = exercices_mod.get_image(exo_id)
    if not img:
        return Response(status_code=404)
    return Response(content=img[0], media_type=img[1],
                    headers={"Cache-Control": "no-store"})


@app.post("/reglages/exercices/{exo_id}/delete")
def reglages_exercice_delete(request: Request, exo_id: int):
    if redirect := _guard(request):
        return redirect
    exercices_mod.delete_perso(exo_id)
    flash(request, "Exercice retiré de votre banque.")
    return RedirectResponse("/reglages#exercices", status_code=303)


@app.get("/sterilisation", response_class=HTMLResponse)
def sterilisation_page(request: Request, tab: str = "registre",
                       cycle: int | None = None, q: str = "",
                       patient: int | None = None, consultation: int | None = None):
    """Traçabilité de stérilisation : registre / rattacher un sachet /
    recherche inverse par lot."""
    if redirect := _guard(request):
        return redirect
    if tab not in ("registre", "rattacher", "recherche"):
        tab = "registre"
    cycles = steril.list_cycles()
    selected = steril.get_cycle(cycle) if cycle else None
    if selected is None and cycles:
        # Par défaut : le cycle non conforme le plus récent (à traiter), sinon
        # le dernier cycle.
        bad = next((c for c in cycles if not c["conforme"]), None)
        selected = bad or cycles[0]
    ctx: dict = dict(tab=tab, cycles=cycles, selected=selected, q=q,
                     kpis=steril.kpis(), next_ref_hint=steril.next_ref(),
                     sachets=steril.sachets_of_cycle(selected["id"]) if selected else [])
    if tab == "rattacher":
        patients = repo.list_patients()
        current = repo.get_patient(patient) if patient else None
        ctx.update(patients=patients, rattache_patient=current,
                   patient_consultations=repo.list_consultations(current["id"]) if current else [],
                   preselect_consultation=consultation,
                   cap_reste=steril.capacite_restante(selected) if selected else None,
                   cap_utilises=steril.sachet_count(selected["id"]) if selected else 0,
                   next_numero=steril.next_numero(selected["id"]) if selected else "S-01")
    elif tab == "recherche":
        results = steril.find_cycles(q)
        found = None
        if results:
            found = steril.get_cycle(results[0]["id"])
        ctx.update(results=results, found=found,
                   exposes=steril.patients_exposes(found["id"]) if found else [])
    return render(request, "sterilisation.html", **ctx)


@app.post("/sterilisation/cycles")
def sterilisation_new_cycle(
    request: Request,
    date: str = Form(""),
    programme: str = Form("prion"),
    temperature: str = Form("134 °C"),
    duree: str = Form(""),
    nb_sachets: int = Form(0),
    operateur: str = Form(""),
    helix: str = Form("conforme"),
    integrateur: str = Form("vire"),
    notes: str = Form(""),
):
    if redirect := _guard(request):
        return redirect
    # <input type="datetime-local"> renvoie « AAAA-MM-JJTHH:MM » → format SQLite.
    date = date.replace("T", " ") if date else ""
    cid = steril.create_cycle(date, programme, temperature, duree, nb_sachets,
                              operateur, helix, integrateur, notes)
    c = steril.get_cycle(cid)
    if c and not c["conforme"]:
        flash(request, f"Cycle {c['ref']} enregistré — NON CONFORME : charge à "
              "reprocesser, vérifiez les patients exposés.", "error")
    else:
        flash(request, f"Cycle {c['ref']} enregistré." if c else "Cycle enregistré.")
    return RedirectResponse(f"/sterilisation?cycle={cid}", status_code=303)


@app.post("/sterilisation/sachets")
def sterilisation_attach_sachet(
    request: Request,
    cycle_id: int = Form(...),
    numero: str = Form(""),
    contenu: str = Form(""),
    patient_id: str = Form(""),
    consultation_id: str = Form(""),
):
    if redirect := _guard(request):
        return redirect
    cycle = steril.get_cycle(cycle_id)
    if not cycle:
        flash(request, "Cycle introuvable.", "error")
        return RedirectResponse("/sterilisation?tab=rattacher", status_code=303)
    # Garde-fou capacité (retour Nico) : impossible de rattacher plus de poches
    # que la charge déclarée du cycle (`nb_sachets`).
    reste = steril.capacite_restante(cycle)
    if reste is not None and reste <= 0:
        flash(request, f"Cycle « {cycle['ref']} » : capacité atteinte "
                       f"({cycle['nb_sachets']} sachet(s) déclaré(s), tous rattachés). "
                       "Augmentez la charge du cycle ou choisissez un autre cycle.", "error")
        return RedirectResponse(f"/sterilisation?tab=rattacher&cycle={cycle_id}", status_code=303)
    pid = int(patient_id) if patient_id.isdigit() else None
    cid = int(consultation_id) if consultation_id.isdigit() else None
    if pid and not repo.get_patient(pid):
        pid, cid = None, None
    steril.attach_sachet(cycle_id, numero, contenu, pid, cid)
    flash(request, "Sachet rattaché — chaîne de traçabilité complète.")
    return RedirectResponse(f"/sterilisation?cycle={cycle_id}", status_code=303)


@app.post("/sterilisation/sachets/{sachet_id}/edit")
def sterilisation_edit_sachet(request: Request, sachet_id: int,
                              numero: str = Form(""), contenu: str = Form("")):
    """Corrige le n° / le contenu d'un sachet (retour Nico : erreur de saisie)."""
    if redirect := _guard(request):
        return redirect
    sachet = steril.get_sachet(sachet_id)
    if not sachet:
        flash(request, "Sachet introuvable.", "error")
        return RedirectResponse("/sterilisation", status_code=303)
    steril.update_sachet(sachet_id, numero, contenu)
    flash(request, "Sachet mis à jour.")
    return RedirectResponse(f"/sterilisation?cycle={sachet['cycle_id']}", status_code=303)


@app.post("/sterilisation/sachets/{sachet_id}/delete")
def sterilisation_delete_sachet(request: Request, sachet_id: int):
    """Supprime un sachet saisi par erreur (retour Nico)."""
    if redirect := _guard(request):
        return redirect
    sachet = steril.get_sachet(sachet_id)
    if not sachet:
        flash(request, "Sachet introuvable.", "error")
        return RedirectResponse("/sterilisation", status_code=303)
    cycle_id = sachet["cycle_id"]
    steril.delete_sachet(sachet_id)
    flash(request, "Sachet supprimé.")
    return RedirectResponse(f"/sterilisation?cycle={cycle_id}", status_code=303)


# --------------------------------------------------------------------------- #
# Design system (écran interne de référence — palette, composants)
# --------------------------------------------------------------------------- #
@app.get("/design", response_class=HTMLResponse)
def design_page(request: Request):
    """Écran de référence du design system « Cabinet laiton » (QA visuelle)."""
    return render(request, "design.html")


# --------------------------------------------------------------------------- #
# Sonde publique de vivacité (détection de redémarrage par l'UI)
# --------------------------------------------------------------------------- #
@app.get("/healthz")
def healthz():
    """Sonde légère SANS authentification, exemptée du portail d'accès.

    Sert au voile « Mise à jour en cours… » à détecter de façon fiable que l'app
    a redémarré (le `boot_id` change), même si elle revient sur l'écran de
    configuration. Réduite au strict minimum : version et état de configuration
    ne sont plus exposés sans auth (ciblage de version / reconnaissance).
    """
    return JSONResponse({"boot_id": BOOT_ID})


# --------------------------------------------------------------------------- #
# Mises à jour à distance
# --------------------------------------------------------------------------- #
@app.get("/updates/status")
def updates_status(request: Request):
    """État de mise à jour connu (cache, sans réseau) — lu par le bandeau."""
    if not auth.is_authenticated(request):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    return JSONResponse(updater.cached_status())


@app.post("/updates/check")
def updates_check(request: Request):
    """Vérification EN LIGNE forcée (bouton « Vérifier les mises à jour »)."""
    if not auth.is_authenticated(request):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    return JSONResponse(updater.check_for_update(force=True))


@app.post("/updates/apply")
def updates_apply(request: Request):
    """Télécharge, vérifie (signature + empreinte) et applique la mise à jour.

    En cas de succès, l'app s'arrête ~1,5 s après la réponse : un processus
    détaché bascule le code puis relance PodoNote.
    """
    if not auth.is_authenticated(request):
        return JSONResponse({"error": "unauthorized"}, status_code=401)

    def _schedule_exit() -> None:
        import os
        import threading
        import time as _t

        def _bye() -> None:
            _t.sleep(1.5)  # laisse la réponse HTTP partir vers l'UI
            os._exit(0)    # arrêt franc : le remplaçant détaché prend le relais

        threading.Thread(target=_bye, daemon=True, name="podonote-exit").start()

    result = updater.update_now(on_shutdown=_schedule_exit)
    status_code = 200 if result.get("ok") else 400
    return JSONResponse(result, status_code=status_code)
