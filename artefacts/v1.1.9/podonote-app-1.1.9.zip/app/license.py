"""Système de licence (abonnement mensuel) — vérification côté app.

Modèle hybride : un serveur Studio Margerit (hors app) émet un JETON SIGNÉ
(Ed25519) valable ~35 jours, mis en cache localement. L'app vérifie la signature
avec la CLÉ PUBLIQUE embarquée ci-dessous, contrôle l'expiration, et tolère une
courte période de grâce. Aucune donnée de santé n'intervient ici.

Format du jeton : "<base64url(payload_json)>.<base64url(signature)>"
payload = {"licensee","plan","iat","exp"(unix s),"machine"(optionnel)}
"""
from __future__ import annotations

import base64
import json
import time
from typing import Any, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .config import DATA_DIR, ensure_dirs

# Clé publique de Studio Margerit (la clé privée signe les licences, hors app).
PUBLIC_KEY_B64 = "4BtFnPdW+EjMlukFYI+xUa4oPKBurvDV566V0sWsB7g="

LICENSE_FILE = DATA_DIR / "license.json"
GRACE_DAYS = 7
_DAY = 86400

# --- Licence DÉMO (podologues testeurs) : 7 jours OU un plafond de minutes de
# transcription, premier atteint. SANS période de grâce (l'essai s'arrête net,
# contrairement à un abonné payant qu'on ne bloque jamais sèchement). « essai »
# (plan historique) reçoit les mêmes règles.
DEMO_PLANS = ("demo", "essai")
DEMO_MINUTES_CAP = 120
DEMO_USAGE_FILE = DATA_DIR / "demo_usage.json"

# Formules connues, encodées sur 1 octet dans le jeton compact (gain de place).
# 5 = « demo » (7 j / plafond de minutes de transcription, SANS grâce) ;
# 6 = « ambassadeur » (tarif dédié Nico — fonctionnellement identique à mensuel).
PLAN_CODES = {0: "mensuel", 1: "annuel", 2: "dev", 3: "essai", 4: "trimestriel",
              5: "demo", 6: "ambassadeur"}
PLAN_IDS = {v: k for k, v in PLAN_CODES.items()}
_FMT_COMPACT = 2  # 1er octet de la charge utile binaire (distingue du JSON hérité)


# --------------------------------------------------------------------------- #
# base64url
# --------------------------------------------------------------------------- #
def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def b64u_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _public_key() -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))


# --------------------------------------------------------------------------- #
# Charge utile COMPACTE (binaire) — jeton bien plus court que l'ancien JSON.
# Format : [0]=2  [1]=code formule  [2:6]=exp en JOURS unix (uint32 BE)  [6:]=titulaire UTF-8
# La signature Ed25519 (64 o) reste le gros du jeton : incompressible hors-ligne.
# --------------------------------------------------------------------------- #
def encode_payload(licensee: str, plan: str, exp_unix: int) -> str:
    code = PLAN_IDS.get(plan, 0)
    exp_days = int(exp_unix) // _DAY
    raw = bytes([_FMT_COMPACT, code]) + exp_days.to_bytes(4, "big") + (licensee or "").encode("utf-8")
    return b64u_encode(raw)


def _decode_payload(raw: bytes) -> dict[str, Any]:
    """Décode une charge utile compacte (v2) OU l'ancien JSON (rétrocompat)."""
    if len(raw) >= 6 and raw[0] == _FMT_COMPACT:
        return {
            "plan": PLAN_CODES.get(raw[1], str(raw[1])),
            "exp": int.from_bytes(raw[2:6], "big") * _DAY,
            "licensee": raw[6:].decode("utf-8", "replace") or "—",
        }
    return json.loads(raw)  # jeton hérité (JSON)


# --------------------------------------------------------------------------- #
# Exigence de licence (au niveau du CODE, pas du .env) : se propage par OTA,
# contrairement au .env qui n'est jamais redistribué. Échappatoire pour le
# développement et les tests via la variable d'environnement PODONOTE_NO_LICENSE.
# --------------------------------------------------------------------------- #
def is_enforced() -> bool:
    import os
    return not os.environ.get("PODONOTE_NO_LICENSE")


# --------------------------------------------------------------------------- #
# Identifiant machine (binding optionnel, anonyme)
# --------------------------------------------------------------------------- #
def _machine_guid() -> Optional[str]:
    """MachineGuid Windows (stable, survit aux changements de carte réseau)."""
    import os
    if os.name != "nt":
        return None
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
            0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
        ) as k:
            val, _ = winreg.QueryValueEx(k, "MachineGuid")
            return str(val)
    except Exception:
        return None


def machine_id() -> str:
    import hashlib
    import platform
    import uuid
    # MachineGuid en priorité (stable) ; repli node()+MAC si indisponible.
    raw = _machine_guid() or f"{platform.node()}|{uuid.getnode()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


# --------------------------------------------------------------------------- #
# Vérification d'un jeton
# --------------------------------------------------------------------------- #
def machine_display(mid: str | None = None) -> str:
    """Présentation Diktae de l'identifiant machine : « DKT-XXXX-XXXX-XXXX-XXXX ».

    Pur AFFICHAGE : le calcul (machine_id) et le flux d'émission de licence sont
    inchangés — les clés déjà émises restent valables. Les tirets/le préfixe
    sont ignorés à la saisie côté support (l'hex sous-jacent suffit).
    """
    raw = (mid or machine_id()).upper()
    groups = [raw[i:i + 4] for i in range(0, len(raw), 4)]
    return "DKT-" + "-".join(groups)


def verify_token(token: str) -> tuple[bool, str, Optional[dict[str, Any]]]:
    """Vérifie la signature et le format. Renvoie (signature_ok, raison, payload).

    Ne juge PAS l'expiration ici (gérée par get_status) — seulement l'authenticité.
    """
    try:
        payload_b64, sig_b64 = token.strip().split(".")
    except ValueError:
        return False, "Format de clé invalide.", None
    try:
        sig = _b64u_decode(sig_b64)
        _public_key().verify(sig, payload_b64.encode("ascii"))
    except InvalidSignature:
        return False, "Signature invalide (clé non émise par Studio Margerit).", None
    except Exception:
        return False, "Clé illisible.", None
    try:
        payload = _decode_payload(_b64u_decode(payload_b64))
    except Exception:
        return False, "Contenu de clé illisible.", None
    if not isinstance(payload, dict):
        return False, "Contenu de clé invalide.", None
    # Binding machine optionnel
    if payload.get("machine") and payload["machine"] != machine_id():
        return False, "Cette clé est liée à un autre ordinateur.", None
    return True, "OK", payload


# --------------------------------------------------------------------------- #
# Stockage / statut
# --------------------------------------------------------------------------- #
def _load() -> Optional[str]:
    if not LICENSE_FILE.exists():
        return None
    try:
        return json.loads(LICENSE_FILE.read_text(encoding="utf-8")).get("token")
    except Exception:
        return None


def current_token() -> Optional[str]:
    """Jeton de licence actif (tel qu'enregistré), ou None. Sert aussi de clé
    d'authentification vers le proxy de clés API Studio Margerit."""
    return _load()


def activate(token: str) -> tuple[bool, str]:
    """Vérifie puis enregistre le jeton. Renvoie (succès, message)."""
    ok, reason, payload = verify_token(token)
    if not ok:
        return False, reason
    grace = 0 if payload.get("plan") in DEMO_PLANS else GRACE_DAYS
    if payload.get("exp", 0) + grace * _DAY < time.time():
        return False, "Cette clé est déjà expirée."
    ensure_dirs()
    LICENSE_FILE.write_text(json.dumps({"token": token.strip()}, indent=2), encoding="utf-8")
    return True, "Licence activée."


# --------------------------------------------------------------------------- #
# Compteur de minutes de transcription (plans démo uniquement)
# --------------------------------------------------------------------------- #
def demo_seconds_used() -> float:
    try:
        return float(json.loads(DEMO_USAGE_FILE.read_text(encoding="utf-8"))
                     .get("transcription_seconds", 0.0))
    except Exception:
        return 0.0


def add_demo_seconds(seconds: float) -> None:
    """Ajoute des secondes de transcription consommées au compteur démo.

    N'est appelé QUE lorsque le plan actif est une démo. Le compteur survit à
    une réactivation de la même clé (le fichier n'est pas remis à zéro par
    `activate`) : réémettre une clé démo ne rend pas des minutes."""
    if seconds <= 0:
        return
    ensure_dirs()
    total = demo_seconds_used() + float(seconds)
    DEMO_USAGE_FILE.write_text(
        json.dumps({"transcription_seconds": round(total, 1)}), encoding="utf-8")


def _demo_fields(plan: str) -> dict[str, Any]:
    """Champs supplémentaires du statut pour un plan démo (minutes)."""
    if plan not in DEMO_PLANS:
        return {}
    used_min = demo_seconds_used() / 60.0
    left = max(0, int(DEMO_MINUTES_CAP - used_min))
    return {
        "demo": True,
        "minutes_cap": DEMO_MINUTES_CAP,
        "minutes_used": int(used_min),
        "minutes_left": left,
    }


def get_status() -> dict[str, Any]:
    """État courant : state ∈ none|invalid|active|grace|expired (+ détails).

    Plans démo : PAS de période de grâce (active -> expired), et le statut
    porte le compteur de minutes (`minutes_left` etc.). Les minutes épuisées
    ne changent pas `state` : l'app reste consultable (fiches déjà produites),
    seule la transcription est bloquée (cf. demo_transcription_allowed)."""
    token = _load()
    if not token:
        return {"state": "none"}
    ok, reason, payload = verify_token(token)
    if not ok:
        return {"state": "invalid", "reason": reason}
    now = time.time()
    exp = payload.get("exp", 0)
    plan = payload.get("plan", "—")
    days_left = int((exp - now) // _DAY)
    base = {
        "licensee": payload.get("licensee", "—"),
        "plan": plan,
        "exp_unix": exp,
        "days_left": days_left,
        **_demo_fields(plan),
    }
    if now < exp:
        return {"state": "active", **base}
    if plan not in DEMO_PLANS and now < exp + GRACE_DAYS * _DAY:
        base["grace_days_left"] = int((exp + GRACE_DAYS * _DAY - now) // _DAY)
        return {"state": "grace", **base}
    return {"state": "expired", **base}


def is_allowed() -> bool:
    """True si l'app peut fonctionner (active ou en période de grâce)."""
    return get_status().get("state") in ("active", "grace")


def demo_transcription_allowed() -> tuple[bool, str]:
    """(autorisé, raison) : une NOUVELLE transcription peut-elle démarrer ?

    Toujours autorisé hors plan démo (et quand la licence n'est pas exigée).
    En démo : refuse quand le plafond de minutes est atteint — l'app, elle,
    reste utilisable (consultation des fiches, compta…)."""
    if not is_enforced():
        return True, ""
    st = get_status()
    if not st.get("demo"):
        return True, ""
    if st.get("minutes_left", 0) <= 0:
        return False, (
            f"Version démo : le quota de {DEMO_MINUTES_CAP} minutes de "
            "transcription est épuisé. Contactez Studio Margerit pour "
            "passer à l'abonnement — vos fiches restent consultables."
        )
    return True, ""
