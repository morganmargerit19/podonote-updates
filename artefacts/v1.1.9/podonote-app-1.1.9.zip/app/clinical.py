"""Catalogues cliniques : terrain médical du patient + étiquettes de soin.

Centralise les libellés et niveaux pour l'UI (badges) et le contexte IA.
"""
from __future__ import annotations

from typing import Any

# --------------------------------------------------------------------------- #
# Terrain médical (au niveau du PATIENT) — coché dans la fiche patient.
# severity : high (rouge, risque majeur), warn (orange), info (neutre).
# --------------------------------------------------------------------------- #
MEDICAL_FLAGS: list[dict[str, str]] = [
    {"key": "diabete", "label": "Diabète", "severity": "high",
     "hint": "Pied diabétique : risque de plaie, vigilance accrue."},
    {"key": "aomi", "label": "Troubles circulatoires (AOMI)", "severity": "high",
     "hint": "Artériopathie : cicatrisation et perfusion réduites."},
    {"key": "neuropathie", "label": "Neuropathie", "severity": "high",
     "hint": "Perte de sensibilité : risque de blessure non ressentie."},
    {"key": "anticoagulant", "label": "Anticoagulants", "severity": "warn",
     "hint": "Risque hémorragique lors des soins."},
    {"key": "immunodepression", "label": "Immunodépression", "severity": "warn",
     "hint": "Risque infectieux majoré."},
    {"key": "allergie", "label": "Allergie", "severity": "info",
     "hint": "Latex, pansements, anesthésiques locaux…"},
    {"key": "grossesse", "label": "Grossesse", "severity": "info"},
]

_FLAG_BY_KEY = {f["key"]: f for f in MEDICAL_FLAGS}

# --------------------------------------------------------------------------- #
# Étiquettes de soin (au niveau de la CONSULTATION) — couleur indicative.
# --------------------------------------------------------------------------- #
# Recentré sur le BILAN PODOLOGIQUE (retours Nico 2026-06-07). On peut en
# cocher plusieurs (au moins 3-4) sur une même consultation.
CARE_TAGS: list[dict[str, str]] = [
    {"key": "premiere_visite", "label": "1ère visite", "color": "blue"},
    {"key": "visite_suivi", "label": "Visite de suivi", "color": "slate"},
    {"key": "aponevrosite_insertion", "label": "Aponévrosite d'insertion", "color": "violet"},
    {"key": "metatarsalgie", "label": "Métatarsalgie", "color": "amber"},
    {"key": "hallux_valgus", "label": "Hallux valgus", "color": "teal"},
    {"key": "consultation_sportif", "label": "Consultation sportif", "color": "green"},
    {"key": "gonalgie", "label": "Gonalgie", "color": "red"},
    {"key": "dorsalgie", "label": "Dorsalgie", "color": "violet"},
]

_TAG_BY_KEY = {t["key"]: t for t in CARE_TAGS}


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def valid_flag_keys(keys: list[str]) -> list[str]:
    """Ne conserve que les clés de terrain connues, dans l'ordre du catalogue."""
    s = set(keys or [])
    return [f["key"] for f in MEDICAL_FLAGS if f["key"] in s]


def valid_tag_keys(keys: list[str]) -> list[str]:
    s = set(keys or [])
    return [t["key"] for t in CARE_TAGS if t["key"] in s]


def flags_detail(keys: list[str]) -> list[dict[str, str]]:
    return [_FLAG_BY_KEY[k] for k in (keys or []) if k in _FLAG_BY_KEY]


def tags_detail(keys: list[str]) -> list[dict[str, str]]:
    return [_TAG_BY_KEY[k] for k in (keys or []) if k in _TAG_BY_KEY]


def flags_context_text(keys: list[str]) -> str:
    """Phrase de contexte pour l'IA à partir du terrain médical du patient."""
    details = flags_detail(keys)
    if not details:
        return ""
    labels = ", ".join(d["label"] for d in details)
    return (
        f"TERRAIN MÉDICAL DU PATIENT (à prendre en compte pour la vigilance, "
        f"sans poser de diagnostic) : {labels}."
    )
