"""Vérifications de l'environnement hôte (chiffrement disque au repos).

La base SQLite et les exports PDF sont en clair sur le disque : la protection au
repos repose entièrement sur le chiffrement du volume système — **BitLocker** sous
Windows, **FileVault** sous macOS (choix d'archi documenté). Ce module vérifie —
en best effort, sans bloquer le démarrage — que le volume est bien chiffré, pour
afficher sinon un avertissement persistant dans l'UI.
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import threading

logger = logging.getLogger("podonote.hostcheck")

# None = indéterminé (vérification impossible : pas d'admin, plateforme inconnue…) ;
# True = volume chiffré ; False = volume NON chiffré (avertir).
_disk_encrypted: bool | None = None
_checked = False


def encryption_name() -> str:
    """Nom de la techno de chiffrement attendue sur cette plateforme (pour l'UI)."""
    if os.name == "nt":
        return "BitLocker"
    if sys.platform == "darwin":
        return "FileVault"
    return "le chiffrement du disque"


def bitlocker_protected() -> bool | None:
    """Dernier état connu du chiffrement disque (nom conservé pour compat UI).

    Rempli en arrière-plan par `start_background_check`. None tant qu'inconnu."""
    return _disk_encrypted


# Alias explicite, multiplateforme, pour le nouveau code.
disk_encryption_protected = bitlocker_protected


def _query_bitlocker() -> bool | None:
    """État BitLocker du volume système (Windows). None si indéterminable.

    Get-BitLockerVolume exige souvent l'élévation : un échec n'est PAS traité
    comme « non protégé » (on ne crie pas au loup sans certitude)."""
    cmd = [
        "powershell", "-NoProfile", "-NonInteractive", "-Command",
        "(Get-BitLockerVolume -MountPoint $env:SystemDrive).ProtectionStatus",
    ]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    out = (proc.stdout or "").strip().lower()
    # ProtectionStatus : 1/'on' = protégé ; 0/'off' = non protégé.
    if out in ("1", "on"):
        return True
    if out in ("0", "off"):
        return False
    return None


def _query_filevault() -> bool | None:
    """État FileVault (macOS) via `fdesetup status`. None si indéterminable."""
    try:
        proc = subprocess.run(
            ["fdesetup", "status"], capture_output=True, text=True, timeout=30,
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    out = (proc.stdout or "").strip().lower()
    # "FileVault is On." / "FileVault is Off."
    if "filevault is on" in out:
        return True
    if "filevault is off" in out:
        return False
    return None


def _query_disk_encryption() -> bool | None:
    """Dispatche vers la vérification propre à la plateforme."""
    if os.name == "nt":
        return _query_bitlocker()
    if sys.platform == "darwin":
        return _query_filevault()
    return None  # Linux/dev : on n'affirme rien (souvent LUKS, non détecté ici).


def start_background_check() -> None:
    """Lance la vérification dans un thread (la commande peut prendre des secondes)."""
    global _checked
    if _checked:
        return
    _checked = True

    def _run() -> None:
        global _disk_encrypted
        _disk_encrypted = _query_disk_encryption()
        if _disk_encrypted is False:
            logger.warning(
                "%s INACTIF sur le volume système : la base patients et les "
                "exports PDF ne sont pas chiffrés au repos.", encryption_name(),
            )
        elif _disk_encrypted is None:
            logger.info("État du chiffrement disque indéterminable (droits insuffisants ?).")

    threading.Thread(target=_run, daemon=True, name="podonote-hostcheck").start()
