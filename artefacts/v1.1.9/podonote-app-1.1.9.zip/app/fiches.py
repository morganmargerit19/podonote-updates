"""Registre des TYPES DE FICHE (« profession » configurable).

Objectif (roadmap multi-métiers, cf. CLAUDE.md) : faire coexister plusieurs
méthodologies de bilan — podologie/semelles (historique), soin de pédicurie,
préférence motrice « Volodalen », futurs métiers (kiné/ostéo/chiro) — SANS
forker le socle commun (ASR, pseudonymisation, persistance, sauvegarde, OTA).

Chaque type expose la MÊME interface minimale, consommée par le pipeline LLM et
la couche de persistance :
  - defaults() -> dict         : fiche vide normalisée (copie profonde indépendante)
  - normalize(raw) -> dict     : coercition d'une sortie brute vers le schéma du type
  - empty(reason) -> dict      : fiche « honnête » quand l'audio est inexploitable
  - system_prompt : str        : consignes de remplissage pour le LLM
  - ai_filled : bool           : l'audio/LLM alimente-t-il la fiche ?

Le rendu UI/PDF reste géré par type (dispatch sur `bilan_type` côté templates et
app/rgpd.py). Ce module ne s'occupe QUE du schéma de données et du prompt.

⚠️ Rétro-compatibilité : le type par défaut est « podologie » (l'unique fiche
historique). Toute consultation sans `bilan_type` explicite est une fiche
podologie — les fiches enregistrées avant l'introduction de ce registre restent
donc lues et normalisées EXACTEMENT comme avant.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Callable

from . import bilan as _podologie
from . import soin as _soin
from . import volodalen as _volodalen

# Type de fiche par défaut : la fiche podologique historique (app/bilan.py).
DEFAULT_TYPE = "podologie"


@dataclass(frozen=True)
class FicheType:
    """Descripteur d'un type de fiche (données + prompt). Voir docstring module."""

    key: str
    label: str                       # libellé long (titre de fiche, ex. « Bilan podologique »)
    short_label: str                 # libellé court (badge, sélecteur)
    defaults: Callable[[], dict]     # fiche vide normalisée (copie indépendante)
    normalize: Callable[[Any], dict]
    empty: Callable[[str], dict]
    system_prompt: str
    ai_filled: bool = True           # l'audio/LLM remplit-il la fiche ?
    selectable: bool = True          # proposé dans le sélecteur de création ? (False =
                                     # type dont l'UI rendu/édition n'est pas encore prête)


_REGISTRY: dict[str, FicheType] = {}


def register(fiche: FicheType) -> None:
    """Enregistre (ou remplace) un type de fiche."""
    _REGISTRY[fiche.key] = fiche


def get(key: str | None) -> FicheType:
    """Type de fiche pour cette clé, ou le type par défaut si inconnue/absente."""
    return _REGISTRY.get(key or DEFAULT_TYPE) or _REGISTRY[DEFAULT_TYPE]


def coerce_key(key: str | None) -> str:
    """Clé de type valide (retombe sur le type par défaut si inconnue/absente)."""
    return key if key in _REGISTRY else DEFAULT_TYPE


def exists(key: str | None) -> bool:
    return key in _REGISTRY


def keys() -> list[str]:
    return list(_REGISTRY.keys())


def all_types() -> list[FicheType]:
    return list(_REGISTRY.values())


def selectable_types() -> list[FicheType]:
    """Types proposés à la création (ceux dont l'UI rendu/édition est prête)."""
    return [f for f in _REGISTRY.values() if f.selectable]


# --------------------------------------------------------------------------- #
# Enregistrement du type HISTORIQUE : podologie (schéma défini dans app/bilan.py)
# --------------------------------------------------------------------------- #
register(FicheType(
    key="podologie",
    label="Bilan podologique",
    short_label="Podologie",
    defaults=lambda: copy.deepcopy(_podologie.DEFAULTS),
    normalize=_podologie.normalize,
    empty=_podologie.empty,
    system_prompt=_podologie.SYSTEM_PROMPT,
    ai_filled=True,
))

# --------------------------------------------------------------------------- #
# Fiche SOIN de pédicurie (acte de soin + bilan de gradation diabétique).
# --------------------------------------------------------------------------- #
register(FicheType(
    key="soin",
    label="Fiche de soin (pédicurie)",
    short_label="Soin",
    defaults=lambda: copy.deepcopy(_soin.DEFAULTS),
    normalize=_soin.normalize,
    empty=_soin.empty,
    system_prompt=_soin.SYSTEM_PROMPT,
    ai_filled=True,
))

# --------------------------------------------------------------------------- #
# Bilan préférence motrice (méthode Volodalen) — autre métier (prépa physique).
# --------------------------------------------------------------------------- #
register(FicheType(
    key="volodalen",
    label="Bilan préférence motrice",
    short_label="Préf. motrice",
    defaults=lambda: copy.deepcopy(_volodalen.DEFAULTS),
    normalize=_volodalen.normalize,
    empty=_volodalen.empty,
    system_prompt=_volodalen.SYSTEM_PROMPT,
    ai_filled=True,
))
