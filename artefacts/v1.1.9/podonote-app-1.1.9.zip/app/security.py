"""Sécurité : identifiants hachés, secret de session persistant, anti-bruteforce.

Les identifiants (mot de passe app + PIN upload) ne sont PLUS stockés en clair.
Ils sont définis au premier lancement via l'assistant /setup et stockés hachés
(PBKDF2-HMAC-SHA256 + sel) dans data/auth.json.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from typing import Optional

from .config import DATA_DIR, ensure_dirs

AUTH_FILE = DATA_DIR / "auth.json"
_PBKDF2_ROUNDS = 200_000


class AuthStateError(RuntimeError):
    """auth.json présent mais illisible/corrompu : on échoue FERMÉ (jamais de bypass)."""


# --------------------------------------------------------------------------- #
# Hachage
# --------------------------------------------------------------------------- #
def _hash(value: str, salt: bytes) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", value.encode("utf-8"), salt, _PBKDF2_ROUNDS)
    return dk.hex()


def _make_record(value: str) -> dict:
    salt = secrets.token_bytes(16)
    return {"salt": salt.hex(), "hash": _hash(value, salt)}


def _check(value: str, record: Optional[dict]) -> bool:
    if not record:
        return False
    try:
        salt = bytes.fromhex(record["salt"])
        expected = record["hash"]
    except (KeyError, ValueError):
        return False
    return hmac.compare_digest(_hash(value or "", salt), expected)


# --------------------------------------------------------------------------- #
# Lecture / écriture du fichier d'auth
# --------------------------------------------------------------------------- #
def _read_raw() -> Optional[str]:
    """Lit auth.json en tolérant un VERROU transitoire (antivirus/OneDrive/disque lent).

    Renvoie None si le fichier n'existe pas. Lève AuthStateError s'il existe mais
    reste illisible après quelques tentatives — on ne dégrade JAMAIS en « non
    configuré » (sinon /setup deviendrait accessible sans authentification).
    """
    last_exc: Optional[Exception] = None
    for _ in range(6):
        try:
            return AUTH_FILE.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None
        except PermissionError as exc:        # verrou transitoire -> on réessaie
            last_exc = exc
            time.sleep(0.15)
        except OSError as exc:
            last_exc = exc
            time.sleep(0.15)
    raise AuthStateError(f"auth.json illisible (verrouillé ?) : {last_exc}")


def _load() -> dict:
    if not AUTH_FILE.exists():
        return {}
    raw = _read_raw()
    if raw is None:
        return {}
    try:
        data = json.loads(raw)
    except Exception as exc:
        raise AuthStateError(f"auth.json corrompu : {exc}") from exc
    if not isinstance(data, dict):
        raise AuthStateError("auth.json malformé (objet attendu).")
    return data


def _save(data: dict) -> None:
    """Écriture ATOMIQUE : on écrit un .tmp puis on remplace (os.replace atomique).

    Évite qu'une coupure/verrou laisse un auth.json tronqué (qui, mal géré,
    ouvrirait /setup sans authentification)."""
    ensure_dirs()
    tmp = AUTH_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, AUTH_FILE)


def exists() -> bool:
    """True dès que le fichier d'identifiants existe sur le disque (même illisible)."""
    return AUTH_FILE.exists()


def is_configured() -> bool:
    """Configuré = identifiants présents. Si le fichier existe mais est illisible,
    on considère l'app COMME configurée (jamais de bascule vers /setup sans auth)."""
    try:
        data = _load()
    except AuthStateError:
        return AUTH_FILE.exists()
    return bool(data.get("password") and data.get("pin"))


def configure(password: str, pin: str) -> None:
    """Définit (ou réinitialise) le mot de passe et le PIN. Conserve le secret de session."""
    data = _load()
    data["password"] = _make_record(password)
    data["pin"] = _make_record(pin)
    data.setdefault("secret_key", secrets.token_hex(32))
    _save(data)


def verify_password(password: str) -> bool:
    return _check(password, _load().get("password"))


def verify_pin(pin: str) -> bool:
    return _check(pin, _load().get("pin"))


def get_or_create_secret() -> str:
    """Secret de session persistant (généré une fois, survit aux redémarrages)."""
    data = _load()
    if not data.get("secret_key"):
        data["secret_key"] = secrets.token_hex(32)
        _save(data)
    return data["secret_key"]


# --------------------------------------------------------------------------- #
# Anti-bruteforce (en mémoire, mono-utilisateur)
# --------------------------------------------------------------------------- #
class RateLimiter:
    """Verrou progressif après N échecs sur une fenêtre glissante."""

    def __init__(self, max_attempts: int = 5, window: int = 300, lockout: int = 60):
        self.max_attempts = max_attempts
        self.window = window
        self.lockout = lockout
        self._fails: dict[str, list[float]] = {}
        self._locked_until: dict[str, float] = {}

    def locked_seconds(self, key: str) -> int:
        until = self._locked_until.get(key, 0)
        remaining = until - time.monotonic()
        return int(remaining) if remaining > 0 else 0

    def record_failure(self, key: str) -> None:
        now = time.monotonic()
        fails = [t for t in self._fails.get(key, []) if now - t < self.window]
        fails.append(now)
        self._fails[key] = fails
        if len(fails) >= self.max_attempts:
            self._locked_until[key] = now + self.lockout
            self._fails[key] = []

    def reset(self, key: str) -> None:
        self._fails.pop(key, None)
        self._locked_until.pop(key, None)


login_limiter = RateLimiter(max_attempts=5, window=300, lockout=60)
pin_limiter = RateLimiter(max_attempts=5, window=300, lockout=60)
