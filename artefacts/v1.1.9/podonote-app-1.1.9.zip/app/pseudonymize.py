"""Pseudonymisation avant appel à un LLM cloud (RGPD).

PRINCIPE : l'audio ne quitte JAMAIS la machine (l'ASR reste local). Quand la
génération de fiche est déléguée à un backend cloud (Sonnet), on n'envoie QUE
du **texte pseudonymisé** : les identifiants directs (nom, prénom, date de
naissance, téléphone, e-mail…) sont remplacés par des jetons neutres AVANT
l'appel, puis **réinjectés** dans la réponse. Le mapping jeton↔valeur reste
strictement local et n'est jamais transmis.

Deux niveaux, complémentaires :
  1. Ancres CERTAINES issues du dossier patient (nom/prénom/date de naissance).
     Le rapprochement est INSENSIBLE AUX ACCENTS (le dossier peut dire « Helene »
     alors que l'ASR transcrit « Hélène »), tolère espace OU tiret entre les
     composants d'un nom composé (« Dupont-Martin » transcrit « Dupont Martin »),
     et la date de naissance — stockée en ISO « AAAA-MM-JJ » — est déclinée en
     tous les formats dits à l'oral (12/03/1980, 12-03-1980, « 12 mars 1980 »…),
     sinon elle ne serait jamais masquée.
     Une passe FLOUE complète l'exact pour les noms/prénoms mal orthographiés
     par l'ASR (« Dupond » pour « Dupont ») : distance d'édition ≤ 1 (≤ 2 entre
     mots longs), avec garde-fous stricts — mot capitalisé, même initiale, mots
     français courants JAMAIS masqués (un faux masquage fausserait la fiche).
  2. Filet GÉNÉRIQUE par regex (e-mail, téléphone, dates chiffrées ET en lettres,
     suites de ≥ 5 chiffres : n° de sécu, code postal, identifiants).

Garde-fou « egress » : avant l'envoi, on RE-VÉRIFIE qu'aucune valeur d'ancre
certaine ne subsiste (fail-safe) — cf. guard_certain().

Limite connue : les noms de TIERS dits à l'oral (conjoint, médecin traitant…)
ne sont pas des ancres du dossier ; leur masquage fiable nécessitera une NER FR
locale (chantier ultérieur).
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Optional

# Jetons neutres, improbables dans une transcription, faciles à restaurer.
_TOKEN = "‹{kind}_{n}›"

# Longueur minimale d'une ancre purement alphabétique. Les patients « Ba »,
# « Ly » existent : on accepte dès 2 lettres, MAIS les ancres de 2-3 lettres ne
# matchent qu'en EXACT avec majuscule initiale (cf. _anchor_pattern) et sont
# refusées si ce sont des mots français courants (« Le », « Ce »…).
_MIN_ALPHA_ANCHOR = 2
# En deçà ou égal à ce nombre de lettres, une ancre est dite « courte ».
_SHORT_ANCHOR_MAX = 3
# Longueur minimale (mot du texte ET composant d'ancre) pour le masquage FLOU.
_MIN_FUZZY_LEN = 4

_MOIS = [
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre",
]

# Classes de caractères pour le rapprochement insensible aux accents.
_ACCENTS = {
    "a": "aàâä", "c": "cç", "e": "eéèêë", "i": "iïî",
    "o": "oôö", "u": "uùûü", "y": "yÿ", "n": "nñ",
}


def _fold(ch: str) -> str:
    return unicodedata.normalize("NFKD", ch).encode("ascii", "ignore").decode().lower()


# Mots français courants susceptibles d'apparaître CAPITALISÉS (début de phrase,
# titres) : JAMAIS soumis au masquage flou ni acceptés comme ancre courte — un
# faux masquage de mot courant rend la fiche fausse. Comparaison effectuée en
# minuscules SANS accents (via _fold).
_COMMON_FR_CAP = frozenset("""
    le la les un une des du de il elle ils elles on nous vous je tu ce cet
    cette ces ca cela celui celle celles ceux mon ma mes ton ta tes son sa ses
    notre votre leur leurs et ou mais donc or ni car alors ainsi apres avant
    aujourd hier demain bonjour bonsoir merci pardon oui non si peut etre pas
    plus moins tres bien mal voila voici attention docteur madame monsieur
    mademoiselle patient patiente ensuite enfin puis bref comme meme autre
    autres beaucoup encore deja aussi tout toute tous toutes rien chaque quand
    comment pourquoi qui que quoi parce pour par dans sur sous avec sans chez
    entre vers selon pendant depuis cependant pourtant neanmoins toutefois
    sinon effectivement justement normalement generalement finalement
    maintenant ici bon bonne allez allons voyons regardez regardons
    dites faites faut est sont avait accord premierement
    deuxiemement pied pieds gauche droite droit talon cheville genou genoux
    semelle semelles douleur douleurs examen bilan marche appui orteil orteils
""".split())


def _levenshtein(a: str, b: str) -> int:
    """Distance d'édition classique, en pur Python (chaînes courtes : noms)."""
    if a == b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _char_class(ch: str) -> str:
    """Pour une lettre, une classe couvrant ses variantes accentuées (2 casses)."""
    base = _fold(ch)
    variants = _ACCENTS.get(base)
    if variants:
        return "[" + variants + variants.upper() + "]"
    return re.escape(ch)


def _accent_insensitive(value: str) -> str:
    """Motif regex insensible aux accents pour une valeur (lettres -> classes)."""
    return "".join(_char_class(c) if c.isalpha() else re.escape(c) for c in value)


def _char_class_keepcase(ch: str) -> str:
    """Comme _char_class mais en CONSERVANT la casse (ancres courtes : exactes)."""
    base = _fold(ch)
    variants = _ACCENTS.get(base)
    if variants and ch.isalpha():
        return "[" + (variants.upper() if ch.isupper() else variants) + "]"
    return re.escape(ch)


def _accent_insensitive_keepcase(value: str) -> str:
    """Motif insensible aux accents mais SENSIBLE à la casse (ancres 2-3 lettres)."""
    return "".join(
        _char_class_keepcase(c) if c.isalpha() else re.escape(c) for c in value
    )


def _phone_regex() -> re.Pattern[str]:
    # FR : 0X XX XX XX XX ou +33[ .-]X XX XX XX XX, séparateurs espace/point/tiret.
    return re.compile(r"\b(?:\+33[ .\-]?|0)[1-9](?:[ .\-]?\d{2}){4}\b")


_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
# Dates numériques : 12/03/1980, 12-03-80, 12.3.1980…
_DATE_RE = re.compile(r"\b\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}\b")
# Dates en LETTRES : « 12 mars 1980 », « 5 fevrier 90 » (mois insensible aux accents).
_DATE_TEXT_RE = re.compile(
    r"\b\d{1,2}\s+(?:janv|f[ée]vr|mars|avr|mai|juin|juil|ao[uû]t|sept|oct|nov|d[ée]c)[a-zûéèêç]*\s+\d{2,4}\b",
    re.IGNORECASE,
)
# Suites de chiffres GROUPÉES (n° de sécu, code postal, identifiants), seuil
# 5 chiffres : un code postal (75011) doit être masqué ; une année (1980) non.
_LONGNUM_RE = re.compile(r"\b\d(?:[ .\-]?\d){4,}\b")
# Mots (suites de lettres, accents compris) pour la passe de masquage flou.
_WORD_RE = re.compile(r"[^\W\d_]+")


@dataclass
class Pseudonymizer:
    """Construit et applique un masquage réversible pour un patient donné."""

    mapping: dict[str, str] = field(default_factory=dict)        # jeton -> valeur réelle
    _seen: dict[str, str] = field(default_factory=dict)          # valeur(lower) -> jeton
    _counters: dict[str, int] = field(default_factory=dict)
    # Ancres CERTAINES du dossier (kind, valeur) : pour le garde-fou egress.
    _certain: list[tuple[str, str]] = field(default_factory=list)

    # ------------------------------------------------------------------ #
    # Construction des ancres certaines depuis le dossier patient
    # ------------------------------------------------------------------ #
    @classmethod
    def for_patient(cls, patient: Optional[dict[str, Any]]) -> "Pseudonymizer":
        p = cls()
        if not patient:
            return p
        for kind, key in (("PRENOM", "prenom"), ("NOM", "nom")):
            val = (patient.get(key) or "").strip()
            letters = re.sub(r"[\s\-]+", "", val)
            if len(letters) < _MIN_ALPHA_ANCHOR:
                continue
            # Ancre courte qui est AUSSI un mot français courant (« Le »,
            # « Ce »…) : la masquer fausserait la fiche, on s'abstient.
            if len(letters) <= _SHORT_ANCHOR_MAX and _fold(val) in _COMMON_FR_CAP:
                continue
            p._register_anchor(kind, val)
        for dob in _dob_variants((patient.get("date_naissance") or "").strip()):
            p._register_anchor("DATE", dob)
        return p

    def _token_for(self, kind: str, value: str) -> str:
        norm = value.lower()
        if norm in self._seen:
            return self._seen[norm]
        self._counters[kind] = self._counters.get(kind, 0) + 1
        tok = _TOKEN.format(kind=kind, n=self._counters[kind])
        self._seen[norm] = tok
        self.mapping[tok] = value
        return tok

    def _register_anchor(self, kind: str, value: str) -> None:
        self._token_for(kind, value)
        self._certain.append((kind, value))

    @staticmethod
    def _is_alpha(value: str) -> bool:
        return value.replace(" ", "").replace("-", "").isalpha()

    def _anchor_pattern(self, value: str) -> re.Pattern[str]:
        if not self._is_alpha(value):
            return re.compile(_accent_insensitive(value), re.IGNORECASE)
        # Nom/prénom : borné aux limites de mots, et tolère espace OU tiret
        # entre composants (« Dupont-Martin » transcrit « Dupont Martin »).
        comps = [c for c in re.split(r"[\s\-]+", value) if c]
        if len("".join(comps)) <= _SHORT_ANCHOR_MAX:
            # Ancre courte (« Ba », « Ly ») : match EXACT avec majuscule
            # initiale, SENSIBLE à la casse (sinon « ba », « la », « ce »…
            # seraient masqués à tort). Accents tolérés (« Léa » / « Lea »).
            core = r"[\s\-]+".join(
                _accent_insensitive_keepcase(c[:1].upper() + c[1:].lower())
                for c in comps
            )
            return re.compile(rf"\b{core}\b")
        core = r"[\s\-]+".join(_accent_insensitive(c) for c in comps)
        return re.compile(rf"\b{core}\b", re.IGNORECASE)

    # ------------------------------------------------------------------ #
    # Masquage / restauration
    # ------------------------------------------------------------------ #
    def scrub(self, text: str) -> str:
        """Remplace identifiants par des jetons. Renseigne self.mapping."""
        if not text:
            return text
        out = text

        # 1) Filet auto-contenu d'abord (e-mail, téléphone) : ces motifs englobent
        #    parfois le nom (prenom.nom@…). Les masquer en entier AVANT les ancres.
        out = _EMAIL_RE.sub(lambda m: self._token_for("EMAIL", m.group(0)), out)
        out = _phone_regex().sub(lambda m: self._token_for("TEL", m.group(0)), out)

        # 2) Ancres certaines du dossier (insensibles aux accents).
        for _norm, tok in list(self._seen.items()):
            real = self.mapping.get(tok, "")
            if real:
                out = self._anchor_pattern(real).sub(tok, out)

        # 2bis) Masquage FLOU : Whisper orthographie les noms propres au hasard
        #       (« Dupond » pour « Dupont ») — on rattrape les quasi-homographes.
        out = self._fuzzy_mask_names(out)

        # 3) Filet final. LONGNUM AVANT DATE pour ne pas laisser un fragment de
        #    chiffres en clair sur des séparateurs mixtes. Puis dates en lettres.
        out = _LONGNUM_RE.sub(lambda m: self._token_for("NUM", m.group(0)), out)
        out = _DATE_RE.sub(lambda m: self._token_for("DATE", m.group(0)), out)
        out = _DATE_TEXT_RE.sub(lambda m: self._token_for("DATE", m.group(0)), out)
        return out

    def _fuzzy_name_targets(self) -> list[tuple[str, str]]:
        """Composants (≥ 4 lettres, repliés) des ancres NOM/PRENOM + leur jeton."""
        targets: list[tuple[str, str]] = []
        for kind, value in self._certain:
            if kind not in ("PRENOM", "NOM"):
                continue  # le flou ne concerne QUE les noms/prénoms
            tok = self._seen.get(value.lower())
            if not tok:
                continue
            for part in re.split(r"[\s\-]+", value):
                folded = _fold(part)
                if len(folded) >= _MIN_FUZZY_LEN:
                    targets.append((folded, tok))
        return targets

    def _fuzzy_mask_names(self, text: str) -> str:
        """Masque les mots capitalisés QUASI identiques à une ancre nom/prénom.

        L'ASR orthographie les noms propres au hasard (« Dupond » / « Dupont »).
        Règle CONSERVATRICE : mot commençant par une majuscule (les noms propres
        sortent capitalisés de l'ASR), ≥ 4 lettres, même initiale (sans accents
        ni casse), distance de Levenshtein ≤ 1 (ou ≤ 2 si mot ET composant font
        ≥ 8 lettres). Les mots français courants (_COMMON_FR_CAP) ne sont JAMAIS
        masqués : un faux masquage rendrait la fiche fausse."""
        targets = self._fuzzy_name_targets()
        if not targets:
            return text

        def repl(m: re.Match[str]) -> str:
            word = m.group(0)
            if not word[0].isupper():
                return word
            if m.start() > 0 and m.string[m.start() - 1] == "‹":
                return word  # intérieur d'un jeton déjà posé (‹NOM_1›…)
            folded = _fold(word)
            if len(folded) < _MIN_FUZZY_LEN or folded in _COMMON_FR_CAP:
                return word
            for comp, tok in targets:
                if folded[0] != comp[0]:
                    continue
                maxd = 2 if (len(folded) >= 8 and len(comp) >= 8) else 1
                if _levenshtein(folded, comp) <= maxd:
                    return tok
            return word

        return _WORD_RE.sub(repl, text)

    def guard_certain(self, text: str) -> tuple[str, list[str]]:
        """Garde-fou egress : re-masque toute valeur d'ancre CERTAINE résiduelle.

        Renvoie (texte_propre, liste_des_valeurs_re-masquees). Si la liste est non
        vide, c'est qu'un identifiant direct du patient subsistait : il a été
        masqué ici (fail-safe), l'appelant doit logguer l'anomalie."""
        if not text:
            return text, []
        out = text
        leaked: list[str] = []
        for kind, value in self._certain:
            pat = self._anchor_pattern(value)
            if pat.search(out):
                leaked.append(value)
                out = pat.sub(self._token_for(kind, value), out)
        return out, leaked

    def guard_generic(self, text: str) -> tuple[str, bool]:
        """Garde-fou egress GÉNÉRIQUE : re-passe les filets regex (e-mail, tél.,
        suites de chiffres, dates chiffrées et en lettres) sur le texte SORTANT.

        En fonctionnement nominal, scrub() les a déjà appliqués sur l'intégralité
        du prompt : ce fail-safe ne masque donc rien de plus. Il existe pour
        couvrir tout résidu d'un texte assemblé APRÈS scrub (évolution du code).
        Ne peut que masquer DAVANTAGE de PII, jamais moins. Renvoie (texte, modifié)."""
        if not text:
            return text, False
        out = text
        out = _EMAIL_RE.sub(lambda m: self._token_for("EMAIL", m.group(0)), out)
        out = _phone_regex().sub(lambda m: self._token_for("TEL", m.group(0)), out)
        out = _LONGNUM_RE.sub(lambda m: self._token_for("NUM", m.group(0)), out)
        out = _DATE_RE.sub(lambda m: self._token_for("DATE", m.group(0)), out)
        out = _DATE_TEXT_RE.sub(lambda m: self._token_for("DATE", m.group(0)), out)
        return out, (out != text)

    def restore(self, text: str) -> str:
        """Réinjecte les valeurs réelles à la place des jetons."""
        if not text:
            return text
        out = text
        for tok in sorted(self.mapping, key=len, reverse=True):
            out = out.replace(tok, self.mapping[tok])
        return out

    def restore_obj(self, obj: Any) -> Any:
        """Restaure récursivement dans une structure JSON (dict/list/str)."""
        if isinstance(obj, str):
            return self.restore(obj)
        if isinstance(obj, list):
            return [self.restore_obj(x) for x in obj]
        if isinstance(obj, dict):
            return {k: self.restore_obj(v) for k, v in obj.items()}
        return obj

    def residual_tokens(self, text: str) -> list[str]:
        """Jetons non restaurés (LLM les a altérés) : pour détecter une dégradation."""
        return re.findall(r"‹[A-Z]+_\d+›", text or "")

    def has_tokens(self) -> bool:
        return bool(self.mapping)


# --------------------------------------------------------------------------- #
# Déclinaison d'une date de naissance ISO en formats dits à l'oral
# --------------------------------------------------------------------------- #
def _dob_variants(iso: str) -> list[str]:
    """À partir de 'AAAA-MM-JJ', génère les écritures probables (chiffres + lettres)."""
    if not iso:
        return []
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", iso)
    if not m:
        return [iso] if iso else []
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if not (1 <= mo <= 12 and 1 <= d <= 31):
        return [iso]
    out = [iso]
    for sep in ("/", "-", "."):
        out.append(f"{d:02d}{sep}{mo:02d}{sep}{y}")
        out.append(f"{d}{sep}{mo}{sep}{y}")
        out.append(f"{d:02d}{sep}{mo:02d}{sep}{y % 100:02d}")
    mois = _MOIS[mo - 1]
    out.append(f"{d} {mois} {y}")
    out.append(f"{d:02d} {mois} {y}")
    out.append(f"{d}er {mois} {y}" if d == 1 else f"{d} {mois} {y}")
    # Dé-duplique en conservant l'ordre.
    seen: set[str] = set()
    uniq = []
    for v in out:
        if v not in seen:
            seen.add(v)
            uniq.append(v)
    return uniq
