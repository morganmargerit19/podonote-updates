"""Banque d'exercices à remettre au patient (étirements, mobilité, renforcement…).

Le praticien coche les exercices utiles → un seul PDF est généré (à imprimer ou à
enregistrer pour l'envoyer). Contenu 100 % TEXTE et générique (pas d'images ni de
protocole sous copyright — cf. la remarque de Nico sur Volodalen) : descriptions
rédigées, réutilisables librement. Catalogue de départ, à enrichir avec Nico.
"""
from __future__ import annotations

# Chaque exercice : clé stable, catégorie (regroupement UI/PDF), titre, description.
EXERCICES = [
    {"key": "etir_gastro", "categorie": "Étirements",
     "titre": "Étirement du mollet (gastrocnémiens)",
     "description": "Face à un mur, mains appuyées. La jambe à étirer est tendue en "
                    "arrière, talon au sol, pointe de pied vers le mur. Avancez le "
                    "bassin jusqu'à sentir l'étirement à l'arrière du mollet. "
                    "Tenez 30 secondes, 3 fois de chaque côté."},
    {"key": "etir_soleaire", "categorie": "Étirements",
     "titre": "Étirement du soléaire",
     "description": "Même position que pour le mollet, mais genou arrière LÉGÈREMENT "
                    "FLÉCHI, talon au sol. L'étirement se ressent plus bas, vers le "
                    "tendon d'Achille. Tenez 30 secondes, 3 fois de chaque côté."},
    {"key": "etir_aponevrose", "categorie": "Étirements",
     "titre": "Étirement de l'aponévrose plantaire",
     "description": "Assis, croisez la cheville sur le genou opposé. Saisissez les "
                    "orteils et tirez-les doucement vers vous jusqu'à sentir la tension "
                    "sous le pied. Tenez 30 secondes, 3 fois — surtout le matin avant "
                    "le premier pas."},
    {"key": "mob_cheville", "categorie": "Mobilité",
     "titre": "Mobilité de la cheville (alphabet)",
     "description": "Assis, jambe tendue. Dessinez lentement l'alphabet dans l'air avec "
                    "le gros orteil, en ne bougeant que la cheville. 1 à 2 passages "
                    "par pied."},
    {"key": "short_foot", "categorie": "Renforcement",
     "titre": "Renforcement de la voûte (« short foot »)",
     "description": "Pied à plat au sol. Sans crisper ni recroqueviller les orteils, "
                    "rapprochez la base du gros orteil vers le talon pour creuser "
                    "légèrement la voûte. Tenez 5 secondes, relâchez. 10 répétitions, "
                    "2 à 3 séries."},
    {"key": "serviette", "categorie": "Renforcement",
     "titre": "Ramassage de serviette",
     "description": "Assis, une serviette au sol sous le pied. Agrippez-la avec les "
                    "orteils pour la ramener vers vous, puis relâchez. 10 à 15 "
                    "répétitions par pied."},
    {"key": "orteils_ecart", "categorie": "Renforcement",
     "titre": "Écartement des orteils",
     "description": "Pied à plat, écartez les orteils les uns des autres sans décoller "
                    "le pied du sol, puis relâchez lentement. 10 répétitions."},
    {"key": "flechisseurs", "categorie": "Renforcement",
     "titre": "Attrape-objets avec les orteils",
     "description": "Posez de petits objets au sol (billes, stylo) et attrapez-les avec "
                    "les orteils pour les déposer dans une coupelle. 1 à 2 minutes "
                    "par pied."},
    {"key": "proprio_unipodal", "categorie": "Proprioception",
     "titre": "Équilibre sur une jambe",
     "description": "Debout, tenez-vous sur une seule jambe, regard devant, près d'un "
                    "appui en cas de besoin. Maintenez 30 secondes. Progression : yeux "
                    "fermés, ou sur un coussin. 3 fois de chaque côté."},
    {"key": "automassage", "categorie": "Auto-massage",
     "titre": "Auto-massage plantaire à la balle",
     "description": "Assis, faites rouler une balle (tennis ou spécifique) sous la "
                    "voûte plantaire, du talon vers les orteils, pendant 1 à 2 minutes "
                    "par pied. Idéal le matin ou après une station debout prolongée."},
    {"key": "etir_chaine_post", "categorie": "Étirements",
     "titre": "Étirement de la chaîne postérieure",
     "description": "Debout, jambes tendues, penchez-vous lentement vers l'avant en "
                    "gardant le dos long, mains vers les pieds, sans forcer. Vous "
                    "étirez l'arrière des jambes. Tenez 30 secondes, 3 fois, sans "
                    "à-coups."},
    {"key": "mob_orteils", "categorie": "Mobilité",
     "titre": "Mobilité du gros orteil",
     "description": "Assis, pied à plat. Décollez UNIQUEMENT le gros orteil en gardant "
                    "les autres au sol, puis inversez (gros orteil au sol, les autres "
                    "levés). Contrôlez le mouvement. 10 répétitions par pied."},
    {"key": "releve_talons", "categorie": "Renforcement",
     "titre": "Relevés de talons (mollets)",
     "description": "Debout, appui léger sur un plan de travail. Montez lentement sur "
                    "la pointe des pieds, tenez 2 secondes en haut, redescendez en "
                    "contrôlant. 12 à 15 répétitions, 2 à 3 séries. Progression : sur "
                    "une seule jambe."},
    {"key": "proprio_fentes", "categorie": "Proprioception",
     "titre": "Transferts d'appui contrôlés",
     "description": "Debout, pieds écartés largeur de bassin. Transférez lentement le "
                    "poids d'un pied sur l'autre, puis d'avant en arrière, en gardant "
                    "l'équilibre. 1 à 2 minutes, regard devant."},
]

_BY_KEY = {e["key"]: e for e in EXERCICES}

# --------------------------------------------------------------------------- #
# Exercices PERSONNELS du praticien (retour Nico) — enregistrés dans Réglages et
# ajoutés à la banque intégrée. Clé préfixée « perso: » : aucune collision
# possible avec les clés du catalogue livré.
# --------------------------------------------------------------------------- #
PERSO_PREFIX = "perso:"


def list_perso(actifs_seulement: bool = True) -> list[dict]:
    """Exercices personnels, au même format que le catalogue intégré.

    Tolérant : si la table n'existe pas encore (base pas initialisée, tests
    unitaires purs), on renvoie simplement la banque intégrée sans erreur."""
    import sqlite3
    from .db import get_connection
    try:
        conn = get_connection()
    except Exception:
        return []
    try:
        where = "WHERE actif = 1" if actifs_seulement else ""
        # On NE charge PAS le BLOB image ici (listes fréquentes) : juste un
        # indicateur de présence ; l'image est lue à la demande par get_image().
        rows = conn.execute(
            "SELECT id, titre, categorie, description,"
            " (image IS NOT NULL) AS has_image"
            f" FROM exercices_perso {where} ORDER BY ordre, id").fetchall()
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()
    return [{"key": f"{PERSO_PREFIX}{r['id']}", "id": r["id"],
             "categorie": (r["categorie"] or "Mes exercices").strip() or "Mes exercices",
             "titre": r["titre"], "description": r["description"] or "",
             "has_image": bool(r["has_image"]), "perso": True}
            for r in rows]


def create_perso(titre: str, categorie: str, description: str) -> int:
    from .db import db_cursor
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO exercices_perso (titre, categorie, description, ordre)"
            " VALUES (?, ?, ?, (SELECT COALESCE(MAX(ordre), -1) + 1 FROM exercices_perso))",
            (titre.strip(), (categorie or "Mes exercices").strip() or "Mes exercices",
             (description or "").strip()),
        )
        return int(cur.lastrowid)


def update_perso(exo_id: int, titre: str, categorie: str, description: str) -> None:
    from .db import db_cursor
    with db_cursor() as cur:
        cur.execute(
            "UPDATE exercices_perso SET titre = ?, categorie = ?, description = ?"
            " WHERE id = ?",
            (titre.strip(), (categorie or "Mes exercices").strip() or "Mes exercices",
             (description or "").strip(), exo_id),
        )


def set_image(exo_id: int, data: bytes | None, mime: str = "image/jpeg") -> None:
    """Attache (ou retire, avec data=None) l'illustration d'un exercice.

    L'image est fournie PAR LE PRATICIEN : aucun visuel sous droits n'est
    embarqué dans le logiciel. Stockée en base (comme les photos cliniques) →
    incluse dans la sauvegarde, jamais écrite dans Documents."""
    from .db import db_cursor
    with db_cursor() as cur:
        cur.execute("UPDATE exercices_perso SET image = ?, image_mime = ? WHERE id = ?",
                    (data, mime if data else None, exo_id))


def get_image(exo_id: int) -> tuple[bytes, str] | None:
    """(données, type MIME) de l'illustration, ou None si l'exercice n'en a pas."""
    from .db import get_connection
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT image, image_mime FROM exercices_perso WHERE id = ?",
            (exo_id,)).fetchone()
    finally:
        conn.close()
    if not row or not row["image"]:
        return None
    return bytes(row["image"]), row["image_mime"] or "image/jpeg"


def delete_perso(exo_id: int) -> None:
    """Retrait LOGIQUE : les fiches déjà remises restent régénérables."""
    from .db import db_cursor
    with db_cursor() as cur:
        cur.execute("UPDATE exercices_perso SET actif = 0 WHERE id = ?", (exo_id,))


def all_exercices() -> list[dict]:
    """Catalogue complet = exercices livrés + exercices du praticien."""
    return list(EXERCICES) + list_perso()


def exists(key: str) -> bool:
    if key in _BY_KEY:
        return True
    return any(e["key"] == key for e in list_perso()) if str(key).startswith(PERSO_PREFIX) else False


def selected(keys: list[str]) -> list[dict]:
    """Exercices correspondant aux clés (dans l'ordre du catalogue, sans doublon)."""
    wanted = set(keys or [])
    return [e for e in all_exercices() if e["key"] in wanted]


def by_category() -> list[tuple[str, list[dict]]]:
    """[(catégorie, [exercices])] dans l'ordre d'apparition — pour l'affichage."""
    order: list[str] = []
    groups: dict[str, list[dict]] = {}
    for e in all_exercices():
        cat = e["categorie"]
        if cat not in groups:
            groups[cat] = []
            order.append(cat)
        groups[cat].append(e)
    return [(cat, groups[cat]) for cat in order]
