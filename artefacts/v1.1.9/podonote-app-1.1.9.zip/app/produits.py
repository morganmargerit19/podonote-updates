"""Catalogue de produits d'ordonnance personnels (nom exact + posologie).

Retour Nico : pouvoir enregistrer, dans Réglages, un produit avec SA posologie,
pour qu'à l'ordonnance la ligne apparaisse déjà complète (nom exact + posologie)
sans re-saisie. Séparer le nom de la posologie prépare aussi le formalisme strict
des ordonnances (nom du produit souligné — à venir avec le modèle de Nico).

Même patron que `app/compta.py` pour les actes : catalogue éditable, retrait
logique (`actif = 0`) plutôt que suppression physique — l'historique reste lisible.
"""
from __future__ import annotations

from typing import Any

from .db import db_cursor, get_connection


def ligne(produit: dict[str, Any]) -> str:
    """Texte inséré dans l'ordonnance : « NOM — posologie » (ou « NOM » seul)."""
    nom = str(produit.get("nom") or "").strip()
    posologie = str(produit.get("posologie") or "").strip()
    return f"{nom} — {posologie}" if nom and posologie else nom


def list_produits(actifs_seulement: bool = True) -> list[dict[str, Any]]:
    conn = get_connection()
    try:
        where = "WHERE actif = 1" if actifs_seulement else ""
        rows = conn.execute(
            f"SELECT * FROM produits_ordonnance {where} ORDER BY ordre, id").fetchall()
        out = [dict(r) for r in rows]
    finally:
        conn.close()
    for p in out:
        p["ligne"] = ligne(p)
    return out


def create_produit(nom: str, posologie: str) -> int:
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO produits_ordonnance (nom, posologie, ordre)"
            " VALUES (?, ?, (SELECT COALESCE(MAX(ordre), -1) + 1 FROM produits_ordonnance))",
            (nom.strip(), posologie.strip()),
        )
        return int(cur.lastrowid)


def update_produit(produit_id: int, nom: str, posologie: str) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE produits_ordonnance SET nom = ?, posologie = ? WHERE id = ?",
            (nom.strip(), posologie.strip(), produit_id),
        )


def delete_produit(produit_id: int) -> None:
    """Retrait logique (les ordonnances déjà générées gardent leur texte)."""
    with db_cursor() as cur:
        cur.execute("UPDATE produits_ordonnance SET actif = 0 WHERE id = ?",
                    (produit_id,))
