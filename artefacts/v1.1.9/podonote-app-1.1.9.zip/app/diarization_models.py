"""Modèles de diarisation EMBARQUÉS — plus de compte HuggingFace côté client.

Problème (remarque de Nico) : la séparation des locuteurs (pyannote) exige un
jeton HuggingFace, donc un compte + un formulaire par praticien — impraticable.
Or le jeton ne sert QU'AU TÉLÉCHARGEMENT des modèles (barrière d'inscription du
Hub) ; les modèles eux-mêmes sont sous licence MIT et librement redistribuables.

Solution : Studio Margerit télécharge les modèles UNE fois (avec son compte,
via scripts/package_diarization_models.py), publie l'archive sur le dépôt
public de diffusion (podonote-updates), et l'app la récupère toute seule au
premier lancement (~35 Mo). La diarisation charge ensuite depuis le disque —
aucun jeton, aucun compte, rien à configurer chez le podologue.

Compat : un poste qui a déjà un HUGGINGFACE_TOKEN dans son .env continue de
fonctionner (repli), mais le dossier local a priorité dès qu'il est présent.
"""
from __future__ import annotations

import hashlib
import logging
import os
import threading
import zipfile
from pathlib import Path
from typing import Callable, Optional

from .config import DATA_DIR, settings

logger = logging.getLogger("podonote.diarization")

# --------------------------------------------------------------------------- #
# Diffusion : archive publiée dans le dépôt PUBLIC podonote-updates (fichier
# committé — ~35 Mo, bien sous la limite GitHub de 100 Mo ; l'URL raw est
# stable). Surchargeable pour les tests via PODONOTE_DIARIZE_MODELS_URL.
# --------------------------------------------------------------------------- #
MODELS_VERSION = "diarization-v1"
MODELS_URL = os.environ.get(
    "PODONOTE_DIARIZE_MODELS_URL",
    "https://raw.githubusercontent.com/morganmargerit19/podonote-updates/"
    f"main/models/{MODELS_VERSION}.zip",
)
# Empreinte SHA-256 de l'archive, FIGÉE dans le code (l'app ne fait confiance
# qu'à ce qu'elle attend — même esprit que l'OTA signée). Vide = téléchargement
# automatique DÉSACTIVÉ (tant que l'archive n'est pas publiée).
MODELS_SHA256 = "da63ef5112df6d94564249a086d852f24599813b875374e43c5ae676d1248925"

# Contenu attendu de l'archive (déposé à plat dans models_dir()).
REQUIRED_FILES = ("config.yaml", "segmentation.bin", "embedding.bin")
# Jeton substitué dans config.yaml au chargement (chemin absolu du dossier).
_DIR_PLACEHOLDER = "__MODELS_DIR__"

_MAX_ZIP_BYTES = 100 * 1024 * 1024           # garde-fou (archive réelle ~35 Mo)
_MAX_UNCOMPRESSED_BYTES = 300 * 1024 * 1024


def models_dir() -> Path:
    """Dossier des modèles : DIARIZE_MODEL_DIR (.env) sinon data/models/diarization."""
    override = (settings.diarize_model_dir or "").strip()
    return Path(override) if override else (DATA_DIR / "models" / "diarization")


def is_installed(directory: Optional[Path] = None) -> bool:
    d = directory or models_dir()
    return all((d / name).is_file() for name in REQUIRED_FILES)


def resolved_config(directory: Optional[Path] = None) -> Path:
    """config.yaml prêt pour pyannote : les jetons __MODELS_DIR__ deviennent le
    chemin ABSOLU du dossier (l'archive est relogeable, le yaml résolu non —
    il est régénéré à chaque chargement, donc un dossier déplacé se répare seul)."""
    d = directory or models_dir()
    raw = (d / "config.yaml").read_text(encoding="utf-8")
    resolved = raw.replace(_DIR_PLACEHOLDER, d.resolve().as_posix())
    out = d / "config.resolved.yaml"
    out.write_text(resolved, encoding="utf-8")
    return out


# --------------------------------------------------------------------------- #
# Téléchargement automatique (premier lancement / après OTA)
# --------------------------------------------------------------------------- #
def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _extract_archive(zip_path: Path, dest: Path) -> None:
    """Extraction SÛRE : noms de fichiers attendus uniquement (pas de chemins,
    pas de traversée), taille décompressée bornée."""
    with zipfile.ZipFile(zip_path) as z:
        total = sum(i.file_size for i in z.infolist())
        if total > _MAX_UNCOMPRESSED_BYTES:
            raise ValueError(f"Archive anormalement grosse ({total} octets).")
        names = {i.filename for i in z.infolist() if not i.is_dir()}
        if set(REQUIRED_FILES) - names:
            raise ValueError(f"Archive incomplète : {sorted(set(REQUIRED_FILES) - names)}")
        dest.mkdir(parents=True, exist_ok=True)
        for name in REQUIRED_FILES:          # extraction NOMINATIVE (ignore le reste)
            with z.open(name) as src, (dest / name).open("wb") as dst:
                while chunk := src.read(1 << 20):
                    dst.write(chunk)


def download_and_install(progress: Optional[Callable[[str], None]] = None) -> tuple[bool, str]:
    """Télécharge, vérifie (SHA-256 figée) et installe les modèles. Idempotent."""
    say = progress or (lambda _msg: None)
    if is_installed():
        return True, "Modèles de diarisation déjà installés."
    if not MODELS_SHA256:
        return False, "Archive de modèles non publiée (empreinte absente du code)."

    import httpx

    tmp = models_dir().parent / f"{MODELS_VERSION}.zip.part"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    try:
        say("Téléchargement des modèles de diarisation…")
        with httpx.stream("GET", MODELS_URL, timeout=120.0, follow_redirects=True) as resp:
            resp.raise_for_status()
            size = 0
            with tmp.open("wb") as f:
                for chunk in resp.iter_bytes(1 << 20):
                    size += len(chunk)
                    if size > _MAX_ZIP_BYTES:
                        raise ValueError("Téléchargement anormalement gros — abandonné.")
                    f.write(chunk)
        got = _sha256_file(tmp).lower()
        if got != MODELS_SHA256.lower():
            raise ValueError(f"Empreinte inattendue ({got[:12]}…) — archive refusée.")
        say("Installation des modèles…")
        _extract_archive(tmp, models_dir())
        if not is_installed():
            raise ValueError("Extraction incomplète.")
        logger.info("Modèles de diarisation installés dans %s.", models_dir())
        return True, "Modèles de diarisation installés."
    except Exception as exc:
        logger.warning("Modèles de diarisation non installés : %s", exc)
        return False, f"Modèles de diarisation non installés : {exc}"
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


_bg_started = False
_bg_lock = threading.Lock()


def start_background_download() -> None:
    """Récupération en tâche de fond au démarrage (jamais bloquant, une seule
    tentative par session — un échec réseau se retentera au prochain démarrage)."""
    global _bg_started
    with _bg_lock:
        if _bg_started:
            return
        _bg_started = True
    if is_installed() or not MODELS_SHA256:
        return

    def _run() -> None:
        try:
            download_and_install()
        except Exception:
            logger.exception("Téléchargement des modèles de diarisation en échec.")

    threading.Thread(target=_run, name="diarize-models", daemon=True).start()
