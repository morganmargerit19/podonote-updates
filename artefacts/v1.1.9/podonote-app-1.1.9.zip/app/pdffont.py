"""Police PDF Unicode (DejaVu Sans) embarquée, avec repli sur la police core.

fpdf2 (≥ 2.8) n'embarque plus de police Unicode : sans police TTF enregistrée,
seul le latin-1 est rendu et tout caractère hors de cette table devient « ? »
(perte SILENCIEUSE de données dans un document médical). On embarque donc
DejaVu Sans (couverture latine étendue) pour rendre fidèlement guillemets
typographiques, tirets longs, symboles, etc.

Conçu pour ne JAMAIS bloquer la génération : si les fichiers de police sont
absents ou illisibles, on retombe automatiquement sur Helvetica + latin-1
(comportement historique). La décision est globale au process (les fichiers de
police sont présents ou non), d'où les constantes calculées à l'import.
"""
from __future__ import annotations

from pathlib import Path

_FONTS_DIR = Path(__file__).resolve().parent / "assets" / "fonts"
_REGULAR = _FONTS_DIR / "DejaVuSans.ttf"
_BOLD = _FONTS_DIR / "DejaVuSans-Bold.ttf"

FAMILY_UNICODE = "DejaVu"
FAMILY_FALLBACK = "Helvetica"


def _available() -> bool:
    return _REGULAR.is_file() and _BOLD.is_file()


# Police Unicode disponible ? (constant pour tout le process)
UNICODE = _available()
# Famille à passer à pdf.set_font(...) dans tout le code de génération PDF.
FAMILY = FAMILY_UNICODE if UNICODE else FAMILY_FALLBACK


def setup(pdf) -> str:
    """Enregistre la police Unicode sur l'instance FPDF et renvoie la famille à
    utiliser. À appeler juste après la création du FPDF. Repli transparent sur
    Helvetica si l'enregistrement échoue."""
    if not UNICODE:
        return FAMILY_FALLBACK
    try:
        pdf.add_font(FAMILY_UNICODE, "", str(_REGULAR))
        pdf.add_font(FAMILY_UNICODE, "B", str(_BOLD))
        # DejaVu Sans n'a pas de variante oblique embarquée : on mappe I/BI sur les
        # variantes droites (texte non penché mais complet et lisible) plutôt que de
        # lever une exception sur set_font(..., "I").
        pdf.add_font(FAMILY_UNICODE, "I", str(_REGULAR))
        pdf.add_font(FAMILY_UNICODE, "BI", str(_BOLD))
        return FAMILY_UNICODE
    except Exception:
        return FAMILY_FALLBACK
