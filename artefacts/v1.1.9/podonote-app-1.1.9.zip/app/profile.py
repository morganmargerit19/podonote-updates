"""Profil du praticien — en-tête des ordonnances. Stocké dans data/praticien.json.

Ces informations (identité, coordonnées, n° AM / RPPS, signature) ne sont PAS des
données patient : elles décrivent le prescripteur et figurent en haut de chaque
ordonnance générée. Pré-rempli avec les coordonnées de Nico, entièrement
modifiable depuis la page Réglages.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

from .config import DATA_DIR, ensure_dirs

PROFILE_FILE = DATA_DIR / "praticien.json"

# Valeurs par défaut (coordonnées de Nico, cf. ordonnance modèle) — modifiables
# dans Réglages. L'app fonctionne « prête à l'emploi » pour lui dès l'installation.
DEFAULT_PROFILE: dict[str, Any] = {
    "nom": "TERRANOVA Nicolas - EI",
    "titre": "Pédicure - Podologue D.E",
    "adresse": "6b rue des lilas\n19490 SAINTE FORTUNADE",
    "telephone": "05 44 40 52 56",
    "num_am": "19 8001877",
    "rpps": "10106041121",
    "signature_path": "",  # nom de fichier relatif à data/ (ex. signature.png)
    # Lignes proposées par défaut dans l'ordonnance (Nico peut en ajouter/retirer).
    # Retour Nico : les semelles ne sont PLUS prescrites d'office — elles se
    # choisissent comme le reste (sélecteur « Semelles / orthèses » du hub).
    "lignes_defaut": [
        "1 BILAN PODOLOGIQUE",
    ],
    # Bibliothèque personnelle de lignes de prescription (retour Nico : pouvoir
    # prescrire le NOM EXACT des produits qu'il utilise). Éditable dans Réglages,
    # insérable en un clic dans l'ordonnance. Vide par défaut.
    "produits_favoris": [],
}

_TEXT_FIELDS = ("nom", "titre", "adresse", "telephone", "num_am", "rpps")


def load() -> dict[str, Any]:
    """Charge le profil (défauts complétés par le fichier s'il existe). Tolérant."""
    ensure_dirs()
    data = dict(DEFAULT_PROFILE)
    try:
        stored = json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
        if isinstance(stored, dict):
            data.update({k: v for k, v in stored.items() if k in DEFAULT_PROFILE})
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError, ValueError):
        pass
    if not isinstance(data.get("lignes_defaut"), list):
        data["lignes_defaut"] = list(DEFAULT_PROFILE["lignes_defaut"])
    if not isinstance(data.get("produits_favoris"), list):
        data["produits_favoris"] = list(DEFAULT_PROFILE["produits_favoris"])
    return data


def save(values: dict[str, Any]) -> None:
    """Écriture ATOMIQUE (.tmp puis os.replace) du profil mis à jour."""
    ensure_dirs()
    current = load()
    for f in _TEXT_FIELDS:
        if f in values:
            current[f] = (values[f] or "").strip()
    if "lignes_defaut" in values:
        current["lignes_defaut"] = [
            l.strip() for l in (values["lignes_defaut"] or []) if l and l.strip()
        ]
    if "produits_favoris" in values:
        current["produits_favoris"] = [
            l.strip() for l in (values["produits_favoris"] or []) if l and l.strip()
        ]
    if "signature_path" in values:
        current["signature_path"] = (values["signature_path"] or "").strip()
    tmp = PROFILE_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    # os.replace est atomique mais peut lever PermissionError sous Windows si le
    # fichier est momentanément ouvert (lecture concurrente). On retente une fois.
    try:
        os.replace(tmp, PROFILE_FILE)
    except PermissionError:
        import time
        time.sleep(0.1)
        try:
            os.replace(tmp, PROFILE_FILE)
        except OSError:
            tmp.unlink(missing_ok=True)
            raise


def effective_header(profile: dict[str, Any], cabinet: Optional[dict[str, Any]]) -> dict[str, Any]:
    """En-tête d'ordonnance effectif : les champs RENSEIGNÉS du cabinet remplacent
    ceux du profil praticien global (signature et lignes par défaut restent du profil).
    Sans cabinet, renvoie le profil tel quel."""
    h = dict(profile)
    if cabinet:
        for f in ("nom", "titre", "adresse", "telephone", "num_am", "rpps"):
            v = (cabinet.get(f) or "").strip()
            if v:
                h[f] = v
    return h


def is_complete(profile: Optional[dict[str, Any]] = None) -> bool:
    """Minimum requis pour une ordonnance valable : identité + RPPS."""
    p = profile or load()
    return bool((p.get("nom") or "").strip() and (p.get("rpps") or "").strip())


def signature_file(profile: Optional[dict[str, Any]] = None) -> Optional[Path]:
    """Chemin absolu de la signature si elle existe sur le disque, sinon None."""
    p = profile or load()
    sp = (p.get("signature_path") or "").strip()
    if not sp:
        return None
    path = DATA_DIR / sp
    # Garde-fou anti-traversal : la signature DOIT rester dans data/ (un
    # praticien.json trafiqué pourrait sinon pointer ../../un_fichier_sensible).
    try:
        path.resolve().relative_to(DATA_DIR.resolve())
    except ValueError:
        return None
    return path if path.exists() else None
