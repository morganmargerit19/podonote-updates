"""Papiers officiels du patient : certificat de soins, compte-rendu au médecin
traitant, feuille de soins (actes + honoraires).

Onglet « Certificat & CR & feuille de soins » du hub Documents. Les textes sont
pré-remplis (modèles validés de la maquette) puis édités librement par le
praticien avant génération — le PDF reprend exactement ce qui est à l'écran.
"""
from __future__ import annotations

from datetime import date as _date
from typing import Any

from . import pdffont as _pdffont
from .rgpd import _body, _pdf_entete, _pdf_signature, _safe
from .utils import date_fr

TYPES = {
    "cert": "Certificat de soins",
    "cr": "Compte-rendu au médecin traitant",
    "soins": "Feuille de soins",
}


def _civ(patient: dict[str, Any]) -> str:
    return {"F": "Mme", "H": "M."}.get(patient.get("sexe") or "", "")


def _patient_ligne(patient: dict[str, Any]) -> str:
    """« Mme Marie Lefèvre · née le 12/03/1979 » (une seule ligne)."""
    e = "e" if patient.get("sexe") == "F" else ""
    out = f"{_civ(patient)} {patient['prenom']} {patient['nom']}".strip()
    if patient.get("date_naissance"):
        out += f" · né{e} le {date_fr(patient['date_naissance'])}"
    return out


def defaults(kind: str, patient: dict[str, Any], header: dict[str, Any]) -> dict[str, Any]:
    """Contenu pré-rempli du papier (modèles de la maquette, adaptés au patient)."""
    e = "e" if patient.get("sexe") == "F" else ""
    nom_complet = f"{_civ(patient)} {patient['prenom']} {patient['nom']}".strip()
    praticien = (header.get("nom") or "").strip() or "—"
    if kind == "cert":
        return {"paragraphs": [
            f"Je soussigné {praticien}, pédicure-podologue D.E., certifie avoir "
            f"examiné ce jour {nom_complet}.",
            "Son état podologique nécessite des soins de pédicurie réguliers "
            "ainsi que le port d'orthèses plantaires sur mesure.",
            f"Certificat établi à la demande de l'intéressé{e} pour faire valoir "
            "ce que de droit.",
        ]}
    if kind == "cr":
        return {"paragraphs": [
            "Chère consœur, cher confrère,",
            f"J'ai reçu {nom_complet} en consultation. "
            "L'examen retrouve : …",
            "Prise en charge : …",
            "Bien confraternellement.",
        ]}
    return {"lignes": []}   # feuille de soins : actes saisis dans le formulaire


def build_pdf(kind: str, patient: dict[str, Any], header: dict[str, Any],
              paragraphs: list[str] | None = None,
              lignes: list[dict[str, Any]] | None = None) -> bytes:
    """PDF A4 du papier demandé (mêmes conventions que app/rgpd.py)."""
    from fpdf import FPDF

    if kind not in TYPES:
        raise ValueError(f"Type de papier inconnu : {kind!r}")
    pdf = FPDF()
    _pdffont.setup(pdf)
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    _pdf_entete(pdf, header, TYPES[kind].upper(),
                f"Le {date_fr(str(_date.today()))}")

    pdf.set_font(_pdffont.FAMILY, "", 10.5)
    pdf.cell(0, 6, _safe(_patient_ligne(patient)), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    if kind == "soins":
        _table_soins(pdf, lignes or [])
    else:
        for p in (paragraphs or []):
            if p.strip():
                _body(pdf, p.strip())
                pdf.ln(2)

    _pdf_signature(pdf, header)
    return bytes(pdf.output())


def _table_soins(pdf, lignes: list[dict[str, Any]]) -> None:
    """Tableau Acte / Honoraires + total (feuille de soins)."""
    total = 0.0
    pdf.set_font(_pdffont.FAMILY, "B", 10)
    pdf.set_fill_color(244, 240, 230)               # --surface-2 papier
    pdf.cell(140, 8, _safe("Acte"), border=1, fill=True)
    pdf.cell(40, 8, _safe("Honoraires"), border=1, fill=True, align="R",
             new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(_pdffont.FAMILY, "", 10)
    for ligne in lignes:
        libelle = str(ligne.get("libelle") or "").strip()
        if not libelle:
            continue
        try:
            prix = float(ligne.get("prix") or 0)
        except (TypeError, ValueError):
            prix = 0.0
        total += prix
        pdf.cell(140, 8, _safe(libelle), border=1)
        pdf.cell(40, 8, _safe(f"{prix:.2f} EUR".replace(".", ",")), border=1,
                 align="R", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(_pdffont.FAMILY, "B", 10)
    pdf.cell(140, 8, _safe("Total"), border=1)
    pdf.cell(40, 8, _safe(f"{total:.2f} EUR".replace(".", ",")), border=1,
             align="R", new_x="LMARGIN", new_y="NEXT")
