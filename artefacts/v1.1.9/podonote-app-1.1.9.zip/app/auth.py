"""Authentification : session app + helpers (les identifiants vivent dans security.py)."""
from __future__ import annotations

from fastapi import Request
from fastapi.responses import RedirectResponse

from . import security


def verify_password(password: str) -> bool:
    return security.verify_password(password)


def verify_pin(pin: str) -> bool:
    return security.verify_pin(pin)


def is_authenticated(request: Request) -> bool:
    return bool(request.session.get("authenticated"))


def login_session(request: Request) -> None:
    # Anti-fixation : on repart d'une session vierge avant d'élever les droits.
    request.session.clear()
    request.session["authenticated"] = True


def logout_session(request: Request) -> None:
    request.session.clear()


def require_login(request: Request) -> RedirectResponse | None:
    if not is_authenticated(request):
        return RedirectResponse(url="/login", status_code=303)
    return None
