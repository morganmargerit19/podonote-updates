"""Accès base SQLite (chiffrement au repos = disque chiffré [BitLocker/FileVault] + login app)."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Iterator

from .config import DB_PATH, ensure_dirs

SCHEMA = """
CREATE TABLE IF NOT EXISTS patients (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    nom           TEXT NOT NULL,
    prenom        TEXT NOT NULL,
    date_naissance TEXT,
    notes         TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS consultations (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id       INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    date             TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    source           TEXT NOT NULL CHECK (source IN ('cabinet', 'domicile')),
    consent_obtained INTEGER NOT NULL DEFAULT 0,
    -- Suivi du pipeline : pending -> processing -> done | error
    status           TEXT NOT NULL DEFAULT 'pending',
    progress         TEXT,                 -- libellé étape courante (UI)
    error_message    TEXT,
    -- Chemin audio transitoire : NULL une fois l'audio supprimé (RGPD)
    audio_path       TEXT,
    transcript_diarise TEXT,
    recap            TEXT,                 -- fiche-bilan en JSON
    created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_consultations_patient
    ON consultations(patient_id, date DESC);

-- Cabinets (multi-sites). En-tête d'ordonnance surchargeable par cabinet :
-- les champs nom/titre/adresse/téléphone/N°AM/RPPS, s'ils sont remplis,
-- remplacent ceux du profil praticien global (utile pour des collaborateurs
-- exerçant sur plusieurs sites). `label` = nom affiché dans le sélecteur.
CREATE TABLE IF NOT EXISTS cabinets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    label       TEXT NOT NULL,
    nom         TEXT,
    titre       TEXT,
    adresse     TEXT,
    telephone   TEXT,
    num_am      TEXT,
    rpps        TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- Journal des ordonnances générées (traçabilité dans la fiche patient :
-- « une ordonnance a été générée le … »). `fichier` = nom du PDF enregistré.
CREATE TABLE IF NOT EXISTS ordonnances (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id  INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    date        TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    fichier     TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_ordonnances_patient
    ON ordonnances(patient_id, date DESC);

-- Journal des fiches d'exercices remises (retour Nico : « retrouver la fiche
-- d'exercice prescrite au patient »). `keys` = JSON des clés d'exercices, pour
-- pouvoir REGÉNÉRER le PDF à l'identique.
CREATE TABLE IF NOT EXISTS exercices_fiches (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id  INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    date        TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    keys        TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_exercices_fiches_patient
    ON exercices_fiches(patient_id, date DESC);

-- Photos cliniques (avant/après), rattachées à une consultation. Stockées en
-- BLOB DANS la base : ainsi elles sont (a) incluses dans la sauvegarde (snapshot
-- SQLite), (b) effacées par la purge RGPD via CASCADE + secure_delete, et (c)
-- jamais écrites dans Documents (risque OneDrive) — elles ne quittent pas la
-- machine, comme l'audio. Ré-encodées en JPEG borné + EXIF supprimé (cf. app/photos.py).
CREATE TABLE IF NOT EXISTS photos (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    consultation_id INTEGER NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    kind            TEXT NOT NULL DEFAULT 'autre',   -- 'avant' | 'apres' | 'autre'
    note            TEXT,
    mime            TEXT NOT NULL DEFAULT 'image/jpeg',
    data            BLOB NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_photos_consultation ON photos(consultation_id, id);

-- Annuaire de correspondants (contact pluridisciplinaire) : médecins, kinés,
-- chirurgiens, podologues, ostéos… pour générer un courrier depuis un dossier.
-- Table de référence GLOBALE (pas de lien patient) — comme cabinets.
CREATE TABLE IF NOT EXISTS correspondants (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL DEFAULT 'medecin',  -- medecin|kine|chirurgien|podologue|osteo|autre
    nom         TEXT NOT NULL,
    email       TEXT,
    telephone   TEXT,
    adresse     TEXT,
    notes       TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- Traçabilité de stérilisation : cycles d'autoclave. `ref` est humaine et
-- unique (« C-2607 · A » = année+mois + lettre du cycle dans le mois). La
-- conformité est RECALCULÉE côté serveur (test Helix + intégrateur), jamais
-- saisie directement (cf. app/sterilisation.py).
CREATE TABLE IF NOT EXISTS sterilisation_cycles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ref         TEXT NOT NULL UNIQUE,
    date        TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    programme   TEXT NOT NULL DEFAULT 'prion',   -- prion | standard
    temperature TEXT,                            -- ex. « 134 °C »
    duree       TEXT,                            -- ex. « 18 min »
    nb_sachets  INTEGER NOT NULL DEFAULT 0,      -- taille de la charge
    operateur   TEXT,
    helix       TEXT NOT NULL DEFAULT 'conforme',   -- conforme | echec
    integrateur TEXT NOT NULL DEFAULT 'vire',       -- vire | douteux
    conforme    INTEGER NOT NULL DEFAULT 1,
    notes       TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_steril_cycles_date ON sterilisation_cycles(date DESC);

-- Sachets rattachés à un cycle puis à un patient/une consultation : c'est le
-- maillon de la recherche inverse (« quels patients ont été exposés au cycle
-- C-2604 ? »). ON DELETE SET NULL : la traçabilité du sachet survit à la purge
-- RGPD d'un dossier (le lien patient disparaît, le sachet reste compté).
CREATE TABLE IF NOT EXISTS sterilisation_sachets (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_id         INTEGER NOT NULL REFERENCES sterilisation_cycles(id) ON DELETE CASCADE,
    numero           TEXT NOT NULL,              -- « S-13 »
    contenu          TEXT,                       -- « Set de détersion »
    patient_id       INTEGER REFERENCES patients(id) ON DELETE SET NULL,
    consultation_id  INTEGER REFERENCES consultations(id) ON DELETE SET NULL,
    date_utilisation TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_steril_sachets_cycle ON sterilisation_sachets(cycle_id, id);

-- Compta : catalogue d'actes tarifés (source des lignes de facture, éditable
-- dans Réglages). TVA non applicable (art. 261-4-1° CGI) : prix = montant dû.
CREATE TABLE IF NOT EXISTS actes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    libelle     TEXT NOT NULL,
    prix        REAL NOT NULL DEFAULT 0,
    ordre       INTEGER NOT NULL DEFAULT 0,
    actif       INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- Factures & devis. Numérotation AUTO par année et par type : F-2026-041 /
-- D-2026-012 (unicité (type, annee, seq)). `patient_nom` est une COPIE : une
-- facture est une pièce comptable légale qui doit survivre à la purge RGPD du
-- dossier (le lien patient_id passe à NULL, le nom facturé reste).
CREATE TABLE IF NOT EXISTS factures (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL DEFAULT 'facture',   -- facture | devis
    annee       INTEGER NOT NULL,
    seq         INTEGER NOT NULL,
    numero      TEXT NOT NULL UNIQUE,              -- « F-2026-041 »
    patient_id  INTEGER REFERENCES patients(id) ON DELETE SET NULL,
    patient_nom TEXT,
    date        TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    lignes      TEXT,                              -- JSON [{libelle, prix}]
    total       REAL NOT NULL DEFAULT 0,
    statut      TEXT NOT NULL DEFAULT 'attente',   -- payee | attente | devis
    fichier     TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    UNIQUE (type, annee, seq)
);

CREATE INDEX IF NOT EXISTS idx_factures_date ON factures(date DESC);

-- Produits d'ordonnance personnels (retour Nico) : nom EXACT du produit + sa
-- posologie, saisis dans Réglages puis proposés à l'ordonnance. La ligne
-- insérée = « nom — posologie », de sorte que la posologie apparaisse sans
-- re-saisie. Même patron que `actes` (catalogue éditable, retrait = actif=0).
CREATE TABLE IF NOT EXISTS produits_ordonnance (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    nom         TEXT NOT NULL,
    posologie   TEXT,
    ordre       INTEGER NOT NULL DEFAULT 0,
    actif       INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- Exercices PERSONNELS du praticien (retour Nico : « chaque praticien doit
-- pouvoir ajouter ses propres étirements / mobilité / renforcement »). Ils
-- s'ajoutent à la banque intégrée et sont proposés dans la fiche d'exercices.
CREATE TABLE IF NOT EXISTS exercices_perso (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    titre       TEXT NOT NULL,
    categorie   TEXT NOT NULL DEFAULT 'Mes exercices',
    description TEXT,
    ordre       INTEGER NOT NULL DEFAULT 0,
    actif       INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
"""


def get_connection() -> sqlite3.Connection:
    ensure_dirs()
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    # Disque lent : attendre jusqu'à 5 s qu'un verrou se libère au lieu de lever
    # « database is locked » immédiatement (POST concurrents / fenêtre du pipeline).
    conn.execute("PRAGMA busy_timeout = 5000;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    # RGPD : écrase physiquement les pages libérées par un DELETE. Sans cela,
    # transcriptions et fiches « définitivement supprimées » restent lisibles
    # dans le fichier .db avec un éditeur hexadécimal. Coût négligeable.
    conn.execute("PRAGMA secure_delete = ON;")
    return conn


# Colonnes ajoutées après la v1 (migration idempotente).
_MIGRATIONS = {
    "patients": [
        ("medical_flags", "TEXT"),          # terrain médical (JSON: liste de clés)
        ("sexe", "TEXT"),                   # 'H' | 'F' | NULL (pour civilité + repère visuel)
        ("cabinet_id", "INTEGER"),          # rattachement multi-cabinet (NULL = non assigné)
        ("recontact_status", "TEXT"),       # suivi « à recontacter (+1 an) » : NULL/'' = à recontacter, 'attente', 'fait'
        # Dossier archivé (patient parti / décédé) : sorti des listes courantes
        # et des relances, mais JAMAIS supprimé (consultable dans « Archivés »).
        ("archived", "INTEGER NOT NULL DEFAULT 0"),
    ],
    "consultations": [
        ("validated", "INTEGER NOT NULL DEFAULT 0"),  # fiche relue et validée
        ("tags", "TEXT"),                  # étiquettes de soin (JSON: liste de clés)
        ("foot_annotations", "TEXT"),      # annotations du schéma du pied (JSON)
        ("resume_attempts", "INTEGER NOT NULL DEFAULT 0"),  # reprises auto au démarrage (anti-boucle)
        # Type de fiche (registre app/fiches.py) : 'podologie' historique par
        # défaut. Discriminant du socle multi-métiers (soin, préférence motrice…).
        ("bilan_type", "TEXT NOT NULL DEFAULT 'podologie'"),
    ],
    "ordonnances": [
        ("ald", "TEXT"),                   # mention ALD ('rapport'|'sans') — régénération
        ("lignes", "TEXT"),                # lignes prescrites (JSON) — régénération du PDF
    ],
    # Illustration d'un exercice personnel (retour Nico : « imager chaque
    # étirement »). Image fournie PAR LE PRATICIEN (aucun visuel sous droits
    # n'est embarqué), stockée en base pour suivre la sauvegarde.
    "exercices_perso": [
        ("image", "BLOB"),
        ("image_mime", "TEXT"),
    ],
    "factures": [
        ("moyen_paiement", "TEXT"),        # CB | CHQ | ESP | VIR | NULL (mode de règlement)
        # Compta par cabinet (retour Nico) : figé à l'émission. Les factures
        # antérieures (NULL) retombent sur le cabinet ACTUEL du patient via
        # COALESCE(f.cabinet_id, p.cabinet_id) dans les requêtes.
        ("cabinet_id", "INTEGER"),
    ],
}


def _migrate(conn: sqlite3.Connection) -> None:
    for table, columns in _MIGRATIONS.items():
        existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
        for name, decl in columns:
            if name not in existing:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")


def init_db() -> None:
    """Crée le schéma puis applique les migrations (idempotent)."""
    conn = get_connection()
    try:
        conn.executescript(SCHEMA)
        _migrate(conn)
        conn.commit()
    finally:
        conn.close()  # sqlite3 ne ferme PAS la connexion en sortie de `with`


@contextmanager
def db_cursor() -> Iterator[sqlite3.Cursor]:
    """Contexte transactionnel : commit auto, rollback en cas d'erreur."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
