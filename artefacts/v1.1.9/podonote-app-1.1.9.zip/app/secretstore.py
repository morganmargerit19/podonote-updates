"""Stockage chiffré multiplateforme de la clé API Anthropic.

Le `.env` posé à l'installation contient la clé en clair (lisible par tout
process de la session). On la range donc dans le coffre du système :

- **Windows** : DPAPI (CryptProtectData, portée utilisateur) — cf. `winsecret.py`.
  Blob `data/anthropic.key.dpapi`, déchiffrable par CE compte sur CE poste.
- **macOS**   : Trousseau (Keychain) via l'outil `security` (aucune dépendance
  pip ; présent sur tout Mac).
- **Autres**  : repli sur `ANTHROPIC_API_KEY` du `.env` (dev / Linux).

Résolution (`get_anthropic_api_key`) : secret du coffre s'il existe, sinon le
`.env` (compatibilité des installations existantes). L'audio ne quitte JAMAIS la
machine ; ce module ne concerne que la clé d'accès au LLM cloud.
"""
from __future__ import annotations

import logging
import subprocess

from .config import settings
from .platform_compat import IS_MAC, IS_WINDOWS

logger = logging.getLogger("podonote.secretstore")

# Identifiants de l'entrée Trousseau macOS (service + compte).
_KC_SERVICE = "PodoNote"
_KC_ACCOUNT = "anthropic-api-key"


# --------------------------------------------------------------------------- #
# Trousseau macOS (via l'outil `security`)
# --------------------------------------------------------------------------- #
def _keychain_set(key: str) -> bool:
    try:
        # -U : met à jour l'entrée si elle existe déjà ; -w : la valeur.
        r = subprocess.run(
            ["security", "add-generic-password", "-U",
             "-a", _KC_ACCOUNT, "-s", _KC_SERVICE, "-w", key],
            capture_output=True, text=True, timeout=30,
        )
        return r.returncode == 0
    except Exception:
        logger.exception("Écriture dans le Trousseau macOS impossible.")
        return False


def _keychain_get() -> str:
    try:
        r = subprocess.run(
            ["security", "find-generic-password", "-w",
             "-a", _KC_ACCOUNT, "-s", _KC_SERVICE],
            capture_output=True, text=True, timeout=30,
        )
        if r.returncode == 0:
            return (r.stdout or "").strip()
    except Exception:
        logger.exception("Lecture du Trousseau macOS impossible.")
    return ""


# --------------------------------------------------------------------------- #
# API publique (dispatch par plateforme)
# --------------------------------------------------------------------------- #
def protect_api_key(key: str) -> bool:
    """Range la clé dans le coffre du système. False si indisponible (Linux/dev)."""
    key = (key or "").strip()
    if not key:
        return False
    if IS_WINDOWS:
        from . import winsecret
        return winsecret.protect_api_key(key)
    if IS_MAC:
        return _keychain_set(key)
    return False  # Linux/dev : pas de coffre natif → la clé reste dans le .env.


_cached: str | None = None


def get_anthropic_api_key() -> str:
    """Clé API effective : coffre système prioritaire, repli sur le `.env`."""
    global _cached
    if _cached is None:
        if IS_WINDOWS:
            from . import winsecret
            _cached = winsecret._unprotect()
        elif IS_MAC:
            _cached = _keychain_get()
        else:
            _cached = ""
    return _cached or settings.anthropic_api_key.strip()
