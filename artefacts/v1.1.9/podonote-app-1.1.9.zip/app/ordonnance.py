"""Génération du PDF d'ordonnance (bilan + semelles orthopédiques).

Reproduit le formalisme de l'ordonnance papier de Nico :
  en-tête prescripteur (profil praticien) · date du jour · « Pour Mr/Mme … » ·
  mention ALD au choix (en rapport / sans rapport) · lignes prescrites · signature.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

from . import pdffont
from . import profile as profile_mod
from .rgpd import _typo  # table de translittération latin-1 (police PDF de base)
from .utils import date_fr

# Mentions ALD possibles (ALD = Affection Longue Durée).
ALD_CHOICES = {
    "rapport": "En rapport avec une ALD",
    "sans": "Sans rapport avec une ALD",
}


def _safe(txt: str) -> str:
    s = str(txt or "")
    # Police Unicode embarquée : on garde la typographie d'origine ; sinon repli
    # translittération + latin-1 (police core).
    return s if pdffont.UNICODE else _typo(s).encode("latin-1", "replace").decode("latin-1")


def civilite(sexe: Optional[str]) -> str:
    s = (sexe or "").strip().upper()
    if s in ("H", "M"):
        return "Mr"
    if s == "F":
        return "Mme"
    return ""


def build_ordonnance_pdf(
    patient: dict[str, Any],
    ald: str,
    lignes: list[str],
    profile: Optional[dict[str, Any]] = None,
) -> bytes:
    from fpdf import FPDF

    prof = profile or profile_mod.load()
    pdf = FPDF()
    pdffont.setup(pdf)  # police Unicode embarquée (repli Helvetica si absente)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # --- En-tête prescripteur (haut gauche) ---
    pdf.set_font(pdffont.FAMILY,"B", 13)
    pdf.cell(0, 7, _safe(prof.get("nom", "")), new_x="LMARGIN", new_y="NEXT")
    if prof.get("titre"):
        pdf.set_font(pdffont.FAMILY,"I", 11)
        pdf.cell(0, 6, _safe(prof["titre"]), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)
    pdf.set_font(pdffont.FAMILY,"", 10)
    for line in (prof.get("adresse") or "").splitlines():
        if line.strip():
            pdf.cell(0, 5, _safe(line), new_x="LMARGIN", new_y="NEXT")
    if prof.get("telephone"):
        pdf.cell(0, 5, _safe(prof["telephone"]), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)
    if prof.get("num_am"):
        pdf.cell(0, 5, _safe(f"N° AM : {prof['num_am']}"), new_x="LMARGIN", new_y="NEXT")
    if prof.get("rpps"):
        pdf.cell(0, 5, _safe(f"RPPS : {prof['rpps']}"), new_x="LMARGIN", new_y="NEXT")

    # --- Date (alignée à droite) ---
    pdf.ln(4)
    pdf.set_font(pdffont.FAMILY,"", 11)
    pdf.cell(0, 6, _safe(f"Le {date.today():%d/%m/%Y}"),
             align="R", new_x="LMARGIN", new_y="NEXT")

    # --- Patient ---
    pdf.ln(6)
    civ = civilite(patient.get("sexe"))
    nom = f"{patient.get('prenom', '')} {patient.get('nom', '')}".strip()
    pdf.set_font(pdffont.FAMILY,"", 12)
    pdf.cell(0, 6, _safe(f"Pour {civ + ' ' if civ else ''}{nom}"),
             new_x="LMARGIN", new_y="NEXT")
    if patient.get("date_naissance"):
        pdf.cell(0, 6, _safe(f"Né(e) le {date_fr(patient['date_naissance'])}"),
                 new_x="LMARGIN", new_y="NEXT")

    # --- Mention ALD ---
    pdf.ln(8)
    pdf.set_font(pdffont.FAMILY,"", 11)
    pdf.cell(0, 6, _safe(ALD_CHOICES.get(ald, "En rapport/Sans rapport avec une ALD")),
             new_x="LMARGIN", new_y="NEXT")

    # --- Lignes prescrites ---
    # Retour Nico : le NOM du produit est mis en avant (souligné) et la posologie
    # figure sur sa PROPRE ligne. Les produits du catalogue sont insérés au format
    # « NOM — posologie » (tiret cadratin) : on scinde sur ce séparateur pour
    # appliquer le formalisme. Le format strict exact (codes, présentation précise)
    # sera calé sur le modèle transmis par Nico.
    pdf.ln(4)
    SEP = " — "   # « — » entouré d'espaces = séparateur de produits.ligne()
    for ligne in lignes:
        # lignes_defaut peut provenir d'un JSON profil mal formé (élément non-str) :
        # on coerce en chaîne pour ne jamais bloquer la génération de l'ordonnance.
        texte = str(ligne).strip()
        if not texte:
            continue
        nom, _sep, poso = texte.partition(SEP)
        pdf.set_x(pdf.l_margin + 10)
        pdf.set_font(pdffont.FAMILY, "BU", 11)          # nom : gras + souligné
        pdf.cell(0, 7, _safe(f"- {nom.strip()}"), new_x="LMARGIN", new_y="NEXT")
        if poso.strip():
            pdf.set_x(pdf.l_margin + 16)
            pdf.set_font(pdffont.FAMILY, "", 10.5)      # posologie : ligne dédiée
            pdf.multi_cell(0, 6, _safe(poso.strip()))

    # --- Signature (image si fournie dans le profil) ---
    sig = profile_mod.signature_file(prof)
    if sig:
        pdf.ln(18)
        try:
            pdf.image(str(sig), x=120, w=55)
        except Exception:
            pass  # une signature illisible ne doit jamais bloquer l'ordonnance

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)
