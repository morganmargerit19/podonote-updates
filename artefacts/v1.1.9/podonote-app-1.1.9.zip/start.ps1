﻿# =============================================================================
#  PodoNote — Démarrage de l'application
# =============================================================================
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

$pyexe = "$Root\.venv\Scripts\python.exe"
if (-not (Test-Path $pyexe)) {
    Write-Host "PodoNote n'est pas installé. Lancez d'abord install.ps1." -ForegroundColor Red
    Read-Host "Entrée pour fermer"; exit 1
}

# Démarre Ollama UNIQUEMENT en mode 100 % local (LLM_BACKEND=ollama). Inutile en
# mode hybride/Sonnet : éviter de consommer RAM/CPU sur une machine sans GPU.
$backend = "sonnet"
if (Test-Path "$Root\.env") {
    $mb = (Get-Content "$Root\.env" | Select-String '^\s*LLM_BACKEND\s*=\s*(.+)$')
    if ($mb) { $backend = $mb.Matches.Groups[1].Value.Trim().Trim('"').ToLower() }
}
if ($backend -eq "ollama" -and (Get-Command ollama -ErrorAction SilentlyContinue)) {
    if (-not (Get-Process ollama -ErrorAction SilentlyContinue)) {
        Start-Process -WindowStyle Hidden ollama -ArgumentList "serve"
        Start-Sleep -Seconds 2
    }
}

Write-Host "Démarrage de PodoNote (fenêtre application)…" -ForegroundColor Green

# Ouvre l'app dans sa propre fenêtre (WebView2). Le serveur écoute aussi sur le
# réseau local pour l'upload iPhone. Pour un démarrage SANS console, utiliser le
# raccourci du Bureau (pythonw -m app.desktop) ; ici on garde la console (debug).
& $pyexe -m app.desktop
