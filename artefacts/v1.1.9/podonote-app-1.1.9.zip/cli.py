"""CLI de validation du pipeline ML (jalon 2).

Usage :
    python cli.py chemin/vers/audio.m4a
    python cli.py audio.wav --model qwen2.5:7b --no-diar

Permet de tester la chaîne transcription -> diarisation -> fiche-bilan
SANS l'interface web ni la base. Affiche la fiche-bilan JSON.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

# Console Windows : forcer l'UTF-8 pour les emojis/accents.
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


def main() -> int:
    parser = argparse.ArgumentParser(description="PodoNote — test du pipeline ML")
    parser.add_argument("audio", help="Chemin du fichier audio (m4a, wav, mp3…)")
    parser.add_argument("--model", help="Modèle Ollama (sinon valeur du .env)")
    parser.add_argument("--out", help="Écrire la fiche-bilan JSON dans ce fichier")
    parser.add_argument(
        "--transcript-only", action="store_true",
        help="S'arrêter après la transcription (ne pas appeler le LLM)",
    )
    args = parser.parse_args()

    audio = Path(args.audio)
    if not audio.exists():
        print(f"❌ Fichier introuvable : {audio}", file=sys.stderr)
        return 1

    # Imports tardifs (messages d'erreur plus clairs si une lib manque)
    from app.pipeline import llm
    from app.pipeline.transcribe import (
        TranscriptionError,
        check_dependencies,
        transcribe_and_diarize,
    )

    ok, msg = check_dependencies()
    if not ok:
        print(f"❌ {msg}", file=sys.stderr)
        print("   Installez les libs ML : voir README (scripts/install_ml.ps1).")
        return 2

    def progress(label: str) -> None:
        print(f"  … {label}")

    print(f"🎙️  Traitement de {audio.name}\n")
    t0 = time.time()
    try:
        result = transcribe_and_diarize(str(audio), progress=progress)
    except TranscriptionError as exc:
        print(f"❌ Transcription échouée : {exc}", file=sys.stderr)
        return 3

    dt = time.time() - t0
    print(f"\n✅ Transcription terminée en {dt:.0f}s "
          f"(diarisation : {'oui' if result.diarized else 'non'}, "
          f"{result.num_speakers} locuteur(s))\n")
    print("----- TRANSCRIPT DIARISÉ -----")
    print(result.text_diarized)
    print("------------------------------\n")

    if args.transcript_only:
        return 0

    ok, msg = llm.check_llm()
    if not ok:
        print(f"❌ {msg}", file=sys.stderr)
        return 4

    print("🤖 Génération de la fiche-bilan via le backend LLM configuré…")
    t0 = time.time()
    try:
        recap = llm.generate_recap(result.text_diarized, model=args.model)
    except llm.LLMError as exc:
        print(f"❌ LLM échoué : {exc}", file=sys.stderr)
        return 5
    print(f"✅ Fiche-bilan générée en {time.time() - t0:.0f}s\n")

    pretty = json.dumps(recap, ensure_ascii=False, indent=2)
    print(pretty)
    if args.out:
        Path(args.out).write_text(pretty, encoding="utf-8")
        print(f"\n💾 Écrit dans {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
