# 🦶 PodoNote

**Assistant local de transcription & bilan de consultation pour la pédicure-podologie.**

PodoNote enregistre une consultation, la transcrit, identifie les locuteurs (praticien / patient)
et génère une **fiche-bilan structurée**. Chaque patient a un dossier qui s'enrichit visite après visite.

> 🔒 **L'audio et la base de données ne quittent jamais l'ordinateur.** La
> transcription est 100 % locale. Pour rédiger la fiche-bilan, la version par
> défaut (hybride) envoie au cloud Claude **uniquement du texte pseudonymisé**
> (nom, prénom, dates… retirés en local puis réinjectés) — jamais l'audio, jamais
> d'identifiant patient. Un mode **100 % local** (Ollama, sans aucun envoi) reste
> disponible (`LLM_BACKEND=ollama`, GPU recommandé). Voir [docs/DECISION_ARCHI.md](docs/DECISION_ARCHI.md).

---

## 🚀 Installation (à faire une seule fois)

1. Copiez le dossier **PodoNote** sur le PC (ex. `C:\PodoNote`).
2. Double-cliquez sur **`Installer-PodoNote.bat`**.
   *(Si Windows affiche un avertissement : « Informations complémentaires » → « Exécuter quand même ».)*
   L'installateur (mode hybride par défaut) met en place automatiquement : Python 3.12, ffmpeg,
   les briques ML, **pré-télécharge les modèles de transcription**, et **demande votre clé API
   Claude** pour la rédaction des fiches. **Comptez 15–40 min** (téléchargements).
   *(Pour une installation 100 % locale sans cloud : `install.ps1 -Mode local` — installe Ollama, GPU recommandé.)*

## ▶️ Lancer l'application

Double-cliquez sur **`PodoNote`** (raccourci créé sur le Bureau) ou sur **`PodoNote.bat`**.
Le navigateur s'ouvre sur l'application.

- **Au tout premier lancement**, un écran vous guide pour **créer votre mot de passe et votre code PIN**
  (rien à éditer à la main). Notez-les : ils sont chiffrés et non récupérables.
- Pour activer l'**identification des locuteurs** (qui parle), ajoutez votre `HUGGINGFACE_TOKEN`
  dans le fichier `.env` (jeton gratuit, voir [GUIDE.md](GUIDE.md) §1a).

Pour quitter : fermez la fenêtre noire.

---

## 🗺️ Comment ça marche

```
Micro USB (cabinet)  ─┐
                      ├─►  fichier audio  ─►  PIPELINE (différé)  ─►  Fiche-bilan
iPhone (à domicile)  ─┘     (upload Wi-Fi)     1. Transcription (locale)
                                               2. Diarisation (qui parle)
                                               3. Pseudonymisation (locale)
                                               4. Fiche-bilan (Claude cloud, ou Ollama local)
                                               5. Audio supprimé (RGPD)
```

- **Au cabinet** : page « Nouvelle consultation » → enregistrement direct au micro.
- **À domicile** : enregistrez avec le Dictaphone de l'iPhone, puis envoyez via la page
  d'upload Wi-Fi (QR code dans l'onglet **État**). Voir [GUIDE.md](GUIDE.md).

---

## 🔐 Sécurité & RGPD

- **L'audio ne quitte jamais le poste** et est supprimé après transcription. La
  transcription est strictement locale.
- **Fiche-bilan (mode hybride, par défaut)** : seul du **texte pseudonymisé** est
  envoyé à Claude (Anthropic, sous-traitant) — identifiants patients retirés en
  local puis réinjectés. À mentionner dans votre registre de traitement. Le mode
  `LLM_BACKEND=ollama` supprime tout envoi (100 % local).
- Le jeton HuggingFace ne sert qu'au **téléchargement initial** des modèles de
  diarisation ; aucune donnée patient n'est transmise.
- Base de données protégée par le **chiffrement disque BitLocker** + mot de passe applicatif.
  → Activez BitLocker sur le disque (Windows : Paramètres → Confidentialité → Chiffrement de l'appareil).
- **L'audio est supprimé automatiquement** après transcription réussie.
- **Consentement** tracé à chaque consultation (obligatoire avant traitement).
- Pour chaque patient : **export** (PDF / JSON) et **suppression définitive** (droit à l'effacement).
- Page d'upload protégée par **PIN**, accessible uniquement sur le réseau local.

---

## 🛠️ Pour les développeurs

```powershell
# Environnement
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
.\scripts\install_ml.ps1            # torch CPU + faster-whisper + whisperx

# Tester la chaîne ML sans l'UI (jalon 2)
python cli.py chemin\vers\audio.m4a

# Lancer le serveur
python -m uvicorn app.main:app --reload --port 8000
```

| Brique        | Techno                                  |
|---------------|-----------------------------------------|
| Serveur/API   | FastAPI + Uvicorn                       |
| Transcription | WhisperX (faster-whisper / CTranslate2) |
| Diarisation   | pyannote (via WhisperX)                 |
| LLM (fiche)   | Claude Sonnet (cloud, défaut) ou Ollama `qwen2.5:7b` (local) |
| Base          | SQLite (chiffrement disque BitLocker)   |
| Front         | Jinja2 + CSS maison (offline)           |

### Structure
```
app/            cœur applicatif (FastAPI, db, pipeline)
  pipeline/     transcribe.py · llm.py · runner.py
templates/      pages web (Jinja2)
static/         CSS
cli.py          test du pipeline en ligne de commande
install.ps1     installation automatique
start.ps1       démarrage
```

Voir le **[brief complet](Brief%20Claude%20Code%20App%20Podologue.md)** pour les choix d'architecture.
