#!/usr/bin/env bash
# =============================================================================
#  PodoNote — Lanceur macOS (double-cliquable depuis le Finder)
#  Démarre l'application dans sa fenêtre native (WKWebView via pywebview).
#  Le serveur écoute aussi sur le réseau local pour l'envoi depuis l'iPhone.
# =============================================================================
cd "$(dirname "$0")" || exit 1
if [ ! -x ".venv/bin/python" ]; then
  echo "PodoNote n'est pas installé (.venv absent)."
  echo "Lancez d'abord :  bash scripts/install_mac.sh"
  read -r -p "Appuyez sur Entrée pour fermer…" _
  exit 1
fi
exec ".venv/bin/python" -m app.desktop
