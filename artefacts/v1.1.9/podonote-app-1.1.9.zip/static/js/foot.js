// Schéma du pied annotable — marquage à niveaux (douleur / lésion / soin).
// Clic sur une zone : cycle '' -> douleur -> lesion -> soin -> ''.
// Sérialise { zones:[...], levels:{zone:level}, note } dans le champ caché.
(function () {
  var LEVELS = ["douleur", "lesion", "soin"];

  function nextLevel(cur) {
    var i = LEVELS.indexOf(cur);
    return i === -1 ? LEVELS[0] : (i + 1 < LEVELS.length ? LEVELS[i + 1] : "");
  }

  function applyLevel(z, level) {
    LEVELS.forEach(function (l) { z.classList.remove("lvl-" + l); });
    z.classList.remove("on");
    if (level) { z.classList.add("lvl-" + level); z.setAttribute("data-level", level); }
    else { z.removeAttribute("data-level"); }
  }

  function sync(root) {
    if (!root || root.dataset.editable !== "1") return;
    var zones = [], levels = {};
    root.querySelectorAll(".fz").forEach(function (z) {
      var lvl = z.getAttribute("data-level");
      if (lvl) { zones.push(z.dataset.zone); levels[z.dataset.zone] = lvl; }
    });
    var noteEl = root.querySelector(".foot-note");
    var field = document.getElementById(root.dataset.field);
    if (field) field.value = JSON.stringify({ zones: zones, levels: levels, note: noteEl ? noteEl.value : "" });
  }

  function cycle(z) {
    var root = z.closest(".foot-widget");
    if (!root || root.dataset.editable !== "1") return;
    applyLevel(z, nextLevel(z.getAttribute("data-level") || ""));
    sync(root);
  }

  document.addEventListener("click", function (e) {
    var z = e.target.closest(".fz");
    if (z) cycle(z);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Enter" && e.key !== " ") return;
    var z = e.target.closest && e.target.closest(".fz");
    if (z) { e.preventDefault(); cycle(z); }
  });
  document.addEventListener("input", function (e) {
    if (e.target.classList && e.target.classList.contains("foot-note")) {
      sync(e.target.closest(".foot-widget"));
    }
  });
})();
