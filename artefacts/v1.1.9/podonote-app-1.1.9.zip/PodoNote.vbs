' =============================================================================
'  PodoNote - lanceur auto-reparant (cible du raccourci Bureau / menu Demarrer)
'
'  TOUJOURS present (livre avec l'app). Le raccourci pointe ICI et non plus
'  directement sur .venv\Scripts\pythonw.exe : ainsi il ne peut plus "pointer
'  dans le vide" (dialogue Windows "Probleme de raccourci") quand l'environnement
'  Python n'a pas encore ete construit -- cas d'une install interrompue ou d'une
'  reinstallation sur un nouveau PC.
'
'  - Si .venv\Scripts\pythonw.exe existe  -> lance l'app SANS console (comme avant).
'  - Sinon                                -> termine/repare l'installation
'    (install.ps1, fenetre visible) PUIS demarre l'app automatiquement.
'
'  Lance via wscript.exe (aucune fenetre console ne clignote sur le cas normal).
' =============================================================================
Option Explicit

Dim fso, shell, root, pythonw, installPs1, cmd

Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

root       = fso.GetParentFolderName(WScript.ScriptFullName)
pythonw    = root & "\.venv\Scripts\pythonw.exe"
installPs1 = root & "\install.ps1"

' L'app attend d'etre lancee depuis son dossier (chemins relatifs : .env, data, ...).
shell.CurrentDirectory = root

' --- Cas normal : environnement present -> demarrage sans console ------------
If fso.FileExists(pythonw) Then
    ' 0 = fenetre masquee, False = ne pas attendre (l'app vit sa vie).
    shell.Run """" & pythonw & """ -m app.desktop", 0, False
    WScript.Quit 0
End If

' --- Environnement absent : terminer / reparer l'installation ---------------
If Not fso.FileExists(installPs1) Then
    MsgBox "PodoNote est incomplet et le script d'installation est introuvable." & vbCrLf & vbCrLf & _
           "Merci de reinstaller PodoNote (PodoNoteSetup.exe) ou de contacter Studio Margerit.", _
           vbCritical, "PodoNote"
    WScript.Quit 1
End If

MsgBox "PodoNote doit terminer son installation avant le premier demarrage." & vbCrLf & vbCrLf & _
       "Une fenetre va s'ouvrir et installer les composants (15 a 40 min selon la" & vbCrLf & _
       "connexion Internet). NE LA FERMEZ PAS : PodoNote demarrera tout seul a la fin.", _
       vbInformation, "PodoNote - finalisation de l'installation"

' Fenetre visible (1) + attendre la fin (True). -NoShortcut : le raccourci existe deja.
cmd = "powershell -NoProfile -ExecutionPolicy Bypass -File """ & installPs1 & """ -NoShortcut"
shell.Run cmd, 1, True

' --- Apres reparation : lancer si l'environnement est desormais present ------
If fso.FileExists(pythonw) Then
    shell.Run """" & pythonw & """ -m app.desktop", 0, False
    WScript.Quit 0
Else
    MsgBox "L'installation des composants n'a pas pu aboutir (connexion Internet ?)." & vbCrLf & vbCrLf & _
           "Verifiez votre connexion et relancez PodoNote. Si le probleme persiste," & vbCrLf & _
           "un rapport << PodoNote-PROBLEME-installation.txt >> peut se trouver sur le" & vbCrLf & _
           "Bureau : envoyez-le a Studio Margerit.", _
           vbCritical, "PodoNote"
    WScript.Quit 1
End If
