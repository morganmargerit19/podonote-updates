@echo off
REM ============================================================
REM  PodoNote - INSTALLATION (double-cliquez sur ce fichier)
REM  A lancer UNE SEULE FOIS a la premiere utilisation.
REM  Rien a configurer : tout est automatique.
REM ============================================================
title Installation de PodoNote

REM Installation PER-USER : aucun droit administrateur requis (Python --scope user,
REM dossier %LocalAppData%, cache modeles dans le profil). On NE force PAS l'UAC :
REM une elevation vers un autre compte admin installerait dans le mauvais profil.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

echo.
echo ============================================
echo  C'est termine. Double-cliquez sur l'icone
echo  PodoNote (Bureau) pour lancer l'application.
echo ============================================
pause
