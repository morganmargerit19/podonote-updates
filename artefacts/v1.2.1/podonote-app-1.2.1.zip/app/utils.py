"""Utilitaires : IP LAN, sauvegarde fichiers, formatage."""
from __future__ import annotations

import re
import socket
import unicodedata
from datetime import datetime
from pathlib import Path

from fastapi import UploadFile

from .config import INCOMING_DIR, settings

# Extensions audio acceptées
ALLOWED_AUDIO = {".wav", ".m4a", ".mp3", ".ogg", ".webm", ".flac", ".aac", ".mp4"}


class UploadTooLarge(Exception):
    """Le fichier dépasse la taille maximale autorisée."""


def get_lan_ip() -> str:
    """Renvoie l'IP LAN du PC (best effort)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(1.0)
        s.connect(("8.8.8.8", 80))  # ne transmet rien, sert juste à choisir l'interface
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        try:
            s.close()
        except OSError:
            pass


def date_fr(value) -> str:
    """ISO 'AAAA-MM-JJ[...]' -> 'JJ/MM/AAAA' (affichage français). Vide si absent.

    Unique source de cette conversion (utilisée par l'UI via filtre Jinja, par les
    PDF RGPD et par l'ordonnance) — éviter de la dupliquer module par module.
    """
    if not value:
        return ""
    s = str(value)[:10]
    try:
        y, m, d = s.split("-")
        return f"{d}/{m}/{y}"
    except ValueError:
        return s


def normalize_dob(value) -> str | None:
    """Normalise une date de naissance vers l'ISO « AAAA-MM-JJ ».

    Le champ est saisi librement : on accepte l'ISO et les écritures françaises
    (JJ/MM/AAAA, JJ-MM-AAAA, JJ.MM.AAAA). Sans cette normalisation, une date
    « 12/03/1980 » stockée telle quelle casse le calcul de l'âge et l'affichage
    (qui attendent l'ISO). En cas de format non reconnu, on RENVOIE la saisie
    d'origine (jamais de perte de donnée)."""
    if not value:
        return None
    s = str(value).strip()
    if not s:
        return None
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        y, mo, d = (int(x) for x in m.groups())
    else:
        m = re.match(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$", s)
        if not m:
            return s  # format inconnu (année sur 2 chiffres incluse) : on n'invente rien
        d, mo, y = (int(x) for x in m.groups())
    try:
        from datetime import date as _date
        _date(y, mo, d)  # rejette les dates impossibles (31/02, mois 13…)
    except ValueError:
        return s
    return f"{y:04d}-{mo:02d}-{d:02d}"


def fold(value) -> str:
    """Forme « pliée » pour la recherche : sans accents ni casse ni espaces
    superflus (« Lefèvre » → « lefevre », « ÉMILIE » → « emilie »). Sert aussi
    de fonction SQL `fold()` (enregistrée dans db.get_connection) pour que les
    LIKE de SQLite — insensibles à la casse seulement en ASCII — trouvent
    « Lefèvre » quand on tape « lefevre » ou « LEFÈVRE »."""
    if value is None:
        return ""
    txt = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode()
    return " ".join(txt.casefold().split())


# Particules toujours en minuscules dans un nom (« de La Tour », « van Gogh »).
_PARTICULES = {"de", "du", "des", "van", "von", "der", "den", "di", "da", "del",
               "della", "el", "al", "y", "et"}


def normalize_person_name(value, garder_majuscules: bool = False) -> str:
    """Casse propre d'un nom ou prénom saisi vite (« claire » → « Claire »,
    « jean-pierre » → « Jean-Pierre », « de la tour » → « de La Tour »,
    « d'arc » → « d'Arc »). Une saisie déjà en casse mixte (« McDonald »,
    « de GAULLE ») est respectée telle quelle.

    `garder_majuscules=True` (nom de famille) : une saisie TOUT EN MAJUSCULES
    est conservée — retour Nico (1.2.0) : il écrit les noms de famille en
    capitales, comme la plupart des cabinets, et la 1.2.0 les lui remettait en
    « Martin ». Seule une saisie tout en minuscules est alors remise au propre."""
    txt = " ".join(str(value or "").split())
    if not txt or not (txt.islower() or txt.isupper()):
        return txt
    if garder_majuscules and txt.isupper():
        return txt

    def cap(tok: str) -> str:
        return tok[:1].upper() + tok[1:]

    def morceau(part: str) -> str:
        # Élision : d'arc → d'Arc (le « d' » reste bas), l'hermite → L'Hermite.
        if "'" in part:
            a, b = part.split("'", 1)
            return f"{a if a == 'd' else cap(a)}'{cap(b)}"
        return cap(part)

    def mot(w: str) -> str:
        if w in _PARTICULES:
            return w
        return "-".join(morceau(x) for x in w.split("-"))

    return " ".join(mot(w) for w in txt.lower().split(" "))


def slugify(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    value = re.sub(r"[^\w\s-]", "", value).strip().lower()
    return re.sub(r"[-\s]+", "-", value) or "audio"


def save_upload(file: UploadFile, prefix: str = "") -> Path:
    """Sauvegarde un UploadFile dans incoming/ avec un nom unique et sûr.

    - le nom de destination est entièrement régénéré (pas de path traversal possible) ;
    - l'extension provient du nom d'origine (basename seul) si autorisée, sinon .webm ;
    - la taille est plafonnée par settings.max_upload_mb (fichier partiel supprimé si dépassement).
    Lève UploadTooLarge si le fichier est trop volumineux.
    """
    INCOMING_DIR.mkdir(parents=True, exist_ok=True)
    # basename uniquement : neutralise tout "../" ou chemin absolu dans filename.
    orig = Path((file.filename or "audio.webm").replace("\\", "/")).name
    ext = Path(orig).suffix.lower()
    if ext not in ALLOWED_AUDIO:
        ext = ".webm"
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    name = f"{slugify(prefix)}-{stamp}{ext}" if prefix else f"{stamp}{ext}"
    dest = INCOMING_DIR / name

    max_bytes = settings.max_upload_mb * 1024 * 1024
    written = 0
    try:
        with dest.open("wb") as out:
            while chunk := file.file.read(1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    out.close()
                    dest.unlink(missing_ok=True)
                    raise UploadTooLarge(
                        f"Fichier trop volumineux (max {settings.max_upload_mb} Mo)."
                    )
                out.write(chunk)
    except OSError as exc:
        # Disque plein / erreur d'écriture : pas de fichier partiel laissé, message clair.
        dest.unlink(missing_ok=True)
        raise UploadTooLarge(
            "Impossible d'enregistrer l'audio (espace disque insuffisant ?)."
        ) from exc
    return dest


def is_allowed_audio(filename: str) -> bool:
    return Path(filename or "").suffix.lower() in ALLOWED_AUDIO


# --------------------------------------------------------------------------- #
# Dossier d'export PDF du patient (Documents\Diktae\<Nom Prénom>\).
# Partagé entre main.py (écriture des PDF) et rgpd.py (droit à l'effacement :
# la suppression définitive d'un dossier doit AUSSI supprimer ces PDF).
# --------------------------------------------------------------------------- #
def user_documents_dir() -> Path:
    """Dossier « Documents » de l'utilisateur (gère la redirection OneDrive)."""
    import os
    one = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
    if one and (Path(one) / "Documents").is_dir():
        return Path(one) / "Documents"
    up = os.environ.get("USERPROFILE")
    if up and (Path(up) / "Documents").is_dir():
        return Path(up) / "Documents"
    return Path.home() / "Documents"


def safe_folder(name: str, fallback: str) -> str:
    """Nom de dossier sûr : retire les caractères interdits par Windows."""
    invalid = '<>:"/\\|?*'
    cleaned = "".join("-" if (ch in invalid or ord(ch) < 32) else ch for ch in (name or ""))
    return cleaned.strip(" .") or fallback


def patient_export_dir_name(patient: dict) -> str:
    """Nom du sous-dossier d'export d'un patient : « Nom Prénom (#id) ».

    Le suffixe « (#id) » rend le dossier STABLE même si le patient est renommé :
    l'effacement RGPD peut alors retrouver tous les dossiers d'un patient par son
    id (cf. app/rgpd.py), sans laisser de PDF nominatifs orphelins."""
    pid = patient.get("id", "")
    base = safe_folder(f"{patient.get('nom', '')} {patient.get('prenom', '')}".strip(),
                       f"patient-{pid}")
    return f"{base} (#{pid})" if pid != "" else base


# Dossier de sortie visible par l'utilisateur (PDF, sauvegardes). Renommage
# Diktae : l'ancien dossier « PodoNote » est migré d'un bloc au premier accès
# (rename) ; s'il ne peut pas l'être (verrou, les deux existent), la purge RGPD
# continue de balayer l'ancien emplacement (cf. app/rgpd.py).
EXPORT_DIR_NAME = "Diktae"
LEGACY_EXPORT_DIR_NAME = "PodoNote"


def export_root(create: bool = False) -> Path:
    """Documents\\Diktae — migre Documents\\PodoNote s'il est seul présent."""
    docs = user_documents_dir()
    root = docs / EXPORT_DIR_NAME
    legacy = docs / LEGACY_EXPORT_DIR_NAME
    try:
        if legacy.is_dir() and not root.exists():
            legacy.rename(root)
    except OSError:
        pass  # best-effort : un verrou ne doit jamais bloquer une génération
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
    return root


def migrate_patient_export_dir(old_patient: dict, new_patient: dict) -> None:
    """Après un RENOMMAGE de patient : déplace le dossier d'export de l'ancien nom
    vers le nouveau, pour qu'il n'en existe qu'UN par patient. Sans cela, l'ancien
    dossier (PDF nominatifs) deviendrait orphelin et échapperait à l'effacement RGPD
    si aucun nouveau PDF n'était généré entre le renommage et la suppression."""
    try:
        root = export_root()
        new_dir = root / patient_export_dir_name(new_patient)
        pid = new_patient.get("id", "")
        old_name = f"{old_patient.get('nom', '')} {old_patient.get('prenom', '')}".strip()
        candidates = [
            root / patient_export_dir_name(old_patient),          # ancien nom + suffixe (#id)
            root / safe_folder(old_name, f"patient-{pid}"),        # ancien nom hérité (sans suffixe)
        ]
        for old_dir in candidates:
            if old_dir == new_dir or not old_dir.is_dir():
                continue
            if new_dir.exists():
                # Fusion : on rapatrie les fichiers dans le dossier courant.
                for f in old_dir.iterdir():
                    target = new_dir / f.name
                    if not target.exists():
                        f.rename(target)
                try:
                    old_dir.rmdir()
                except OSError:
                    pass
            else:
                old_dir.rename(new_dir)
    except OSError:
        pass  # best-effort : un dossier verrouillé ne doit pas bloquer l'édition


def patient_export_dir(patient: dict, create: bool = True) -> Path:
    """Dossier Documents\\Diktae\\<Nom Prénom (#id)>\\ (créé au besoin).

    Un sous-dossier par patient pour s'y retrouver dans la durée ; l'historique
    des PDF y est conservé (cf. choix de l'utilisateur) — mais il est SUPPRIMÉ
    avec le dossier patient lors d'un effacement RGPD (app/rgpd.py)."""
    root = export_root()
    d = root / patient_export_dir_name(patient)
    if create:
        # Migration : si un dossier hérité « Nom Prénom » (sans suffixe id, ancienne
        # convention) existe et pas encore le nouveau, on le renomme pour consolider
        # l'historique des PDF au même endroit (pas de dossier « fantôme » dupliqué).
        legacy = root / safe_folder(
            f"{patient.get('nom', '')} {patient.get('prenom', '')}".strip(),
            f"patient-{patient.get('id', '')}",
        )
        try:
            if legacy != d and legacy.is_dir() and not d.exists():
                legacy.rename(d)
        except OSError:
            pass  # un dossier verrouillé ne doit jamais bloquer la génération du PDF
        d.mkdir(parents=True, exist_ok=True)
    return d
