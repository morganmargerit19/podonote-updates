/* Micro des enregistreurs de Diktae : choix du périphérique + veille de silence.
 *
 * - DiktaeMic.open(nom, contraintes) ouvre le micro retenu par le praticien
 *   (reconnu à son NOM : les identifiants changent d'une session à l'autre), et
 *   se rabat sur le micro par défaut s'il est introuvable (`fallback`).
 * - DiktaeMic.inputs() liste les micros (noms visibles une fois l'accès accordé).
 * - DiktaeMic.watch(flux, {ctx, onSilent, onHeard}) surveille qu'un son arrive :
 *   un micro coupé enregistre du silence sans rien signaler.
 */
(function(){
  'use strict';
  var SOUND_MIN = 0.004;      // ≈ -48 dBFS : sous ce pic, rien n'a été capté
  var ALERT_MS = 6000;        // silence complet depuis le début → alerte
  var MIN_OBSERVED = 20;      // ≥ 2 s de mesures avant de conclure

  function inputs(){
    if(!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return Promise.resolve([]);
    return navigator.mediaDevices.enumerateDevices().then(function(ds){
      var seen = {};
      return ds.filter(function(d){
        // « default » / « communications » : doublons du micro par défaut (Chromium).
        if(d.kind !== 'audioinput' || !d.label) return false;
        if(d.deviceId === 'default' || d.deviceId === 'communications') return false;
        if(seen[d.label]) return false;
        seen[d.label] = true; return true;
      });
    }).catch(function(){ return []; });
  }

  function stop(stream){ if(stream) stream.getTracks().forEach(function(t){ t.stop(); }); }

  function open(wanted, base){
    base = base || {};
    var audio = Object.keys(base).length ? base : true;
    return navigator.mediaDevices.getUserMedia({audio: audio}).then(function(stream){
      function done(s, fallback){
        var t = s.getAudioTracks()[0];
        return {stream: s, label: t ? t.label : '', fallback: !!fallback};
      }
      var cur = stream.getAudioTracks()[0];
      if(!wanted || (cur && cur.label === wanted)) return done(stream, false);
      return inputs().then(function(ds){
        var hit = ds.filter(function(d){ return d.label === wanted; })[0];
        if(!hit) return done(stream, true);
        var c = {}; for(var k in base) c[k] = base[k];
        c.deviceId = {exact: hit.deviceId};
        return navigator.mediaDevices.getUserMedia({audio: c}).then(function(s2){
          stop(stream); return done(s2, false);
        }).catch(function(){ return done(stream, true); });
      });
    });
  }

  function watch(stream, opts){
    opts = opts || {};
    var none = {stop: function(){ return {heard: true, silent: false}; }};
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if(!Ctx) return none;
    var own = !opts.ctx, ctx = opts.ctx || new Ctx(), ear;
    try {
      // Fenêtre large (≈ 40 ms relus toutes les 100 ms) : on écoute près de la
      // moitié du temps, assez pour ne manquer aucune parole.
      ear = ctx.createAnalyser(); ear.fftSize = 2048;
      if(!ear.getFloatTimeDomainData){ if(own) ctx.close(); return none; }
      ctx.createMediaStreamSource(stream).connect(ear);
    } catch(e){ if(own){ try { ctx.close(); } catch(_){} } return none; }
    var wave = new Float32Array(ear.fftSize);
    var heard = false, observed = 0, warned = false, t0 = Date.now();
    // Minuterie, pas requestAnimationFrame (suspendu fenêtre masquée) ; et on ne
    // compte que les mesures d'un contexte audio qui tourne vraiment.
    var id = setInterval(function(){
      if(ctx.state !== 'running') return;
      ear.getFloatTimeDomainData(wave);
      var peak = 0;
      for(var i = 0; i < wave.length; i++){ var v = Math.abs(wave[i]); if(v > peak) peak = v; }
      observed++;
      if(peak >= SOUND_MIN){
        if(!heard && warned && opts.onHeard) opts.onHeard();
        heard = true;
      } else if(!heard && !warned && Date.now() - t0 > ALERT_MS){
        warned = true;
        if(opts.onSilent) opts.onSilent();
      }
    }, 100);
    return {stop: function(){
      clearInterval(id);
      if(own){ try { ctx.close(); } catch(_){} }
      return {heard: heard, silent: !heard && observed >= MIN_OBSERVED};
    }};
  }

  window.DiktaeMic = {
    inputs: inputs, open: open, watch: watch, stop: stop,
    MSG_SILENT: "Le micro ne capte aucun son. Vérifiez qu'il est branché, non coupé, et que c'est bien lui qui est choisi.",
    MSG_SILENT_END: "Aucun son n'a été capté pendant cet enregistrement : le micro semble muet."
  };
})();
