"""Lit les retours praticiens (bug / suggestion) déposés sur le proxy.

Fait pour une session Claude dans le cloud : le jeton est de LECTURE SEULE
(`PROXY_FEEDBACK_READ_TOKEN` du Pi, rangé dans les secrets de l'environnement
cloud sous `DIKTAE_RETOURS_TOKEN`). Il lit la liste et les captures, et peut
DEMANDER le journal technique d'un poste (le poste l'envoie seul, il arrive
ici en type « journal ») ; rien d'autre : répondre ou changer un statut se
fait au tableau de bord.
Le jeton admin (`DIKTAE_ADMIN_TOKEN`) marche aussi, depuis le Mac.

Usage :
  python scripts/lire_retours.py                       # les 20 derniers
  python scripts/lire_retours.py --statut nouveau      # seulement les non lus
  python scripts/lire_retours.py --qui Bryan           # un praticien
  python scripts/lire_retours.py --id 12               # un retour en entier
  python scripts/lire_retours.py --capture 12 --dossier /tmp/x   # sa capture
  python scripts/lire_retours.py --demander-journal "Bryan Laurent"  # journal à distance
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

PROXY = os.environ.get("DIKTAE_PROXY_URL", "https://api.studio-margerit.fr").rstrip("/")
# Cloudflare refuse l'agent par défaut de urllib (« Python-urllib ») : 403.
AGENT = "diktae-lire-retours/1.0"


def _jeton() -> str:
    jeton = (os.environ.get("DIKTAE_RETOURS_TOKEN")
             or os.environ.get("DIKTAE_ADMIN_TOKEN") or "").strip()
    if not jeton:
        sys.exit("Aucun jeton : définir DIKTAE_RETOURS_TOKEN (secrets de l'environnement "
                 "cloud) — cf. server/keyproxy/rpi/jeton-lecture-retours.sh.")
    return jeton


def _get(chemin: str, corps: dict | None = None) -> tuple[bytes, str]:
    entetes = {"Authorization": f"Bearer {_jeton()}", "User-Agent": AGENT}
    data = None
    if corps is not None:
        data = json.dumps(corps).encode("utf-8")
        entetes["Content-Type"] = "application/json"
    req = urllib.request.Request(PROXY + chemin, data=data, headers=entetes)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read(), resp.headers.get("Content-Type", "")
    except urllib.error.HTTPError as exc:
        if exc.code == 404 and corps is not None:
            sys.exit(f"Introuvable : {exc.read()[:300].decode('utf-8', 'replace')}")
        if exc.code == 401:
            sys.exit("Jeton refusé (401) : le Pi a-t-il PROXY_FEEDBACK_READ_TOKEN, "
                     "et le même jeton est-il dans DIKTAE_RETOURS_TOKEN ?")
        sys.exit(f"Erreur {exc.code} du proxy : {exc.read()[:300]!r}")
    except urllib.error.URLError as exc:
        sys.exit(f"Proxy injoignable ({PROXY}) : {exc.reason}")


def _liste(statut: str, limite: int) -> list[dict]:
    q = f"?limit={limite}" + (f"&status={statut}" if statut else "")
    corps, _ = _get("/admin/feedback" + q)
    return json.loads(corps)["feedback"]


def _ligne(f: dict) -> str:
    texte = " ".join((f.get("message") or "").split())
    if len(texte) > 110:
        texte = texte[:107] + "…"
    capture = (" 📎" if f.get("has_image") else "") + (
        " 📜" if (f.get("context") or {}).get("journal") else "")
    return (f"#{f['id']:<4} {f['ts'][:16].replace('T', ' ')}  {f.get('status', ''):<8} "
            f"{f.get('kind', ''):<10} v{f.get('app_version') or '?':<7} "
            f"{f.get('licensee', '')}{capture}\n      {texte}")


def _detail(f: dict) -> str:
    lignes = [
        f"Retour #{f['id']}  ({f.get('ref') or 'sans référence'})",
        f"Reçu le      : {f['ts'].replace('T', ' ')}",
        f"Praticien    : {f.get('licensee', '')}  (formule {f.get('plan', '?')})",
        f"Type         : {f.get('kind', '')}",
        f"Statut       : {f.get('status', '')}",
        f"Version app  : {f.get('app_version') or '?'}   Plateforme : {f.get('platform') or '?'}",
        f"Capture      : {'oui (--capture ' + str(f['id']) + ')' if f.get('has_image') else 'non'}",
        "",
        "Message :",
        f.get("message") or "",
    ]
    if f.get("reply"):
        lignes += ["", "Réponse déjà envoyée :", f["reply"]]
    contexte = dict(f.get("context") or {})
    journal = contexte.pop("journal", "")
    if contexte:
        lignes += ["", "Contexte technique :"]
        lignes += [f"  {k} : {v}" for k, v in contexte.items()]
    if journal:
        lignes += ["", "Journal technique (pseudonymisé par le poste) :", journal]
    return "\n".join(lignes)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--statut", default="", help="nouveau, vu, traite, archive")
    ap.add_argument("--limite", type=int, default=20)
    ap.add_argument("--qui", default="", help="filtre sur le nom du praticien")
    ap.add_argument("--id", type=int, help="affiche un retour en entier")
    ap.add_argument("--capture", type=int, help="enregistre la capture de ce retour")
    ap.add_argument("--dossier", default=".", help="où enregistrer la capture")
    ap.add_argument("--json", action="store_true", help="sortie brute")
    ap.add_argument("--demander-journal", metavar="NOM",
                    help="demande au poste de ce praticien (nom exact du titulaire) "
                         "d'envoyer son journal technique")
    ap.add_argument("--annuler", action="store_true",
                    help="avec --demander-journal : retire la demande")
    args = ap.parse_args()

    if args.demander_journal:
        corps, _ = _get("/admin/journal", {"licensee": args.demander_journal,
                                           "annuler": args.annuler})
        cles = json.loads(corps).get("cles") or []
        if args.annuler:
            print(f"Demande retirée ({len(cles)} clé(s)).")
        else:
            print(f"Journal demandé pour {args.demander_journal} ({len(cles)} clé(s)). "
                  "Le poste l'enverra à sa prochaine ouverture, ou dans les 5 minutes "
                  "s'il est ouvert ; il arrivera ici en type « journal ».")
        return 0

    if args.capture is not None:
        corps, mime = _get(f"/admin/feedback/{args.capture}/image")
        ext = ".png" if "png" in mime else ".jpg"
        dest = Path(args.dossier) / f"retour-{args.capture}{ext}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(corps)
        print(dest)
        return 0

    retours = _liste(args.statut, 1000 if (args.id or args.qui) else args.limite)
    if args.qui:
        retours = [f for f in retours if args.qui.lower() in (f.get("licensee") or "").lower()]
        retours = retours[:args.limite]
    if args.id is not None:
        retours = [f for f in retours if f["id"] == args.id]
        if not retours:
            sys.exit(f"Retour #{args.id} introuvable.")
    if args.json:
        print(json.dumps(retours, ensure_ascii=False, indent=2))
    elif args.id is not None:
        print(_detail(retours[0]))
    elif not retours:
        print("Aucun retour.")
    else:
        print("\n".join(_ligne(f) for f in retours))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
