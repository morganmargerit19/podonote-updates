#!/usr/bin/env bash
# ============================================================================ #
#  Diktae — poser sur le Pi le jeton de LECTURE des retours praticiens
#  (PROXY_FEEDBACK_READ_TOKEN) et l'afficher, pour le ranger dans les secrets
#  de l'environnement cloud de Claude (variable DIKTAE_RETOURS_TOKEN).
#
#  Ce jeton lit les retours et leurs captures, RIEN d'autre (ni statut, ni
#  suppression, ni dépenses, ni clés). Déjà posé : il est seulement réaffiché.
#
#  Depuis le Mac, puis mettre le proxy à jour (il relit son .env) :
#      bash server/keyproxy/rpi/jeton-lecture-retours.sh --ssh admin@diktae-proxy.local
#      bash server/keyproxy/rpi/mettre-a-jour.sh --ssh admin@diktae-proxy.local
#
#  Changer de jeton (s'il a fuité) : --nouveau, puis mettre-a-jour.sh.
# ============================================================================ #
set -euo pipefail

ENV_FILE=/opt/diktae-keyproxy/.env
CLE=PROXY_FEEDBACK_READ_TOKEN
CIBLE=""
NOUVEAU=0

fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --ssh) CIBLE="$2"; shift 2 ;;
    --nouveau) NOUVEAU=1; shift ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) fail "Option inconnue : $1" ;;
  esac
done

# --------------------------------------------------------------------------- #
# Sur le Mac : envoyer ce script au Pi et l'y exécuter avec sudo
# --------------------------------------------------------------------------- #
if [ -n "$CIBLE" ]; then
  OPT=(); [ "$NOUVEAU" = 1 ] && OPT=(--nouveau)
  DISTANT="$(ssh "$CIBLE" 'mktemp')" || fail "Connexion SSH impossible."
  ssh "$CIBLE" "cat > '$DISTANT'" < "$0"
  ssh -t "$CIBLE" "sudo bash '$DISTANT' ${OPT[*]+"${OPT[*]}"}; code=\$?; rm -f '$DISTANT'; exit \$code"
  exit $?
fi

# --------------------------------------------------------------------------- #
# Sur le Pi
# --------------------------------------------------------------------------- #
[ -f "$ENV_FILE" ] || fail "$ENV_FILE introuvable : ce n'est pas le Pi du keyproxy."
[ "$(id -u)" -eq 0 ] || fail "Lancez avec sudo : sudo bash $0"

ACTUEL="$(grep -E "^${CLE}=" "$ENV_FILE" | tail -1 | cut -d= -f2- || true)"
if [ -n "$ACTUEL" ] && [ "$NOUVEAU" = 0 ]; then
  JETON="$ACTUEL"
  ETAT="déjà en place"
else
  JETON="$(openssl rand -hex 32 2>/dev/null || python3 -c 'import secrets; print(secrets.token_hex(32))')"
  [ -n "$JETON" ] || fail "Impossible de générer un jeton."
  cp "$ENV_FILE" "$ENV_FILE.bak"
  grep -vE "^${CLE}=" "$ENV_FILE.bak" > "$ENV_FILE" || true
  printf '%s=%s\n' "$CLE" "$JETON" >> "$ENV_FILE"
  chmod --reference="$ENV_FILE.bak" "$ENV_FILE" 2>/dev/null || chmod 600 "$ENV_FILE"
  rm -f "$ENV_FILE.bak"
  ETAT="posé dans $ENV_FILE"
fi

cat <<FIN

Jeton de lecture des retours ($ETAT) :

    $JETON

À ranger dans les secrets de l'environnement cloud de Claude, sous le nom :
    DIKTAE_RETOURS_TOKEN
(ne pas le coller dans une conversation). Puis, si ce n'est pas déjà fait,
mettre le proxy à jour pour qu'il relise son .env :
    bash server/keyproxy/rpi/mettre-a-jour.sh --ssh admin@diktae-proxy.local
FIN
