"""Micro choisi par le praticien pour enregistrer — data/micro.json.

L'enregistreur prenait toujours le micro par défaut du système, sans le montrer :
quand Windows bascule sur un autre périphérique (casque, webcam, écran), la
consultation s'enregistre en silence (retour n°9 de Nico). Le praticien choisit
désormais son micro dans la page ; on retient son NOM (« Microphone (Realtek) »),
côté serveur : les identifiants de périphérique du navigateur changent d'une
session à l'autre dans la fenêtre native, et son stockage local n'y est pas gardé.
Aucune donnée patient ici.
"""
from __future__ import annotations

import json
import os

from .config import DATA_DIR, ensure_dirs

MICRO_FILE = DATA_DIR / "micro.json"
_MAX = 200


def load() -> str:
    """Nom du micro retenu, ou "" (micro par défaut du système). Tolérant."""
    try:
        data = json.loads(MICRO_FILE.read_text(encoding="utf-8"))
        label = data.get("label") if isinstance(data, dict) else ""
        return label.strip()[:_MAX] if isinstance(label, str) else ""
    except (OSError, ValueError):
        return ""


def save(label: str) -> str:
    """Retient le micro choisi ("" = revenir au micro par défaut)."""
    label = " ".join(str(label or "").split())[:_MAX]
    ensure_dirs()
    if not label:
        MICRO_FILE.unlink(missing_ok=True)
        return ""
    tmp = MICRO_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps({"label": label}, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, MICRO_FILE)
    return label
