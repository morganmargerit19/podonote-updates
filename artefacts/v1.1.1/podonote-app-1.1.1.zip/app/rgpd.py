"""Fonctions RGPD : export (JSON / PDF) et suppression définitive d'un dossier."""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any

from . import bilan
from . import clinical
from . import pdffont as _pdffont
from . import profile as profile_mod
from . import repository as repo
from .utils import date_fr

logger = logging.getLogger("podonote.rgpd")


def build_patient_export(patient_id: int) -> dict[str, Any]:
    """Construit le dossier complet d'un patient (patient + consultations + fiches)."""
    patient = repo.get_patient(patient_id)
    if not patient:
        raise ValueError("Patient introuvable.")
    consultations = repo.list_consultations(patient_id)
    return {
        "export_genere_le": datetime.now().isoformat(timespec="seconds"),
        "patient": patient,
        "consultations": consultations,
    }


def export_json(patient_id: int) -> bytes:
    data = build_patient_export(patient_id)
    # Minimisation : le chemin disque de l'audio n'a pas à figurer dans l'export.
    for c in data.get("consultations", []):
        c.pop("audio_path", None)
    return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")


# --------------------------------------------------------------------------- #
# Export PDF — charte graphique alignée sur l'app (retour Nico 2026-06-11 :
# la fiche doit être lisible et remettable à un patient / un confrère).
# --------------------------------------------------------------------------- #
# Caractères Unicode fréquents ABSENTS du latin-1 (police PDF de base) -> équivalents.
_TYPO = {
    "’": "'", "‘": "'", "“": '"', "”": '"',
    "–": "-", "—": "-", "…": "...", " ": " ",
    "→": "->", "•": "-", "œ": "oe", "Œ": "OE",
    "æ": "ae", "Æ": "AE", "€": "EUR", "²": "2", "✓": "v",
    "±": "+/-",
}

# Palette de l'app (app.css) transposée au papier.
_INK = (28, 24, 19)            # charbon (texte)
_MUTED = (122, 112, 100)       # texte secondaire
_ACCENT = (172, 122, 82)       # laiton (filets, titres de section)
_SECT_BG = (247, 244, 240)     # fond des bandeaux de section
_TLDR_BG = (232, 244, 237)     # cadre vert du résumé
_TLDR_INK = (21, 106, 68)


def _typo(txt: str) -> str:
    for k, v in _TYPO.items():
        txt = txt.replace(k, v)
    return txt


def _safe(txt: Any) -> str:
    s = str(txt or "")
    # Police Unicode embarquée : on garde la typographie d'origine ; sinon repli
    # translittération + latin-1 (police core fpdf2).
    return s if _pdffont.UNICODE else _typo(s).encode("latin-1", "replace").decode("latin-1")


def _pdf_text(pdf, txt: str, h: float = 6) -> None:
    """Écrit du texte multi-ligne en gérant l'encodage latin-1 de fpdf2 core."""
    # new_x=LMARGIN + new_y=NEXT : chaque bloc repart à la marge gauche, ligne suivante.
    pdf.multi_cell(0, h, _safe(txt), new_x="LMARGIN", new_y="NEXT")


def _kv(pdf, label: str, value: str) -> None:
    """Ligne « Libellé : valeur » (libellé en gras), avec retour à la ligne géré."""
    pdf.set_x(pdf.l_margin + 2)
    pdf.set_text_color(*_INK)
    pdf.set_font(_pdffont.FAMILY,"B", 9.5)
    pdf.write(5.5, _safe(label) + " : ")
    pdf.set_font(_pdffont.FAMILY,"", 9.5)
    pdf.write(5.5, _safe(value))
    pdf.ln(5.5)


def _body(pdf, txt: str) -> None:
    pdf.set_x(pdf.l_margin + 2)
    pdf.set_text_color(*_INK)
    pdf.set_font(_pdffont.FAMILY,"", 9.5)
    _pdf_text(pdf, txt, h=5.5)


def _section_title(pdf, title: str) -> None:
    """Bandeau de section : fond léger + filet d'accent (comme les blocs de l'app)."""
    pdf.ln(2.5)
    if pdf.get_y() > pdf.h - 32:        # évite un titre orphelin en bas de page
        pdf.add_page()
    y = pdf.get_y()
    width = pdf.w - pdf.l_margin - pdf.r_margin
    pdf.set_fill_color(*_SECT_BG)
    pdf.rect(pdf.l_margin, y, width, 7.5, "F")
    pdf.set_fill_color(*_ACCENT)
    pdf.rect(pdf.l_margin, y, 1.6, 7.5, "F")
    pdf.set_xy(pdf.l_margin + 4, y + 1.1)
    pdf.set_font(_pdffont.FAMILY,"B", 10.5)
    pdf.set_text_color(*_INK)
    pdf.cell(0, 5.3, _safe(title), new_x="LMARGIN", new_y="NEXT")
    pdf.set_y(y + 9.5)


def _sub(pdf, label: str) -> None:
    """Sous-titre d'examen (PIED / GENOU / BASSIN / DOS)."""
    pdf.ln(1)
    pdf.set_x(pdf.l_margin + 2)
    pdf.set_font(_pdffont.FAMILY,"B", 8.7)
    pdf.set_text_color(*_ACCENT)
    _pdf_text(pdf, label.upper(), h=5)
    pdf.set_text_color(*_INK)


def _tldr_box(pdf, text: str) -> None:
    """Résumé en cadre vert, comme dans l'app."""
    pdf.set_fill_color(*_TLDR_BG)
    pdf.set_text_color(*_TLDR_INK)
    pdf.set_font(_pdffont.FAMILY,"B", 10.5)
    pdf.multi_cell(0, 7.5, _safe("  " + text), fill=True,
                   new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(*_INK)
    pdf.ln(1.5)


def _civilite(sexe: Any) -> str:
    s = (str(sexe or "")).strip().upper()
    return "Mr" if s in ("H", "M") else ("Mme" if s == "F" else "")


def _age_str(date_naissance: Any) -> str:
    try:
        from datetime import date as _d
        y, m, dd = (int(x) for x in str(date_naissance)[:10].split("-"))
        t = _d.today()
        return f" ({t.year - y - ((t.month, t.day) < (m, dd))} ans)"
    except (ValueError, TypeError):
        return ""


def _pdf_entete(pdf, header: dict[str, Any], titre_doc: str, sous_titre: str) -> None:
    """En-tête prescripteur (même formalisme que l'ordonnance) + titre du document."""
    top = pdf.get_y()
    # Titre du document, à droite.
    pdf.set_xy(105, top)
    pdf.set_font(_pdffont.FAMILY,"B", 14)
    pdf.set_text_color(*_ACCENT)
    pdf.cell(0, 7, _safe(titre_doc), align="R", new_x="LMARGIN", new_y="NEXT")
    pdf.set_xy(105, top + 8)
    pdf.set_font(_pdffont.FAMILY,"", 9.5)
    pdf.set_text_color(*_MUTED)
    pdf.cell(0, 5, _safe(sous_titre), align="R")
    # Bloc praticien, à gauche.
    pdf.set_xy(pdf.l_margin, top)
    pdf.set_text_color(*_INK)
    pdf.set_font(_pdffont.FAMILY,"B", 11.5)
    pdf.cell(100, 6, _safe(header.get("nom", "")), new_x="LMARGIN", new_y="NEXT")
    if header.get("titre"):
        pdf.set_font(_pdffont.FAMILY,"I", 9.5)
        pdf.cell(100, 5, _safe(header["titre"]), new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(_pdffont.FAMILY,"", 9)
    pdf.set_text_color(*_MUTED)
    for line in (header.get("adresse") or "").splitlines():
        if line.strip():
            pdf.cell(100, 4.5, _safe(line), new_x="LMARGIN", new_y="NEXT")
    if header.get("telephone"):
        pdf.cell(100, 4.5, _safe(header["telephone"]), new_x="LMARGIN", new_y="NEXT")
    ids = " · ".join(x for x in (
        f"N° AM : {header['num_am']}" if header.get("num_am") else "",
        f"RPPS : {header['rpps']}" if header.get("rpps") else "",
    ) if x)
    if ids:
        pdf.cell(100, 4.5, _safe(ids), new_x="LMARGIN", new_y="NEXT")
    # Filet de séparation.
    y = max(pdf.get_y(), top + 15) + 2
    pdf.set_draw_color(*_ACCENT)
    pdf.set_line_width(0.5)
    pdf.line(pdf.l_margin, y, pdf.w - pdf.r_margin, y)
    pdf.set_y(y + 4)
    pdf.set_text_color(*_INK)


def _pdf_signature(pdf, header: dict[str, Any]) -> None:
    """Bloc signature en bas de fiche (image du profil si fournie)."""
    if pdf.get_y() > pdf.h - 50:
        pdf.add_page()
    pdf.ln(6)
    pdf.set_font(_pdffont.FAMILY,"", 10)
    pdf.set_text_color(*_INK)
    pdf.cell(0, 6, _safe("Le praticien,"), align="R", new_x="LMARGIN", new_y="NEXT")
    sig = profile_mod.signature_file(header)
    if sig:
        try:
            pdf.image(str(sig), x=pdf.w - pdf.r_margin - 55, w=55)
        except Exception:
            pass  # une signature illisible ne doit jamais bloquer l'export


def _pdf_medical_flags(pdf, patient: dict[str, Any]) -> None:
    """Affiche le terrain médical (diabète, AOMI, neuropathie…) — contre-indications
    cruciales pour un soin de pédicurie."""
    flags = clinical.flags_detail(patient.get("medical_flags") or [])
    if not flags:
        return
    high = [f["label"] for f in flags if f.get("severity") == "high"]
    other = [f["label"] for f in flags if f.get("severity") != "high"]
    pdf.ln(1)
    pdf.set_font(_pdffont.FAMILY,"B", 10)
    label = "Terrain medical (vigilance) : " if high else "Terrain medical : "
    _pdf_text(pdf, label + ", ".join(high + other))
    pdf.set_font(_pdffont.FAMILY,"", 10)


def export_pdf(patient_id: int) -> bytes:
    """Dossier patient complet (export RGPD) : en-tête patient + toutes les fiches."""
    from fpdf import FPDF

    data = build_patient_export(patient_id)
    patient = data["patient"]

    pdf = FPDF()
    _pdffont.setup(pdf)  # police Unicode embarquée (repli Helvetica si absente)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    pdf.set_font(_pdffont.FAMILY,"B", 18)
    pdf.set_text_color(*_INK)
    _pdf_text(pdf, f"Dossier patient — {patient['prenom']} {patient['nom']}")
    pdf.ln(2)
    pdf.set_font(_pdffont.FAMILY,"", 10)
    if patient.get("date_naissance"):
        _pdf_text(pdf, f"Naissance : {date_fr(patient['date_naissance'])}"
                       f"{_age_str(patient['date_naissance'])}")
    _pdf_text(pdf, f"Dossier créé le : {date_fr(patient.get('created_at', ''))}")
    _pdf_text(pdf, f"Export généré le : {date_fr(data['export_genere_le'])}")
    if patient.get("notes"):
        pdf.ln(1)
        _pdf_text(pdf, f"Notes : {patient['notes']}")
    _pdf_medical_flags(pdf, patient)
    pdf.ln(4)

    for c in data["consultations"]:
        _consultation_heading(pdf, c)
        _consultation_block(pdf, c)
        pdf.ln(4)

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)


# Sections sélectionnables pour le PDF de la fiche (compte rendu). Clé technique
# + libellé affiché. L'ordre est celui du rendu. Sert à la fois aux cases à cocher
# de l'UI et au filtrage côté serveur — une seule source de vérité.
COMPTE_RENDU_SECTIONS: list[tuple[str, str]] = [
    ("tldr", "Résumé (l'essentiel)"),
    ("anamnese", "Anamnèse"),
    ("decharge", "Examen en décharge"),
    ("statique", "Examen en charge — statique"),
    ("dynamique", "Examen en charge — dynamique"),
    ("conclusion", "Conclusion"),
    ("reflexions_ia", "Réflexions IA"),
    ("plan_semelles", "Plan d'appareillage des semelles"),
    ("evolution", "Évolution depuis la dernière visite"),
]


def export_consultation_pdf(consultation_id: int, header: dict[str, Any] | None = None,
                            sections: set[str] | None = None) -> bytes:
    """PDF d'une fiche de consultation : en-tête prescripteur (comme l'ordonnance),
    identité patient, bilan structuré façon app, signature.

    `sections` (clés de COMPTE_RENDU_SECTIONS) : si fourni, seules ces sections
    sont rendues — pour transmettre un compte rendu allégé à un médecin. `None`
    = fiche complète (comportement par défaut, rétrocompatible)."""
    from fpdf import FPDF

    c = repo.get_consultation(consultation_id)
    if not c:
        raise ValueError("Consultation introuvable.")
    # Patient possiblement absent (dossier supprimé, incohérence référentielle) :
    # on génère quand même un PDF lisible plutôt que de planter sur un NoneType.
    patient = repo.get_patient(c["patient_id"]) or {}

    pdf = FPDF()
    _pdffont.setup(pdf)  # police Unicode embarquée (repli Helvetica si absente)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    date_c = date_fr(c.get("date", ""))
    heure = (c.get("date") or "")[11:16]
    lieu = "à domicile" if c.get("source") == "domicile" else "au cabinet"
    if header:
        _pdf_entete(pdf, header, "BILAN PODOLOGIQUE",
                    f"Consultation du {date_c}{' à ' + heure if heure else ''} ({lieu})")

    # Identité patient.
    civ = _civilite(patient.get("sexe"))
    pdf.set_font(_pdffont.FAMILY,"B", 13)
    pdf.set_text_color(*_INK)
    _pdf_text(pdf, f"{civ + ' ' if civ else ''}{patient.get('prenom', '')} {patient.get('nom', '')}".strip())
    pdf.set_font(_pdffont.FAMILY,"", 9.5)
    pdf.set_text_color(*_MUTED)
    infos = []
    if patient.get("date_naissance"):
        infos.append(f"Né(e) le {date_fr(patient['date_naissance'])}"
                     f"{_age_str(patient['date_naissance'])}")
    if not header:
        infos.append(f"Consultation du {date_c} ({lieu})")
    if infos:
        _pdf_text(pdf, " · ".join(infos), h=5)
    pdf.set_text_color(*_INK)
    _pdf_medical_flags(pdf, patient)
    pdf.ln(2)

    _consultation_block(pdf, c, sections)
    if header:
        _pdf_signature(pdf, header)

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)


# --------------------------------------------------------------------------- #
# PDF de la fiche de SOIN (pédicurie) — même charte que le compte rendu.
# --------------------------------------------------------------------------- #
def export_soin_pdf(consultation_id: int, header: dict[str, Any] | None = None) -> bytes:
    """PDF d'une fiche de soin : en-tête prescripteur, identité patient, actes
    réalisés, état des pieds, bilan de gradation diabétique, conseils, suivi."""
    from fpdf import FPDF

    c = repo.get_consultation(consultation_id)
    if not c:
        raise ValueError("Consultation introuvable.")
    patient = repo.get_patient(c["patient_id"]) or {}

    pdf = FPDF()
    _pdffont.setup(pdf)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    date_c = date_fr(c.get("date", ""))
    heure = (c.get("date") or "")[11:16]
    lieu = "à domicile" if c.get("source") == "domicile" else "au cabinet"
    if header:
        _pdf_entete(pdf, header, "FICHE DE SOIN",
                    f"Soin du {date_c}{' à ' + heure if heure else ''} ({lieu})")

    civ = _civilite(patient.get("sexe"))
    pdf.set_font(_pdffont.FAMILY, "B", 13)
    pdf.set_text_color(*_INK)
    _pdf_text(pdf, f"{civ + ' ' if civ else ''}{patient.get('prenom', '')} {patient.get('nom', '')}".strip())
    pdf.set_font(_pdffont.FAMILY, "", 9.5)
    pdf.set_text_color(*_MUTED)
    infos = []
    if patient.get("date_naissance"):
        infos.append(f"Né(e) le {date_fr(patient['date_naissance'])}"
                     f"{_age_str(patient['date_naissance'])}")
    if not header:
        infos.append(f"Soin du {date_c} ({lieu})")
    if infos:
        _pdf_text(pdf, " · ".join(infos), h=5)
    pdf.set_text_color(*_INK)
    _pdf_medical_flags(pdf, patient)
    pdf.ln(2)

    _soin_block(pdf, c)
    if header:
        _pdf_signature(pdf, header)

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)


def _soin_block(pdf, c: dict[str, Any]) -> None:
    """Corps de la fiche de soin (sections rendues seulement si renseignées)."""
    from . import soin as _soin

    recap = c.get("recap") or {}
    if recap.get("tl_dr"):
        _tldr_box(pdf, recap["tl_dr"])
    if recap.get("motif"):
        _section_title(pdf, "Motif")
        _body(pdf, recap["motif"])

    actes = recap.get("actes") or []
    if actes:
        _section_title(pdf, "Actes de soin réalisés")
        for a in actes:
            line = "- " + _soin.acte_resume(a)
            if a.get("note"):
                line += f" ({a['note']})"
            _body(pdf, line)

    ep = recap.get("etat_pieds") or {}
    if ep.get("cutane") or ep.get("ungueal"):
        _section_title(pdf, "État des pieds")
        if ep.get("cutane"):
            _kv(pdf, "Cutané", ep["cutane"])
        if ep.get("ungueal"):
            _kv(pdf, "Unguéal", ep["ungueal"])

    di = recap.get("diabete") or {}
    if di.get("concerne"):
        _section_title(pdf, "Bilan de gradation — pied diabétique")
        grade = di.get("grade")
        if grade is not None:
            _kv(pdf, "Grade de risque podologique",
                _soin.GRADE_LIBELLE.get(grade, str(grade)))
            seances = _soin.seances_remboursables(grade, bool(di.get("plaie_en_cours")))
            if seances:
                _kv(pdf, "Séances de prévention prises en charge / an", str(seances))
        else:
            _kv(pdf, "Grade de risque podologique",
                "à compléter (critères manquants)")

        def _on(v):
            return "oui" if v is True else ("non" if v is False else "non précisé")

        _kv(pdf, "Neuropathie (monofilament 10 g)", _on(di.get("neuropathie")))
        _kv(pdf, "Artériopathie (AOMI)", _on(di.get("aomi")))
        _kv(pdf, "Déformation du pied", _on(di.get("deformation")))
        _kv(pdf, "Antécédent ulcération > 4 sem. / amputation",
            _on(di.get("antecedent_ulcere_amputation")))
        if di.get("plaie_en_cours"):
            _kv(pdf, "Plaie du pied diabétique en cours", "oui")
        if di.get("note"):
            _body(pdf, di["note"])

    if recap.get("conseils"):
        _section_title(pdf, "Conseils / produits")
        _body(pdf, recap["conseils"])
    if recap.get("suivi"):
        _section_title(pdf, "Suivi")
        _body(pdf, recap["suivi"])

    refs = recap.get("reflexions_ia") or []
    if refs:
        _section_title(pdf, "Réflexions IA (pistes à vérifier)")
        for r in refs:
            txt = r.get("constat") or ""
            if r.get("piste"):
                txt += f" -> {r['piste']}"
            if r.get("statut"):
                txt += f" [{r['statut']}]"
            _body(pdf, "- " + txt)
            if r.get("details"):
                _body(pdf, "  " + r["details"])

    if recap.get("evolution_depuis_derniere_visite"):
        _section_title(pdf, "Évolution depuis la dernière visite")
        _body(pdf, recap["evolution_depuis_derniere_visite"])


# --------------------------------------------------------------------------- #
# PDF « fiche d'exercices » à remettre au patient (banque d'exercices).
# --------------------------------------------------------------------------- #
def export_exercices_pdf(patient_id: int, header: dict[str, Any] | None,
                         keys: list[str]) -> bytes:
    """PDF regroupant les exercices cochés (titre + description), à imprimer ou
    enregistrer pour le patient."""
    from datetime import date as _date

    from fpdf import FPDF

    from . import exercices as _ex

    patient = repo.get_patient(patient_id) or {}
    items = _ex.selected(keys)

    pdf = FPDF()
    _pdffont.setup(pdf)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    if header:
        _pdf_entete(pdf, header, "FICHE D'EXERCICES",
                    f"Programme remis le {date_fr(str(_date.today()))}")
    # Bandeau titre proéminent (retour Nico : mettre « FICHE D'EXERCICES » plus en
    # avant). Pavé laiton pleine largeur, texte crème centré.
    pdf.ln(1)
    _x0, _y0 = pdf.get_x(), pdf.get_y()
    pdf.set_fill_color(*_ACCENT)
    pdf.set_text_color(248, 244, 236)
    pdf.set_font(_pdffont.FAMILY, "B", 15)
    pdf.cell(0, 11, _safe("FICHE D'EXERCICES"), align="C", fill=True,
             new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(*_INK)
    pdf.ln(3)
    civ = _civilite(patient.get("sexe"))
    pdf.set_font(_pdffont.FAMILY, "B", 13)
    pdf.set_text_color(*_INK)
    _pdf_text(pdf, f"{civ + ' ' if civ else ''}{patient.get('prenom', '')} "
                   f"{patient.get('nom', '')}".strip())
    pdf.set_font(_pdffont.FAMILY, "", 9.5)
    pdf.set_text_color(*_MUTED)
    _pdf_text(pdf, "À réaliser régulièrement. En cas de douleur inhabituelle, "
                   "arrêtez l'exercice et parlez-en à votre praticien.", h=5)
    pdf.set_text_color(*_INK)
    pdf.ln(2)

    if not items:
        _body(pdf, "Aucun exercice sélectionné.")
    for e in items:
        _section_title(pdf, e["titre"])
        _body(pdf, e["description"])

    if header:
        _pdf_signature(pdf, header)

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)


# --------------------------------------------------------------------------- #
# PDF « courrier » à un correspondant (contact pluridisciplinaire).
# --------------------------------------------------------------------------- #
def export_courrier_pdf(patient_id: int, header: dict[str, Any] | None,
                        correspondant: dict[str, Any] | None,
                        visite_ids: list[int], ordo_ids: list[int],
                        photo_ids: list[int], message: str = "",
                        detail_complet: bool = False) -> bytes:
    """Courrier adressé à un correspondant, synthétisant les visites/ordonnances/
    photos choisies dans le dossier patient."""
    from datetime import date as _date
    from io import BytesIO

    from fpdf import FPDF

    from . import soin as _soin

    patient = repo.get_patient(patient_id) or {}
    consultations = {c["id"]: c for c in repo.list_consultations(patient_id)}
    ordonnances = {o["id"]: o for o in repo.list_ordonnances(patient_id)}

    pdf = FPDF()
    _pdffont.setup(pdf)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    if header:
        _pdf_entete(pdf, header, "COURRIER", f"Le {date_fr(str(_date.today()))}")

    if correspondant:
        pdf.set_font(_pdffont.FAMILY, "B", 10.5)
        pdf.set_text_color(*_INK)
        _pdf_text(pdf, f"À l'attention de {correspondant.get('nom', '')}", h=5.5)
        pdf.set_font(_pdffont.FAMILY, "", 9.5)
        pdf.set_text_color(*_MUTED)
        dinfos = [repo.CORRESPONDANT_TYPES.get(correspondant.get("type"), "")]
        if correspondant.get("adresse"):
            dinfos.append(correspondant["adresse"])
        if correspondant.get("email"):
            dinfos.append(correspondant["email"])
        _pdf_text(pdf, " · ".join(x for x in dinfos if x), h=5)
        pdf.set_text_color(*_INK)
    pdf.ln(2)

    civ = _civilite(patient.get("sexe"))
    nom_pat = f"{civ + ' ' if civ else ''}{patient.get('prenom', '')} " \
              f"{patient.get('nom', '')}".strip()
    _section_title(pdf, f"Concernant {nom_pat}")
    if patient.get("date_naissance"):
        _kv(pdf, "Né(e) le",
            f"{date_fr(patient['date_naissance'])}{_age_str(patient['date_naissance'])}")
    _pdf_medical_flags(pdf, patient)
    if message:
        pdf.ln(1)
        _body(pdf, message)

    sel_visites = [consultations[i] for i in visite_ids if i in consultations]
    if sel_visites:
        _section_title(pdf, "Consultations")
        for c in sel_visites:
            recap = c.get("recap") or {}
            _sub(pdf, date_fr(c.get("date", "")))
            if recap.get("tl_dr"):
                _body(pdf, recap["tl_dr"])
            # Retour Nico : inclure PLUS que la conclusion (motif, synthèse,
            # conseils) quand le praticien coche « détail complet ».
            if detail_complet:
                _an = recap.get("anamnese") or {}
                _motif = _an.get("souci_actuel") or _an.get("motif") or recap.get("motif")
                if _motif:
                    _body(pdf, "Motif / plainte : " + str(_motif))
                _note = (recap.get("synthese") or {}).get("note")
                if _note:
                    _body(pdf, "Synthèse : " + str(_note))
                if recap.get("conseils"):
                    _body(pdf, "Conseils : " + str(recap["conseils"]))
            if c.get("bilan_type") == "soin":
                for a in (recap.get("actes") or []):
                    _body(pdf, "- " + _soin.acte_resume(a))
                di = recap.get("diabete") or {}
                if di.get("concerne") and di.get("grade") is not None:
                    _body(pdf, "Gradation pied diabétique : "
                          + _soin.GRADE_LIBELLE.get(di["grade"], str(di["grade"])))
            else:
                concl = recap.get("conclusion") or {}
                if concl.get("synthese"):
                    _body(pdf, "Conclusion : " + concl["synthese"])
                if concl.get("suivi"):
                    _body(pdf, "Suivi : " + concl["suivi"])

    sel_ordos = [ordonnances[i] for i in ordo_ids if i in ordonnances]
    if sel_ordos:
        _section_title(pdf, "Ordonnances")
        for o in sel_ordos:
            _sub(pdf, date_fr(o.get("date", "")))
            for ligne in (o.get("lignes") or []):
                _body(pdf, "- " + str(ligne))

    if photo_ids:
        shown = False
        for pid in photo_ids:
            p = repo.get_photo(pid)
            # N'inclure que des photos appartenant à ce patient (via sa consultation).
            if not p or p.get("consultation_id") not in consultations:
                continue
            if not shown:
                _section_title(pdf, "Photos")
                shown = True
            try:
                if pdf.get_y() > pdf.h - 75:
                    pdf.add_page()
                pdf.image(BytesIO(p["data"]), w=80)
                pdf.ln(3)
            except Exception:
                continue

    if header:
        _pdf_signature(pdf, header)

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)


# --------------------------------------------------------------------------- #
# PDF « bilan préférence motrice » (synthèse patient — méthode Volodalen).
# --------------------------------------------------------------------------- #
def export_volodalen_pdf(consultation_id: int, header: dict[str, Any] | None = None) -> bytes:
    """Fiche synthèse préférence motrice à remettre au patient : synthèse en tête,
    cadran, exercices, anamnèse, pratique sportive."""
    from fpdf import FPDF

    from . import volodalen as _v

    c = repo.get_consultation(consultation_id)
    if not c:
        raise ValueError("Consultation introuvable.")
    patient = repo.get_patient(c["patient_id"]) or {}
    recap = c.get("recap") or {}
    fe = recap.get("flexion_extension") or {}
    an = recap.get("anamnese") or {}
    ps = recap.get("pratique_sportive") or {}

    pdf = FPDF()
    _pdffont.setup(pdf)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    date_c = date_fr(c.get("date", ""))
    if header:
        _pdf_entete(pdf, header, "PRÉFÉRENCE MOTRICE", f"Bilan du {date_c}")

    civ = _civilite(patient.get("sexe"))
    pdf.set_font(_pdffont.FAMILY, "B", 13)
    pdf.set_text_color(*_INK)
    _pdf_text(pdf, f"{civ + ' ' if civ else ''}{patient.get('prenom', '')} "
                   f"{patient.get('nom', '')}".strip())
    pdf.set_font(_pdffont.FAMILY, "", 9.5)
    pdf.set_text_color(*_MUTED)
    infos = []
    if an.get("poids") or an.get("taille"):
        infos.append(f"Poids/taille : {an.get('poids') or '?'} / {an.get('taille') or '?'}")
    if not header:
        infos.append(f"Bilan du {date_c}")
    if infos:
        _pdf_text(pdf, " · ".join(infos), h=5)
    pdf.set_text_color(*_INK)
    pdf.ln(2)

    if recap.get("tl_dr"):
        _tldr_box(pdf, recap["tl_dr"])

    _section_title(pdf, "Synthèse")
    sc = _v.synthese_checks(recap)
    _kv(pdf, "Mobilité classique", _v.label(_v.PREFERENCE, sc.get("classique")) or "-")
    _kv(pdf, "Mobilité excessive",
        {"hyper_mobile": "Hyper-mobile", "rigide": "Rigide"}.get(sc.get("excessive"), "-"))
    _kv(pdf, "Chaîne de respiration", _v.label(_v.CHAINE, fe.get("chaine")) or "-")
    assoc = _v.association_probable(fe.get("preference"),
                                    fe.get("chaine"))
    aval = _v.label(_v.ASSOCIATION, recap.get("association")) or "-"
    if assoc:
        aval += (f" (tendance {_v.label(_v.ASSOCIATION, assoc['tendance']).lower()} "
                 f"~{assoc['pourcentage']}%)")
    _kv(pdf, "Association / dissociation", aval)
    _kv(pdf, "Épaule motrice",
        _v.label(_v.COTE, (recap.get("complementaire") or {}).get("epaule_motrice")) or "-")
    cad = _v.cadran_points(fe.get("preference"),
                           (recap.get("mouvement") or {}).get("jambe_extension"))
    if cad.get("point1"):
        _kv(pdf, "Cadran du mouvement",
            f"Point 1 : {_v.CADRAN_POS.get(cad['point1'], '')} · "
            f"Point 4 : {_v.CADRAN_POS.get(cad['point4'], '')}")

    exos = recap.get("exercices") or []
    if exos:
        _section_title(pdf, "Exercices prioritaires")
        for i, k in enumerate(exos, 1):
            _body(pdf, f"{i}. {_v.EXERCICES_LABELS.get(k, k)}")

    if any(an.get(x) for x in ("motif", "pathologies_chroniques", "operation_membre_inf",
                               "operation_membre_sup_dos", "activite_professionnelle")) \
            or any((an.get("plainte") or {}).values()):
        _section_title(pdf, "Anamnèse")
        if an.get("motif"):
            _body(pdf, an["motif"])
        pl = an.get("plainte") or {}
        for lbl, key in (("Localisation", "localisation"), ("Depuis", "depuis"),
                         ("Moment", "moment"), ("Modif. habitudes", "modification_habitudes")):
            if pl.get(key):
                _kv(pdf, lbl, pl[key])
        for lbl, key in (("Pathologies chroniques", "pathologies_chroniques"),
                         ("Opération MI", "operation_membre_inf"),
                         ("Opération MS/dos", "operation_membre_sup_dos"),
                         ("Activité professionnelle", "activite_professionnelle")):
            if an.get(key):
                _kv(pdf, lbl, an[key])

    if any(ps.get(x) for x in ("sports", "niveau", "intensite", "objectifs",
                               "blessures_anterieures")):
        _section_title(pdf, "Pratique sportive")
        if ps.get("sports"):
            _kv(pdf, "Sport(s)", ps["sports"])
        if ps.get("niveau"):
            _kv(pdf, "Niveau", _v.label(_v.NIVEAU, ps["niveau"]))
        if ps.get("intensite"):
            _kv(pdf, "Intensité", ps["intensite"])
        if ps.get("objectifs"):
            _kv(pdf, "Objectifs", ps["objectifs"])
        if ps.get("blessures_anterieures"):
            _kv(pdf, "Blessures antérieures", ps["blessures_anterieures"])

    if recap.get("synthese", {}).get("note"):
        _section_title(pdf, "Note")
        _body(pdf, recap["synthese"]["note"])

    if header:
        _pdf_signature(pdf, header)

    out = pdf.output()
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else bytes(out)


# --------------------------------------------------------------------------- #
# Rendu d'une fiche-bilan (partagé : fiche seule + dossier complet)
# --------------------------------------------------------------------------- #
def _lr_text(mapping: dict, d: Any) -> str:
    """« G: … | D: … » pour un champ latéralisé (vide si rien)."""
    d = d or {}
    g = bilan.label(mapping, d.get("gauche"))
    dr = bilan.label(mapping, d.get("droite"))
    if not g and not dr:
        return ""
    return f"G : {g or '-'}   |   D : {dr or '-'}"


def _lr_multi_text(mapping: dict, d: Any) -> str:
    d = d or {}
    g = bilan.label_multi(mapping, d.get("gauche"))
    dr = bilan.label_multi(mapping, d.get("droite"))
    if not g and not dr:
        return ""
    return f"G : {g or '-'}   |   D : {dr or '-'}"


def _tests_rows(tests_def: list, data: Any) -> list[tuple[str, str]]:
    """Lignes (libellé, résultat G/D) des tests cliniques renseignés."""
    data = data if isinstance(data, dict) else {}
    rows = []
    for key, lbl, _objet, opts in tests_def:
        t = _lr_text(opts, data.get(key))
        if t:
            rows.append((lbl, t))
    return rows


def _consultation_heading(pdf, c: dict[str, Any]) -> None:
    """Titre d'une consultation dans l'export du dossier complet."""
    if pdf.get_y() > pdf.h - 40:
        pdf.add_page()
    heure = (c.get("date") or "")[11:16]
    lieu = "domicile" if c.get("source") == "domicile" else "cabinet"
    pdf.set_font(_pdffont.FAMILY,"B", 12.5)
    pdf.set_text_color(*_INK)
    _pdf_text(pdf, f"Consultation du {date_fr(c.get('date', ''))}"
                   f"{' à ' + heure if heure else ''}  ({lieu})")


def _statique_rows(st: dict[str, Any] | None) -> tuple[list, list, list, list]:
    """(pied, genou, bassin, dos) — lignes renseignées de l'examen statique.
    Source unique partagée par le rendu PDF et sections_present()."""
    st = st or {}
    dos = st.get("dos") or {}
    pied_rows = []
    for lbl, mp, key in (
        ("Empreinte", bilan.TYPE_EMPREINTE, "type_empreinte"),
        ("Arrière-pied", bilan.VALGUS_VARUS, "arriere_pied"),
        ("Médio-pied", bilan.PRONATION_SUPINATION, "mediopied"),
        ("Avant-pied", bilan.PRONATION_SUPINATION, "avant_pied"),
    ):
        t = _lr_text(mp, st.get(key))
        if t:
            pied_rows.append((lbl, t))
    deform = _lr_multi_text(bilan.DEFORMATIONS_PIED, st.get("deformations"))
    if deform:
        pied_rows.append(("Déformations", deform))

    genou_rows = []
    posture_genou = _lr_multi_text(bilan.GENOU, st.get("genou"))
    if posture_genou:
        genou_rows.append(("Posture générale", posture_genou))
    genou_rows += _tests_rows(bilan.TESTS_GENOU, st.get("tests_genou"))

    bassin_rows = []
    pulsion = _lr_text(bilan.BASSIN_PULSION, st.get("bassin_pulsion"))
    if pulsion:
        bassin_rows.append(("Antépulsion / rétropulsion", pulsion))
    if st.get("bassin_version"):
        bassin_rows.append(("Version", bilan.label(bilan.BASSIN_VERSION, st["bassin_version"])))
    bassin_rows += _tests_rows(bilan.TESTS_BASSIN, st.get("tests_bassin"))

    dos_rows = []
    for lbl, key in (("Creux poplité", "creux_poplite"), ("EIPS", "eips"),
                     ("Pointe scapulaire", "pointe_scapulaire"),
                     ("Acromioclaviculaire", "acromioclaviculaire")):
        v = bilan.label(bilan.ASYMETRIE, dos.get(key))
        if v:
            dos_rows.append((lbl, v))
    td = st.get("tests_dos") or {}
    if td.get("adams"):
        dos_rows.append(("Test d'Adams", bilan.label(bilan.TEST_ADAMS, td["adams"])))
    dw = td.get("downing") or {}
    if dw.get("jambe_gauche_cm") or dw.get("jambe_droite_cm"):
        val = (f"Jambe G : {dw.get('jambe_gauche_cm') or '-'} cm   |   "
               f"Jambe D : {dw.get('jambe_droite_cm') or '-'} cm")
        concl = bilan.downing_conclusion(dw)
        if concl:
            val += f"  ->  {concl}"
        dos_rows.append(("Downing Test (ILMI)", val))
    fap = td.get("fil_a_plomb") or {}
    if fap.get("resultat"):
        val = bilan.label(bilan.FIL_A_PLOMB, fap["resultat"])
        if fap.get("cale_mm"):
            val += (f" · test de cale : {fap['cale_mm']} mm"
                    f" {bilan.label(bilan.CALE_COTE, fap.get('cale_cote'))}").rstrip()
        dos_rows.append(("Test du fil à plomb", val))
    return pied_rows, genou_rows, bassin_rows, dos_rows


def _dynamique_rows(dy: dict[str, Any] | None) -> list:
    """Lignes renseignées de l'examen dynamique (source unique)."""
    dy = dy or {}
    dyn_rows = []
    if dy.get("temps_du_pas"):
        dyn_rows.append(("Temps du pas", bilan.label(bilan.TEMPS_DU_PAS, dy["temps_du_pas"])))
    am = _lr_text(bilan.PRONATION_SUPINATION, dy.get("arriere_mediopied"))
    if am:
        dyn_rows.append(("Arrière/médio-pied", am))
    fick = _lr_text(bilan.ANGLE_FICK, dy.get("angle_de_fick"))
    if fick:
        dyn_rows.append(("Angle de Fick", fick))
    return dyn_rows


def sections_present(c: dict[str, Any]) -> set[str]:
    """Clés de COMPTE_RENDU_SECTIONS réellement renseignées dans cette fiche — soit
    exactement les sections qu'un export complet afficherait. Permet à l'UI de
    n'offrir que des sections existantes. Réutilise les mêmes prédicats / lignes
    que _consultation_block : aucune divergence possible (test de cohérence dédié)."""
    recap = c.get("recap") or {}
    an = recap.get("anamnese") or {}
    pl = an.get("plainte") or {}
    atcd = an.get("atcd") or {}
    hv = an.get("habitudes_vie") or {}
    ed = recap.get("examen_decharge") or {}
    bc = ed.get("bilan_cutane") or {}
    st = recap.get("statique") or {}
    cc = recap.get("conclusion") or {}
    ps = recap.get("plan_semelles") or {}
    present: set[str] = set()
    if recap.get("tl_dr"):
        present.add("tldr")
    if (an.get("souci_actuel") or any(pl.get(k) for k in pl)
            or atcd.get("pathologies_chroniques") or atcd.get("operations_membre_inf")
            or atcd.get("operations_dos") or atcd.get("blessures_repetition")
            or hv.get("activite_sportive") or hv.get("activite_professionnelle")
            or hv.get("actif_maison") or hv.get("type_chaussant")):
        present.add("anamnese")
    if (ed.get("douleur_localisation") or ed.get("douleur_intensite_sur_10") is not None
            or any(bc.get(k) for k, _ in bilan.BILAN_CUTANE_CHAMPS)
            or _lr_text(bilan.MOBILITE_CHEVILLE, ed.get("mobilite_cheville"))):
        present.add("decharge")
    if st.get("description_generale") or any(_statique_rows(st)):
        present.add("statique")
    if _dynamique_rows(recap.get("dynamique")):
        present.add("dynamique")
    if cc.get("synthese") or cc.get("suivi"):
        present.add("conclusion")
    if recap.get("reflexions_ia"):
        present.add("reflexions_ia")
    if any(ps.get(k) for k, _ in bilan.PLAN_SEMELLES_CHAMPS) or ps.get("notes"):
        present.add("plan_semelles")
    if recap.get("evolution_depuis_derniere_visite"):
        present.add("evolution")
    return present


def _consultation_block(pdf, c: dict[str, Any], sections: set[str] | None = None) -> None:
    # `sections` filtre les blocs rendus (cf. COMPTE_RENDU_SECTIONS) ; None = tout.
    def _inc(key: str) -> bool:
        return sections is None or key in sections

    # Numérotation séquentielle des sections RÉELLEMENT rendues : indispensable dès
    # qu'on filtre (sinon « 5 · Conclusion » apparaît seul), et corrige aussi le cas
    # historique où une section sans donnée laissait un trou dans la numérotation.
    _counter = {"n": 0}

    def _num_title(label: str) -> None:
        _counter["n"] += 1
        _section_title(pdf, f"{_counter['n']} · {label}")

    recap = c.get("recap") or {}
    an = recap.get("anamnese") or {}
    pl = an.get("plainte") or {}
    atcd = an.get("atcd") or {}
    hv = an.get("habitudes_vie") or {}
    ed = recap.get("examen_decharge") or {}
    st = recap.get("statique") or {}
    dy = recap.get("dynamique") or {}
    cc = recap.get("conclusion") or {}

    # Présence des sections : prédicat unique (cf. sections_present), pour que ce qui
    # est rendu == ce que l'UI propose à la sélection. _inc applique en plus le filtre.
    present = sections_present(c)

    pdf.set_font(_pdffont.FAMILY,"", 9.5)
    if "tldr" in present and _inc("tldr"):
        _tldr_box(pdf, recap["tl_dr"])

    # 1. Anamnèse -------------------------------------------------------------
    if "anamnese" in present and _inc("anamnese"):
        _num_title("Anamnèse")
        if an.get("souci_actuel"):
            _body(pdf, an["souci_actuel"])
        for lbl, key in (("Localisation", "localisation"), ("Depuis", "depuis"),
                         ("Moment / déclencheur", "moment"),
                         ("Modification des habitudes", "modification_habitudes")):
            if pl.get(key):
                _kv(pdf, lbl, pl[key])
        if atcd.get("pathologies_chroniques"):
            _kv(pdf, "Pathologies chroniques", ", ".join(atcd["pathologies_chroniques"]))
        for op in atcd.get("operations_membre_inf") or []:
            _kv(pdf, "Opération membre inf.", _op_text(op))
        for op in atcd.get("operations_dos") or []:
            _kv(pdf, "Opération du dos", _op_text(op))
        if atcd.get("blessures_repetition"):
            _kv(pdf, "Blessures à répétition", atcd["blessures_repetition"])
        if hv.get("activite_sportive"):
            _kv(pdf, "Activité sportive", hv["activite_sportive"])
        if hv.get("activite_professionnelle"):
            _kv(pdf, "Activité professionnelle", hv["activite_professionnelle"])
        if hv.get("actif_maison"):
            _kv(pdf, "Actif à la maison", hv["actif_maison"])
        if hv.get("type_chaussant"):
            _kv(pdf, "Chaussant", hv["type_chaussant"])

    # 2. Examen en décharge ---------------------------------------------------
    bc = ed.get("bilan_cutane") or {}
    if "decharge" in present and _inc("decharge"):
        _num_title("Examen en décharge")
        if ed.get("douleur_localisation") or ed.get("douleur_intensite_sur_10") is not None:
            inten = ed.get("douleur_intensite_sur_10")
            _kv(pdf, "Douleur", (ed.get("douleur_localisation") or "")
                + (f"  ({inten}/10)" if inten is not None else ""))
        mob = _lr_text(bilan.MOBILITE_CHEVILLE, ed.get("mobilite_cheville"))
        if mob:
            _kv(pdf, "Mobilité cheville", mob)
        if any(bc.get(k) for k, _ in bilan.BILAN_CUTANE_CHAMPS):
            _sub(pdf, "Bilan cutané")
            for key, lbl in bilan.BILAN_CUTANE_CHAMPS:
                if bc.get(key):
                    _kv(pdf, lbl, bc[key])

    # 3. Examen en charge (statique) ------------------------------------------
    pied_rows, genou_rows, bassin_rows, dos_rows = _statique_rows(st)
    if "statique" in present and _inc("statique"):
        _num_title("Examen en charge (statique)")
        if st.get("description_generale"):   # anciennes fiches uniquement
            _body(pdf, st["description_generale"])
        for sub_lbl, rows in (("Pied", pied_rows), ("Genou", genou_rows),
                              ("Bassin", bassin_rows), ("Dos", dos_rows)):
            if rows:
                _sub(pdf, sub_lbl)
                for lbl, val in rows:
                    _kv(pdf, lbl, val)

    # 4. Dynamique -------------------------------------------------------------
    dyn_rows = _dynamique_rows(dy)
    if "dynamique" in present and _inc("dynamique"):
        _num_title("Examen en charge (dynamique)")
        for lbl, val in dyn_rows:
            _kv(pdf, lbl, val)

    # 5. Conclusion --------------------------------------------------------------
    if "conclusion" in present and _inc("conclusion"):
        _num_title("Conclusion")
        if cc.get("synthese"):
            _body(pdf, cc["synthese"])
        if cc.get("suivi"):
            _kv(pdf, "Suivi / recommandations", cc["suivi"])

    # Réflexions IA --------------------------------------------------------------
    if "reflexions_ia" in present and _inc("reflexions_ia"):
        _section_title(pdf, "Réflexions IA — pistes à vérifier")
        for r in recap["reflexions_ia"]:
            _kv(pdf, "Constat", r.get("constat", ""))
            if r.get("piste"):
                _kv(pdf, "Piste", f"{r['piste']}  [{r.get('statut', 'à vérifier')}]")
            if r.get("details"):
                _body(pdf, r["details"])
        pdf.set_font(_pdffont.FAMILY,"I", 8.5)
        pdf.set_text_color(*_MUTED)
        _body(pdf, "L'IA ne pose aucun diagnostic : pistes à valider par le praticien.")
        pdf.set_text_color(*_INK)

    # 6. Plan d'appareillage des semelles -----------------------------------------
    ps = recap.get("plan_semelles") or {}
    sem = [(lbl, ps[key]) for key, lbl in bilan.PLAN_SEMELLES_CHAMPS if ps.get(key)]
    if "plan_semelles" in present and _inc("plan_semelles"):
        _num_title("Plan d'appareillage des semelles")
        for lbl, val in sem:
            _kv(pdf, lbl, val)
        if ps.get("notes"):
            _body(pdf, ps["notes"])

    # Évolution ---------------------------------------------------------------
    if "evolution" in present and _inc("evolution"):
        _section_title(pdf, "Évolution depuis la dernière visite")
        _body(pdf, recap["evolution_depuis_derniere_visite"])


def _op_text(op: dict[str, Any]) -> str:
    parts = [op.get("intervention", "")]
    if op.get("date"):
        parts.append(op["date"])
    if op.get("suivi_kine") is True:
        parts.append("suivi kiné")
    elif op.get("suivi_kine") is False:
        parts.append("sans kiné")
    if op.get("sequelles"):
        parts.append("séquelles : " + op["sequelles"])
    return " - ".join(p for p in parts if p)


def _remove_audio_file(path: Any) -> None:
    """Supprime un fichier audio du disque (droit à l'effacement RGPD). Tolérant."""
    if not path:
        return
    # Logs sans le chemin : le nom de fichier peut contenir l'identité du patient
    # et ces lignes finissent dans podonote.log puis le rapport de diagnostic.
    try:
        os.remove(path)
        logger.info("Audio supprimé (effacement RGPD).")
    except FileNotFoundError:
        pass
    except OSError as exc:
        logger.warning("Échec suppression audio (effacement RGPD) : %s",
                       exc.strerror or exc)


def _remove_export_dir(patient: dict[str, Any]) -> None:
    """Supprime le(s) dossier(s) Documents\\Diktae\\<patient> (PDF de bilans,
    ordonnances, exports). Sans cela, l'effacement RGPD laisserait des PDF
    nominatifs en clair sur le disque — et dans OneDrive si Documents y est
    redirigé.

    Robuste au RENOMMAGE du patient : on cible le dossier courant « Nom Prénom (#id) »,
    TOUT dossier portant le même suffixe « (#id) » (anciens noms après renommage),
    et le dossier hérité « Nom Prénom » sans suffixe (PDF générés avant cette version)."""
    import shutil

    from .utils import (patient_export_dir, patient_export_dir_name,
                        safe_folder, user_documents_dir)

    targets: set = set()
    try:
        targets.add(patient_export_dir(patient, create=False))
    except Exception:
        pass
    pid = patient.get("id", "")
    # Balaye le dossier courant (Documents\Diktae) ET l'ancien emplacement
    # PodoNote : si la migration d'un bloc a échoué (verrou), aucun PDF
    # nominatif ne doit échapper au droit à l'effacement.
    from .utils import export_root, LEGACY_EXPORT_DIR_NAME
    roots = [export_root(), user_documents_dir() / LEGACY_EXPORT_DIR_NAME]
    for root in roots:
        try:
            if pid != "" and root.is_dir():
                # Tout dossier d'un précédent nom du patient (suffixe « (#id) » stable).
                for d in root.glob(f"*(#{pid})"):
                    if d.is_dir():
                        targets.add(d)
        except OSError:
            pass
        # Dossier hérité sans suffixe id (ancienne convention).
        targets.add(root / safe_folder(
            f"{patient.get('nom', '')} {patient.get('prenom', '')}".strip(),
            f"patient-{pid}",
        ))

    removed = 0
    for d in targets:
        try:
            if d.is_dir():
                shutil.rmtree(d)
                removed += 1
        except OSError as exc:
            logger.warning("Échec suppression du dossier d'export PDF : %s",
                           exc.strerror or exc)
    if removed:
        logger.info("%d dossier(s) d'export PDF supprimé(s) (effacement RGPD).", removed)


def delete_patient_record(patient_id: int) -> None:
    """Suppression définitive d'un dossier (droit à l'effacement RGPD).

    Supprime AUSSI, AVANT le DELETE en base (sinon les chemins sont perdus par
    le CASCADE) : les fichiers audio encore sur disque, et le dossier d'export
    PDF du patient (Documents\\Diktae\\<Nom Prénom>)."""
    patient = repo.get_patient(patient_id)
    for c in repo.list_consultations(patient_id):
        _remove_audio_file(c.get("audio_path"))
    if patient:
        _remove_export_dir(patient)
    repo.delete_patient(patient_id)
    # Efface physiquement les pages libérées (secure_delete couvre les nouvelles
    # écritures ; VACUUM compacte et réécrit le fichier pour l'historique).
    try:
        repo.vacuum()
    except Exception:
        logger.warning("VACUUM post-effacement impossible (non bloquant).")


def delete_consultation_record(consultation_id: int) -> None:
    """Suppression définitive d'une consultation + son audio (droit à l'effacement)."""
    c = repo.get_consultation(consultation_id)
    if c:
        _remove_audio_file(c.get("audio_path"))
    repo.delete_consultation(consultation_id)
