"""Mac à puce Apple installé en mode Intel (Rosetta) : repasser en natif.

L'app Mac (`Diktae-Mac.zip`) range son Python DANS son bundle. Son lanceur,
un script bash, a pu être démarré sous Rosetta : il a alors installé le Python
INTEL, et toute la pile de transcription qui va avec (PyTorch 2.2, dernière
version Intel). Cette pile n'a jamais marché sur un Mac à puce Apple (Bryan,
M4 : « Numpy is not available », puis « GenerationMixin ») et Apple retire
Rosetta. Le remède durable est la pile NATIVE, celle validée sur un Mac M.

Ce module, appelé au démarrage (app/desktop.py) :
- recopie dans l'app le lanceur et l'installeur de la version installée — une
  OTA ne remplace que le code, pas le bundle ; c'est ainsi qu'un correctif du
  lanceur atteint les Mac déjà installés ;
- détecte un Python Intel sur une puce Apple, et, avec l'accord du praticien,
  met ce Python de côté puis rouvre l'app : son lanceur réinstalle alors le
  Python natif et les composants (20 à 40 min). Les données (`data/`) et
  réglages (`.env`) ne sont pas touchés.
"""
from __future__ import annotations

import logging
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from .config import BASE_DIR

log = logging.getLogger("podonote.mac_natif")

# Posé à côté du code : le lanceur y lit que le praticien a déjà accepté la
# réinstallation (pas de seconde question), et l'efface.
MARQUEUR = ".reinstallation-native"
# Python Intel mis de côté ; installer.py les supprime une fois le natif en place.
RESTES_INTEL = ("MacOS/python3.12-intel", "lib-intel")


def app_bundle() -> Optional[Path]:
    """Le Diktae.app dont le Python exécute ce code, ou None (poste de
    développement, Windows, lanceur Terminal…)."""
    exe = Path(sys.executable)
    if exe.parent.name != "MacOS" or exe.parent.parent.name != "Contents":
        return None
    app = exe.parent.parent.parent
    if app.suffix != ".app" or not (exe.parent / "Diktae").is_file():
        return None
    return app


def puce_apple() -> bool:
    """Processeur Apple (M1…M4), même si ce processus est traduit par Rosetta."""
    try:
        r = subprocess.run(["/usr/sbin/sysctl", "-n", "hw.optional.arm64"],
                           capture_output=True, text=True, timeout=5)
        return r.stdout.strip() == "1"
    except Exception:
        return False


def rafraichir_bundle(app: Path, source: Path = BASE_DIR / "installer" / "mac") -> list[str]:
    """Recopie le lanceur et installer.py de cette version dans l'app, s'ils
    diffèrent. Renvoie les fichiers remplacés. Jamais bloquant."""
    remplaces = []
    for nom, dest, mode in (
        ("Diktae", app / "Contents" / "MacOS" / "Diktae", 0o755),
        ("installer.py", app / "Contents" / "Resources" / "installer.py", 0o644),
    ):
        src = source / nom
        try:
            if not src.is_file():
                continue
            donnees = src.read_bytes()
            if dest.is_file() and dest.read_bytes() == donnees:
                continue
            tmp = dest.with_name(dest.name + ".nouveau")
            tmp.write_bytes(donnees)
            tmp.chmod(mode)
            os.replace(tmp, dest)  # atomique : jamais de lanceur à moitié écrit
            remplaces.append(nom)
        except OSError:
            log.exception("Mise à jour de %s dans l'app impossible (non bloquant).", nom)
    if remplaces:
        log.info("App Mac : %s mis à jour depuis la version installée.", ", ".join(remplaces))
    return remplaces


def doit_repasser_en_natif() -> Optional[Path]:
    """L'app tourne-t-elle avec son Python Intel sur une puce Apple ? Renvoie
    alors le Diktae.app concerné."""
    if sys.platform != "darwin" or platform.machine() != "x86_64":
        return None
    app = app_bundle()
    if app is None or not puce_apple():
        return None
    return app


def preparer_reinstallation(app: Path, root: Path = BASE_DIR) -> None:
    """Met le Python Intel de côté : au prochain lancement, le lanceur ne le
    trouve plus et installe le Python natif, sans reposer la question."""
    contents = app / "Contents"
    for rel in ("MacOS/python3.12", "lib"):
        actuel = contents / rel
        cote = contents / f"{rel}-intel"
        if cote.is_dir() and not cote.is_symlink():
            shutil.rmtree(cote, ignore_errors=True)
        elif cote.exists() or cote.is_symlink():
            cote.unlink()
        if actuel.exists() or actuel.is_symlink():
            os.rename(actuel, cote)
    try:
        (root / ".installation-ok").unlink()
    except FileNotFoundError:
        pass
    (root / MARQUEUR).write_text("1", encoding="utf-8")
    log.info("Python Intel mis de côté dans %s : réinstallation native au prochain lancement.", app)


def rouvrir(app: Path) -> None:
    """Rouvre l'app une fois ce processus terminé (détaché)."""
    subprocess.Popen(
        ["/bin/sh", "-c", 'sleep 2; exec /usr/bin/open -n "$0"', str(app)],
        start_new_session=True, stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True,
    )


QUESTION = (
    "Diktae doit se réinstaller pour votre Mac.\n\n"
    "Il a été installé en mode Intel (Rosetta), ce qui empêche la transcription "
    "de fonctionner sur les Mac à puce Apple.\n\n"
    "La réinstallation se fait toute seule : comptez 20 à 40 minutes, connecté à "
    "Internet. Vos patients, consultations et réglages sont conservés."
)


def demander() -> bool:
    """Accord du praticien (Réinstaller / Plus tard)."""
    script = (
        "on run argv\n"
        "  activate\n"
        '  button returned of (display dialog (item 1 of argv) buttons {"Plus tard", "Réinstaller"} '
        'default button "Réinstaller" with title "Diktae" with icon note)\n'
        "end run"
    )
    try:
        r = subprocess.run(["/usr/bin/osascript", "-", QUESTION], input=script,
                           capture_output=True, text=True, timeout=600)
        return r.stdout.strip() == "Réinstaller"
    except Exception:
        log.exception("Question de réinstallation native impossible.")
        return False
