#!/usr/bin/env python3
"""Installation de Diktae sur Mac : fenêtre de progression, sans Terminal.

Lancé par le lanceur de Diktae.app (`installer/mac/Diktae`) au premier
démarrage, avec le Python autonome rangé DANS l'app. Tout s'installe dans ce
Python, sans `.venv` : l'app EST l'environnement (le lanceur dit pourquoi :
identité macOS et autorisation du micro). Le code de Diktae va dans
~/Library/Application Support/Diktae/app ; les mises à jour OTA l'y remplacent,
et `data/` comme `.env` n'y sont jamais écrasés.

Étapes : code (dernière Release OTA, empreinte vérifiée) → composants de base
(requirements.txt + ffmpeg) → IA (scripts/install_ml_mac.sh) → réglages (.env,
ffmpeg/ffprobe, relais .venv) → modèles (scripts/warmup_models.py) → contrôle
(import de l'app). Sans tkinter, la même suite tourne avec des notifications.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import queue
import shutil
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

MANIFEST_URL = ("https://github.com/morganmargerit19/podonote-updates/releases/"
                "latest/download/manifest.json")
# Le 8000 est souvent pris par un autre serveur local (ex. un projet PHP) :
# la fenêtre afficherait alors un autre site.
PORT = "8765"
IMAGEIO_FFMPEG = "imageio-ffmpeg==0.6.0"   # ffmpeg 7.1 pour Mac Apple Silicon et Intel
IS_MAC = sys.platform == "darwin"

# Libellé, durée annoncée, poids dans la barre de progression.
ETAPES = (
    ("Télécharger Diktae", "≈ 1 min", 1),
    ("Composants de base", "≈ 3 min", 3),
    ("Composants d’intelligence artificielle", "≈ 10 min", 10),
    ("Réglages", "quelques secondes", 0.3),
    ("Modèles de transcription (≈ 3 Go)", "≈ 10 min", 8),
    ("Vérification", "≈ 30 s", 0.7),
)

# ffprobe de secours : Diktae ne lui demande que la DURÉE d'un enregistrement
# (décompte des minutes de la licence démo, app/pipeline/runner.py). PyAV,
# installé avec faster-whisper, la lit sans binaire supplémentaire.
FFPROBE_PY = r'''
import sys
try:
    import av
    with av.open(sys.argv[-1]) as c:
        if c.duration:
            print(c.duration / av.time_base)
        else:
            s = c.streams.audio[0]
            fin = 0
            for p in c.demux(s):
                if p.pts is not None:
                    fin = max(fin, p.pts + (p.duration or 0))
            print(float(fin * s.time_base))
except Exception:
    sys.exit(1)
'''


class Echec(Exception):
    """Étape en échec, avec un conseil lisible par le praticien."""

    def __init__(self, message: str, conseil: str = "Vérifiez la connexion Internet, puis réessayez."):
        super().__init__(message)
        self.conseil = conseil


def _b64u(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _contexte_ssl() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    # Le Python autonome ne connaît pas forcément le magasin de certificats du
    # Mac : on lui donne celui du système.
    for ca in ("/etc/ssl/cert.pem", "/private/etc/ssl/cert.pem"):
        if os.path.exists(ca):
            try:
                ctx.load_verify_locations(cafile=ca)
                break
            except (OSError, ssl.SSLError):
                pass
    return ctx


class Installation:
    """Enchaîne les étapes ; `emettre(type, **données)` informe l'interface."""

    def __init__(self, app: Path, root: Path, journal: Path, emettre,
                 manifest_url: str = MANIFEST_URL, sauter: bool = False):
        self.app = app
        self.contents = app / "Contents"
        self.py = str(self.contents / "MacOS" / "python3.12")
        self.root = root
        self.journal = journal
        self.emettre = emettre
        self.manifest_url = manifest_url
        self.sauter = sauter          # tests : ni pip, ni IA, ni modèles
        self.version = ""
        self.proc: subprocess.Popen | None = None
        self.annule = False

    # --- outils -------------------------------------------------------------
    def log(self, texte: str) -> None:
        self.journal.parent.mkdir(parents=True, exist_ok=True)
        with self.journal.open("a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%H:%M:%S')}] {texte}\n")

    def _env(self) -> dict:
        env = dict(os.environ)
        env.update(PIP_DISABLE_PIP_VERSION_CHECK="1", PIP_NO_INPUT="1",
                   PIP_TIMEOUT="120", PIP_RETRIES="5", PYTHONUNBUFFERED="1")
        return env

    def lancer(self, cmd: list[str], cwd: Path | None = None) -> str:
        """Commande dont la sortie va au journal ; la dernière ligne s'affiche."""
        self.log("$ " + " ".join(cmd))
        sortie: list[str] = []
        self.proc = subprocess.Popen(
            cmd, cwd=str(cwd) if cwd else None, env=self._env(),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
        )
        assert self.proc.stdout is not None
        for ligne in self.proc.stdout:
            ligne = ligne.rstrip()
            if ligne:
                sortie.append(ligne)
                self.log(ligne)
                self.emettre("ligne", texte=ligne)
        code = self.proc.wait()
        self.proc = None
        if self.annule:
            raise Echec("Installation interrompue.", "Rouvrez Diktae pour la reprendre.")
        if code != 0:
            raise Echec(f"Commande en échec (code {code}).")
        return "\n".join(sortie[-5:])

    def lire(self, url: str) -> bytes:
        with urllib.request.urlopen(url, timeout=60, context=_contexte_ssl()) as r:
            return r.read()

    def telecharger(self, url: str, dest: Path) -> None:
        with urllib.request.urlopen(url, timeout=60, context=_contexte_ssl()) as r, \
                dest.open("wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            recu = 0
            while True:
                bloc = r.read(1 << 16)
                if not bloc:
                    break
                f.write(bloc)
                recu += len(bloc)
                if total:
                    self.emettre("ligne", texte=f"Téléchargement : {recu / 1e6:.1f} / {total / 1e6:.1f} Mo")

    def pip(self, *args: str) -> None:
        self.lancer([self.py, "-m", "pip", *args])

    # --- étapes -------------------------------------------------------------
    def etape_code(self) -> None:
        try:
            obj = json.loads(self.lire(self.manifest_url))
            payload = json.loads(_b64u(obj["payload"]))
            url, attendu = payload["url"], str(payload["sha256"]).lower()
            self.version = str(payload.get("version") or "")
        except Echec:
            raise
        except Exception as exc:
            self.log(f"Manifest illisible : {exc!r}")
            raise Echec("Impossible de joindre le serveur de Diktae.") from exc
        self.log(f"Diktae {self.version} : {url}")
        with tempfile.TemporaryDirectory() as tmp:
            z = Path(tmp) / "diktae.zip"
            try:
                self.telecharger(url, z)
            except Exception as exc:
                self.log(f"Téléchargement en échec : {exc!r}")
                raise Echec("Téléchargement de Diktae impossible.") from exc
            obtenu = hashlib.sha256(z.read_bytes()).hexdigest()
            if obtenu != attendu:
                self.log(f"Empreinte {obtenu}, attendu {attendu}")
                raise Echec("Téléchargement de Diktae incomplet.")
            extrait = Path(tmp) / "x"
            with zipfile.ZipFile(z) as zf:
                zf.extractall(extrait)
            # Du code seulement : les données et réglages d'une installation
            # précédente restent intacts.
            self.root.mkdir(parents=True, exist_ok=True)
            for item in extrait.iterdir():
                if item.name in ("data", ".env", ".venv"):
                    continue
                dest = self.root / item.name
                if item.is_dir():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, dest)

    def etape_base(self) -> None:
        if self.sauter:
            return
        self.pip("install", "-r", str(self.root / "requirements.txt"))
        self.pip("install", IMAGEIO_FFMPEG)

    def etape_ia(self) -> None:
        if self.sauter:
            return
        self.lancer(["/bin/bash", str(self.root / "scripts" / "install_ml_mac.sh"), self.py],
                    cwd=self.root)

    def etape_reglages(self) -> None:
        env = self.root / ".env"
        if not env.exists():
            shutil.copy2(self.root / ".env.example", env)
            outil = str(self.root / "scripts" / "_envtool.py")
            # Fiches via le proxy Studio Margerit : la licence du poste sert
            # d'accès, aucune clé à saisir (défaut du code depuis la 1.3.1).
            for cle, valeur in (("LLM_BACKEND", "sonnet"), ("PORT", PORT)):
                self.lancer([self.py, outil, "set", str(env), cle, valeur])

        dossier = self.contents / "Resources" / "ffmpeg"
        dossier.mkdir(parents=True, exist_ok=True)
        if not self.sauter:
            exe = self.lancer([self.py, "-c",
                               "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"])
            source = Path(exe.strip().splitlines()[-1])
            source.chmod(0o755)
            lien = dossier / "ffmpeg"
            if lien.is_symlink() or lien.exists():
                lien.unlink()
            lien.symlink_to(source)
        ffprobe = dossier / "ffprobe"
        ffprobe.write_text(
            "#!/bin/bash\n"
            "# ffprobe de secours de Diktae (Mac) : durée d'un fichier audio via PyAV.\n"
            'HERE="$(cd "$(dirname "$0")" && pwd)"\n'
            f"exec \"$HERE/../../MacOS/python3.12\" -c '{FFPROBE_PY}' \"$@\"\n",
            encoding="utf-8",
        )
        ffprobe.chmod(0o755)

        # Relais « .venv/bin/python » attendu par les mises à jour OTA.
        bin_dir = self.root / ".venv" / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        relais = bin_dir / "python"
        relais.write_text(f'#!/bin/bash\nexec "{self.py}" "$@"\n', encoding="utf-8")
        relais.chmod(0o755)
        lien3 = bin_dir / "python3"
        if lien3.is_symlink() or lien3.exists():
            lien3.unlink()
        lien3.symlink_to("python")

    def etape_modeles(self) -> None:
        if self.sauter:
            return
        self.lancer([self.py, str(self.root / "scripts" / "warmup_models.py")], cwd=self.root)

    def etape_controle(self) -> None:
        if self.sauter:
            return
        self.lancer([self.py, "-c", "import app.main; print('Diktae prêt.')"], cwd=self.root)

    def terminer(self) -> None:
        (self.root / ".installation-ok").write_text(json.dumps({
            "version": self.version, "app": str(self.app),
            "date": time.strftime("%Y-%m-%d %H:%M:%S"),
        }, ensure_ascii=False), encoding="utf-8")
        # Python Intel mis de côté par une réinstallation native (app/mac_natif.py).
        for reste in (self.contents / "MacOS" / "python3.12-intel", self.contents / "lib-intel"):
            if reste.is_dir() and not reste.is_symlink():
                shutil.rmtree(reste, ignore_errors=True)
            elif reste.exists() or reste.is_symlink():
                reste.unlink()
        if IS_MAC:
            # Plus jamais l'avertissement de Gatekeeper pour cette app.
            subprocess.run(["/usr/bin/xattr", "-dr", "com.apple.quarantine", str(self.app)],
                           capture_output=True)

    def executer(self, depuis: int = 0) -> bool:
        etapes = (self.etape_code, self.etape_base, self.etape_ia,
                  self.etape_reglages, self.etape_modeles, self.etape_controle)
        self.log(f"== Installation (étape {depuis + 1}) — app {self.app}")
        for i in range(depuis, len(etapes)):
            self.emettre("etape", index=i)
            try:
                etapes[i]()
            except Echec as exc:
                self.log(f"ÉCHEC étape {i + 1} : {exc}")
                self.emettre("echec", index=i, message=str(exc), conseil=exc.conseil)
                return False
            except Exception as exc:  # imprévu : on le journalise, on ne plante pas
                self.log(f"ÉCHEC étape {i + 1} : {exc!r}")
                self.emettre("echec", index=i, message="Erreur inattendue.",
                             conseil="Réessayez ; si cela se reproduit, envoyez le rapport au support Diktae.")
                return False
        self.terminer()
        self.log("== Installation terminée")
        self.emettre("fini")
        return True

    def interrompre(self) -> None:
        self.annule = True
        if self.proc is not None:
            try:
                self.proc.terminate()
            except OSError:
                pass

    def rapport_sur_bureau(self) -> Path | None:
        dest = Path.home() / "Desktop" / "Diktae-installation.txt"
        try:
            shutil.copy2(self.journal, dest)
            return dest
        except OSError:
            return None


# --------------------------------------------------------------------------- #
# Lancement de Diktae une fois installé
# --------------------------------------------------------------------------- #
_CAFEINE: subprocess.Popen | None = None


def ouvrir_diktae(inst: Installation) -> None:
    """Remplace ce processus par l'app : même bundle, donc même identité macOS."""
    if _CAFEINE is not None:
        # Il suit notre pid, que l'app va reprendre : sans cela, le Mac ne se
        # mettrait plus jamais en veille tant que Diktae reste ouvert.
        _CAFEINE.terminate()
    os.chdir(inst.root)
    os.execv(inst.py, [inst.py, "-m", "app.desktop"])


def osascript(script: str, *args: str) -> str:
    # DIKTAE_SANS_DIALOGUE : tests, aucune fenêtre ne doit bloquer.
    if not IS_MAC or os.environ.get("DIKTAE_SANS_DIALOGUE"):
        return ""
    r = subprocess.run(["/usr/bin/osascript", "-", *args], input=script,
                       capture_output=True, text=True)
    return r.stdout.strip()


def notifier(texte: str) -> None:
    osascript('on run argv\ndisplay notification (item 1 of argv) with title "Diktae"\nend run', texte)


# --------------------------------------------------------------------------- #
# Interface : fenêtre tkinter aux couleurs de Diktae
# --------------------------------------------------------------------------- #
FOND, ENCRE, ENCRE_2, ENCRE_3 = "#f5f4f0", "#1d1c1a", "#5b5854", "#78746d"
ACCENT, OK, ERREUR = "#8a5a36", "#1f8a5b", "#b42318"


class Fenetre:
    def __init__(self, inst: Installation):
        import tkinter as tk
        from tkinter import ttk

        self.tk, self.ttk = tk, ttk
        self.inst = inst
        self.file: queue.Queue = queue.Queue()
        inst.emettre = lambda type_, **d: self.file.put((type_, d))
        self.debut_etape = time.monotonic()
        self.courante = 0
        self.en_cours = False

        r = self.root = tk.Tk()
        r.title("Installation de Diktae")
        r.configure(bg=FOND, padx=28, pady=24)
        r.resizable(False, False)
        r.protocol("WM_DELETE_WINDOW", self.fermer)

        tete = tk.Frame(r, bg=FOND)
        tete.pack(fill="x")
        logo = inst.contents / "Resources" / "logo.png"
        if logo.exists():
            try:
                self.img = tk.PhotoImage(file=str(logo))
                tk.Label(tete, image=self.img, bg=FOND).pack(side="left", padx=(0, 14))
            except tk.TclError:
                pass
        textes = tk.Frame(tete, bg=FOND)
        textes.pack(side="left", fill="x")
        self.titre = tk.Label(textes, text="Installation de Diktae", bg=FOND, fg=ENCRE,
                              font=("Helvetica Neue", 20, "bold"), anchor="w")
        self.titre.pack(fill="x")
        self.sous_titre = tk.Label(
            textes, bg=FOND, fg=ENCRE_2, anchor="w", justify="left", wraplength=400,
            font=("Helvetica Neue", 13),
            text="Comptez 20 à 40 minutes. Vous pouvez utiliser votre Mac pendant ce temps.")
        self.sous_titre.pack(fill="x", pady=(2, 0))

        liste = tk.Frame(r, bg=FOND)
        liste.pack(fill="x", pady=(20, 8))
        self.lignes = []
        for libelle, duree, _poids in ETAPES:
            ligne = tk.Frame(liste, bg=FOND)
            ligne.pack(fill="x", pady=3)
            puce = tk.Label(ligne, text="○", width=2, bg=FOND, fg=ENCRE_3, font=("Helvetica Neue", 15))
            puce.pack(side="left")
            nom = tk.Label(ligne, text=libelle, bg=FOND, fg=ENCRE_3, anchor="w",
                           font=("Helvetica Neue", 14))
            nom.pack(side="left", fill="x", expand=True)
            tk.Label(ligne, text=duree, bg=FOND, fg=ENCRE_3, font=("Helvetica Neue", 12)).pack(side="right")
            self.lignes.append((puce, nom))

        style = ttk.Style(r)
        style.configure("Diktae.Horizontal.TProgressbar", troughcolor="#e9e6df", background=ACCENT)
        self.barre = ttk.Progressbar(r, style="Diktae.Horizontal.TProgressbar",
                                     orient="horizontal", length=480, mode="determinate", maximum=100)
        self.barre.pack(fill="x", pady=(10, 6))
        self.detail = tk.Label(r, text="", bg=FOND, fg=ENCRE_3, anchor="w",
                               font=("Menlo", 10), width=64)
        self.detail.pack(fill="x")

        self.boutons = tk.Frame(r, bg=FOND)
        self.boutons.pack(fill="x", pady=(18, 0))

        r.update_idletasks()
        largeur, hauteur = r.winfo_reqwidth(), r.winfo_reqheight()
        x = (r.winfo_screenwidth() - largeur) // 2
        y = max(40, (r.winfo_screenheight() - hauteur) // 3)
        r.geometry(f"+{x}+{y}")
        r.lift()
        r.attributes("-topmost", True)
        r.after(1500, lambda: r.attributes("-topmost", False))

    # --- boutons --------------------------------------------------------------
    def poser_boutons(self, *specs) -> None:
        for w in self.boutons.winfo_children():
            w.destroy()
        for texte, action, principal in reversed(specs):
            b = self.ttk.Button(self.boutons, text=texte, command=action,
                                default="active" if principal else "normal")
            b.pack(side="right", padx=(8, 0))
            if principal:
                self.root.bind("<Return>", lambda _e, a=action: a())

    # --- déroulé --------------------------------------------------------------
    def demarrer(self, depuis: int = 0) -> None:
        self.en_cours = True
        self.titre.config(text="Installation de Diktae", fg=ENCRE)
        self.sous_titre.config(fg=ENCRE_2,
                               text="Comptez 20 à 40 minutes. Vous pouvez utiliser votre Mac pendant ce temps.")
        self.poser_boutons(("Annuler", self.fermer, False))
        threading.Thread(target=self.inst.executer, args=(depuis,), daemon=True).start()
        self.root.after(150, self.ecouter)

    def progression(self) -> float:
        poids = [p for _l, _d, p in ETAPES]
        fait = sum(poids[: self.courante])
        # Avance douce dans l'étape en cours, plafonnée : la barre ne ment pas.
        ecoule = (time.monotonic() - self.debut_etape) / 60.0
        dans = min(poids[self.courante] * 0.9, ecoule * poids[self.courante] / max(poids[self.courante], 1))
        return 100.0 * (fait + dans) / sum(poids)

    def ecouter(self) -> None:
        try:
            while True:
                type_, d = self.file.get_nowait()
                if type_ == "etape":
                    self.marquer(d["index"])
                elif type_ == "ligne":
                    texte = d["texte"]
                    self.detail.config(text=texte if len(texte) <= 70 else texte[:67] + "…")
                elif type_ == "fini":
                    self.fini()
                    return
                elif type_ == "echec":
                    self.echec(d["index"], d["message"], d["conseil"])
                    return
        except queue.Empty:
            pass
        if self.en_cours:
            self.barre["value"] = self.progression()
            self.root.after(150, self.ecouter)

    def marquer(self, index: int) -> None:
        self.courante = index
        self.debut_etape = time.monotonic()
        for i, (puce, nom) in enumerate(self.lignes):
            if i < index:
                puce.config(text="✓", fg=OK)
                nom.config(fg=ENCRE)
            elif i == index:
                puce.config(text="●", fg=ACCENT)
                nom.config(fg=ENCRE, font=("Helvetica Neue", 14, "bold"))
            else:
                puce.config(text="○", fg=ENCRE_3)
                nom.config(fg=ENCRE_3, font=("Helvetica Neue", 14))

    def fini(self) -> None:
        self.en_cours = False
        for puce, nom in self.lignes:
            puce.config(text="✓", fg=OK)
            nom.config(fg=ENCRE, font=("Helvetica Neue", 14))
        self.barre["value"] = 100
        self.detail.config(text="")
        self.titre.config(text="Diktae est installé")
        self.sous_titre.config(text="La prochaine fois, ouvrez simplement Diktae depuis le dossier Applications.")
        self.poser_boutons(("Ouvrir Diktae", self.ouvrir, True))

    def echec(self, index: int, message: str, conseil: str) -> None:
        self.en_cours = False
        self.detail.config(text="")
        puce, nom = self.lignes[index]
        puce.config(text="✕", fg=ERREUR)
        nom.config(fg=ERREUR)
        rapport = self.inst.rapport_sur_bureau()
        suite = (" Si cela se reproduit, envoyez au support Diktae le fichier "
                 "« Diktae-installation.txt » posé sur votre Bureau.") if rapport else ""
        self.titre.config(text="L’installation s’est arrêtée", fg=ERREUR)
        self.sous_titre.config(fg=ENCRE_2, text=f"{message} {conseil}{suite}")
        self.poser_boutons(("Fermer", self.root.destroy, False),
                           ("Réessayer", lambda: self.reprendre(index), True))

    def reprendre(self, index: int) -> None:
        self.inst.annule = False
        self.demarrer(index)

    def ouvrir(self) -> None:
        self.root.destroy()
        ouvrir_diktae(self.inst)

    def fermer(self) -> None:
        if self.en_cours:
            from tkinter import messagebox
            if not messagebox.askyesno(
                    "Interrompre l’installation ?",
                    "Diktae n’est pas encore installé. Vous pourrez reprendre en rouvrant Diktae.",
                    icon="warning", parent=self.root):
                return
            self.inst.interrompre()
        self.root.destroy()

    def boucle(self) -> None:
        self.demarrer(0)
        self.root.mainloop()


# --------------------------------------------------------------------------- #
# Sans interface (tkinter indisponible, ou tests)
# --------------------------------------------------------------------------- #
def sans_interface(inst: Installation, lancer_app: bool) -> int:
    def emettre(type_, **d):
        if type_ == "etape":
            libelle = ETAPES[d["index"]][0]
            print(f"[{d['index'] + 1}/{len(ETAPES)}] {libelle}", flush=True)
            notifier(f"Installation : {libelle} ({d['index'] + 1}/{len(ETAPES)})")
        elif type_ == "echec":
            print(f"ÉCHEC : {d['message']} {d['conseil']}", flush=True)

    inst.emettre = emettre
    if not inst.executer(0):
        inst.rapport_sur_bureau()
        osascript('on run argv\nactivate\ndisplay alert (item 1 of argv) '
                  'message (item 2 of argv) as critical\nend run',
                  "L’installation de Diktae s’est arrêtée",
                  "Rouvrez Diktae pour réessayer. Un rapport « Diktae-installation.txt » est sur votre Bureau.")
        return 1
    if lancer_app:
        ouvrir_diktae(inst)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--app", required=True, type=Path, help="chemin de Diktae.app")
    ap.add_argument("--root", required=True, type=Path, help="dossier du code de Diktae")
    ap.add_argument("--journal", required=True, type=Path)
    ap.add_argument("--manifest-url", default=MANIFEST_URL)
    ap.add_argument("--sans-interface", action="store_true")
    ap.add_argument("--sauter-installations", action="store_true",
                    help="tests : ni pip, ni IA, ni modèles, ni contrôle")
    ap.add_argument("--ne-pas-lancer", action="store_true", help="tests : ne pas ouvrir Diktae à la fin")
    args = ap.parse_args()

    inst = Installation(args.app.resolve(), args.root, args.journal, lambda *_a, **_k: None,
                        manifest_url=args.manifest_url, sauter=args.sauter_installations)
    if IS_MAC:
        # Pas de mise en veille pendant l'installation (≈ 30 min).
        global _CAFEINE
        _CAFEINE = subprocess.Popen(["/usr/bin/caffeinate", "-i", "-w", str(os.getpid())],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not args.sans_interface:
        try:
            fenetre = Fenetre(inst)
        except Exception as exc:  # tkinter absent ou Tcl introuvable
            inst.log(f"Fenêtre impossible, suite sans interface : {exc!r}")
        else:
            fenetre.boucle()
            return 0
    return sans_interface(inst, lancer_app=not args.ne_pas_lancer)


if __name__ == "__main__":
    sys.exit(main())
